<?php 
    include "model.php";

    $model = new model();
    $model->cn();
    $logs = [];
    
    if (isset($_POST["usersearch"])){
        $usersearch = $_POST["usersearch"];
    }    
    else {
        $usersearch = NULL;
    }

    if (isset($_POST["rolesearch"])){
        $rolesearch = $_POST["rolesearch"];
    }    
    else {
        $rolesearch = NULL;
    }

    $cus = NULL;
    $userData = NULL;
    $userDataD = NULL;
    $Deleted = NULL;

    $pdo = new PDO("mysql:host=localhost;dbname=eurotechdb", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        if (isset($_POST['confirmI'])) {
            $stmt = $pdo->prepare("SELECT Username FROM users WHERE Username = ?");
            $stmt->execute([
                $_POST['Username']
            ]);
            $user = $stmt->fetchAll(PDO::FETCH_COLUMN);


            if($user == NULL) {
                $stmt = $pdo->prepare("INSERT INTO users (Username, `Password`, `Role`) 
                                                            VALUES (?, ?, ?)");
                $stmt->execute([
                    $_POST['Username'],
                    $_POST['Password'],
                    $_POST['Role']
                ]);
            }
            else {
                $_POST['insert'] = 1;
                $error = "Username <b>".$_POST['Username']."</b> already exists.";
            }

            $_SESSION['saved'] = true;
        }

        if (isset($_POST['edit'])) {
            $id = $_POST['IDedit'];
            $stmt = $pdo->prepare("SELECT ID, Username, `Password`, `Role` FROM users WHERE ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $userData = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmU'])) {
            $stmt = $pdo->prepare("SELECT Username FROM users WHERE Username = ? AND ID != ?");
            $stmt->execute([
                $_POST['Username'],
                $_POST['ID']
            ]);
            $user = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($user != NULL) {
                $_POST['edit'] = 1;
                $error = "Username <b>".$_POST['Username']."</b> already exists.";
            }
            if(!isset($error)) {
                $stmt = $pdo->prepare("UPDATE users SET 
                                                Username = ?, 
                                                `Password` = ?,
                                                `Role` = ?
                                            WHERE ID = ?");
                $stmt->execute([
                    $_POST['Username'],
                    $_POST['Password'],
                    $_POST['Role'],
                    $_POST['ID']
                ]);
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['delete'])) {
            $id = $_POST['IDdelete'];
            $stmt = $pdo->prepare("SELECT * FROM users WHERE ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $userDataD = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmD'])) {
            $id = $_POST['ID'];

            $stmt = $pdo->prepare("DELETE FROM users
                                        WHERE ID = ?");

            $stmt->execute([$id]);
            
            $Deleted = 'Y';

            $_SESSION['saved'] = true;
        }
    }
    
    
    $Usernames = $model->searchUsernames();
    $Roles = $model->searchRoles();
    $logs = $model->search();

    include 'view.php';
?>