<?php 
    include "model.php";

    $model = new model();
    $model->cn();
    $logs = [];
    
    if (isset($_POST["idsearch"])){
        $idsearch = $_POST["idsearch"];
    }    
    else {
        $idsearch = NULL;
    }

    if (isset($_POST["custsearch"])){
        $custsearch = $_POST["custsearch"];
    }    
    else {
        $custsearch = NULL;
    }

    if (isset($_POST["counsearch"])){
        $counsearch = $_POST["counsearch"];
    }    
    else {
        $counsearch = NULL;
    }

    if (isset($_POST["ppapsearch"])){
        $ppapsearch = $_POST["ppapsearch"];
    }    
    else {
        $ppapsearch = NULL;
    }

    if (isset($_POST["imdssearch"])){
        $imdssearch = $_POST["imdssearch"];
    }    
    else {
        $imdssearch = NULL;
    }

    if (isset($_POST["bssearch"])){
        $bssearch = $_POST["bssearch"];
    }    
    else {
        $bssearch = "";
    } 

    if (isset($_POST["cabsearch"])){
        $cabsearch = $_POST["cabsearch"];
    }    
    else {
        $cabsearch = "";
    } 

    if (isset($_POST["tapsearch"])){
        $tapsearch = $_POST["tapsearch"];
    }    
    else {
        $tapsearch = "";
    } 

    if (isset($_POST["tubsearch"])){
        $tubsearch = $_POST["tubsearch"];
    }    
    else {
        $tubsearch = "";
    } 

    $Products = $model->searchProducts();
    $cus = NULL;
    $customerData = NULL;
    $customerDataD = NULL;
    $Deleted = NULL;

    $pdo = new PDO("mysql:host=localhost;dbname=eurotechdb", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        if (isset($_POST['confirmI'])) {
            $length = strlen($_POST['Customer_ID']);
            if($length >= 3) {
                $cus = $_POST['Customer_ID'][0].''.$_POST['Customer_ID'][1].''.$_POST['Customer_ID'][2];
            }
            else {
                $cus = NULL;
            }
            if($cus == 'CUS') {
                $ID = explode("CUS", $_POST['Customer_ID']);
                $ID_number = $ID[1];
                if (ctype_digit($ID_number)) {
                    if($_POST['Country'] != "") {
                        $stmt = $pdo->prepare("SELECT `Name`, Country FROM customers WHERE `Name` = ? AND Country = ?");
                        $stmt->execute([
                            $_POST['Name'],
                            $_POST['Country']
                        ]);
                        $custexist = $stmt->fetchAll(PDO::FETCH_COLUMN);
                    }
                    else {
                        $stmt = $pdo->prepare("SELECT `Name`, Country FROM customers WHERE `Name` = ? AND Country IS NULL");
                        $stmt->execute([
                            $_POST['Name']
                        ]);
                        $custexist = $stmt->fetchAll(PDO::FETCH_COLUMN);
                    }

                    if(!empty($_POST['Customer_PPAP_Number'])) {
                        if(isset($_POST['Customer_PPAP_Number'][6])) {
                            $PP = $_POST['Customer_PPAP_Number'][0].''.$_POST['Customer_PPAP_Number'][1];
                            if($PP == 'PP') {
                                $ID = explode("PP", $_POST['Customer_PPAP_Number']);
                                $ID_number = explode("-", $ID[1]);
                                if(ctype_digit($ID_number[0])) {
                                    $stmt = $pdo->prepare("SELECT Customer_PPAP_Number FROM customers WHERE Customer_PPAP_Number = ?");
                                    $stmt->execute([
                                        $_POST['Customer_PPAP_Number']
                                    ]);
                                    $ppapexist = $stmt->fetchAll(PDO::FETCH_COLUMN);
                                }
                                else {
                                    $_POST['insert'] = 1;
                                    $ppapexist = NULL;
                                    $error = "Customer PPAP Number must have the form 'PP00000'.";
                                }
                            }
                            else {
                                $_POST['insert'] = 1;
                                $ppapexist = NULL;
                                $error = "Customer PPAP Number must have the form 'PP00000'.";
                            }
                        }
                        else {
                            $_POST['insert'] = 1;
                            $ppapexist = NULL;
                            $error = "Customer PPAP Number must have the form 'PP00000'.";
                        }                
                    }

                    if($_POST['Customer_PPAP_Number'] == "") {
                        $ppapexist = NULL;
                        $_POST['Customer_PPAP_Number'] = NULL;
                    }
                    
                    if($_POST['IMDS_ID_no'] == "") {
                        $_POST['IMDS_ID_no'] = NULL;
                    }

                    if($_POST['Country'] == "") {
                        $_POST['Country'] = NULL;
                    }

                    if($custexist != NULL) {
                        $_POST['insert'] = 1;
                        if($_POST['Country'] != NULL) {
                            $error = "The customer <b>".$_POST['Name']."</b> - <b>".$_POST['Country']."</b> already exists.";
                        }
                        else {
                            $error = "The customer <b>".$_POST['Name']."</b> already exists.";
                        }
                    }
                    if($ppapexist != NULL) {
                        $_POST['insert'] = 1;
                        $error = "The Customer PPAP Number <b>".$_POST['Customer_PPAP_Number']."</b> already exists.";
                    }
                    if(!isset($error)) {
                        $prods_array = [];
                        foreach($Products as $Prod) {
                            if(isset($_POST[$Prod]) && $_POST[$Prod] != NULL) {
                                $prods_array[] = $_POST[$Prod];
                            }
                        }

                        $prods = implode(', ', $prods_array);

                        if($prods != "") {
                            $stmt = $pdo->prepare("INSERT INTO customers (Customer_ID, `Name`, Country, Customer_PPAP_Number, IMDS_ID_no, Products) 
                                                            VALUES (?, ?, ?, ?, ?, ?)");
                            $stmt->execute([
                                $_POST['Customer_ID'],
                                $_POST['Name'],
                                $_POST['Country'],
                                $_POST['Customer_PPAP_Number'],
                                $_POST['IMDS_ID_no'],
                                $prods
                            ]);
                        }
                        else {
                            $_POST['insert'] = 1;
                            $error = "You should select at least 1 product for the customer.";
                        }
                    }
                } else {
                    $_POST['insert'] = 1;
                    $error = "Customer ID must contain only numbers after 'CUS'.";
                }
            }
            else {
                $_POST['insert'] = 1;
                $error = "Customer ID must start with 'CUS'.";
            }

            $_SESSION['saved'] = true;
        }

        if (isset($_POST['edit'])) {
            $id = $_POST['IDedit'];
            $stmt = $pdo->prepare("SELECT * FROM customers WHERE C_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $customerData = $stmt->fetch(PDO::FETCH_ASSOC);
            }

            $stmt = $pdo->prepare("SELECT Products FROM customers WHERE C_ID = ?");
            $stmt->execute([$id]);
            $productsData = $stmt->fetch(PDO::FETCH_ASSOC);
        }

        if (isset($_POST['confirmU'])) {
            $id = $_POST['C_ID'];

            $length = strlen($_POST['Customer_ID']);
            if($length >= 3) {
                $cus = $_POST['Customer_ID'][0].''.$_POST['Customer_ID'][1].''.$_POST['Customer_ID'][2];
            }
            else {
                $cus = NULL;
            }
            if($cus == 'CUS') {
                $ID = explode("CUS", $_POST['Customer_ID']);
                $ID_number = $ID[1];
                if (ctype_digit($ID_number)) {
                    if($_POST['Country'] != "") {
                        $stmt = $pdo->prepare("SELECT `Name`, Country FROM customers WHERE `Name` = ? AND Country = ? AND C_ID != ?");
                        $stmt->execute([
                            $_POST['Name'],
                            $_POST['Country'],
                            $id
                        ]);
                        $custexist = $stmt->fetchAll(PDO::FETCH_COLUMN);
                    }
                    else {
                        $stmt = $pdo->prepare("SELECT `Name`, Country FROM customers WHERE `Name` = ? AND Country IS NULL AND C_ID != ?");
                        $stmt->execute([
                            $_POST['Name'],
                            $id
                        ]);
                        $custexist = $stmt->fetchAll(PDO::FETCH_COLUMN);
                    }

                    if(!empty($_POST['Customer_PPAP_Number'])) {
                        if(isset($_POST['Customer_PPAP_Number'][6])) {
                            $PP = $_POST['Customer_PPAP_Number'][0].''.$_POST['Customer_PPAP_Number'][1];
                            if($PP == 'PP') {
                                $ID = explode("PP", $_POST['Customer_PPAP_Number']);
                                $ID_number = explode("-", $ID[1]);
                                if(ctype_digit($ID_number[0])) {
                                    $stmt = $pdo->prepare("SELECT Customer_PPAP_Number FROM customers WHERE Customer_PPAP_Number = ? AND C_ID != ?");
                                    $stmt->execute([
                                        $_POST['Customer_PPAP_Number'],
                                        $id
                                    ]);
                                    $ppapexist = $stmt->fetchAll(PDO::FETCH_COLUMN);
                                }
                                else {
                                    $_POST['edit'] = 1;
                                    $ppapexist = NULL;
                                    $error = "Customer PPAP Number must have the form 'PP00000'.";
                                }
                            }
                            else {
                                $_POST['edit'] = 1;
                                $ppapexist = NULL;
                                $error = "Customer PPAP Number must have the form 'PP00000'.";
                            }
                        }
                        else {
                            $_POST['edit'] = 1;
                            $ppapexist = NULL;
                            $error = "Customer PPAP Number must have the form 'PP00000'.";
                        }                
                    }

                    if($_POST['Customer_PPAP_Number'] == "") {
                        $ppapexist = NULL;
                        $_POST['Customer_PPAP_Number'] = NULL;
                    }
                    
                    if($_POST['IMDS_ID_no'] == "") {
                        $_POST['IMDS_ID_no'] = NULL;
                    }

                    if($_POST['Country'] == "") {
                        $_POST['Country'] = NULL;
                    }

                    if($custexist != NULL) {
                        $_POST['edit'] = 1;
                        if($_POST['Country'] != NULL) {
                            $error = "The customer <b>".$_POST['Name']."</b> - <b>".$_POST['Country']."</b> already exists.";
                        }
                        else {
                            $error = "The customer <b>".$_POST['Name']."</b> already exists.";
                        }
                    }
                    if($ppapexist != NULL) {
                        $_POST['edit'] = 1;
                        $error = "The Customer PPAP Number <b>".$_POST['Customer_PPAP_Number']."</b> already exists.";
                    }
                    if(!isset($error)) {
                        $prods_array = [];
                        foreach($Products as $Prod) {
                            if(isset($_POST[$Prod]) && $_POST[$Prod] != NULL) {
                                $prods_array[] = $_POST[$Prod];
                            }
                        }

                        $prods = implode(', ', $prods_array);

                        if($prods != "") {
                            $stmt = $pdo->prepare("UPDATE customers SET 
                                                        `Name` = ?, 
                                                        Products = ?,
                                                        Country = ?,
                                                        Customer_PPAP_Number = ?,
                                                        IMDS_ID_no = ?,
                                                        Customer_ID = ?
                                                    WHERE C_ID = ?");
                            $stmt->execute([
                                $_POST['Name'],
                                $prods,
                                $_POST['Country'],
                                $_POST['Customer_PPAP_Number'],
                                $_POST['IMDS_ID_no'],
                                $_POST['Customer_ID'],
                                $id
                            ]);
                        }
                        else {
                            $_POST['edit'] = 1;
                            $error = "You should select at least 1 product for the customer.";
                        }
                    }
                } else {
                    $_POST['edit'] = 1;
                    $error = "Customer ID must contain only numbers after 'CUS'.";
                }
            }
            else {
                $_POST['edit'] = 1;
                $error = "Customer ID must start with 'CUS'.";
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['delete'])) {
            $id = $_POST['IDdelete'];
            $stmt = $pdo->prepare("SELECT * FROM customers WHERE C_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $customerDataD = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmD'])) {
            $id = $_POST['C_ID'];
            $stmt = $pdo->prepare("SELECT Customer_ID FROM customers c
                                        INNER JOIN customer_pn cpn ON c.C_ID = cpn.FK_Customer_ID
                                    WHERE C_ID = ?");
            $stmt->execute([$id]);
            $cpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($cpn == NULL) {
                $stmt = $pdo->prepare("DELETE FROM customers
                                        WHERE C_ID = ?");

                $stmt->execute([$id]);
            
                $Deleted = 'Y';
            }
            else {
                $_POST['delete'] = 1;
                $error = "This customer can't be deleted, because it already has registers.";

                $stmt = $pdo->prepare("SELECT * FROM customers WHERE C_ID = ?");
                $stmt->execute([$id]);

                if ($stmt->rowCount() > 0) {
                    $customerDataD = $stmt->fetch(PDO::FETCH_ASSOC);
                }
            }

            $_SESSION['saved'] = true;
        }
    }
    
    
    $IDs = $model->searchIDs();
    $Customers = $model->searchCustomers();
    $Countries = $model->searchCountries();
    $PPAPNumbers = $model->searchPPAPNumbers();
    $IMDSs = $model->searchIMDS();
    $logs = $model->search();

    include 'view.php';
?>