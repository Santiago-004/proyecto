<?php
    class model {                                        

        public  $mbd;
        
        function cn() {
            $this->mbd = new PDO('mysql:host=localhost;dbname=eurotechdb;port=3306', 'root', '');
            $this->mbd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
        }
    
        function search(){
            $logs = [];
            if (isset($_POST['btnsearch'])) {
                if (isset($_POST['submit1search']) || isset($_POST['submit2search']) || isset($_POST['ppapnsearch']) ||
                    isset($_POST['req1search']) || isset($_POST['req2search']) || isset($_POST['pisearch']) || isset($_POST['custsearch']))
                    {
                    $having = [];
                    $params = [];

                    if(empty($_POST['submit1search']) || empty($_POST['submit2search'])) {
                        $having[] = "1 = 1";
                    }
                    if(!empty($_POST['submit1search']) && !empty($_POST['submit2search'])) {
                        $having[] = "`Days to Submit` BETWEEN :sub1 AND :sub2";
                        $params[':sub1'] = $_POST['submit1search'];
                        $params[':sub2'] = $_POST['submit2search'];
                    }

                    if (!empty($_POST['ppapnsearch'])) {
                        $having[] = "PPAP_Number = :ppapn";
                        $params[':ppapn'] = $_POST['ppapnsearch'];
                    }

                    if(!empty($_POST['req1search']) && !empty($_POST['req2search'])) {
                        $having[] = "PPAP_Req_by_Cus_Date BETWEEN :req1 AND :req2";
                        $params[':req1'] = $_POST['req1search'];
                        $params[':req2'] = $_POST['req2search'];
                    }

                    if (!empty($_POST['currentsearch'])) {
                        $having[] = "Current_Status = :current";
                        $params[':current'] = $_POST['currentsearch'];
                    }

                    if (!empty($_POST['pisearch'])) {
                        $having[] = "Vendor = :pi";
                        $params[':pi'] = $_POST['pisearch'];
                    }

                    if (!empty($_POST['custsearch'])) {
                        $having[] = "`Name` = :cust";
                        $params[':cust'] = $_POST['custsearch'];
                    }

                    $sql = "
                        SELECT 
                            if(Sent_Customer IS NULL, datediff(NOW(), PPAP_Req_by_Cus_Date), datediff(Sent_Customer, PPAP_Req_by_Cus_Date)) AS 'Days to Submit',
                            tp.PPAP_Number,
                            tps.PPAP_Req_by_Cus_Date,
                            tps.Current_Status,
                            tp.Vendor,
                            tc.`Name`,
                            tcc.Country,
                            tcp.TUB_Customer_PN,
                            t.ET_Model,
                            t.ET_Dwg,
                            tps.Rev,
                            t.Eurotech_PN_TUB,
                            t.`Description`,
                            tps.IMDS_Number,
                            tps.IMDS_Status,
                            tps.PPAP_do,
                            tps.`Level`,
                            tps.Samples_Status,
                            tps.Reason_submission,
                            tps.Sent_Customer,
                            tps.PSW_Returned,
                            tps.Origin_from_report,
                            tps.Comments,
                            tps.Inspection_rep_numb
                        FROM tubes_ppaps tps
                            INNER JOIN tubes_ppap tp ON tps.FK_PPAP_Number = tp.PPAP_Number
                            INNER JOIN tubes_customer_pn tcp ON tps.FK_TUB_Customer_PN = tcp.TUB_Customer_PN
                            INNER JOIN tubes_customers tc ON tp.FK_ID_TUB_Customer = tc.ID_TUB_Customer
                            INNER JOIN `tubes_customer-country` tcc ON tp.`FK_TUB_Customer-Country` = tcc.`TUB_Customer-Country`
                            INNER JOIN tubes t ON tcp.FK_Eurotech_PN_TUB = t.Eurotech_PN_TUB
                        HAVING " . implode(' AND ', $having) . "
                        ORDER BY PPAP_Number;";

                    $stmt = $this->mbd->prepare($sql);
                    $stmt->execute($params);

                    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
            } else {
                foreach ($this->mbd->query(
                    "SELECT 
                        if(Sent_Customer IS NULL, datediff(NOW(), PPAP_Req_by_Cus_Date), datediff(Sent_Customer, PPAP_Req_by_Cus_Date)) AS 'Days to Submit',
                        tp.PPAP_Number,
                        tps.PPAP_Req_by_Cus_Date,
                        tps.Current_Status,
                        tp.Vendor,
                        tc.`Name`,
                        tcc.Country,
                        tcp.TUB_Customer_PN,
                        t.ET_Model,
                        t.ET_Dwg,
                        tps.Rev,
                        t.Eurotech_PN_TUB,
                        t.`Description`,
                        tps.IMDS_Number,
                        tps.IMDS_Status,
                        tps.PPAP_do,
                        tps.`Level`,
                        tps.Samples_Status,
                        tps.Reason_submission,
                        tps.Sent_Customer,
                        tps.PSW_Returned,
                        tps.Origin_from_report,
                        tps.Comments,
                        tps.Inspection_rep_numb
                    FROM tubes_ppaps tps
                        INNER JOIN tubes_ppap tp ON tps.FK_PPAP_Number = tp.PPAP_Number
                        INNER JOIN tubes_customer_pn tcp ON tps.FK_TUB_Customer_PN = tcp.TUB_Customer_PN
                        INNER JOIN tubes_customers tc ON tp.FK_ID_TUB_Customer = tc.ID_TUB_Customer
                        INNER JOIN `tubes_customer-country` tcc ON tp.`FK_TUB_Customer-Country` = tcc.`TUB_Customer-Country`
                        INNER JOIN tubes t ON tcp.FK_Eurotech_PN_TUB = t.Eurotech_PN_TUB
                    ORDER BY PPAP_Number;"
                ) as $log) {
                    $logs[] = $log;
                }
            }
            return $logs;
        }

        function searchPPAPN(){
            $PPAPNS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        PPAP_Number
                    FROM tubes_ppap
                    ORDER BY PPAP_Number;"
                ) as $PPAPN) {
                    $PPAPNS[] = $PPAPN;
                }
            return $PPAPNS;
        }

        function searchCS(){
            $Currents = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Current_Status
                    FROM tubes_ppaps
                    ORDER BY Current_Status;"
                ) as $Current) {
                    $Currents[] = $Current;
                }
            return $Currents;
        }

        function searchPIS(){
            $PIS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Vendor
                    FROM tubes_ppap
                    ORDER BY Vendor;"
                ) as $PI) {
                    $PIS[] = $PI;
                }
            return $PIS;
        }

        function searchCust(){
            $Customers = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        `Name`
                    FROM tubes_customers
                    ORDER BY `Name`;"
                ) as $Customer) {
                    $Customers[] = $Customer;
                }
            return $Customers;
        }
    }
?>