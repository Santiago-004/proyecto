<?php 
    include "model.php";

    $model = new model();
    $model->cn();
    $logs = [];
    
    if (isset($_POST["submit1search"]) && isset($_POST["submit2search"])){
        $submit1search = $_POST["submit1search"];
        $submit2search = $_POST["submit2search"];
    }    
    else {
        $submit1search = "";
        $submit2search = "";
    }

    if (isset($_POST["ppapnsearch"])){
        $ppapnsearch = $_POST["ppapnsearch"];
    }    
    else {
        $ppapnsearch = "";
    }
    
    if (isset($_POST["req1search"]) && isset($_POST["req2search"])){
        $req1search = $_POST["req1search"];
        $req2search = $_POST["req2search"];
    }    
    else {
        $req1search = "";
        $req2search = "";
    }

    if (isset($_POST["currentsearch"])){
        $currentsearch = $_POST["currentsearch"];
    }    
    else {
        $currentsearch = "";
    }

    if (isset($_POST["pisearch"])){
        $pisearch = $_POST["pisearch"];
    }    
    else {
        $pisearch = "";
    }

    if (isset($_POST["custsearch"])){
        $custsearch = $_POST["custsearch"];
    }    
    else {
        $custsearch = "";
    }

    $logs = $model->search();
    $PPAPNS = $model->searchPPAPN();
    $Currents = $model->searchCS();
    $PIS = $model->searchPIS();
    $Customers = $model->searchCust();

    include 'view.php';
?>