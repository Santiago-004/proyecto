<?php
header('Content-Type: application/json');

$connection = new mysqli("localhost", "root", "", "eurotechdb");
if ($connection->connect_error) {
    echo json_encode(["success" => false, "error" => "Connection Error"]);
    exit;
}

$PPAP_Number = $_POST['PPAP_Number'] ?? '';

if ($PPAP_Number !== '') {
    $stmt = $connection->prepare("
        SELECT Customer_PN, IMDS, Eurotech_PN, Description, v.Short_name AS 'Vendor', Supplier_PN, c.Country, c.Name AS 'Customer'
        FROM ppap pp
        INNER JOIN customer_pn cpn ON pp.FK_Customer_PN_ID = cpn.Customer_PN_ID
        INNER JOIN customers c ON cpn.FK_Customer_ID = c.C_ID
        INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
        LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
        WHERE PPAP_Number = ?
        LIMIT 1
    ");
    $stmt->bind_param("s", $PPAP_Number);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($fila = $resultado->fetch_assoc()) {
        echo json_encode([
            "success" => true,
            "Customer_PN" => $fila['Customer_PN'],
            "IMDS" => $fila['IMDS'],
            "Eurotech_PN" => $fila['Eurotech_PN'],
            "Description" => $fila['Description'],
            "Vendor" => $fila['Vendor'],
            "Supplier_PN" => $fila['Supplier_PN'],
            "Country" => $fila['Country'],
            "Customer" => $fila['Customer']
        ]);
    } else {
        echo json_encode(["success" => false]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false]);
}

$connection->close();
?>