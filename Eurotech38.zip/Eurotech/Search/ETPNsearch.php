<?php
header('Content-Type: application/json');

$connection = new mysqli("localhost", "root", "", "eurotechdb");
if ($connection->connect_error) {
    echo json_encode(["success" => false, "error" => "Connection Error"]);
    exit;
}

$Description = $_POST['Description'] ?? '';

if ($Description !== '') {
    $stmt = $connection->prepare("
        SELECT Eurotech_PN, Short_name AS 'Vendor', Supplier_PN
        FROM products p
        LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
        WHERE Description = ?
        LIMIT 1");
    $stmt->bind_param("s", $Description);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($fila = $resultado->fetch_assoc()) {
        echo json_encode([
            "success" => true, 
            "Eurotech_PN" => $fila['Eurotech_PN'],
            "Vendor" => $fila['Vendor'],
            "Supplier_PN" => $fila['Supplier_PN']
        ]);
    } else {
        echo json_encode(["success" => false]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false]);
}

$connection->close();
?>