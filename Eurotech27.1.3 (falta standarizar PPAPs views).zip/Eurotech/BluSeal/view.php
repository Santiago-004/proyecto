<link href="./css/style.css" rel="stylesheet">
<style>
    .clear {
        color: white;
        padding: 8px 14px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
        transition: background-color 0.2s;
        font-size: 14px;
        background-color: #16bacfff;
    }

    .clear:hover {
        background-color: #1dd1e8ff;
        color: white;
    }

    .error {
        background-color: #ffe6e6;
        color: #d63031;
        padding: 10px;
        border-radius: 8px;
        margin-bottom: 15px;
        font-size: 0.9rem;
    }

    .form-search .camp {
        flex: 1 1 20%;
        min-width: 250px;
    }

    .form-search .camp1 {
        display: none;
    }

    .form-search .camp2 {
        display: flex;
        flex: 1 1 20%;
        min-width: 250px;
    }

    .form-search input[type="date"],
    .form-search input[type="number"]{
        padding: 8px 10px;
        border: 1px solid #bbb;
        border-radius: 8px;
        width: 46%;
        box-sizing: border-box;
    }

    @media (max-width: 1630px) {
        .note {
            padding: 15px 10px;
        }
    }
    
    @media (max-width: 1453px) {
        .form-search .camp {
            flex: 1 1 40%; 
            min-width: 300px;
        }

        .form-search .camp1 {
            display: flex;
            flex: 1 1 40%;
            min-width: 250px;
        }

        .form-search .camp2 {
            display: none;
        }
    }

    @media (max-width: 660px) {
        .form-search .camp {
            flex: 1 1 100%; 
            min-width: 300px;
        }

        .form-search .camp1 {
            display: none;
        }
    }
</style>
<form action="" id="form" method="post" class="form-search">
    <input type="hidden" name="page" value="BluSeal">
    <div class="camp">
        <label>Days to Submit:</label>
        <input type="number" disabled> -
        <input type="number" disabled>
    </div>
    
    <div class="camp">
        <label>PPAP Number:</label>
        <input type="text" disabled>
    </div>

    <div class="camp">
        <label>PPAP Req'd by Customer:</label>
        <input type="date" name="date1search" value="<?php if ($date1search != NULL) { echo $date1search;} ?>"> - <input type="date" name="date2search" value="<?php if ($date2search != NULL) { echo $date2search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="reqn" id="" value="" <?php if ($reqn != "N" && $reqn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="reqn" id="" value="N" <?php if ($reqn == "N") { echo "checked";} ?>> No date        
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="reqn" id="" value="Y" <?php if ($reqn == "Y") { echo "checked";} ?>> W/ date
    </div>

    <div class="camp">
        <label>Current Status:</label>
        <input type="text" disabled>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" disabled> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" disabled> No current status
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" disabled> W/ current status
    </div>

    <div class="camp">
        <label>Vendor:</label>
        <input type="text" maxlength="15" name="suppsearch" list="Supplier" value="<?php if ($suppsearch != NULL) { echo $suppsearch;} ?>">
        <datalist id="Supplier">
            <?php foreach ($Suppliers as $Supplier) {  ?>
                <option value="<?php echo $Supplier['Supplier'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Supplier PN:</label>
        <input type="text" maxlength="6" name="spnsearch" list="SupplierPN" value="<?php if ($spnsearch != NULL) { echo $spnsearch;} ?>">
        <datalist id="SupplierPN">
            <?php foreach ($SPNS as $SPN) {  ?>
                <option value="<?php echo $SPN['Supplier_PN'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Customer:</label>
        <input type="text" maxlength="70" name="custsearch" list="Customer" value="<?php if ($custsearch != NULL) { echo $custsearch;} ?>">
        <datalist id="Customer">
            <?php foreach ($Customers as $Customer) {  ?>
                <option value="<?php echo $Customer['Name'] ?>">
            <?php } ?>
        </datalist>
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="cusn" id="" value="" <?php if ($cusn != "N" && $cusn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="cusn" id="" value="N" <?php if ($cusn == "N") { echo "checked";} ?>> No Customer
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="cusn" id="" value="Y" <?php if ($cusn == "Y") { echo "checked";} ?>> W/ Customer
    </div>

    <div class="camp">
        <label>Country:</label>
        <input type="text" disabled>
    </div>

    <div class="camp">
        <label>Customer PN:</label>
        <input type="text" maxlength="20" name="cpnsearch" list="CPN" value="<?php if ($cpnsearch != NULL) { echo $cpnsearch;} ?>">
        <datalist id="CPN">
            <?php foreach ($CPNS as $CPN) {  ?>
                <option value="<?php echo $CPN['Customer_PN'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>ET Model:</label>
        <input type="text" disabled>
    </div>

    <div class="camp">
        <label>ET Dwg:</label>
        <input type="text" disabled>
    </div>

    <div class="camp">
        <label>Rev:</label>
        <input type="text" disabled>
    </div>

    <div class="camp">
        <label>ET PN:</label>
        <select name="modelsearch" >
            <option value="">All</option>
            <?php foreach ($Models as $Model) {  ?>
                <option value="<?php echo $Model['Eurotech_PN'] ?>" <?php if ($modelsearch == $Model['Eurotech_PN']) { echo 'selected';} ?>><?php echo $Model['Eurotech_PN'] ?></option>
            <?php } ?>
        </select>
    </div>

    <div class="camp">
        <label>Coroflex PN:</label>
        <input  type="text" disabled>
    </div>

    <div class="camp">
        <label>Description:</label>
        <select name="descsearch" >
            <option value="">All</option>
            <?php foreach ($Descs as $Desc) {  ?>
                <option value="<?php echo $Desc['Description'] ?>" <?php if ($descsearch == $Desc['Description']) { echo 'selected';} ?>><?php echo $Desc['Description'] ?></option>
            <?php } ?>
        </select>
    </div>

    <div class="camp">
        <label>IMDS Number:</label>
        <input type="text" maxlength="15" name="imdssearch" list="IMDS" value="<?php if ($imdssearch != NULL) { echo $imdssearch;} ?>">
        <datalist id="IMDS">
            <?php foreach ($IMDS as $IM) {  ?>
                <option value="<?php echo $IM['IMDS'] ?>">
            <?php } ?>
        </datalist>
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="imdn" id="" value="" <?php if ($imdn != "N" && $imdn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="imdn" id="" value="N" <?php if ($imdn == "N") { echo "checked";} ?>> No IMDS
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="imdn" id="" value="Y" <?php if ($imdn == "Y") { echo "checked";} ?>> W/ IMDS
    </div>

    <div class="camp">
        <label>IMDS Status:</label>
        <input type="text" disabled>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" disabled> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" disabled> No IMDS status
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" disabled> W/ IMDS status
    </div>

    <div class="camp">
        <label>PPAP docs:</label>
        <input type="text" disabled>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" disabled> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" disabled> No PPAP docs
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" disabled> W/ PPAP docs
    </div>

    <div class="camp">
        <label>Level:</label>
        <input type="text" disabled>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" disabled> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" disabled> No level
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" disabled> W/ level
    </div>

    <div class="camp">
        <label>PPAP samples status:</label>
        <input type="text" disabled>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" disabled> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" disabled> No PPAP sample status
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" disabled> W/ PPAP sample status
    </div>

    <div class="camp">
        <label>Reason of Submission:</label>
        <input type="text" disabled>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" disabled> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" disabled> No reason of submission
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" disabled> W/ reason of submission
    </div>

    <div class="camp">
        <label>Received Date:</label>
        <input type="date" name="date3search" value="<?php if ($date3search != NULL) { echo $date3search;} ?>"> - <input type="date" name="date4search" value="<?php if ($date4search != NULL) { echo $date4search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="recn" id="" value="" <?php if ($recn != "N" && $recn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="recn" id="" value="N" <?php if ($recn == "N") { echo "checked";} ?>> No date        
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="recn" id="" value="Y" <?php if ($recn == "Y") { echo "checked";} ?>> W/ date
    </div>

    <div class="camp">
        <label>Sent to Customer:</label>
        <input type="date" name="date5search" value="<?php if ($date5search != NULL) { echo $date5search;} ?>"> - <input type="date" name="date6search" value="<?php if ($date6search != NULL) { echo $date6search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="psen" id="" value="" <?php if ($psen != "N" && $psen != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="psen" id="" value="N" <?php if ($psen == "N") { echo "checked";} ?>> No date        
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="psen" id="" value="Y" <?php if ($psen == "Y") { echo "checked";} ?>> W/ date
    </div>

    <div class="camp">
        <label>PSW returned from Customer Signed:</label>
        <input type="date" name="date7search" value="<?php if ($date7search != NULL) { echo $date7search;} ?>"> - <input type="date" name="date8search" value="<?php if ($date8search != NULL) { echo $date8search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="psin" id="" value="" <?php if ($psin != "N" && $psin != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="psin" id="" value="N" <?php if ($psin == "N") { echo "checked";} ?>> No date        
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="psin" id="" value="Y" <?php if ($psin == "Y") { echo "checked";} ?>> W/ date
    </div>

    <div class="camp">
        <label>Origin from report:</label>
        <input type="radio" disabled> All <br>
        <input type="radio" disabled> No <br>
        <input type="radio" disabled> Yes
    </div>

    <div class="camp">
        <label>Comments:</label>
        <input type="text" disabled>
    </div>

    <div class="camp">
        <label>Inspection Report Number:</label>
        <input type="text" disabled>
    </div>

    <div class="camp"></div>
    <div class="camp"></div>
    <div class="camp"></div>
    <div class="camp"></div>

    
    <div class="campbtn">
        <button type="submit" name="btnsearch" class="insert">Search</button>
        <button style="margin: 0px 0px 0px 15px;"  type="submit" name="btnsearch" class="clear" onclick="clearForm()">Clear All</button>
    </div>
</form>

<div style="display: flex;">
    <form action="?page=BluSeal" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insertD" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
        <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
        <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
        <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
        <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
        <button type="submit" class="insert">New PPAP (Description)</button>
    </form>

    <form action="?page=BluSeal" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insertET" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
        <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
        <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
        <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
        <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
        <button type="submit" class="insert">New PPAP (ET PN)</button>
    </form>

    <form action="?page=BluSeal" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insertC" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
        <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
        <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
        <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
        <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
        <button type="submit" class="insert">New PPAP (Cust PN)</button>
    </form>
</div>

<?php if($logs == NULL) { ?>
    <br>
    <h1>No results.</h1>
<?php } ?>

<?php if($logs != NULL) { ?>
    <div class="table-responsive">
        <table class="table table-bordered" id="PPAP_table">
            <tr>    
                <?php if($_SESSION["Role"] == 'Administrator') { ?>
                    <th style="background-color:#1c18AA;"></th>
                    <th style="background-color:#1c18AA;"></th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(2, 'number')">Days to Submit</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(3, 'text')">PPAP Number</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(4, 'date')">PPAP Req'd by Customer</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(5, 'text')">Current Status</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(6, 'text')">Vendor</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(7, 'text')">Supplier PN</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(8, 'text')">Customer</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(9, 'text')">Country</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(10, 'text')">Customer PN</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(11, 'text')">ET Model</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(12, 'text')">ET Dwg</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(13, 'text')">Rev</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(14, 'text')">ET PN</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(15, 'text')">Description</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(16, 'text')">IMDS Number</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(17, 'text')">IMDS Status</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(18, 'text')">PPAP docs</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(19, 'text')">Level</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(20, 'text')">PPAP samples status</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(21, 'text')">Reason of Submission</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(22, 'date')">Received Date</th>
                    <th style="background-color:#1c18AA; color:white">PPAP ET & IMDS ET</th>
                    <th style="background-color:#1c18AA; color:white">PSW ET & IMDS ET</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(25, 'date')">Sent to Customer</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(26, 'date')">PSW returned from Cust Signed</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(27, 'text')">Origin from report</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(28, 'text')">Comments</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(29, 'text')">Inspection Report Number</th>
                <?php } 
                else { ?>
                    <th style="background-color:#1c18AA;"></th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(1, 'number')">Days to Submit</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(2, 'text')">PPAP Number</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(3, 'date')">PPAP Req'd by Customer</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(4, 'text')">Current Status</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(5, 'text')">Vendor</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(6, 'text')">Supplier PN</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(7, 'text')">Customer</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(8, 'text')">Country</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(9, 'text')">Customer PN</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(10, 'text')">ET Model</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(11, 'text')">ET Dwg</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(12, 'text')">Rev</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(13, 'text')">ET PN</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(14, 'text')">Description</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(15, 'text')">IMDS Number</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(16, 'text')">IMDS Status</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(17, 'text')">PPAP docs</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(18, 'text')">Level</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(19, 'text')">PPAP samples status</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(20, 'text')">Reason of Submission</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(21, 'date')">Received Date</th>
                    <th style="background-color:#1c18AA; color:white">PPAP ET & IMDS ET</th>
                    <th style="background-color:#1c18AA; color:white">PSW ET & IMDS ET</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(24, 'date')">Sent to Customer</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(25, 'date')">PSW returned from Cust Signed</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(26, 'text')">Origin from report</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(27, 'text')">Comments</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(28, 'text')">Inspection Report Number</th>
                <?php } ?>
            </tr>
            
            <?php foreach ($logs as $log) { ?>
                <tr>
                    <?php if($log['Name'] != NULL && $log['PPAP_Signed_Date'] == NULL) { ?>
                        <td style="text-align: center; vertical-align: middle;">
                            <form action="?page=BluSeal" method="post" style="display:inline;">
                                <input type="hidden" name="edit" value="">
                                <input type="hidden" name="btnsearch" value="1">
                                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
                                <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
                                <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
                                <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
                                <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
                                <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
                                <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
                                <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
                                <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
                                <input type="hidden" name="IDedit" value="<?php echo $log['BS_PPAP_ID']; ?>">
                                <button type="submit" class="editar">Edit</button>
                            </form>
                        </td>
                        <?php if($_SESSION["Role"] == 'Administrator') { ?>
                            <td style="text-align: center; vertical-align: middle;">
                                <form action="?page=BluSeal" method="post" style="display:inline;">
                                    <input type="hidden" name="delete" value="">
                                    <input type="hidden" name="btnsearch" value="1">
                                    <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                    <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
                                    <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                    <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                    <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                    <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
                                    <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
                                    <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                    <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                    <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                    <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                    <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
                                    <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
                                    <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
                                    <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
                                    <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                    <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                    <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                    <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                    <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
                                    <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
                                    <input type="hidden" name="IDdelete" value="<?php echo $log['BS_PPAP_ID']; ?>">
                                    <button type="submit" class="eliminar">Delete</button>
                                </form>
                            </td>
                        <?php } ?>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                        <?php if($log['Request_Date'] != NULL) { 
                            $reqDate = new DateTime($log['Request_Date']); ?>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $reqDate->format('m/d/Y') ?></td>
                        <?php } 
                        if($log['Request_Date'] == NULL) { ?>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                        <?php } ?>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Supplier']; ?></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Supplier_PN']; ?></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Name']; ?></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Customer_PN']; ?></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Eurotech_PN']; ?></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Description']; ?></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['IMDS']; ?></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                        <?php 
                        if($log['PPAP_Received_Date'] != NULL) { 
                            $recDate = new DateTime($log['PPAP_Received_Date']); ?>
                            <td style="background-color: rgba(255, 235, 0, 0.7);">
                                <?php echo $recDate->format('m/d/Y') ?>
                            </td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7); text-align: center; vertical-align: middle;">
                                <form action="?page=BluSeal" method="POST">
                                    <input type="hidden" name="note" value="">
                                    <input type="hidden" name="btnsearch" value="1">
                                    <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                    <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
                                    <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                    <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                    <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                    <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
                                    <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
                                    <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                    <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                    <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                    <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                    <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
                                    <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
                                    <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
                                    <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
                                    <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                    <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                    <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                    <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                    <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
                                    <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
                                    <input type="hidden" name="IDnote" value="<?php echo $log['BS_PPAP_ID'] ?>">
                                    <button type="submit"  class="note">Note</button>
                                </form>
                            </td>
                        <?php }
                        if($log['PPAP_Received_Date'] == NULL) { ?>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                        <?php }
                        if($log['Sent_Customer'] != NULL) { 
                            $sentCust = new DateTime($log['Sent_Customer']); ?>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $sentCust->format('m/d/Y') ?></td>
                        <?php }
                        if($log['Sent_Customer'] == NULL) { ?>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                        <?php } ?>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    <?php } 
                    if($log['Name'] != NULL && $log['PPAP_Signed_Date'] != NULL) {?>
                        <td style="text-align: center; vertical-align: middle;">
                            <form action="?page=BluSeal" method="post" style="display:inline;">
                                <input type="hidden" name="edit" value="">
                                <input type="hidden" name="btnsearch" value="1">
                                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
                                <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
                                <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
                                <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
                                <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
                                <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
                                <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
                                <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
                                <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
                                <input type="hidden" name="IDedit" value="<?php echo $log['BS_PPAP_ID']; ?>">
                                <button type="submit" class="editar">Edit</button>
                            </form>
                        </td>
                        <?php if($_SESSION["Role"] == 'Administrator') { ?>
                            <td style="text-align: center; vertical-align: middle;">
                                <form action="?page=BluSeal" method="post" style="display:inline;">
                                    <input type="hidden" name="delete" value="">
                                    <input type="hidden" name="btnsearch" value="1">
                                    <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                    <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
                                    <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                    <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                    <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                    <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
                                    <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
                                    <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                    <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                    <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                    <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                    <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
                                    <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
                                    <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
                                    <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
                                    <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                    <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                    <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                    <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                    <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
                                    <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
                                    <input type="hidden" name="IDdelete" value="<?php echo $log['BS_PPAP_ID']; ?>">
                                    <button type="submit" class="eliminar">Delete</button>
                                </form>
                            </td>
                        <?php } ?>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                        <?php if($log['Request_Date'] != NULL) { 
                            $reqDate = new DateTime($log['Request_Date']); ?>
                            <td style="background-color: rgba(0, 255, 0, 0.7);"><?php echo $reqDate->format('m/d/Y') ?></td>
                        <?php }
                        if($log['Request_Date'] == NULL) { ?>
                            <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                        <?php } ?>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"><?php echo $log['Supplier']; ?></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"><?php echo $log['Supplier_PN']; ?></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"><?php echo $log['Name']; ?></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"><?php echo $log['Customer_PN']; ?></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"><?php echo $log['Eurotech_PN']; ?></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"><?php echo $log['Description']; ?></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"><?php echo $log['IMDS']; ?></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                        <?php if($log['PPAP_Received_Date'] != NULL) { 
                            $recDate = new DateTime($log['PPAP_Received_Date']); ?>
                            <td style="background-color: rgba(0, 255, 0, 0.7);">
                                <?php echo $recDate->format('m/d/Y') ?>
                            </td>
                            <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.7); text-align: center; vertical-align: middle;">
                                <form action="?page=BluSeal" method="POST">
                                    <input type="hidden" name="note" value="">
                                    <input type="hidden" name="btnsearch" value="1">
                                    <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                    <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
                                    <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                    <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                    <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                    <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
                                    <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
                                    <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                    <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                    <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                    <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                    <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
                                    <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
                                    <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
                                    <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
                                    <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                    <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                    <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                    <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                    <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
                                    <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
                                    <input type="hidden" name="IDnote" value="<?php echo $log['BS_PPAP_ID'] ?>">
                                    <button type="submit"  class="note">Note</button>
                                </form>
                            </td>
                        <?php }
                        if($log['PPAP_Received_Date'] == NULL) { ?>
                            <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                        <?php }
                        if($log['Sent_Customer'] != NULL) { 
                            $sentCust = new DateTime($log['Sent_Customer']); ?>
                            <td style="background-color: rgba(0, 255, 0, 0.7);"><?php echo $sentCust->format('m/d/Y') ?></td>
                        <?php }
                        if($log['Sent_Customer'] == NULL) { ?>
                            <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                        <?php } 
                        if($log['PPAP_Signed_Date'] != NULL) { 
                            $signDate = new DateTime($log['PPAP_Signed_Date']); ?>
                            <td style="background-color: rgba(0, 255, 0, 0.7);"><?php echo $signDate->format('m/d/Y') ?></td>
                        <?php } ?>
                        <td></td>
                        <td></td>
                        <td></td>
                    <?php } 
                    if($log['Name'] == NULL) {?>
                        <td></td>
                        <?php if($_SESSION["Role"] == 'Administrator') { ?>
                            <td></td>
                        <?php } ?>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td><?php echo $log['Supplier']; ?></td>
                        <td><?php echo $log['Supplier_PN']; ?></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td><?php echo $log['Eurotech_PN']; ?></td>
                        <td><?php echo $log['Description']; ?></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    <?php } ?>
                </tr> 
            <?php } ?>
        </table> 
    </div>
<?php } 

if (isset($_POST['note'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Note</h2>
    <form action="?page=BluSeal" method="post">
        <input type="hidden" name="confirmNote" value="1">
        <input type="hidden" name="confirmIDNote" value="<?php echo $_POST['IDnote']; ?>">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
        <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
        <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
        <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
        <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
        <div>
            <input style="width: 10px;" type="checkbox" name="PPAP_ET" <?php if($noteData['PPAP_ET'] != NULL) { echo "checked value='<?php echo 1; ?>'";  } else { echo "value=''"; } ?>> PPAP ET
        </div>

        <div>
            <input style="width: 10px;" type="checkbox" name="IMDS_ET" <?php if($noteData['IMDS_ET'] != NULL) { echo "checked value='<?php echo 1; ?>'";  } else { echo "value=''"; } ?>> IMDS ET
        </div>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if (isset($_POST['insertD'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New PPAP</h2>
    <?php if (isset($error)) : ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form action="?page=BluSeal" method="post">
        <input type="hidden" name="confirmID" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
        <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
        <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
        <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
        <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
        <label><label style="color:red">*</label> Description:</label>
        <select name="Description"  required>
            <option value=""></option>
            <?php foreach ($Descs as $Desc) {  ?>
                <option value="<?php echo $Desc['Description'] ?>" <?php if(isset($_POST['Description']) && $_POST['Description']  == $Desc['Description']) { echo 'selected'; } ?>><?php echo $Desc['Description'] ?></option>
            <?php } ?>
        </select> <br>

        <label><label style="color:red">*</label> Customer:</label>
        <input type="text" maxlength="70" name="Name" list="Customer" value="<?php if(isset($_POST['Name'])) { echo $_POST['Name']; } ?>" required> <br>

        <label>IMDS:</label>
        <input type="text" maxlength="15" name="IMDS" list="IMDS" value="<?php if(isset($_POST['IMDS'])) { echo $_POST['IMDS']; } ?>"> <br>

        <label><label style="color:red">*</label> PPAP Requested Date:</label>
        <input type="date" name="Request_Date" value="<?php if(isset($_POST['Request_Date'])) { echo $_POST['Request_Date']; } ?>" required> <br>

        <label>PPAP Received Date:</label>
        <input type="date" name="PPAP_Received_Date" value="<?php if(isset($_POST['PPAP_Received_Date'])) { echo $_POST['PPAP_Received_Date']; } ?>"> <br>

        <label>PPAP Sent Date:</label>
        <input type="date" name="Sent_Customer" value="<?php if(isset($_POST['Sent_Customer'])) { echo $_POST['Sent_Customer']; } ?>"> <br>

        <label>PPAP Signed Date:</label>
        <input type="date" name="PPAP_Signed_Date" value="<?php if(isset($_POST['PPAP_Signed_Date'])) { echo $_POST['PPAP_Signed_Date']; } ?>">

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if (isset($_POST['insertET'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New PPAP</h2>
    <?php if (isset($error)) : ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form action="?page=BluSeal" method="post">
        <input type="hidden" name="confirmIE" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
        <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
        <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
        <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
        <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
        <label><label style="color:red">*</label> Eurotech PN:</label>
        <select name="Eurotech_PN" required>
            <option value=""></option>
            <?php foreach ($Models as $Model) {  ?>
                <option value="<?php echo $Model['Eurotech_PN'] ?>" <?php if(isset($_POST['Eurotech_PN']) && $_POST['Eurotech_PN']  == $Model['Eurotech_PN']) { echo 'selected'; } ?>><?php echo $Model['Eurotech_PN'] ?></option>
            <?php } ?>
        </select> <br>

        <label><label style="color:red">*</label> Customer:</label>
        <input type="text" maxlength="70" name="Name" list="Customer" value="<?php if(isset($_POST['Name'])) { echo $_POST['Name']; } ?>" required> <br>

        <label>IMDS:</label>
        <input type="text" maxlength="15" name="IMDS" list="IMDS" value="<?php if(isset($_POST['IMDS'])) { echo $_POST['IMDS']; } ?>"> <br>

        <label><label style="color:red">*</label> PPAP Requested Date:</label>
        <input type="date" name="Request_Date" value="<?php if(isset($_POST['Request_Date'])) { echo $_POST['Request_Date']; } ?>" required> <br>

        <label>PPAP Received Date:</label>
        <input type="date" name="PPAP_Received_Date" value="<?php if(isset($_POST['PPAP_Received_Date'])) { echo $_POST['PPAP_Received_Date']; } ?>"> <br>

        <label>PPAP Sent Date:</label>
        <input type="date" name="Sent_Customer" value="<?php if(isset($_POST['Sent_Customer'])) { echo $_POST['Sent_Customer']; } ?>"> <br>

        <label>PPAP Signed Date:</label>
        <input type="date" name="PPAP_Signed_Date" value="<?php if(isset($_POST['PPAP_Signed_Date'])) { echo $_POST['PPAP_Signed_Date']; } ?>">

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if (isset($_POST['insertC'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New PPAP</h2>
    <?php if (isset($error)) : ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form action="?page=BluSeal" method="post">
        <input type="hidden" name="confirmIC" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
        <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
        <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
        <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
        <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
        <label><label style="color:red">*</label> Customer PN:</label>
        <input type="text" maxlength="20" name="Customer_PN" list="CPN" value="<?php if(isset($_POST['Customer_PN'])) { echo $_POST['Customer_PN']; } ?>" required> <br>

        <label>IMDS:</label>
        <input type="text" maxlength="15" name="IMDS" list="IMDS" value="<?php if(isset($_POST['IMDS'])) { echo $_POST['IMDS']; } ?>"> <br>

        <label><label style="color:red">*</label> PPAP Requested Date:</label>
        <input type="date" name="Request_Date" value="<?php if(isset($_POST['Request_Date'])) { echo $_POST['Request_Date']; } ?>" required> <br>

        <label>PPAP Received Date:</label>
        <input type="date" name="PPAP_Received_Date" value="<?php if(isset($_POST['PPAP_Received_Date'])) { echo $_POST['PPAP_Received_Date']; } ?>"> <br>

        <label>PPAP Sent Date:</label>
        <input type="date" name="Sent_Customer" value="<?php if(isset($_POST['Sent_Customer'])) { echo $_POST['Sent_Customer']; } ?>"> <br>

        <label>PPAP Signed Date:</label>
        <input type="date" name="PPAP_Signed_Date" value="<?php if(isset($_POST['PPAP_Signed_Date'])) { echo $_POST['PPAP_Signed_Date']; } ?>">

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if (isset($_POST['edit'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Update PPAP</h2>
    <?php if (isset($error)) : ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form action="?page=BluSeal" method="post">
        <input type="hidden" name="confirmU" value="1">
        <input type="hidden" name="BS_PPAP_ID" value="<?php echo $_POST['IDedit']; ?>">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
        <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
        <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
        <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
        <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
        <label>IMDS:</label>
        <input type="text" maxlength="15" name="IMDS" list="IMDS" value="<?php echo $bsData['IMDS']; ?>"> <br>

        <label><label style="color:red">*</label> PPAP Requested Date:</label>
        <input type="date" name="Request_Date" value="<?php echo $bsData['Request_Date']; ?>" required> <br>

        <label>PPAP Received Date:</label>
        <input type="date" name="PPAP_Received_Date" value="<?php echo $bsData['PPAP_Received_Date']; ?>"> <br>

        <label>PPAP Sent Date:</label>
        <input type="date" name="Sent_Customer" value="<?php echo $bsData['Sent_Customer']; ?>"> <br>

        <label>PPAP Signed Date:</label>
        <input type="date" name="PPAP_Signed_Date" value="<?php echo $bsData['PPAP_Signed_Date']; ?>">

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php }

if (isset($_POST['delete'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Delete PPAP</h2>
    <form action="?page=BluSeal" method="post">
        <input type="hidden" name="confirmD" value="1">
        <input type="hidden" name="IDdelete" value="<?php echo $_POST['IDdelete']; ?>">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
        <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
        <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
        <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
        <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
        <?php 
            if($bsDataD['Request_Date'] != NULL) {
                $reqD = new DateTime($bsDataD['Request_Date']);
            }
            if($bsDataD['PPAP_Received_Date'] != "") {
                $recD = new DateTime($bsDataD['PPAP_Received_Date']);
            }
            if($bsDataD['Sent_Customer'] != "") {
                $senD = new DateTime($bsDataD['Sent_Customer']);
            }
            if($bsDataD['PPAP_Signed_Date'] != "") {
                $sigD = new DateTime($bsDataD['PPAP_Signed_Date']);
            }
        ?>
        <h5><b>Are you sure you want to delete the data of this PPAP?</b></h5> <br>
        <h6><b>Model:</b> <?php echo $bsDataD['Eurotech_PN'] ?></h6>
        <h6><b>Description:</b> <?php echo $bsDataD['Description'] ?></h6>
        <h6><b>Customer:</b> <?php echo $bsDataD['Name'] ?></h6>
        <h6><b>Customer PN:</b> <?php echo $bsDataD['Customer_PN'] ?></h6>
        <h6><b>IMDS:</b> <?php echo $bsDataD['IMDS'] ?></h6>
        <h6><b>Supplier:</b> <?php echo $bsDataD['Supplier'] ?></h6>
        <h6><b>Supplier PN:</b> <?php echo $bsDataD['Supplier_PN'] ?></h6>
        <h6><b>Requested Date:</b> <?php if($bsDataD['Request_Date'] != NULL) { echo $reqD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
        <h6><b>Received Date:</b> <?php if($bsDataD['PPAP_Received_Date'] != NULL) { echo $recD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
        <h6><b>Sent Date:</b> <?php if($bsDataD['Sent_Customer'] != NULL) { echo $senD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
        <h6><b>Signed Date:</b> <?php if($bsDataD['PPAP_Signed_Date'] != NULL) { echo $sigD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
        <button type="submit">Confirm</button>
    </form>
  </div>
</div>
<?php }

if ($Deleted != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Register Deleted</h2>
        <form action="?page=Cables" method="post">
            <h6><b>The register was deleted correctly.</b></h6>
        </form>
    </div>
    </div>
<?php } ?>

<script>
    function closeForm() {
        document.getElementById('formularioModal').style.display = 'none';
    }

    function sendForm() {
        closeForm();
        return true;
    }

    function clearForm() {
        document.querySelectorAll("#form input[type='text']").forEach(input => input.value = "");
        document.querySelectorAll("#form input[type='date']").forEach(input => input.value = "");

        const radioButtons = document.querySelectorAll("#form input[type='radio']");
        const defaultValue = '';

        for (const radio of radioButtons) {
            if (radio.value === defaultValue) {
                radio.checked = true;
            }
        }

        const selects = document.querySelectorAll("#form select");

        for (const select of selects) {
            select.value = defaultValue;
        }
    }

    let sortOrder = {};

    function sortTable(columnIndex, type) {
        const table = document.getElementById("PPAP_table");
        const rows = Array.from(table.rows).slice(1);
        const isAscending = !sortOrder[columnIndex];
        
        rows.sort((rowA, rowB) => {
            const cellA = rowA.cells[columnIndex].innerText.trim();
            const cellB = rowB.cells[columnIndex].innerText.trim();
            
            if (type === "date") {
                const dateA = new Date(cellA);
                const dateB = new Date(cellB);
                const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
                const dateformatedA = dateA.toLocaleDateString('ja-JP', options);
                const dateformatedB = dateB.toLocaleDateString('ja-JP', options);
                return isAscending ? dateformatedA.localeCompare(dateformatedB) : dateformatedB.localeCompare(dateformatedA);
            } else if (type === "text") {
                return isAscending ? cellA.localeCompare(cellB) : cellB.localeCompare(cellA);
            }
        });

        rows.forEach(row => table.tBodies[0].appendChild(row));
        sortOrder[columnIndex] = isAscending;
    }
</script>