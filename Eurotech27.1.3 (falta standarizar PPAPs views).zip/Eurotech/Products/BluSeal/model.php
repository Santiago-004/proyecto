<?php
    class model {                                        

        public  $mbd;
        
        function cn() {
            $this->mbd = new PDO('mysql:host=localhost;dbname=eurotechdb;port=3306', 'root', '');
            $this->mbd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
        }
    
        function search(){
            $logs = [];
            if (isset($_POST['btnsearch'])) {
                if (!empty($_POST['idsearch']) || !empty($_POST['descsearch']) || !empty($_POST['suppsearch']) || !empty($_POST['snsearch'])) {
                    $where = [];
                    $params = [];

                    if (!empty($_POST['idsearch'])) {
                        $where[] = "Eurotech_PN = :id";
                        $params[':id'] = $_POST['idsearch'];
                    }
                    
                    if(!empty($_POST['descsearch'])) {
                        $where[] = "`Description` LIKE :desc";
                        $params[':desc'] = $_POST['descsearch']."%";
                    }

                    if (!empty($_POST['suppsearch'])) {
                        $where[] = "Supplier = :supp";
                        $params[':supp'] = $_POST['suppsearch'];
                    }

                    if (!empty($_POST['snsearch'])) {
                        $where[] = "Supplier_PN = :sn";
                        $params[':sn'] = $_POST['snsearch'];
                    }

                    if(!empty($where)) {
                        $sql = "
                        SELECT 
                            *
                        FROM products
                        WHERE " . implode(' AND ', $where) . "
                        AND Product = 'BluSeal'
                        ORDER BY Eurotech_PN;";
                    }
                    else {
                        $sql = "
                        SELECT 
                            *
                        FROM products
                        WHERE Product = 'BluSeal'
                        ORDER BY Eurotech_PN;";
                    }

                    $stmt = $this->mbd->prepare($sql);
                    $stmt->execute($params);

                    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
                else {
                    foreach ($this->mbd->query(
                        "SELECT 
                            *
                        FROM products
                        WHERE Product = 'BluSeal'
                        ORDER BY Eurotech_PN;"
                    ) as $log) {
                        $logs[] = $log;
                    }
                }
            } else {
                foreach ($this->mbd->query(
                    "SELECT 
                        *
                    FROM products
                    WHERE Product = 'BluSeal'
                    ORDER BY Eurotech_PN;"
                ) as $log) {
                    $logs[] = $log;
                }
            }
            return $logs;
        }

        function searchETPNs(){
            $ETPNs = [];
                foreach ($this->mbd->query(
                    "SELECT
                        Eurotech_PN
                    FROM products
                    WHERE Product = 'BluSeal'
                    ORDER BY Eurotech_PN;"
                ) as $ETPN) {
                    $ETPNs[] = $ETPN;
                }
            return $ETPNs;
        }

        function searchDescriptions(){
            $Descriptions = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        `Description`
                    FROM products
                    WHERE Product = 'BluSeal'
                    ORDER BY `Description`;"
                ) as $Description) {
                    $Descriptions[] = $Description;
                }
            return $Descriptions;
        }

        function searchSuppliers(){
            $Suppliers = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Supplier
                    FROM products
                    WHERE Product = 'BluSeal'
                    ORDER BY Supplier;"
                ) as $Supplier) {
                    $Suppliers[] = $Supplier;
                }
            return $Suppliers;
        }

        function searchSuppliersPN(){
            $SuppliersPN = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        Supplier_PN
                    FROM products
                    WHERE Product = 'BluSeal'
                    ORDER BY Supplier_PN;"
                ) as $SupplierPN) {
                    $SuppliersPN[] = $SupplierPN;
                }
            return $SuppliersPN;
        }



        // function searchProducts(){
        //     $Products = [];
        //     $Products = ['BluSeal', 'Cables', 'Tapes', 'Tubes'];
        //     return $Products;
        // }
    }
?>