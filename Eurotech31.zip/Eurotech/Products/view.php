<link href="./css/style.css" rel="stylesheet">
<style>
    details {
        background-color: #ffffff;
        border: 1px solid #d1d5db;
        border-radius: 10px;
        padding: 0.75rem 1rem;
        margin-bottom: 1rem;
    }

    details[open] {
        background-color: #ffffff;
        border-color: #9ca3af;
    }

    summary {
        cursor: pointer;
        font-size: 18px;
        font-weight: 600;
        color: #374151;
        list-style: none;
        display: flex;
        align-items: center;
    }

    summary::marker {
        display: none;
    }

    summary::after {
        content: "▸";
        font-size: 25px;
        margin-left: auto;
        color: #6b7280;
        transition: transform 0.3s ease;
    }

    details[open] summary::after {
        transform: rotate(90deg);
    }

    details summary:hover {
        color: #111827;
    }
    
    tr {
        border: 0.1px solid black;
    }
    
    .clear {
        color: white;
        padding: 8px 14px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
        transition: background-color 0.2s;
        font-size: 14px;
        background-color: #16bacfff;
    }

    .clear:hover {
        background-color: #1dd1e8ff;
        color: white;
    }

    .error {
        background-color: #ffe6e6;
        color: #d63031;
        padding: 10px;
        border-radius: 8px;
        margin-bottom: 15px;
        font-size: 0.9rem;
    }

    .form-search .camp {
        flex: 1 1 30%;
        min-width: 250px;
    }

    .form-search input[type="date"]{
        padding: 8px 10px;
        border: 1px solid #bbb;
        border-radius: 8px;
        width: 46%;
        box-sizing: border-box;
    }

    @media (max-width: 1630px) {
        .note {
            padding: 15px 10px;
        }
    }
    
    @media (max-width: 1300px) {
        .form-search .camp
        {
            flex: 1 1 40%;
        }
    }

    @media (max-width: 900px) {
        .form-search .camp
        {
            flex: 1 1 100%;
        }
    }
</style>
<?php if(isset($_COOKIE['open'])) { $_SESSION["Search"] = $_COOKIE['open']; } else { $_SESSION["Search"] = "Open"; } ?>
<details id="details"<?php if(isset($_SESSION["Search"]) && $_SESSION["Search"] == "Open") { echo "open"; } if(isset($_SESSION["Search"]) && $_SESSION["Search"] == "Close") { echo ""; } if(!isset($_SESSION["Search"])) { echo "open"; }?>>  
    <summary style="font-size: 20px;">Search Form</summary>
    <form action="" id="form" method="post" class="form-search">
        <input type="hidden" name="page" value="Products">
        <div class="camp">
            <label>Eurotech PN:</label>
            <input type="text" maxlength="30" name="idsearch" list="ETPNs" value="<?php if ($idsearch != NULL) { echo $idsearch;} ?>">
            <datalist id="ETPNs">
                <?php foreach ($ETPNs as $ETPN) {  ?>
                    <option value="<?php echo $ETPN['Eurotech_PN'] ?>">
                <?php } ?>
            </datalist>
        </div>

        <div class="camp">
            <label>Description:</label>
            <input type="text" maxlength="255" name="descsearch" list="Description" value="<?php if ($descsearch != NULL) { echo $descsearch;} ?>">
            <datalist id="Description">
                <?php foreach ($Descriptions as $Description) {  ?>
                    <option value="<?php echo $Description['Description'] ?>">
                <?php } ?>
            </datalist>
        </div>

        <div class="camp">
            <label>Supplier:</label>
            <input type="text" maxlength="20" name="suppsearch" list="Supplier" value="<?php if ($suppsearch != NULL) { echo $suppsearch;} ?>">
            <datalist id="Supplier">
                <?php foreach ($Suppliers as $Supplier) {  ?>
                    <option value="<?php echo $Supplier['Short_name'] ?>">
                <?php } ?>
            </datalist>
        </div>

        <div class="camp">
            <label>Supplier PN:</label>
            <input type="text" maxlength="12" name="snsearch" list="SupplierPN" value="<?php if ($snsearch != NULL) { echo $snsearch;} ?>">
            <datalist id="SupplierPN">
                <?php foreach ($SuppliersPN as $SupplierPN) {  ?>
                    <option value="<?php echo $SupplierPN['Supplier_PN'] ?>">
                <?php } ?>
            </datalist>
        </div>

        <div class="camp">
            <label>Description (Tapes):</label> 
            <input style="width: 21%;" type="text" maxlength="25" placeholder="Tape" list="Tapes" name="tapesearch" value="<?php if ($tapesearch != NULL) { echo $tapesearch;} ?>"> -
            <input style="width: 21%;" type="text" maxlength="8" placeholder="Width" list="Widths" name="widthsearch" value="<?php if ($widthsearch != NULL) { echo $widthsearch;} ?>"> -
            <input style="width: 21%;" type="text" maxlength="8" placeholder="Length" list="Lengths" name="lengthsearch" value="<?php if ($lengthsearch != NULL) { echo $lengthsearch;} ?>"> -
            <input style="width: 20%;" type="text" maxlength="8" placeholder="Color" list="Colors" name="colorsearch" value="<?php if ($colorsearch != NULL) { echo $colorsearch;} ?>">
            <datalist id="Tapes">
                <?php foreach ($Tapes as $Tape) {  ?>
                    <option value="<?php echo $Tape['Tape'] ?>">
                <?php } ?>
            </datalist>
            <datalist id="Widths">
                <?php foreach ($Widths as $Width) {  ?>
                    <option value="<?php echo $Width['Width'] ?>">
                <?php } ?>
            </datalist>
            <datalist id="Lengths">
                <?php foreach ($Lengths as $Length) {  ?>
                    <option value="<?php echo $Length['Length'] ?>">
                <?php } ?>
            </datalist>
            <datalist id="Colors">
                <?php foreach ($Colors as $Color) {  ?>
                    <option value="<?php echo $Color['Color'] ?>">
                <?php } ?>
            </datalist>
        </div>

        <div class="camp">
            <label>ET Model:</label>
            <input type="text" list="Models" maxlength="10" name="modelsearch" value="<?php if ($modelsearch != NULL) { echo $modelsearch;} ?>">
            <datalist id="Models">
                <?php foreach ($Models as $Model) {  ?>
                    <option value="<?php echo $Model['ET_Model'] ?>">
                <?php } ?>
            </datalist>
        </div>

        <div class="camp">
            <label>ET Dwg:</label>
            <input type="text" list="Dwgs" maxlength="8" name="dwgsearch" value="<?php if ($dwgsearch != NULL) { echo $dwgsearch;} ?>">
            <datalist id="Dwgs">
                <?php foreach ($Dwgs as $Dwg) {  ?>
                    <option value="<?php echo $Dwg['ET_Dwg'] ?>">
                <?php } ?>
            </datalist>
        </div>

        <div class="camp"></div>
        <div class="camp"></div>
        
        <div class="campbtn">
            <button type="submit" name="btnsearch" class="insert">Search</button>
            <button style="margin: 0px 0px 0px 15px;"  type="submit" name="btnsearch" class="clear" onclick="clearForm()">Clear All</button>
        </div>
    </form>
</details>
<br>
<div style="display: flex;">
    <form action="?page=Products" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insert" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="idsearch" value="<?php if(isset($_POST['idsearch'])) { echo $_POST['idsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="snsearch" value="<?php if(isset($_POST['snsearch'])) { echo $_POST['snsearch']; } ?>">
        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="dwgsearch" value="<?php if(isset($_POST['dwgsearch'])) { echo $_POST['dwgsearch']; } ?>">
        <button type="submit" class="insert">New Product</button>
    </form>
</div>

<?php if($logs == NULL) { ?>
    <br>
    <h1>No results.</h1>
<?php } ?>

<?php if($logs != NULL) { ?>
    <div class="table-responsive">
        <table class="table table-bordered" id="Customer_table">
            <tr>    
                <th style="background-color:#1c18AA;"></th>
                <th style="background-color:#1c18AA;"></th>
                <th style="background-color:#1c18AA; color:white" onclick="sortTable(2, 'text')">Eurotech PN</th>
                <th style="background-color:#1c18AA; color:white" onclick="sortTable(3, 'text')">Description</th>
                <th style="background-color:#1c18AA; color:white" onclick="sortTable(4, 'text')">Supplier</th>
                <th style="background-color:#1c18AA; color:white" onclick="sortTable(5, 'text')">Supplier PN</th>
                <th style="background-color:#1c18AA; color:white" onclick="sortTable(6, 'text')">Tape</th>
                <th style="background-color:#1c18AA; color:white" onclick="sortTable(7, 'text')">Width</th>
                <th style="background-color:#1c18AA; color:white" onclick="sortTable(8, 'text')">Lemgth</th>
                <th style="background-color:#1c18AA; color:white" onclick="sortTable(9, 'text')">Color</th>
                <th style="background-color:#1c18AA; color:white" onclick="sortTable(10, 'text')">ET Model</th>
                <th style="background-color:#1c18AA; color:white" onclick="sortTable(11, 'text')">ET Dwg</th>
            </tr>
            
            <?php foreach ($logs as $log) { ?>
                <tr>
                    <td style="text-align: center; vertical-align: middle;">
                        <form action="?page=Products" method="post" style="display:inline;">
                            <input type="hidden" name="edit" value="">
                            <input type="hidden" name="btnsearch" value="1">
                            <input type="hidden" name="idsearch" value="<?php if(isset($_POST['idsearch'])) { echo $_POST['idsearch']; } ?>">
                            <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                            <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
                            <input type="hidden" name="snsearch" value="<?php if(isset($_POST['snsearch'])) { echo $_POST['snsearch']; } ?>">
                            <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                            <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                            <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                            <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                            <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
                            <input type="hidden" name="dwgsearch" value="<?php if(isset($_POST['dwgsearch'])) { echo $_POST['dwgsearch']; } ?>">
                            <input type="hidden" name="IDedit" value="<?php echo $log['Eurotech_PN']; ?>">
                            <button type="submit" class="editar">Edit</button>
                        </form>
                    </td>
                    <td style="text-align: center; vertical-align: middle;">
                        <form action="?page=Products" method="post" style="display:inline;">
                            <input type="hidden" name="delete" value="">
                            <input type="hidden" name="btnsearch" value="1">
                            <input type="hidden" name="idsearch" value="<?php if(isset($_POST['idsearch'])) { echo $_POST['idsearch']; } ?>">
                            <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                            <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
                            <input type="hidden" name="snsearch" value="<?php if(isset($_POST['snsearch'])) { echo $_POST['snsearch']; } ?>">
                            <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                            <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                            <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                            <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                            <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
                            <input type="hidden" name="dwgsearch" value="<?php if(isset($_POST['dwgsearch'])) { echo $_POST['dwgsearch']; } ?>">
                            <input type="hidden" name="IDdelete" value="<?php echo $log['Eurotech_PN']; ?>">
                            <button type="submit" class="eliminar">Delete</button>
                        </form>
                    </td>
                    <td><?php echo $log['Eurotech_PN']; ?></td>
                    <td><?php echo $log['Description']; ?></td>
                    <td><?php if($log['Supplier'] != NULL) { echo $log['Name']; ?> (<?php echo $log['Short_name']; ?>) <?php } ?></td>
                    <td><?php echo $log['Supplier_PN']; ?></td>
                    <td><?php echo $log['Tape']; ?></td>
                    <td><?php echo $log['Width']; ?></td>
                    <td><?php echo $log['Length']; ?></td>
                    <td><?php echo $log['Color']; ?></td>
                    <td><?php echo $log['ET_Model']; ?></td>
                    <td><?php echo $log['ET_Dwg']; ?></td>
                </tr> 
            <?php } ?>
        </table> 
    </div>
<?php } 

 if (isset($_POST['insert'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New Product</h2>
    <?php if (isset($error)) : ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form action="?page=Products" method="post">
        <input type="hidden" name="confirmI" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="idsearch" value="<?php if(isset($_POST['idsearch'])) { echo $_POST['idsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="snsearch" value="<?php if(isset($_POST['snsearch'])) { echo $_POST['snsearch']; } ?>">
        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="dwgsearch" value="<?php if(isset($_POST['dwgsearch'])) { echo $_POST['dwgsearch']; } ?>">
        <label><label style="color:red">*</label> Eurotech PN:</label>
        <input type="text" maxlength="30" name="Eurotech_PN" value="<?php if(isset($_POST['Eurotech_PN'])) { echo $_POST['Eurotech_PN']; } ?>" required> <br>

        <label><label style="color:red">*</label> Description:</label>
        <textarea name="Description" maxlength="225" required><?php if(isset($_POST['Description'])) { echo $_POST['Description']; } ?></textarea> <br>
        
        <label>Supplier:</label>
        <input type="text" maxlength="20" name="Supplier" list="Supplier" value="<?php if(isset($_POST['Supplier'])) { echo $_POST['Supplier']; } ?>"> <br>

        <label>Supplier PN:</label>
        <input type="text" maxlength="12" name="Supplier_PN" list="SupplierPN" value="<?php if(isset($_POST['Supplier_PN'])) { echo $_POST['Supplier_PN']; } ?>"> <br>

        <label>ET Model:</label>
        <input type="text" maxlength="10" name="ET_Model" list="Models" value="<?php if(isset($_POST['ET_Model'])) { echo $_POST['ET_Model']; } ?>"> <br>

        <label>ET Dwg:</label>
        <input type="text" maxlength="8" name="ET_Dwg" list="Dwgs" value="<?php if(isset($_POST['ET_Dwg'])) { echo $_POST['ET_Dwg']; } ?>"> <br>

        <label><label style="color:red">*</label> Product:</label>
        <div>
            <input type="radio" name="product" value="BluSeal" <?php if(isset($_POST['product']) && $_POST['product'] == "BluSeal") { echo 'checked'; } ?> checked> BluSeal
        </div>
        <div>
            <input type="radio" name="product" value="Cable" <?php if(isset($_POST['product']) && $_POST['product'] == "Cable") { echo 'checked'; } ?>> Cable
        </div>
        <div>
            <input type="radio" name="product" value="Tape" <?php if(isset($_POST['product']) && $_POST['product'] == "Tape") { echo 'checked'; } ?>> Tape
        </div>
        <div>
            <input type="radio" name="product" value="Tube" <?php if(isset($_POST['product']) && $_POST['product'] == "Tube") { echo 'checked'; } ?>> Tube
        </div>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if (isset($_POST['edit'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Update Product</h2>
    <?php if (isset($error)) : ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form action="?page=Products" method="post">
        <input type="hidden" name="confirmU" value="1">
        <input type="hidden" name="Eurotech_PN" value="<?php if(isset($_POST['Eurotech_PN'])) { echo $_POST['Eurotech_PN']; } else { echo $_POST['IDedit']; } ?>">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="idsearch" value="<?php if(isset($_POST['idsearch'])) { echo $_POST['idsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="snsearch" value="<?php if(isset($_POST['snsearch'])) { echo $_POST['snsearch']; } ?>">
        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="dwgsearch" value="<?php if(isset($_POST['dwgsearch'])) { echo $_POST['dwgsearch']; } ?>">
        <label><label style="color:red">*</label> Description:</label>
        <textarea name="Description" maxlength="225" required><?php if(isset($productsData['Description'])) { echo $productsData['Description']; } else { if(isset($_POST['Description'])) { echo $_POST['Description'];  } } ?></textarea> <br>
        
        <label>Supplier:</label>
        <input type="text" maxlength="20" list="Supplier" name="Supplier" value="<?php if(isset($productsData['Short_name'])) { echo $productsData['Short_name']; } else { if(isset($_POST['Supplier'])) { echo $_POST['Supplier'];  } } ?>"> <br>

        <label>Supplier PN:</label>
        <input type="text" maxlength="12" list="SupplierPN" name="Supplier_PN" value="<?php if(isset($productsData['Supplier_PN'])) { echo $productsData['Supplier_PN']; } else { if(isset($_POST['Supplier_PN'])) { echo $_POST['Supplier_PN'];  } } ?>"> <br>

        <label>ET Model:</label>
        <input type="text" maxlength="10" list="Models" name="ET_Model" value="<?php if(isset($productsData['ET_Model'])) { echo $productsData['ET_Model']; } else { if(isset($_POST['ET_Model'])) { echo $_POST['ET_Model'];  } } ?>"> <br>

        <label>ET Dwg:</label>
        <input type="text" maxlength="8" list="Dwgs" name="ET_Dwg" value="<?php if(isset($productsData['ET_Dwg'])) { echo $productsData['ET_Dwg']; } else { if(isset($_POST['ET_Dwg'])) { echo $_POST['ET_Dwg'];  } } ?>"> <br>

        <label><label style="color:red">*</label> Product:</label>
        <div>
            <input type="radio" name="product" value="BluSeal" <?php if(isset($productsData['Product']) && $productsData['Product'] == "BluSeal") { echo 'checked'; } else { if(isset($_POST['product']) && $_POST['product'] == "BluSeal") { echo 'checked';} } ?> checked> BluSeal
        </div>
        <div>
            <input type="radio" name="product" value="Cable" <?php if(isset($productsData['Product']) && $productsData['Product'] == "Cable") { echo 'checked'; } else { if(isset($_POST['product']) && $_POST['product'] == "Cable") { echo 'checked';} } ?>> Cable
        </div>
        <div>
            <input type="radio" name="product" value="Tape" <?php if(isset($productsData['Product']) && $productsData['Product'] == "Tape") { echo 'checked'; } else { if(isset($_POST['product']) && $_POST['product'] == "Tape") { echo 'checked';} } ?>> Tape
        </div>
        <div>
            <input type="radio" name="product" value="Tube" <?php if(isset($productsData['Product']) && $productsData['Product'] == "Tube") { echo 'checked'; } else { if(isset($_POST['product']) && $_POST['product'] == "Tube") { echo 'checked';} } ?>> Tube
        </div>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php }

if (isset($_POST['delete'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Delete Product</h2>

    <form action="?page=Products" method="post">
        <input type="hidden" name="confirmD" value="1">
        <input type="hidden" name="Eurotech_PN" value="<?php if(isset($_POST['Eurotech_PN'])) { echo $_POST['Eurotech_PN']; } else { echo $_POST['IDdelete']; } ?>">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="idsearch" value="<?php if(isset($_POST['idsearch'])) { echo $_POST['idsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="snsearch" value="<?php if(isset($_POST['snsearch'])) { echo $_POST['snsearch']; } ?>">
        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="dwgsearch" value="<?php if(isset($_POST['dwgsearch'])) { echo $_POST['dwgsearch']; } ?>">
        <h5><b>Are you sure you want to delete the data of this Product?</b></h5> 
        <?php if (!isset($error)) : ?>
            <br>
        <?php endif; ?>
        <?php if (isset($error)) : ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>
        <h6><b>Eurotech PN:</b> <?php echo $productsDataD['Eurotech_PN'] ?></h6>
        <h6><b>Description:</b> <?php echo $productsDataD['Description'] ?></h6>
        <h6><b>Supplier:</b> <?php if($productsDataD['Supplier'] != NULL) { echo $productsDataD['Name']; ?> (<?php echo $productsDataD['Short_name'] ?>) <?php } ?></h6>
        <h6><b>Supplier PN:</b> <?php echo $productsDataD['Supplier_PN'] ?></h6>
        <h6><b>ET Model:</b> <?php echo $productsDataD['ET_Model'] ?></h6>
        <h6><b>ET Dwg:</b> <?php echo $productsDataD['ET_Dwg'] ?></h6>
        <h6><b>Product:</b> <?php echo $productsDataD['Product'] ?></h6>

        <button type="submit">Confirm</button>
    </form>
  </div>
</div>
<?php }

if ($Deleted != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Register Deleted</h2>
        
        <form action="?page=Products" method="post">
            <h6><b>The register was deleted correctly.</b></h6>
        </form>
    </div>
    </div>
<?php }   ?>

<script>
    function closeForm() {
        document.getElementById('formularioModal').style.display = 'none';
    }

    function sendForm() {
        closeForm();
        return true;
    }

    function clearForm() {
        document.querySelectorAll("#form input[type='text']").forEach(input => input.value = "");
        document.querySelectorAll("#form input[type='date']").forEach(input => input.value = "");

        const radioButtons = document.querySelectorAll("#form input[type='radio']");
        const defaultValue = '';

        for (const radio of radioButtons) {
            if (radio.value === defaultValue) {
                radio.checked = true;
            }
        }

        const selects = document.querySelectorAll("#form select");

        for (const select of selects) {
            select.value = defaultValue;
        }
    }

    let sortOrder = {};

    function sortTable(columnIndex, type) {
        const table = document.getElementById("Customer_table");
        const rows = Array.from(table.rows).slice(1);
        const isAscending = !sortOrder[columnIndex];
        
        rows.sort((rowA, rowB) => {
            const cellA = rowA.cells[columnIndex].innerText.trim();
            const cellB = rowB.cells[columnIndex].innerText.trim();
            
            if (type === "date") {
                const dateA = new Date(cellA);
                const dateB = new Date(cellB);
                const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
                const dateformatedA = dateA.toLocaleDateString('ja-JP', options);
                const dateformatedB = dateB.toLocaleDateString('ja-JP', options);
                return isAscending ? dateformatedA.localeCompare(dateformatedB) : dateformatedB.localeCompare(dateformatedA);
            } else if (type === "text") {
                return isAscending ? cellA.localeCompare(cellB) : cellB.localeCompare(cellA);
            }
        });

        rows.forEach(row => table.tBodies[0].appendChild(row));
        sortOrder[columnIndex] = isAscending;
    }

    const details = document.getElementById("details");
    details.addEventListener("toggle", () => { 
        if (details.open) {
            document.cookie = "open=Open";
        } 
        else {
            document.cookie = "open=Close";
        }
    });
</script>