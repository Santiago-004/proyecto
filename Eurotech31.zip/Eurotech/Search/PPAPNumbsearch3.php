<?php
header('Content-Type: application/json');

$connection = new mysqli("localhost", "root", "", "eurotechdb");
if ($connection->connect_error) {
    echo json_encode(["success" => false, "error" => "Connection Error"]);
    exit;
}

$Customer = $_POST['Customer'] ?? '';
$Country = $_POST['Country'] ?? '';

if ($Customer !== '') {
    $stmt = $connection->prepare("
        SELECT Customer_PPAP_Number
        FROM customer_ppap_number cppn
        INNER JOIN customers c ON c.Customer_ID = cppn.FK_Customer_ID
        WHERE Name = ? AND Country = ?
        ORDER BY Customer_PPAP_Number LIMIT 1
    ");
    $stmt->bind_param("ss", $Customer, $Country);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($fila = $resultado->fetch_assoc()) {
        echo json_encode([
            "success" => true,
            "Customer_PPAP_Number" => $fila['Customer_PPAP_Number']
        ]);
    } else {
        echo json_encode(["success" => false]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false]);
}

$connection->close();
?>