<?php
    class model {                                        

        public  $mbd;
        
        function cn() {
            $this->mbd = new PDO('mysql:host=localhost;dbname=eurotechdb;port=3306', 'root', '');
            $this->mbd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
        }
    
        function search(){
            $logs = [];
            if (isset($_POST['btnsearch'])) {
                if (!empty($_POST['idsearch']) || !empty($_POST['custsearch']) || !empty($_POST['prodsearch']) || !empty($_POST['imdssearch'])
                        || isset($_POST['bssearch']) || !isset($_POST['bssearch'])
                        || isset($_POST['cabsearch']) || !isset($_POST['cabsearch'])
                        || isset($_POST['tapsearch']) || !isset($_POST['tapsearch'])
                        || isset($_POST['tubsearch']) || !isset($_POST['tubsearch'])
                    ) {
                    $where = [];
                    $params = [];
                    $products = [];

                    if (!empty($_POST['idsearch'])) {
                        $where[] = "Customer_ID = :id";
                        $params[':id'] = $_POST['idsearch'];
                    }
                    
                    if(!empty($_POST['custsearch'])) {
                        $where[] = "`Name` LIKE :cust";
                        $params[':cust'] = $_POST['custsearch']."%";
                    }

                    if (!empty($_POST['prodsearch'])) {
                        $where[] = "Products LIKE :prod";
                        $params[':prod'] = "%".$_POST['prodsearch']."%";
                    }

                    if (!empty($_POST['imdssearch'])) {
                        $where[] = "IMDS_ID_no = :imds";
                        $params[':imds'] = $_POST['imdssearch'];
                    }

                    if(isset($_POST['bssearch']))
                        $products[] = 'BluSeal';
                    else 
                        $_POST['bssearch'] = 'N';

                    if(isset($_POST['cabsearch']))
                        $products[] = 'Cables';
                    else 
                        $_POST['cabsearch'] = 'N';

                    if(isset($_POST['tapsearch']))
                        $products[] = 'Tapes';
                    else 
                        $_POST['tapsearch'] = 'N';

                    if(isset($_POST['tubsearch']))
                        $products[] = 'Tubes';
                    else 
                        $_POST['tubsearch'] = 'N';

                    if($products != NULL) {
                        $where[] = "(Products LIKE '%". implode("%' OR Products LIKE '%", $products)."%')";
                    }
                    else {
                        $where[] = "Products IS NULL";
                    }

                    if(!empty($where)) {
                        $sql = "
                        SELECT 
                            *
                        FROM customers
                        WHERE " . implode(' AND ', $where) . "
                        ORDER BY Customer_ID;";
                    }
                    else {
                        $sql = "
                        SELECT 
                            *
                        FROM customers
                        ORDER BY Customer_ID;";
                    }

                    $stmt = $this->mbd->prepare($sql);
                    $stmt->execute($params);

                    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
                else {
                    foreach ($this->mbd->query(
                        "SELECT 
                            *
                        FROM customers
                        ORDER BY Customer_ID;"
                    ) as $log) {
                        $logs[] = $log;
                    }
                }
            } else {
                foreach ($this->mbd->query(
                    "SELECT 
                        *
                    FROM customers
                    ORDER BY Customer_ID;"
                ) as $log) {
                    $logs[] = $log;
                }
            }
            return $logs;
        }

        function searchIDs(){
            $IDs = [];
                foreach ($this->mbd->query(
                    "SELECT
                        Customer_ID
                    FROM customers
                    ORDER BY Customer_ID;"
                ) as $ID) {
                    $IDs[] = $ID;
                }
            return $IDs;
        }

        function searchCustomers(){
            $Customers = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        `Name`
                    FROM customers
                    ORDER BY `Name`;"
                ) as $Customer) {
                    $Customers[] = $Customer;
                }
            return $Customers;
        }

        function searchIMDS(){
            $IMDSs = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        IMDS_ID_no
                    FROM customers
                    ORDER BY IMDS_ID_no;"
                ) as $IMDS) {
                    $IMDSs[] = $IMDS;
                }
            return $IMDSs;
        }

        function searchProducts(){
            $Products = [];
            $Products = ['BluSeal', 'Cables', 'Tapes', 'Tubes'];
            return $Products;
        }
    }
?>