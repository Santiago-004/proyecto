<link href="./css/style.css" rel="stylesheet">
<style>
    .clear {
        color: white;
        padding: 8px 14px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
        transition: background-color 0.2s;
        font-size: 14px;
        background-color: #16bacfff;
    }

    .clear:hover {
        background-color: #1dd1e8ff;
        color: white;
    }

    .error {
        background-color: #ffe6e6;
        color: #d63031;
        padding: 10px;
        border-radius: 8px;
        margin-bottom: 15px;
        font-size: 0.9rem;
    }

    .renewal {
        color: black;
        padding: 8px 14px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
        transition: background-color 0.2s;
        font-size: 14px;
        background-color: #e6df1dff;
    }

    .renewal:hover {
        background-color: #f9f110ff;
    }

    .form-search .camp{
        flex: 1 1 20%;
    }

    .form-search .camp2 {
        flex: 1 1 40%;
    }

    .form-search .camp3 {
        flex: 1 1 15%;
    }

    .form-search .camp4 {
        flex: 1 1 100%;
    }

    .form-search input[type="date"],
    .form-search input[type="number"] {
        padding: 8px 10px;
        border: 1px solid #bbb;
        border-radius: 8px;
        width: 46%;
        box-sizing: border-box;
    }

    @media (max-width: 1530px) {
        .form-search .camp {
            flex: 1 1 40%; 
            min-width: 300px;
        }
    }

    @media (max-width: 1501px) {
        .form-search input[type="number"] {
            width: 46%;
        }

        .form-search .camp2 {
            flex: 1 1 30%;
        }

        .form-search .camp3 {
            flex: 1 1 20%;
        }
    }

    @media (max-width: 1040px) {
        .form-search .camp {
            flex: 1 1 100%; 
            min-width: 300px;
        }

        .form-search .camp2 {
            flex: 1 1 20%;
        }

        .form-search .camp3 {
            flex: 1 1 20%;
        }
    }
</style>
<form action="" id="form" method="post" class="form-search">
    <?php $MaxYs = $model->searchMaxY(); 
    $newestyear =  $MaxYs[0][0]; ?>
    <input type="hidden" name="page" value="Tapes">
    <div class="camp2"></div>
    <div class="camp2"></div>
    <div class="camp3">
        <label>Renewal Period:</label>
        <input type="number" name="submit1search" min="2020" max="<?php echo (int)(date("Y", strtotime("+2 year"))); ?>" value="<?php if ($submit1search != NULL) { echo $submit1search;} else { $pastyear = (int)(date("Y")); echo $pastyear; }?>" required> -
        <input type="number" name="submit2search" min="2020" max="<?php echo (int)(date("Y", strtotime("+2 year"))); ?>" value="<?php if ($submit2search != NULL) { echo $submit2search;} else { echo $newestyear; }?>" required>
    </div>

    <div class="camp">
        <label>Days to Submit:</label>
        <input type="number" name="days1search" id="days1search" value="<?php if ($days1search != NULL) { echo $days1search;} ?>"> -
        <input type="number" name="days2search" id="days2search" value="<?php if ($days2search != NULL) { echo $days2search;} ?>">
    </div>
    
    <div class="camp">
        <label>PPAP Number:</label>
        <input type="text" name="ppapnsearch" maxlength="10" list="PPAPN" value="<?php if ($ppapnsearch != NULL) { echo $ppapnsearch;} ?>">
        <datalist id="PPAPN">
            <?php foreach ($PPAPNS as $PPAPN) {  ?>
                <option value="<?php echo $PPAPN['PPAP_Number'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>PPAP Req'd by Customer:</label>
        <input type="date" name="date1search" value="<?php if ($date1search != NULL) { echo $date1search;} ?>"> - <input type="date" name="date2search" value="<?php if ($date2search != NULL) { echo $date2search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="req1n" id="" value="" <?php if ($req1n != "N" && $req1n != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="req1n" id="" value="N" <?php if ($req1n == "N") { echo "checked";} ?>> No date        
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="req1n" id="" value="Y" <?php if ($req1n == "Y") { echo "checked";} ?>> W/ date
    </div>

    <div class="camp">
        <label>Current Status:</label>
        <input type="text" name="currentsearch" maxlength="255" list="Current" value="<?php  if ($currentsearch != NULL) { echo $currentsearch;} ?>">
        <datalist id="Current">
            <?php foreach ($Currents as $Current) {  ?>
                <option value="<?php echo $Current['Current_Status'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="curn" id="" value="" <?php if ($curn != "N" && $curn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="curn" id="" value="N" <?php if ($curn == "N") { echo "checked";} ?>> No current status
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="curn" id="" value="Y" <?php if ($curn == "Y") { echo "checked";} ?>> W/ current status
    </div>

    <div class="camp">
        <label>Vendor:</label>
        <input type="text" name="pisearch" maxlength="5" list="PI" value="<?php if ($pisearch != NULL) { echo $pisearch;} ?>">
        <datalist id="PI">
            <?php foreach ($PIS as $PI) {  ?>
                <option value="<?php echo $PI['Short_name'] ?>">
            <?php } ?>
        </datalist>
    </div>
    
    <div class="camp">
        <label>Supplier PN:</label>
        <input type="text" name="sapsearch" maxlength="8" list="SAP" value="<?php if ($sapsearch != NULL) { echo $sapsearch;} ?>">
        <datalist id="SAP">
            <?php foreach ($SAPS as $SAP) {  ?>
                <option value="<?php echo $SAP['Supplier_PN'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>OEM:</label>
        <input type="text" name="oemsearch" maxlength="255" list="OEM" value="<?php if ($oemsearch != NULL) { echo $oemsearch;} ?>">
        <datalist id="OEM">
            <?php foreach ($OEMS as $OEM) {  ?>
                <option value="<?php echo $OEM['OEM'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Customer:</label>
        <input type="text" name="custsearch" maxlength="70" list="Customer" value="<?php if ($custsearch != NULL) { echo $custsearch;} ?>">
        <datalist id="Customer">
            <?php foreach ($Customers as $Customer) {  ?>
                <option value="<?php echo $Customer['Name'] ?>">
            <?php } ?>
        </datalist>
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="cusn" id="" value="" <?php if ($cusn != "N" && $cusn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="cusn" id="" value="N" <?php if ($cusn == "N") { echo "checked";} ?>> No Customer
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="cusn" id="" value="Y" <?php if ($cusn == "Y") { echo "checked";} ?>> W/ Customer
    </div>

    <div class="camp">
        <label>Country:</label>
        <input type="text" name="counsearch" maxlength="30" list="Country" value="<?php if ($counsearch != NULL) { echo $counsearch;} ?>">
        <datalist id="Country">
            <?php foreach ($Countries as $Country) {  ?>
                <option value="<?php echo $Country['Country'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Customer PN:</label>
        <input type="text" name="cpnsearch" maxlength="20" list="CPN" value="<?php if ($cpnsearch != NULL) { echo $cpnsearch;} ?>">
        <datalist id="CPN">
            <?php foreach ($CPNS as $CPN) {  ?>
                <option value="<?php echo $CPN['Customer_PN'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>ET Model:</label>
        <input type="text" name="etmsearch" maxlength="10" list="ETM" value="<?php if ($etmsearch != NULL) { echo $etmsearch;} ?>">
        <datalist id="ETM">
            <?php foreach ($ETMS as $ETM) {  ?>
                <option value="<?php echo $ETM['ET_Model'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>ET Dwg:</label>
        <input type="text" name="etdsearch" maxlength="8" list="ETD" value="<?php if ($etdsearch != NULL) { echo $etdsearch;} ?>">
        <datalist id="ETD">
            <?php foreach ($ETDS as $ETD) {  ?>
                <option value="<?php echo $ETD['ET_Dwg'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Rev:</label>
        <input type="text" name="revsearch" maxlength="5" list="Rev" value="<?php if ($revsearch != NULL) { echo $revsearch;} ?>">
        <datalist id="Rev">
            <?php foreach ($Revs as $Rev) {  ?>
                <option value="<?php echo $Rev['Rev'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>ET PN:</label>
        <input type="text" name="etpnsearch" maxlength="12" list="ETPN" value="<?php if ($etpnsearch != NULL) { echo $etpnsearch;} ?>">
        <datalist id="ETPN">
            <?php foreach ($ETPNS as $ETPN) {  ?>
                <option value="<?php echo $ETPN['Eurotech_PN'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Description:</label> 
        <input type="text" name="descsearch" maxlength="255" list="Desc" value="<?php if ($descsearch != NULL) { echo $descsearch;} ?>">
        <datalist id="Desc">
            <?php foreach ($Descs as $Desc) {  ?>
                <option value="<?php echo $Desc['Description'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>IMDS Number:</label>
        <input type="text" name="imdssearch" maxlength="15" list="IMDS" value="<?php if ($imdssearch != NULL) { echo $imdssearch;} ?>">
        <datalist id="IMDS">
            <?php foreach ($IMDS as $IM) {  ?>
                <option value="<?php echo $IM['IMDS_ID_No'] ?>">
            <?php } ?>
        </datalist>
    </div>
    
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="imdn" id="" value="" <?php if ($imdn != "N" && $imdn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="imdn" id="" value="N" <?php if ($imdn == "N") { echo "checked";} ?>> No IMDS
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="imdn" id="" value="Y" <?php if ($imdn == "Y") { echo "checked";} ?>> W/ IMDS
    </div>

    <div class="camp">
        <label>IMDS Status:</label>
        <input type="text" name="issearch" maxlength="10" list="IS" value="<?php if ($issearch != NULL) { echo $issearch;} ?>">
        <datalist id="IS">
            <?php foreach ($ISS as $IS) {  ?>
                <option value="<?php echo $IS['IMDS_Status'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="imsn" id="" value="" <?php if ($imsn != "N" && $imsn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="imsn" id="" value="N" <?php if ($imsn == "N") { echo "checked";} ?>> No IMDS status
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="imsn" id="" value="Y" <?php if ($imsn == "Y") { echo "checked";} ?>> W/ IMDS status
    </div>

    <div class="camp">
        <label>PPAP docs:</label>
        <input type="text" name="pdsearch" maxlength="15" list="PD" value="<?php if ($pdsearch != NULL) { echo $pdsearch;} ?>">
        <datalist id="PD">
            <?php foreach ($PDS as $PD) {  ?>
                <option value="<?php echo $PD['PPAP_docs'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="ppdn" id="" value="" <?php if ($ppdn != "N" && $ppdn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="ppdn" id="" value="N" <?php if ($ppdn == "N") { echo "checked";} ?>> No PPAP docs
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="ppdn" id="" value="Y" <?php if ($ppdn == "Y") { echo "checked";} ?>> W/ PPAP docs
    </div>

    <div class="camp">
        <label>Level:</label>
        <select name="levelsearch">
            <option value="">All</option>
            <option value="1" <?php if ($levelsearch != NULL && $levelsearch == '1') { echo 'selected';} ?>>1</option>
            <option value="2" <?php if ($levelsearch != NULL && $levelsearch == '2') { echo 'selected';} ?>>2</option>
            <option value="3" <?php if ($levelsearch != NULL && $levelsearch == '3') { echo 'selected';} ?>>3</option>
            <option value="4" <?php if ($levelsearch != NULL && $levelsearch == '4') { echo 'selected';} ?>>4</option>
            <option value="5" <?php if ($levelsearch != NULL && $levelsearch == '5') { echo 'selected';} ?>>5</option>
        </select>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="lvln" id="" value="" <?php if ($lvln != "N" && $lvln != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="lvln" id="" value="N" <?php if ($lvln == "N") { echo "checked";} ?>> No level
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="lvln" id="" value="Y" <?php if ($lvln == "Y") { echo "checked";} ?>> W/ level
    </div>

    <div class="camp">
        <label>PPAP samples status:</label>
        <input type="text" name="psssearch" maxlength="9" list="PSS" value="<?php if ($psssearch != NULL) { echo $psssearch;} ?>">
        <datalist id="PSS">
            <?php foreach ($PSSS as $PSS) {  ?>
                <option value="<?php echo $PSS['Samples_Status'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="pssn" id="" value="" <?php if ($pssn != "N" && $pssn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pssn" id="" value="N" <?php if ($pssn == "N") { echo "checked";} ?>> No PPAP sample status
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pssn" id="" value="Y" <?php if ($pssn == "Y") { echo "checked";} ?>> W/ PPAP sample status
    </div>

    <div class="camp">
        <label>Reason of Submission:</label>
        <input type="text" name="rssearch" maxlength="20" list="RS" value="<?php if ($rssearch != NULL) { echo $rssearch;} ?>">
        <datalist id="RS">
            <?php foreach ($RSS as $RS) {  ?>
                <option value="<?php echo $RS['Reason_submission'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="rosn" id="" value="" <?php if ($rosn != "N" && $rosn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="rosn" id="" value="N" <?php if ($rosn == "N") { echo "checked";} ?>> No reason of submission
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="rosn" id="" value="Y" <?php if ($rosn == "Y") { echo "checked";} ?>> W/ reason of submission
    </div>

    <div class="camp">
        <label>Received Date:</label>
        <input type="date" name="date3search" value="<?php if ($date3search != NULL) { echo $date3search;} ?>"> - <input type="date" name="date4search" value="<?php if ($date4search != NULL) { echo $date4search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="recn" id="" value="" <?php if ($recn != "N" && $recn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="recn" id="" value="N" <?php if ($recn == "N") { echo "checked";} ?>> No date        
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="recn" id="" value="Y" <?php if ($recn == "Y") { echo "checked";} ?>> W/ date
    </div>

    <div class="camp">
        <label>Sent to Customer:</label>
        <input type="date" name="ret1search" value="<?php if ($ret1search != NULL) { echo $ret1search;} ?>"> - <input type="date" name="ret2search" value="<?php if ($ret2search != NULL) { echo $ret2search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="retn" id="" value="" <?php if ($retn != "N" && $retn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="retn" id="" value="N" <?php if ($retn == "N") { echo "checked";} ?>> No date
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="retn" id="" value="Y" <?php if ($retn == "Y") { echo "checked";} ?>> W/ date
    </div>

    <div class="camp">
        <label>PSW returned from Customer Signed:</label>
        <input type="date" name="psw1search" value="<?php if ($psw1search != NULL) { echo $psw1search;} ?>"> - <input type="date" name="psw2search" value="<?php if ($psw2search != NULL) { echo $psw2search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="pscn" id="" value="" <?php if ($pscn != "N" && $pscn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pscn" id="" value="N" <?php if ($pscn == "N") { echo "checked";} ?>> No date
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pscn" id="" value="Y" <?php if ($pscn == "Y") { echo "checked";} ?>> W/ date
    </div>

    <hr style="width: 100%;">
    <div class="camp4">
        <label style="font-size: 20px;"><b>Renewal <?php if ($submit2search != NULL) { echo $submit2search;} else { echo $newestyear; }?></b></label>
    </div>
    <div class="camp">
        <label>Renewal Date:</label>
        <input type="date" name="ren1search" value="<?php if ($ren1search != NULL) { echo $ren1search;} ?>"> - <input type="date" name="ren2search" value="<?php if ($ren2search != NULL) { echo $ren2search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="renn" id="" value="" <?php if ($renn != "N" && $renn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="renn" id="" value="N" <?php if ($renn == "N") { echo "checked";} ?>> No date
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="renn" id="" value="Y" <?php if ($renn == "Y") { echo "checked";} ?>> W/ date
    </div>
    
    <div class="camp">
        <label>When to send Request to CTC:</label>
        <input type="date" name="req1search" value="<?php if ($req1search != NULL) { echo $req1search;} ?>"> - <input type="date" name="req2search" value="<?php if ($req2search != NULL) { echo $req2search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="reqn" id="" value="" <?php if ($reqn != "N" && $reqn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="reqn" id="" value="N" <?php if ($reqn == "N") { echo "checked";} ?>> No date
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="reqn" id="" value="Y" <?php if ($reqn == "Y") { echo "checked";} ?>> W/ date
    </div>
    
    <div class="camp">
        <label>Sent to Customer:</label>
        <input type="date" name="sent1search" value="<?php if ($sent1search != NULL) { echo $sent1search;} ?>"> - <input type="date" name="sent2search" value="<?php if ($sent2search != NULL) { echo $sent2search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="stcn" id="" value="" <?php if ($stcn != "N" && $stcn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="stcn" id="" value="N" <?php if ($stcn == "N") { echo "checked";} ?>> No date
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="stcn" id="" value="Y" <?php if ($stcn == "Y") { echo "checked";} ?>> W/ date
    </div>
    
    <div class="camp">
        <label>PSW returned from Customer signed:</label>
        <input type="date" name="pswr1search" value="<?php if ($pswr1search != NULL) { echo $pswr1search;} ?>"> - <input type="date" name="pswr2search" value="<?php if ($pswr2search != NULL) { echo $pswr2search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="pcsn" id="" value="" <?php if ($pcsn != "N" && $pcsn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pcsn" id="" value="N" <?php if ($pcsn == "N") { echo "checked";} ?>> No date
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pcsn" id="" value="Y" <?php if ($pcsn == "Y") { echo "checked";} ?>> W/ date
    </div>

    <hr style="width: 100%;">
    <div class="camp">
        <label>PPAP from shipments:</label>
        <input type="radio" name="pfsn" value="" <?php if ($pfsn != "N" && $pfsn != "Y") { echo "checked";} ?> checked> All <br>
        <input type="radio" name="pfsn" value="N" <?php if ($pfsn == "N") { echo "checked";} ?>> No <br>
        <input type="radio" name="pfsn" value="Y" <?php if ($pfsn == "Y") { echo "checked";} ?>> Yes
    </div>

    <div class="camp">
        <label>Origin from report:</label>
        <input type="radio" name="originsearch" value="" checked> All <br>
        <input type="radio" name="originsearch" value="N" <?php if ($originsearch == "N") { echo "checked";} ?>> No <br>
        <input type="radio" name="originsearch" value="Y" <?php if ($originsearch == "Y") { echo "checked";} ?>> Yes
    </div>

    <div class="camp">
        <label>Comments:</label>
        <input type="text" name="comsearch" maxlength="255" list="Com" value="<?php if ($comsearch != NULL) { echo $comsearch;} ?>">
        <datalist id="Com">
            <?php foreach ($Coms as $Com) {  ?>
                <option value="<?php echo $Com['Comments'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Inspection Report Number:</label>
        <input type="text" name="irnsearch" maxlength="10" list="IRN" value="<?php if ($irnsearch != NULL) { echo $irnsearch;} ?>">
        <datalist id="IRN">
            <?php foreach ($IRNS as $IRN) {  ?>
                <option value="<?php echo $IRN['Inspection_rep_numb'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp"></div>
    <div class="camp"></div>
    <div class="camp"></div>
    <div class="camp"></div>

    <div class="campbtn">
        <button type="submit" name="btnsearch" class="insert">Search</button>
        <button style="margin: 0px 0px 0px 15px;"  type="submit" name="btnsearch" class="clear" onclick="clearForm()">Clear All</button>
    </div>
</form>

<!-- INSERTS -->
<div style="display: flex;">
    <form action="?page=PPAPs" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insertNP" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
        <button type="submit" class="insert">New PPAP</button>
    </form>
</div>


<?php if($logsTapes == NULL && $logsBluSeal == NULL && $logsCables == NULL && $logsTubes == NULL) { ?>
    <br>
    <h1>No results.</h1>
<?php } ?>

<?php if($logsTapes != NULL || $logsBluSeal != NULL || $logsCables != NULL || $logsTubes != NULL) { ?>
    <div class="table-responsive">
        <table class="table table-bordered" id="PPAP_table">
            <?php if($_SESSION["Role"] == 'Administrator') { ?>
                <tr>
                    <th style="background-color:#1c18AA; color:white" colspan="1" rowspan="2"></th>
                    <th style="background-color:#1c18AA; color:white" colspan="1" rowspan="2"></th>
                    <th style="background-color:#1c18AA; color:white" colspan="1" rowspan="2"></th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(3, 'number')" colspan="1" rowspan="2">Days to Submit</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(4, 'text')" colspan="1" rowspan="2">PPAP Number</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(5, 'date')" colspan="1" rowspan="2">PPAP Req'd by Customer</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(6, 'text')" colspan="1" rowspan="2">Current Status</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(7, 'text')" colspan="1" rowspan="2">Vendor</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(8, 'text')" colspan="1" rowspan="2">Supplier PN</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(9, 'text')" colspan="1" rowspan="2">OEM</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(10, 'text')" colspan="1" rowspan="2">Customer</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(11, 'text')" colspan="1" rowspan="2">Country</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(12, 'text')" colspan="1" rowspan="2">Customer PN</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(13, 'text')" colspan="1" rowspan="2">ET Model</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(14, 'text')" colspan="1" rowspan="2">ET Dwg</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(15, 'text')" colspan="1" rowspan="2">Rev</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(16, 'text')" colspan="1" rowspan="2">ET PN</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(17, 'text')" colspan="1" rowspan="2">Description</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(18, 'text')" colspan="1" rowspan="2">Tape</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(19, 'text')" colspan="1" rowspan="2">Width (MM)</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(20, 'text')" colspan="1" rowspan="2">Length (M)</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(21, 'text')" colspan="1" rowspan="2">Color</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(22, 'text')" colspan="1" rowspan="2">IMDS Number</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(23, 'text')" colspan="1" rowspan="2">IMDS Status</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(24, 'text')" colspan="1" rowspan="2">PPAP docs</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(25, 'text')" colspan="1" rowspan="2">Level</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(26, 'text')" colspan="1" rowspan="2">PPAP samples status</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(27, 'text')" colspan="1" rowspan="2">Reason of Submission</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(28, 'date')" colspan="1" rowspan="2">Received Date</th>
                    <th style="background-color:#1c18AA; color:white" colspan="1" rowspan="2">PPAP ET & IMDS ET</th>
                    <th style="background-color:#1c18AA; color:white" colspan="1" rowspan="2">PSW ET & IMDS ET</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(31, 'date')" colspan="1" rowspan="2">Sent to Customer</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(32, 'date')" colspan="1" rowspan="2">PSW returned from Cust Signed</th>
                    <?php if($submit1search != NULL && $submit2search != NULL) {
                        $sT = 33;
                        for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { ?>
                            <th style="background-color:#1c18AA; color:white" colspan="4"><?php echo $i; ?></th>
                            <?php $sT++; $sT++; $sT++; $sT++;
                        } 
                    } 
                    if($submit1search == NULL && $submit2search == NULL) {
                        $sT = 33;
                        for($i = $pastyear; $i <= $newestyear; $i++) { ?>
                            <th style="background-color:#1c18AA; color:white" colspan="4"><?php echo $i; ?></th>
                            <?php $sT++; $sT++; $sT++; $sT++;
                        } 
                    }?>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(<?php echo $sT; $sT++; ?>, 'number')">PPAP from shipments</th>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(<?php echo $sT; $sT++; ?>, 'text')" colspan="1" rowspan="2">Origin from report</th>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(<?php echo $sT; $sT++; ?>, 'number')">Comments</th>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(<?php echo $sT; $sT++; ?>, 'text')" colspan="1" rowspan="2">Inspection Report Number</th>
                </tr>
                <tr>
                    <?php if($submit1search != NULL && $submit2search != NULL) {
                        $sT2 = 33;
                        for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { ?>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">Renewal Date</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">When to send Request to CTC</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">Sent to Customer</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">PSW returned from Customer signed</th>
                        <?php 
                        } 
                    } 
                    if($submit1search == NULL && $submit2search == NULL) {
                        $sT2 = 33;
                        for($i = $pastyear; $i <= $newestyear; $i++) { ?>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">Renewal Date</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">When to send Request to CTC</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">Sent to Customer</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">PSW returned from Customer signed</th>
                        <?php $sT++; 
                        } 
                    }?>
                </tr>
            <?php } 
            else { ?>
                <tr>
                    <th style="background-color:#1c18AA; color:white" colspan="1" rowspan="2"></th>
                    <th style="background-color:#1c18AA; color:white" colspan="1" rowspan="2"></th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(2, 'number')" colspan="1" rowspan="2">Days to Submit</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(3, 'text')" colspan="1" rowspan="2">PPAP Number</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(4, 'date')" colspan="1" rowspan="2">PPAP Req'd by Customer</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(5, 'text')" colspan="1" rowspan="2">Current Status</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(6, 'text')" colspan="1" rowspan="2">Vendor</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(7, 'text')" colspan="1" rowspan="2">Supplier PN</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(8, 'text')" colspan="1" rowspan="2">OEM</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(9, 'text')" colspan="1" rowspan="2">Customer</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(10, 'text')" colspan="1" rowspan="2">Country</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(11, 'text')" colspan="1" rowspan="2">Customer PN</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(12, 'text')" colspan="1" rowspan="2">ET Model</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(13, 'text')" colspan="1" rowspan="2">ET Dwg</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(14, 'text')" colspan="1" rowspan="2">Rev</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(15, 'text')" colspan="1" rowspan="2">ET PN</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(16, 'text')" colspan="1" rowspan="2">Description</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(17, 'text')" colspan="1" rowspan="2">Tape</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(18, 'text')" colspan="1" rowspan="2">Width (MM)</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(19, 'text')" colspan="1" rowspan="2">Length (M)</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(20, 'text')" colspan="1" rowspan="2">Color</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(21, 'text')" colspan="1" rowspan="2">IMDS Number</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(22, 'text')" colspan="1" rowspan="2">IMDS Status</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(23, 'text')" colspan="1" rowspan="2">PPAP docs</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(24, 'text')" colspan="1" rowspan="2">Level</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(25, 'text')" colspan="1" rowspan="2">PPAP samples status</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(26, 'text')" colspan="1" rowspan="2">Reason of Submission</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(27, 'date')" colspan="1" rowspan="2">Received Date</th>
                    <th style="background-color:#1c18AA; color:white" colspan="1" rowspan="2">PPAP ET & IMDS ET</th>
                    <th style="background-color:#1c18AA; color:white" colspan="1" rowspan="2">PSW ET & IMDS ET</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(30, 'date')" colspan="1" rowspan="2">Sent to Customer</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(31, 'date')" colspan="1" rowspan="2">PSW returned from Cust Signed</th>
                    <?php if($submit1search != NULL && $submit2search != NULL) {
                        $sT = 32;
                        for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { ?>
                            <th style="background-color:#1c18AA; color:white" colspan="4"><?php echo $i; ?></th>
                            <?php $sT++; $sT++; $sT++; $sT++;
                        } 
                    } 
                    if($submit1search == NULL && $submit2search == NULL) {
                        $sT = 32;
                        for($i = $pastyear; $i <= $newestyear; $i++) { ?>
                            <th style="background-color:#1c18AA; color:white" colspan="4"><?php echo $i; ?></th>
                            <?php $sT++; $sT++; $sT++; $sT++;
                        } 
                    }?>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(<?php echo $sT; $sT++; ?>, 'number')">PPAP from shipments</th>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(<?php echo $sT; $sT++; ?>, 'text')" colspan="1" rowspan="2">Origin from report</th>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(<?php echo $sT; $sT++; ?>, 'number')">Comments</th>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(<?php echo $sT; $sT++; ?>, 'text')" colspan="1" rowspan="2">Inspection Report Number</th>
                </tr>
                <tr>
                    <?php if($submit1search != NULL && $submit2search != NULL) {
                        $sT2 = 32;
                        for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { ?>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">Renewal Date</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">When to send Request to CTC</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">Sent to Customer</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">PSW returned from Customer signed</th>
                        <?php 
                        } 
                    } 
                    if($submit1search == NULL && $submit2search == NULL) {
                        $sT2 = 32;
                        for($i = $pastyear; $i <= $newestyear; $i++) { ?>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">Renewal Date</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">When to send Request to CTC</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">Sent to Customer</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">PSW returned from Customer signed</th>
                        <?php $sT++; 
                        } 
                    }?>
                </tr>
                <tr>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2"></th>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2"></th>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(2, 'text')">CUSTOMER</th>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(3, 'text')">OEM</th>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(4, 'text')">Country</th>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(5, 'text')">PPAP Level</th>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(6, 'number')">SAP No.</th>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(7, 'text')">Customer Part No.</th>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(8, 'text')">Tape</th>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(9, 'text')">Width (MM)</th>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(10, 'text')">Length (M)</th>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(11, 'text')">Color</th>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(12, 'number')">IMDS ID no.</th>
                    <th style="background-color:#1c18AA; color:white" colspan="2">INITIAL</th>
                    <?php if($submit1search != NULL && $submit2search != NULL) {
                        $sT = 15;
                        for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { ?>
                            <th style="background-color:#1c18AA; color:white" colspan="4"><?php echo $i; ?></th>
                            <?php $sT++; $sT++; $sT++; $sT++;
                        } 
                    } 
                    if($submit1search == NULL && $submit2search == NULL) {
                        $sT = 15;
                        for($i = $pastyear; $i <= $newestyear; $i++) { ?>
                            <th style="background-color:#1c18AA; color:white" colspan="4"><?php echo $i; ?></th>
                            <?php $sT++; $sT++; $sT++; $sT++;
                        } 
                    }?>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(<?php echo $sT; ?>, 'number')">PPAP from shipments</th>
                    <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2" onclick="sortTable(<?php echo $sT+1; ?>, 'number')">Comments</th>
                </tr>
                <tr>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(13, 'date')">Returned from CTC / Sent to Customer</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(14, 'date')">PSW returned from Customer signed / Sent to CTC</th>
                    <?php if($submit1search != NULL && $submit2search != NULL) {
                        $sT2 = 15;
                        for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { ?>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">Renewal Date</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">When to send Request to CTC</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">Sent to Customer</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">PSW returned from Customer signed</th>
                        <?php 
                        } 
                    } 
                    if($submit1search == NULL && $submit2search == NULL) {
                        $sT2 = 15;
                        for($i = $pastyear; $i <= $newestyear; $i++) { ?>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">Renewal Date</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">When to send Request to CTC</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">Sent to Customer</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(<?php echo $sT2; $sT2++; ?>, 'date')">PSW returned from Customer signed</th>
                        <?php $sT++; 
                        } 
                    }?>
                </tr>
            <?php } 

            if($logsBluSeal != NULL) {
                foreach ($logsBluSeal as $log) { ?>
                    <tr>
                        <?php if($log['Name'] != NULL && $log['Sent_Customer'] == NULL && $log['PPAP_Signed_Date'] == NULL) { ?>
                            <td style="text-align: center; vertical-align: middle;">
                                <form action="?page=PPAPs" method="post" style="display:inline;">
                                    <input type="hidden" name="edit" value="">
                                    <input type="hidden" name="btnsearch" value="1">
                                    <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                    <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                    <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                    <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                    <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                    <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                    <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                    <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                    <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                    <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                    <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                    <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                    <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                    <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                    <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                    <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                    <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                    <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                    <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                    <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                    <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                    <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                    <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
                                    <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                    <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
                                    <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                    <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
                                    <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                    <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
                                    <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
                                    <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
                                    <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
                                    <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
                                    <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
                                    <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                    <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                    <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                    <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                    <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                    <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                    <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                    <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                    <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                    <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                    <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                    <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                    <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                    <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                    <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                    <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                    <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                    <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                    <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
                                    <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
                                    <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                    <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                    <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                    <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                    <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                    <input type="hidden" name="IDedit" value="<?php echo $log['BS_PPAP_ID']; ?>">
                                    <button type="submit" class="editar">Edit</button>
                                </form>
                            </td>
                            <?php if($_SESSION["Role"] == 'Administrator') { ?>
                                <td style="text-align: center; vertical-align: middle;">
                                    <form action="?page=PPAPs" method="post" style="display:inline;">
                                        <input type="hidden" name="delete" value="">
                                        <input type="hidden" name="btnsearch" value="1">
                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
                                        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
                                        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
                                        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
                                        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
                                        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
                                        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
                                        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
                                        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
                                        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                        <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
                                        <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                        <input type="hidden" name="IDdelete" value="<?php echo $log['BS_PPAP_ID']; ?>">
                                        <button type="submit" class="eliminar">Delete</button>
                                    </form>
                                </td>
                            <?php } ?>
                            <td></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <?php if($log['Request_Date'] != NULL) { 
                                $reqDate = new DateTime($log['Request_Date']); ?>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $reqDate->format('m/d/Y') ?></td>
                            <?php } 
                            if($log['Request_Date'] == NULL) { ?>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <?php } ?>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Vendor']; ?> (<?php echo $log['Short_name']; ?>)</td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Supplier_PN']; ?></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Name']; ?></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Customer_PN']; ?></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Eurotech_PN']; ?></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Description']; ?></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['IMDS']; ?></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <?php 
                            if($log['PPAP_Received_Date'] != NULL) { 
                                $recDate = new DateTime($log['PPAP_Received_Date']); ?>
                                <td style="background-color: rgba(0, 150, 255, 0.7);">
                                    <?php echo $recDate->format('m/d/Y') ?>
                                </td>
                                <td style="background-color: rgba(0, 150, 255, 0.7); text-align: center; vertical-align: middle;">
                                    <form action="?page=PPAPs" method="POST">
                                        <input type="hidden" name="noteB" value="">
                                        <input type="hidden" name="btnsearch" value="1">
                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
                                        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
                                        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
                                        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
                                        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
                                        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
                                        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
                                        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
                                        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
                                        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                        <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
                                        <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                        <input type="hidden" name="IDnote" value="<?php echo $log['BS_PPAP_ID'] ?>">
                                        <button type="submit"  class="note">Note</button>
                                    </form>
                                </td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <?php }
                            if($log['PPAP_Received_Date'] == NULL) { ?>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <?php }
                            if($log['Sent_Customer'] != NULL) { 
                                $sentCust = new DateTime($log['Sent_Customer']); ?>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $sentCust->format('m/d/Y') ?></td>
                            <?php }
                            if($log['Sent_Customer'] == NULL) { ?>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <?php } ?>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <?php if($submit1search != NULL && $submit2search != NULL) {
                                for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { ?>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                <?php }
                            } 
                            else {
                                for($i = $pastyear; $i <= $newestyear; $i++) { ?>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                <?php }
                            } ?>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        <?php } 
                        if($log['Name'] != NULL && $log['Sent_Customer'] != NULL && $log['PPAP_Signed_Date'] == NULL) { ?>
                            <td style="text-align: center; vertical-align: middle;">
                                <form action="?page=PPAPs" method="post" style="display:inline;">
                                    <input type="hidden" name="edit" value="">
                                    <input type="hidden" name="btnsearch" value="1">
                                    <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                    <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                    <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                    <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                    <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                    <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                    <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                    <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                    <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                    <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                    <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                    <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                    <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                    <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                    <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                    <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                    <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                    <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                    <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                    <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                    <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                    <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                    <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
                                    <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                    <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
                                    <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                    <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
                                    <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                    <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
                                    <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
                                    <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
                                    <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
                                    <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
                                    <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
                                    <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                    <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                    <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                    <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                    <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                    <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                    <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                    <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                    <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                    <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                    <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                    <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                    <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                    <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                    <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                    <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                    <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                    <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                    <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
                                    <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
                                    <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                    <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                    <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                    <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                    <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                    <input type="hidden" name="IDedit" value="<?php echo $log['BS_PPAP_ID']; ?>">
                                    <button type="submit" class="editar">Edit</button>
                                </form>
                            </td>
                            <?php if($_SESSION["Role"] == 'Administrator') { ?>
                                <td style="text-align: center; vertical-align: middle;">
                                    <form action="?page=PPAPs" method="post" style="display:inline;">
                                        <input type="hidden" name="delete" value="">
                                        <input type="hidden" name="btnsearch" value="1">
                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
                                        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
                                        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
                                        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
                                        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
                                        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
                                        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
                                        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
                                        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
                                        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                        <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
                                        <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                        <input type="hidden" name="IDdelete" value="<?php echo $log['BS_PPAP_ID']; ?>">
                                        <button type="submit" class="eliminar">Delete</button>
                                    </form>
                                </td>
                            <?php } ?>
                            <td></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <?php if($log['Request_Date'] != NULL) { 
                                $reqDate = new DateTime($log['Request_Date']); ?>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $reqDate->format('m/d/Y') ?></td>
                            <?php } 
                            if($log['Request_Date'] == NULL) { ?>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <?php } ?>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Vendor']; ?> (<?php echo $log['Short_name']; ?>)</td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Supplier_PN']; ?></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Name']; ?></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Customer_PN']; ?></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Eurotech_PN']; ?></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Description']; ?></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['IMDS']; ?></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <?php 
                            if($log['PPAP_Received_Date'] != NULL) { 
                                $recDate = new DateTime($log['PPAP_Received_Date']); ?>
                                <td style="background-color: rgba(255, 235, 0, 0.7);">
                                    <?php echo $recDate->format('m/d/Y') ?>
                                </td>
                                <td style="background-color: rgba(255, 235, 0, 0.7); text-align: center; vertical-align: middle;">
                                    <form action="?page=PPAPs" method="POST">
                                        <input type="hidden" name="noteB" value="">
                                        <input type="hidden" name="btnsearch" value="1">
                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
                                        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
                                        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
                                        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
                                        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
                                        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
                                        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
                                        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
                                        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
                                        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                        <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
                                        <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                        <input type="hidden" name="IDnote" value="<?php echo $log['BS_PPAP_ID'] ?>">
                                        <button type="submit"  class="note">Note</button>
                                    </form>
                                </td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <?php }
                            if($log['PPAP_Received_Date'] == NULL) { ?>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <?php }
                            if($log['Sent_Customer'] != NULL) { 
                                $sentCust = new DateTime($log['Sent_Customer']); ?>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $sentCust->format('m/d/Y') ?></td>
                            <?php }
                            if($log['Sent_Customer'] == NULL) { ?>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <?php } ?>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <?php if($submit1search != NULL && $submit2search != NULL) {
                                for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { ?>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                <?php }
                            } 
                            else {
                                for($i = $pastyear; $i <= $newestyear; $i++) { ?>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                <?php }
                            } ?>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        <?php } 
                        if($log['Name'] != NULL && $log['PPAP_Signed_Date'] != NULL) {?>
                            <td style="text-align: center; vertical-align: middle;">
                                <form action="?page=PPAPs" method="post" style="display:inline;">
                                    <input type="hidden" name="edit" value="">
                                    <input type="hidden" name="btnsearch" value="1">
                                    <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
                                        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
                                        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
                                        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
                                        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
                                        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
                                        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
                                        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
                                        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
                                        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                        <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
                                        <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                    <input type="hidden" name="IDedit" value="<?php echo $log['BS_PPAP_ID']; ?>">
                                    <button type="submit" class="editar">Edit</button>
                                </form>
                            </td>
                            <?php if($_SESSION["Role"] == 'Administrator') { ?>
                                <td style="text-align: center; vertical-align: middle;">
                                    <form action="?page=PPAPs" method="post" style="display:inline;">
                                        <input type="hidden" name="delete" value="">
                                        <input type="hidden" name="btnsearch" value="1">
                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
                                        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
                                        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
                                        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
                                        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
                                        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
                                        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
                                        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
                                        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
                                        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                        <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
                                        <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                        <input type="hidden" name="IDdelete" value="<?php echo $log['BS_PPAP_ID']; ?>">
                                        <button type="submit" class="eliminar">Delete</button>
                                    </form>
                                </td>
                            <?php } ?>
                            <td></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <?php if($log['Request_Date'] != NULL) { 
                                $reqDate = new DateTime($log['Request_Date']); ?>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $reqDate->format('m/d/Y') ?></td>
                            <?php }
                            if($log['Request_Date'] == NULL) { ?>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <?php } ?>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Vendor']; ?> (<?php echo $log['Short_name']; ?>)</td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Supplier_PN']; ?></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Name']; ?></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Customer_PN']; ?></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Eurotech_PN']; ?></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Description']; ?></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['IMDS']; ?></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <?php if($log['PPAP_Received_Date'] != NULL) { 
                                $recDate = new DateTime($log['PPAP_Received_Date']); ?>
                                <td style="background-color: rgba(0, 255, 0, 0.5);">
                                    <?php echo $recDate->format('m/d/Y') ?>
                                </td>
                                <td style="background-color: rgba(0, 255, 0, 0.5); text-align: center; vertical-align: middle;">
                                    <form action="?page=PPAPs" method="POST">
                                        <input type="hidden" name="noteB" value="">
                                        <input type="hidden" name="btnsearch" value="1">
                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
                                        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
                                        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
                                        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
                                        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
                                        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
                                        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
                                        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
                                        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
                                        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                        <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
                                        <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                        <input type="hidden" name="IDnote" value="<?php echo $log['BS_PPAP_ID'] ?>">
                                        <button type="submit"  class="note">Note</button>
                                    </form>
                                </td>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <?php }
                            if($log['PPAP_Received_Date'] == NULL) { ?>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <?php }
                            if($log['Sent_Customer'] != NULL) { 
                                $sentCust = new DateTime($log['Sent_Customer']); ?>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $sentCust->format('m/d/Y') ?></td>
                            <?php }
                            if($log['Sent_Customer'] == NULL) { ?>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <?php } 
                            if($log['PPAP_Signed_Date'] != NULL) { 
                                $signDate = new DateTime($log['PPAP_Signed_Date']); ?>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $signDate->format('m/d/Y') ?></td>
                            <?php } 
                            if($submit1search != NULL && $submit2search != NULL) {
                                for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { ?>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                <?php }
                            } 
                            else {
                                for($i = $pastyear; $i <= $newestyear; $i++) { ?>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                <?php }
                            } ?>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        <?php } 
                        if($log['Name'] == NULL) {?>
                            <td></td>
                            <?php if($_SESSION["Role"] == 'Administrator') { ?>
                                <td></td>
                            <?php } ?>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td><?php echo $log['Vendor']; ?> (<?php echo $log['Short_name']; ?>)</td>
                            <td><?php echo $log['Supplier_PN']; ?></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td><?php echo $log['Eurotech_PN']; ?></td>
                            <td><?php echo $log['Description']; ?></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <?php if($submit1search != NULL && $submit2search != NULL) {
                                for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { ?>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                <?php }
                            } 
                            else {
                                for($i = $pastyear; $i <= $newestyear; $i++) { ?>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                <?php }
                            } ?>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        <?php } ?>
                    </tr> 
                <?php } 
            }

            if($logsCables != NULL) {
                foreach ($logsCables as $log) { ?>
                    <tr>
                        <?php if($log['Name'] != NULL && $log['PPAP_Sent_Date'] == NULL && $log['PPAP_Signed_Date'] == NULL) { ?>
                            <td style="text-align: center; vertical-align: middle;">
                                <form action="?page=PPAPs" method="post" style="display:inline;">
                                    <input type="hidden" name="edit" value="">
                                    <input type="hidden" name="btnsearch" value="1">
                                    <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                    <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                    <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                    <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                    <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                    <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                    <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                    <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                    <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                    <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                    <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                    <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                    <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                    <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                    <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                    <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                    <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                    <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                    <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                    <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                    <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                    <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                    <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
                                    <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                    <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
                                    <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                    <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
                                    <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                    <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
                                    <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
                                    <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
                                    <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
                                    <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
                                    <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
                                    <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                    <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                    <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                    <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                    <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                    <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                    <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                    <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                    <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                    <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                    <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                    <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                    <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                    <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                    <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                    <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                    <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                    <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                    <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
                                    <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
                                    <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                    <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                    <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                    <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                    <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                    <input type="hidden" name="IDedit" value="<?= $log['CAB_PPAP_ID']; ?>">
                                    <button type="submit" class="editar">Edit</button>
                                </form>
                            </td>
                            <?php if($_SESSION["Role"] == 'Administrator') { ?>
                                <td style="text-align: center; vertical-align: middle;">
                                    <form action="?page=PPAPs" method="post" style="display:inline;">
                                        <input type="hidden" name="delete" value="">
                                        <input type="hidden" name="btnsearch" value="1">
                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
                                        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
                                        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
                                        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
                                        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
                                        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
                                        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
                                        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
                                        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
                                        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                        <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
                                        <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                        <input type="hidden" name="IDdelete" value="<?= $log['CAB_PPAP_ID']; ?>">
                                        <button type="submit" class="eliminar">Delete</button>
                                    </form>
                                </td>
                            <?php } ?>
                            <td></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <?php if($log['PPAP_Requested_Date'] != NULL) { 
                                $reqDate = new DateTime($log['PPAP_Requested_Date']); ?>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $reqDate->format('m/d/Y') ?></td>
                            <?php }
                            if($log['PPAP_Requested_Date'] == NULL) { ?>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <?php } ?>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Supplier_PN']; ?></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Name']; ?></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Customer_PN']; ?></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Eurotech_PN']; ?></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Description']; ?></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <?php  
                            if($log['PPAP_Received_Date'] != NULL) { 
                                $recDate = new DateTime($log['PPAP_Received_Date']); ?>
                                <td style="background-color: rgba(0, 150, 255, 0.7);">
                                    <?php echo $recDate->format('m/d/Y'); ?> 
                                </td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7); text-align: center; vertical-align: middle;">
                                    <form action="?page=PPAPs" method="POST">
                                        <input type="hidden" name="noteC" value="1">
                                        <input type="hidden" name="btnsearch" value="1">
                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
                                        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
                                        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
                                        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
                                        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
                                        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
                                        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
                                        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
                                        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
                                        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                        <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
                                        <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                        <input type="hidden" name="IDnote" value="<?= $log['CAB_PPAP_ID']; ?>">
                                        <button type="submit"  class="note">Note</button>
                                    </form>
                                </td>
                            <?php }
                            if($log['PPAP_Received_Date'] == NULL) { ?>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <?php } 
                            if($log['PPAP_Sent_Date'] != NULL) { 
                                $sentDate = new DateTime($log['PPAP_Sent_Date']); ?>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $sentDate->format('m/d/Y') ?></td>
                            <?php }
                            if($log['PPAP_Sent_Date'] == NULL) { ?>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <?php }  ?>
                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                            <?php if($submit1search != NULL && $submit2search != NULL) {
                                for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { ?>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                <?php }
                            } 
                            else {
                                for($i = $pastyear; $i <= $newestyear; $i++) { ?>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                <?php }
                            } ?>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        <?php } 
                        if($log['Name'] != NULL && $log['PPAP_Sent_Date'] != NULL && $log['PPAP_Signed_Date'] == NULL) { ?>
                            <td style="text-align: center; vertical-align: middle;">
                                <form action="?page=PPAPs" method="post" style="display:inline;">
                                    <input type="hidden" name="edit" value="">
                                    <input type="hidden" name="btnsearch" value="1">
                                    <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                    <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                    <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                    <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                    <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                    <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                    <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                    <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                    <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                    <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                    <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                    <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                    <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                    <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                    <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                    <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                    <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                    <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                    <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                    <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                    <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                    <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                    <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
                                    <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                    <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
                                    <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                    <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
                                    <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                    <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
                                    <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
                                    <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
                                    <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
                                    <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
                                    <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
                                    <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                    <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                    <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                    <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                    <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                    <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                    <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                    <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                    <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                    <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                    <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                    <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                    <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                    <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                    <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                    <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                    <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                    <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                    <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
                                    <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
                                    <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                    <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                    <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                    <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                    <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                    <input type="hidden" name="IDedit" value="<?= $log['CAB_PPAP_ID']; ?>">
                                    <button type="submit" class="editar">Edit</button>
                                </form>
                            </td>
                            <?php if($_SESSION["Role"] == 'Administrator') { ?>
                                <td style="text-align: center; vertical-align: middle;">
                                    <form action="?page=PPAPs" method="post" style="display:inline;">
                                        <input type="hidden" name="delete" value="">
                                        <input type="hidden" name="btnsearch" value="1">
                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
                                        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
                                        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
                                        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
                                        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
                                        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
                                        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
                                        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
                                        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
                                        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                        <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
                                        <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                        <input type="hidden" name="IDdelete" value="<?= $log['CAB_PPAP_ID']; ?>">
                                        <button type="submit" class="eliminar">Delete</button>
                                    </form>
                                </td>
                            <?php } ?>
                            <td></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <?php if($log['PPAP_Requested_Date'] != NULL) { 
                                $reqDate = new DateTime($log['PPAP_Requested_Date']); ?>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $reqDate->format('m/d/Y') ?></td>
                            <?php }
                            if($log['PPAP_Requested_Date'] == NULL) { ?>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <?php } ?>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Supplier_PN']; ?></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Name']; ?></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Customer_PN']; ?></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Eurotech_PN']; ?></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Description']; ?></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <?php  
                            if($log['PPAP_Received_Date'] != NULL) { 
                                $recDate = new DateTime($log['PPAP_Received_Date']); ?>
                                <td style="background-color: rgba(255, 235, 0, 0.7);">
                                    <?php echo $recDate->format('m/d/Y'); ?> 
                                </td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7); text-align: center; vertical-align: middle;">
                                    <form action="?page=PPAPs" method="POST">
                                        <input type="hidden" name="noteC" value="1">
                                        <input type="hidden" name="btnsearch" value="1">
                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
                                        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
                                        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
                                        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
                                        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
                                        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
                                        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
                                        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
                                        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
                                        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                        <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
                                        <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                        <input type="hidden" name="IDnote" value="<?= $log['CAB_PPAP_ID']; ?>">
                                        <button type="submit"  class="note">Note</button>
                                    </form>
                                </td>
                            <?php }
                            if($log['PPAP_Received_Date'] == NULL) { ?>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <?php } 
                            if($log['PPAP_Sent_Date'] != NULL) { 
                                $sentDate = new DateTime($log['PPAP_Sent_Date']); ?>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $sentDate->format('m/d/Y') ?></td>
                            <?php }
                            if($log['PPAP_Sent_Date'] == NULL) { ?>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <?php }  ?>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                            <?php if($submit1search != NULL && $submit2search != NULL) {
                                for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { ?>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                <?php }
                            } 
                            else {
                                for($i = $pastyear; $i <= $newestyear; $i++) { ?>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                <?php }
                            } ?>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        <?php } 
                        if($log['Name'] != NULL && $log['PPAP_Signed_Date'] != NULL) { ?>
                            <td style="text-align: center; vertical-align: middle;">
                                <form action="?page=PPAPs" method="post" style="display:inline;">
                                    <input type="hidden" name="edit" value="">
                                    <input type="hidden" name="btnsearch" value="1">
                                    <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                    <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                    <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                    <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                    <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                    <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                    <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                    <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                    <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                    <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                    <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                    <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                    <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                    <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                    <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                    <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                    <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                    <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                    <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                    <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                    <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                    <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                    <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
                                    <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                    <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
                                    <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                    <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
                                    <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                    <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
                                    <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
                                    <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
                                    <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
                                    <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
                                    <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
                                    <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                    <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                    <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                    <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                    <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                    <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                    <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                    <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                    <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                    <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                    <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                    <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                    <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                    <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                    <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                    <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                    <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                    <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                    <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
                                    <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
                                    <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                    <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                    <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                    <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                    <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                    <input type="hidden" name="IDedit" value="<?= $log['CAB_PPAP_ID']; ?>">
                                    <button type="submit" class="editar">Edit</button>
                                </form>
                            </td>
                            <?php if($_SESSION["Role"] == 'Administrator') { ?>
                                <td style="text-align: center; vertical-align: middle;">
                                    <form action="?page=PPAPs" method="post" style="display:inline;">
                                        <input type="hidden" name="delete" value="">
                                        <input type="hidden" name="btnsearch" value="1">
                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
                                        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
                                        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
                                        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
                                        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
                                        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
                                        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
                                        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
                                        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
                                        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                        <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
                                        <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                        <input type="hidden" name="IDdelete" value="<?= $log['CAB_PPAP_ID']; ?>">
                                        <button type="submit" class="eliminar">Delete</button>
                                    </form>
                                </td>
                            <?php } ?>
                            <td></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <?php if($log['PPAP_Requested_Date'] != NULL) { 
                                $reqDate = new DateTime($log['PPAP_Requested_Date']); ?>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $reqDate->format('m/d/Y') ?></td>
                            <?php }
                            if($log['PPAP_Requested_Date'] == NULL) { ?>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <?php } ?>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Supplier_PN']; ?></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Name']; ?></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Customer_PN']; ?></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Eurotech_PN']; ?></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Description']; ?></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <?php if($log['PPAP_Received_Date'] != NULL) { 
                                $recDate = new DateTime($log['PPAP_Received_Date']); ?>
                                <td style="background-color: rgba(0, 255, 0, 0.5);">
                                    <?php echo $recDate->format('m/d/Y') ?>
                                    </td>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                <td style="background-color: rgba(0, 255, 0, 0.5); text-align: center; vertical-align: middle;">
                                    <form action="?page=PPAPs" method="POST">
                                        <input type="hidden" name="noteC" value="1">
                                        <input type="hidden" name="btnsearch" value="1">
                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
                                        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
                                        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
                                        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
                                        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
                                        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
                                        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
                                        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
                                        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
                                        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                        <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
                                        <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                        <input type="hidden" name="IDnote" value="<?= $log['CAB_PPAP_ID']; ?>">
                                        <button type="submit"  class="note">Note</button>
                                    </form>
                                </td>
                            <?php }
                            if($log['PPAP_Received_Date'] == NULL) { ?>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <?php } 
                            if($log['PPAP_Sent_Date'] != NULL) { 
                                $sentDate = new DateTime($log['PPAP_Sent_Date']); ?>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $sentDate->format('m/d/Y') ?></td>
                            <?php }
                            if($log['PPAP_Sent_Date'] == NULL) { ?>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                            <?php } 
                            $signDate = new DateTime($log['PPAP_Signed_Date']); ?>
                            <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $signDate->format('m/d/Y') ?></td>
                            <?php if($submit1search != NULL && $submit2search != NULL) {
                                for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { ?>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                <?php }
                            } 
                            else {
                                for($i = $pastyear; $i <= $newestyear; $i++) { ?>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                <?php }
                            } ?>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        <?php } ?>
                        <?php if($log['Name'] == NULL) { ?>
                            <td></td>
                            <?php if($_SESSION["Role"] == 'Administrator') { ?>
                                <td></td>
                            <?php } ?>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td><?php echo $log['Supplier_PN']; ?></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td><?php echo $log['Eurotech_PN']; ?></td>
                            <td><?php echo $log['Description']; ?></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        <?php } ?>
                    </tr> 
                <?php }
            }
            
            if($logsTapes != NULL) {
                foreach ($logsTapes as $log) { ?>
                        <tr>
                            <?php 
                            $MaxYear = $model->searchMaxYearRD($log['TAP_PPAP_ID']);
                            $MaxYearsSCS = $model->searchMaxYearSC($log['TAP_PPAP_ID']);
                            $mx = [];
                            if($MaxYear != NULL && $MaxYearsSCS != NULL){
                                $mx[0] = $MaxYearsSCS[0][1];
                                $mx[1] = $MaxYear[0][1];

                                $maxyearSD = max($mx);
                            }
                            if($MaxYear != NULL && $MaxYearsSCS == NULL){
                                if($MaxYear[0][1] != NULL) {
                                    $maxyearSD = $MaxYear[0][1];
                                }
                                else {
                                    $maxyearSD = NULL;
                                }
                            }
                            if($MaxYear == NULL && $MaxYearsSCS != NULL){
                                if($MaxYearsSCS[0][1] != NULL) {
                                    $maxyearSD = $MaxYearsSCS[0][1];
                                }
                                else {
                                    $maxyearSD = NULL;
                                }
                            }
                            if($MaxYear == NULL && $MaxYearsSCS == NULL){  
                                $maxyearSD = NULL;
                            }

                        

                            if($maxyearSD != NULL) {
                                $dates2 = $model->searchDates2($maxyearSD, $log['TAP_PPAP_ID']);
                            }
                            if($maxyearSD == NULL) {
                                $dates2 = $model->searchDates2($newestyear, $log['TAP_PPAP_ID']);
                            }
                            
                            foreach ($dates2 as $dateN) { 
                                if($dateN['Sent_Customer'] != NULL && $dateN['Returned_Cust_Signed'] != NULL && $log['TAP_PPAP_ID'] == $dateN['TAP_PPAP_ID']) { ?>
                                    <td style="text-align: center; vertical-align: middle;">
                                        <form action="?page=PPAPs" method="post" style="display:inline;">
                                        <input type="hidden" name="edit" value="">
                                            <input type="hidden" name="IDedit" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                            <input type="hidden" name="btnsearch" value="1">
                                            <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                            <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                            <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                            <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                            <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                            <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                            <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                            <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                            <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                            <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                            <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                            <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                            <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                            <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                            <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                            <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                            <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                            <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                            <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                            <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                            <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                            <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                            <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                            <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                            <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                            <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                            <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                            <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                            <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                            <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                            <button type="submit" class="editar">Edit</button>
                                        </form>
                                    </td>
                                    <?php if($_SESSION["Role"] == 'Administrator') { ?>
                                        <td style="text-align: center; vertical-align: middle;">
                                            <form action="?page=PPAPs" method="post" style="display:inline;">
                                            <input type="hidden" name="delete" value="">
                                                <input type="hidden" name="IDdelete" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                <input type="hidden" name="btnsearch" value="1">
                                                <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                <button type="submit" class="eliminar">Delete</button>
                                            </form>
                                        </td>
                                    <?php } ?>
                                    <td style="text-align: center; vertical-align: middle;">
                                        <form action="?page=PPAPs" method="post" style="display:inline;">
                                        <input type="hidden" name="renewal" value="">
                                            <input type="hidden" name="IDPPAP" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                            <input type="hidden" name="InitialSCust" value="<?php echo $log['Returned_CTC-Sent_Cust']; ?>">
                                            <input type="hidden" name="InitialSCTC" value="<?php echo $log['Cust_Signed-Sent_CTC']; ?>">
                                            <input type="hidden" name="btnsearch" value="1">
                                            <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                            <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                            <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                            <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                            <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                            <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                            <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                            <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                            <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                            <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                            <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                            <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                            <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                            <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                            <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                            <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                            <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                            <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                            <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                            <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                            <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                            <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                            <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                            <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                            <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                            <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                            <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                            <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                            <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                            <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                            <button type="submit" class="renewal">Add Renewal</button>
                                        </form>
                                    </td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Supplier_PN']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['OEM']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Name']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Country']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['FK_Customer_PN']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Eurotech_PN']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Description']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Tape']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Width']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Length']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Color']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['IMDS_ID_No']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['PPAP_level']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <?php if($log['Returned_CTC-Sent_Cust'] != NULL) { 
                                        $retCtc = new DateTime($log['Returned_CTC-Sent_Cust']); ?>
                                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $retCtc->format('m/d/Y') ?></td>
                                    <?php }
                                    if($log['Returned_CTC-Sent_Cust'] == NULL) { ?>
                                        <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <?php } 
                                    if($log['Cust_Signed-Sent_CTC'] != NULL) { 
                                        $custSign = new DateTime($log['Cust_Signed-Sent_CTC']); ?>
                                        <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $custSign->format('m/d/Y') ?></td>
                                    <?php }
                                    if($log['Cust_Signed-Sent_CTC'] == NULL) { ?>
                                        <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <?php } 
                                }
                                if($dateN['Sent_Customer'] != NULL && $dateN['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $dateN['TAP_PPAP_ID']) { ?>
                                    <td style="text-align: center; vertical-align: middle;">
                                        <form action="?page=PPAPs" method="post" style="display:inline;">
                                        <input type="hidden" name="edit" value="">
                                            <input type="hidden" name="IDedit" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                            <input type="hidden" name="btnsearch" value="1">
                                            <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                            <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                            <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                            <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                            <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                            <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                            <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                            <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                            <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                            <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                            <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                            <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                            <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                            <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                            <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                            <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                            <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                            <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                            <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                            <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                            <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                            <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                            <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                            <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                            <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                            <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                            <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                            <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                            <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                            <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                            <button type="submit" class="editar">Edit</button>
                                        </form>
                                    </td>
                                    <?php if($_SESSION["Role"] == 'Administrator') { ?>
                                        <td style="text-align: center; vertical-align: middle;">
                                            <form action="?page=PPAPs" method="post" style="display:inline;">
                                            <input type="hidden" name="delete" value="">
                                                <input type="hidden" name="IDdelete" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                <input type="hidden" name="btnsearch" value="1">
                                                <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                <button type="submit" class="eliminar">Delete</button>
                                            </form>
                                        </td>
                                    <?php } ?>
                                    <td style="text-align: center; vertical-align: middle;">
                                        <form action="?page=PPAPs" method="post" style="display:inline;">
                                        <input type="hidden" name="renewal" value="">
                                                    <input type="hidden" name="IDPPAP" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                    <input type="hidden" name="InitialSCust" value="<?php echo $log['Returned_CTC-Sent_Cust']; ?>">
                                                    <input type="hidden" name="InitialSCTC" value="<?php echo $log['Cust_Signed-Sent_CTC']; ?>">
                                                    <input type="hidden" name="btnsearch" value="1">
                                                    <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                    <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                    <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                    <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                    <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                    <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                    <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                    <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                    <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                    <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                    <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                    <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                    <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                    <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                    <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                    <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                    <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                    <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                    <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                    <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                    <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                    <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                    <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                    <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                    <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                    <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                    <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                    <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                    <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                    <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                    <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                    <button type="submit" class="renewal">Add Renewal</button>
                                        </form>
                                    </td>
                                    <?php if($dateN['Renewal_Date'] != NULL) { 
                                        $rD = new DateTime($dateN['Renewal_Date']);
                                        $limit = $rD->modify('+7 days'); 
                                        $renDate = new DateTime($dateN['Renewal_Date']); 
                                        if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['Supplier_PN']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['OEM']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['Name']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['Country']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['FK_Customer_PN']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['Eurotech_PN']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['Description']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['Tape']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['Width']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['Length']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['Color']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['IMDS_ID_No']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['PPAP_level']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"></td>
                                            <?php if($log['Returned_CTC-Sent_Cust'] != NULL) { 
                                                $retCtc = new DateTime($log['Returned_CTC-Sent_Cust']); ?>
                                                <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $retCtc->format('m/d/Y') ?></td>
                                            <?php }
                                            if($log['Returned_CTC-Sent_Cust'] == NULL) { ?>
                                                <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <?php } 
                                            if($log['Cust_Signed-Sent_CTC'] != NULL) { 
                                                $custSign = new DateTime($log['Cust_Signed-Sent_CTC']); ?>
                                                <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $custSign->format('m/d/Y') ?></td>
                                            <?php }
                                            if($log['Cust_Signed-Sent_CTC'] == NULL) { ?>
                                                <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <?php }  
                                        }
                                        if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Supplier_PN']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['OEM']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Name']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Country']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['FK_Customer_PN']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Eurotech_PN']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Description']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Tape']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Width']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Length']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Color']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['IMDS_ID_No']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['PPAP_level']; ?></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <?php if($log['Returned_CTC-Sent_Cust'] != NULL) { 
                                                $retCtc = new DateTime($log['Returned_CTC-Sent_Cust']); ?>
                                                <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $retCtc->format('m/d/Y') ?></td>
                                            <?php }
                                            if($log['Returned_CTC-Sent_Cust'] == NULL) { ?>
                                                <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <?php } 
                                            if($log['Cust_Signed-Sent_CTC'] != NULL) { 
                                                $custSign = new DateTime($log['Cust_Signed-Sent_CTC']); ?>
                                                <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $custSign->format('m/d/Y') ?></td>
                                            <?php }
                                            if($log['Cust_Signed-Sent_CTC'] == NULL) { ?>
                                                <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <?php }  
                                        } 
                                    } 
                                    else { ?>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Supplier_PN']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['OEM']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Name']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Country']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['FK_Customer_PN']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Eurotech_PN']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Description']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Tape']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Width']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Length']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Color']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['IMDS_ID_No']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['PPAP_level']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <?php if($log['Returned_CTC-Sent_Cust'] != NULL) { 
                                            $retCtc = new DateTime($log['Returned_CTC-Sent_Cust']); ?>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $retCtc->format('m/d/Y') ?></td>
                                        <?php }
                                        if($log['Returned_CTC-Sent_Cust'] == NULL) { ?>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <?php } 
                                        if($log['Cust_Signed-Sent_CTC'] != NULL) { 
                                            $custSign = new DateTime($log['Cust_Signed-Sent_CTC']); ?>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $custSign->format('m/d/Y') ?></td>
                                        <?php }
                                        if($log['Cust_Signed-Sent_CTC'] == NULL) { ?>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <?php } 
                                    } 
                                }
                                if($dateN['Sent_Customer'] == NULL && $dateN['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $dateN['TAP_PPAP_ID']) {
                                    if($dateN['Renewal_Date'] != NULL) {
                                        $rD = new DateTime($dateN['Renewal_Date']);
                                        $limit = $rD->modify('+7 days'); 
                                        if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                            <td style="text-align: center; vertical-align: middle;">
                                                <form action="?page=PPAPs" method="post" style="display:inline;">
                                                <input type="hidden" name="edit" value="">
                                                            <input type="hidden" name="IDedit" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                            <input type="hidden" name="btnsearch" value="1">
                                                            <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                            <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                            <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                            <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                            <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                            <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                            <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                            <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                            <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                            <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                            <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                            <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                            <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                            <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                            <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                            <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                            <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                            <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                            <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                            <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                            <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                            <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                            <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                            <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                            <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                            <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                            <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                            <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                            <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                            <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                            <button type="submit" class="editar">Edit</button>
                                                </form>
                                            </td>
                                            <?php if($_SESSION["Role"] == 'Administrator') { ?>
                                                <td style="text-align: center; vertical-align: middle;">
                                                    <form action="?page=PPAPs" method="post" style="display:inline;">
                                                    <input type="hidden" name="delete" value="">
                                                                <input type="hidden" name="IDdelete" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                                <input type="hidden" name="btnsearch" value="1">
                                                                <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                                <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                                <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                                <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                                <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                                <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                                <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                                <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                                <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                                <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                                <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                                <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                                <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                                <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                                <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                                <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                                <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                                <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                                <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                                <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                                <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                                <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                                <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                                <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                                <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                                <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                                <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                                <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                                <button type="submit" class="eliminar">Delete</button>
                                                    </form>
                                                </td>
                                            <?php } ?>
                                            <td style="text-align: center; vertical-align: middle;">
                                                <form action="?page=PPAPs" method="post" style="display:inline;">
                                                <input type="hidden" name="renewal" value="">
                                                            <input type="hidden" name="IDPPAP" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                            <input type="hidden" name="InitialSCust" value="<?php echo $log['Returned_CTC-Sent_Cust']; ?>">
                                                            <input type="hidden" name="InitialSCTC" value="<?php echo $log['Cust_Signed-Sent_CTC']; ?>">
                                                            <input type="hidden" name="btnsearch" value="1">
                                                            <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                            <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                            <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                            <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                            <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                            <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                            <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                            <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                            <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                            <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                            <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                            <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                            <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                            <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                            <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                            <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                            <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                            <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                            <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                            <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                            <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                            <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                            <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                            <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                            <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                            <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                            <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                            <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                            <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                            <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                            <button type="submit" class="renewal">Add Renewal</button>
                                                </form>
                                            </td>
                                            <td style="color: #FF0000;"></td>
                                            <td style="color: #FF0000;"></td>
                                            <td style="color: #FF0000;"></td>
                                            <td style="color: #FF0000;"></td>
                                            <td style="color: #FF0000;"></td>
                                            <td style="color: #FF0000;"><?php echo $log['Supplier_PN']; ?></td>
                                            <td style="color: #FF0000;"><?php echo $log['OEM']; ?></td>
                                            <td style="color: #FF0000;"><?php echo $log['Name']; ?></td>
                                            <td style="color: #FF0000;"><?php echo $log['Country']; ?></td>
                                            <td style="color: #FF0000;"><?php echo $log['FK_Customer_PN']; ?></td>
                                            <td style="color: #FF0000;"></td>
                                            <td style="color: #FF0000;"></td>
                                            <td style="color: #FF0000;"></td>
                                            <td style="color: #FF0000;"><?php echo $log['Eurotech_PN']; ?></td>
                                            <td style="color: #FF0000;"><?php echo $log['Description']; ?></td>
                                            <td style="color: #FF0000;"><?php echo $log['Tape']; ?></td>
                                            <td style="color: #FF0000;"><?php echo $log['Width']; ?></td>
                                            <td style="color: #FF0000;"><?php echo $log['Length']; ?></td>
                                            <td style="color: #FF0000;"><?php echo $log['Color']; ?></td>
                                            <td style="color: #FF0000;"><?php echo $log['IMDS_ID_No']; ?></td>
                                            <td style="color: #FF0000;"></td>
                                            <td style="color: #FF0000;"></td>
                                            <td style="color: #FF0000;"><?php echo $log['PPAP_level']; ?></td>
                                            <td style="color: #FF0000;"></td>
                                            <td style="color: #FF0000;"></td>
                                            <td style="color: #FF0000;"></td>
                                            <td style="color: #FF0000;"></td>
                                            <td style="color: #FF0000;"></td>
                                            <?php if($log['Returned_CTC-Sent_Cust'] != NULL) { 
                                                $retCtc = new DateTime($log['Returned_CTC-Sent_Cust']); ?>
                                                <td style="color: #FF0000;"><?php echo $retCtc->format('m/d/Y') ?></td>
                                            <?php }
                                            if($log['Returned_CTC-Sent_Cust'] == NULL) { ?>
                                                <td style="color: #FF0000;"></td>
                                            <?php } 
                                            if($log['Cust_Signed-Sent_CTC'] != NULL) { 
                                                $custSign = new DateTime($log['Cust_Signed-Sent_CTC']); ?>
                                                <td style="color: #FF0000;"><?php echo $custSign->format('m/d/Y') ?></td>
                                            <?php }
                                            if($log['Cust_Signed-Sent_CTC'] == NULL) { ?>
                                                <td style="color: #FF0000;"></td>
                                            <?php } 
                                        }
                                        if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                            <td style="text-align: center; vertical-align: middle;">
                                                <form action="?page=PPAPs" method="post" style="display:inline;">
                                                <input type="hidden" name="edit" value="">
                                                            <input type="hidden" name="IDedit" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                            <input type="hidden" name="btnsearch" value="1">
                                                            <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                            <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                            <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                            <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                            <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                            <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                            <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                            <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                            <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                            <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                            <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                            <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                            <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                            <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                            <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                            <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                            <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                            <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                            <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                            <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                            <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                            <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                            <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                            <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                            <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                            <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                            <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                            <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                            <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                            <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                            <button type="submit" class="editar">Edit</button>
                                                </form>
                                            </td>
                                            <?php if($_SESSION["Role"] == 'Administrator') { ?>
                                                <td style="text-align: center; vertical-align: middle;">
                                                    <form action="?page=PPAPs" method="post" style="display:inline;">
                                                    <input type="hidden" name="delete" value="">
                                                                <input type="hidden" name="IDdelete" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                                <input type="hidden" name="btnsearch" value="1">
                                                                <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                                <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                                <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                                <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                                <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                                <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                                <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                                <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                                <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                                <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                                <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                                <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                                <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                                <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                                <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                                <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                                <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                                <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                                <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                                <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                                <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                                <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                                <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                                <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                                <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                                <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                                <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                                <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                                <button type="submit" class="eliminar">Delete</button>
                                                    </form>
                                                </td>
                                            <?php } ?>
                                            <td style="text-align: center; vertical-align: middle;">
                                                <form action="?page=PPAPs" method="post" style="display:inline;">
                                                <input type="hidden" name="renewal" value="">
                                                            <input type="hidden" name="IDPPAP" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                            <input type="hidden" name="InitialSCust" value="<?php echo $log['Returned_CTC-Sent_Cust']; ?>">
                                                            <input type="hidden" name="InitialSCTC" value="<?php echo $log['Cust_Signed-Sent_CTC']; ?>">
                                                            <input type="hidden" name="btnsearch" value="1">
                                                            <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                            <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                            <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                            <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                            <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                            <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                            <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                            <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                            <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                            <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                            <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                            <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                            <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                            <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                            <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                            <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                            <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                            <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                            <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                            <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                            <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                            <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                            <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                            <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                            <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                            <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                            <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                            <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                            <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                            <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                            <button type="submit" class="renewal">Add Renewal</button>
                                                </form>
                                            </td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td><?php echo $log['Supplier_PN']; ?></td>
                                            <td><?php echo $log['OEM']; ?></td>
                                            <td><?php echo $log['Name']; ?></td>
                                            <td><?php echo $log['Country']; ?></td>
                                            <td><?php echo $log['FK_Customer_PN']; ?></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td><?php echo $log['Eurotech_PN']; ?></td>
                                            <td><?php echo $log['Description']; ?></td>
                                            <td><?php echo $log['Tape']; ?></td>
                                            <td><?php echo $log['Width']; ?></td>
                                            <td><?php echo $log['Length']; ?></td>
                                            <td><?php echo $log['Color']; ?></td>
                                            <td><?php echo $log['IMDS_ID_No']; ?></td>
                                            <td></td>
                                            <td></td>
                                            <td><?php echo $log['PPAP_level']; ?></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <?php if($log['Returned_CTC-Sent_Cust'] != NULL) { 
                                                $retCtc = new DateTime($log['Returned_CTC-Sent_Cust']); ?>
                                                <td><?php echo $retCtc->format('m/d/Y') ?></td>
                                            <?php }
                                            if($log['Returned_CTC-Sent_Cust'] == NULL) { ?>
                                                <td></td>
                                            <?php } 
                                            if($log['Cust_Signed-Sent_CTC'] != NULL) { 
                                                $custSign = new DateTime($log['Cust_Signed-Sent_CTC']); ?>
                                                <td><?php echo $custSign->format('m/d/Y') ?></td>
                                            <?php }
                                            if($log['Cust_Signed-Sent_CTC'] == NULL) { ?>
                                                <td></td>
                                            <?php } 
                                        }
                                    }
                                    else { ?>
                                        <td style="text-align: center; vertical-align: middle;">
                                            <form action="?page=PPAPs" method="post" style="display:inline;">
                                            <input type="hidden" name="edit" value="">
                                                        <input type="hidden" name="IDedit" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                        <input type="hidden" name="btnsearch" value="1">
                                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                        <button type="submit" class="editar">Edit</button>
                                            </form>
                                        </td>
                                        <?php if($_SESSION["Role"] == 'Administrator') { ?>
                                            <td style="text-align: center; vertical-align: middle;">
                                                <form action="?page=PPAPs" method="post" style="display:inline;">
                                                <input type="hidden" name="delete" value="">
                                                            <input type="hidden" name="IDdelete" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                            <input type="hidden" name="btnsearch" value="1">
                                                            <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                            <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                            <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                            <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                            <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                            <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                            <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                            <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                            <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                            <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                            <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                            <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                            <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                            <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                            <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                            <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                            <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                            <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                            <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                            <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                            <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                            <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                            <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                            <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                            <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                            <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                            <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                            <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                            <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                            <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                            <button type="submit" class="eliminar">Delete</button>
                                                </form>
                                            </td>
                                        <?php } ?>
                                        <td style="text-align: center; vertical-align: middle;">
                                            <form action="?page=PPAPs" method="post" style="display:inline;">
                                            <input type="hidden" name="renewal" value="">
                                                        <input type="hidden" name="IDPPAP" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                        <input type="hidden" name="InitialSCust" value="<?php echo $log['Returned_CTC-Sent_Cust']; ?>">
                                                        <input type="hidden" name="InitialSCTC" value="<?php echo $log['Cust_Signed-Sent_CTC']; ?>">
                                                        <input type="hidden" name="btnsearch" value="1">
                                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                        <button type="submit" class="renewal">Add Renewal</button>
                                            </form>
                                        </td>
                                        <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Supplier_PN']; ?></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['OEM']; ?></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Name']; ?></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Country']; ?></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['FK_Customer_PN']; ?></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Eurotech_PN']; ?></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Description']; ?></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Tape']; ?></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Width']; ?></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Length']; ?></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Color']; ?></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['IMDS_ID_No']; ?></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['PPAP_level']; ?></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                        <?php if($log['Returned_CTC-Sent_Cust'] != NULL) { 
                                            $retCtc = new DateTime($log['Returned_CTC-Sent_Cust']); ?>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $retCtc->format('m/d/Y') ?></td>
                                        <?php }
                                        if($log['Returned_CTC-Sent_Cust'] == NULL) { ?>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                        <?php } 
                                        if($log['Cust_Signed-Sent_CTC'] != NULL) { 
                                            $custSign = new DateTime($log['Cust_Signed-Sent_CTC']); ?>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $custSign->format('m/d/Y') ?></td>
                                        <?php }
                                        if($log['Cust_Signed-Sent_CTC'] == NULL) { ?>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                        <?php } 
                                    }
                                }
                            }
                                
                            if($submit1search != NULL && $submit2search != NULL) {
                                for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { 
                                    $Renewlogs = $model->searchRenew($log['TAP_PPAP_ID'], $i);
                                    $NRenewlogs = $model->searchNoRenew($log['TAP_PPAP_ID']);
                                    if($Renewlogs == NULL) { 
                                        foreach ($NRenewlogs as $NRenewlog) { 
                                            if($log['TAP_PPAP_ID'] == $NRenewlog['TAP_PPAP_ID']) { ?>
                                                <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                                <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                                <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                                <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <?php }
                                        }
                                        foreach ($dates2 as $date) { 
                                            if($date['Sent_Customer'] != NULL && $date['Returned_Cust_Signed'] != NULL && $log['TAP_PPAP_ID'] == $date['TAP_PPAP_ID']) { ?>
                                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                            <?php }
                                            if($date['Sent_Customer'] != NULL && $date['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $date['TAP_PPAP_ID']) { ?>
                                                    <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                    <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                    <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                    <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <?php }
                                            if($date['Sent_Customer'] == NULL && $date['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $date['TAP_PPAP_ID']) {
                                                if($date['Renewal_Date'] != NULL) {
                                                        $rD = new DateTime($date['Renewal_Date']);
                                                        $limit = $rD->modify('+7 days'); 
                                                        if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                            <td style="color: #FF0000;"></td>
                                                            <td style="color: #FF0000;"></td>
                                                            <td style="color: #FF0000;"></td>
                                                            <td style="color: #FF0000;"></td>
                                                        <?php }
                                                        if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                        <?php }
                                                }
                                            }
                                        }
                                    }
                                    else {
                                        foreach ($Renewlogs as $Renewlog) {  
                                            foreach ($dates2 as $date) { 
                                                        if($date['Sent_Customer'] != NULL && $date['Returned_Cust_Signed'] != NULL && $log['TAP_PPAP_ID'] == $date['TAP_PPAP_ID']) {
                                                            if($Renewlog['Renewal_Date'] != NULL) { 
                                                                $renDate = new DateTime($Renewlog['Renewal_Date']); ?>
                                                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo  $renDate->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if($Renewlog['Renewal_Date'] == NULL) { ?>
                                                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                            <?php }
                                                            if($Renewlog['Sent_Request_CTC'] != NULL) { 
                                                                $sendReq = new DateTime($Renewlog['Sent_Request_CTC']); ?>
                                                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $sendReq->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if($Renewlog['Sent_Request_CTC'] == NULL) { ?>
                                                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                            <?php }
                                                            if($Renewlog['Sent_Customer'] != NULL) { 
                                                                $sentCust = new DateTime($Renewlog['Sent_Customer']); ?>
                                                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $sentCust->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if($Renewlog['Sent_Customer'] == NULL) { ?>
                                                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                            <?php }
                                                            if($Renewlog['Returned_Cust_Signed'] != NULL) { 
                                                                $retCust = new DateTime($Renewlog['Returned_Cust_Signed']); ?>
                                                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $retCust->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if($Renewlog['Returned_Cust_Signed'] == NULL) { ?>
                                                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                            <?php }
                                                        }
                                                        if($date['Renewal_Date'] != NULL && $date['Sent_Customer'] != NULL && $date['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $date['TAP_PPAP_ID']) {
                                                            $rD = new DateTime($date['Renewal_Date']);
                                                            $limit = $rD->modify('+7 days'); 
                                                            if($Renewlog['Renewal_Date'] != NULL) {
                                                                $rDrl = new DateTime($Renewlog['Renewal_Date']);

                                                                if($rDrl->format('Y') == $i) {
                                                                    if($Renewlog['Renewal_Date'] != NULL) { 
                                                                        $renDate = new DateTime($Renewlog['Renewal_Date']); 
                                                                        if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $renDate->format('m/d/Y') ?></td>
                                                                        <?php }
                                                                        if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $renDate->format('m/d/Y') ?></td>
                                                                        <?php } 
                                                                    }
                                                                    if($Renewlog['Renewal_Date'] == NULL) { ?>
                                                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                                    <?php }
                                                                    if($Renewlog['Sent_Request_CTC'] != NULL) { 
                                                                        $sendReq = new DateTime($Renewlog['Sent_Request_CTC']);
                                                                        if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $sendReq->format('m/d/Y') ?></td>
                                                                        <?php }
                                                                        if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $sendReq->format('m/d/Y') ?></td>
                                                                        <?php }
                                                                    }
                                                                    if($Renewlog['Sent_Request_CTC'] == NULL) { ?>
                                                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                                    <?php }
                                                                    if($Renewlog['Sent_Customer'] != NULL) { 
                                                                        $sentCust = new DateTime($Renewlog['Sent_Customer']); 
                                                                        if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $sentCust->format('m/d/Y') ?></td>
                                                                        <?php }
                                                                        if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $sentCust->format('m/d/Y') ?></td>
                                                                        <?php } 
                                                                    }
                                                                    if($Renewlog['Sent_Customer'] == NULL) { ?>
                                                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                                    <?php }
                                                                    if($Renewlog['Returned_Cust_Signed'] != NULL) { 
                                                                        $retCust = new DateTime($Renewlog['Returned_Cust_Signed']); 
                                                                        if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $retCust->format('m/d/Y') ?></td>
                                                                        <?php }
                                                                        if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $retCust->format('m/d/Y') ?></td>
                                                                        <?php } 
                                                                    }
                                                                    if($Renewlog['Returned_Cust_Signed'] == NULL) { ?>
                                                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                                    <?php }
                                                                }
                                                            }
                                                                if($Renewlog['Sent_Customer'] != NULL && $Renewlog['Renewal_Date'] == NULL) {
                                                                    $sDrl = new DateTime($Renewlog['Sent_Customer']);
                                                                    if($sDrl->format('Y') == $i) {
                                                                        if($Renewlog['Renewal_Date'] == NULL) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                                        <?php }
                                                                        if($Renewlog['Sent_Request_CTC'] != NULL) { 
                                                                            $sendReq = new DateTime($Renewlog['Sent_Request_CTC']);
                                                                            if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                                <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $sendReq->format('m/d/Y') ?></td>
                                                                            <?php }
                                                                            if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $sendReq->format('m/d/Y') ?></td>
                                                                            <?php }
                                                                        }
                                                                        if($Renewlog['Sent_Request_CTC'] == NULL) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                                        <?php }
                                                                        if($Renewlog['Sent_Customer'] != NULL) { 
                                                                            $sentCust = new DateTime($Renewlog['Sent_Customer']); 
                                                                            if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                                <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $sentCust->format('m/d/Y') ?></td>
                                                                            <?php }
                                                                            if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $sentCust->format('m/d/Y') ?></td>
                                                                            <?php } 
                                                                        }
                                                                        if($Renewlog['Sent_Customer'] == NULL) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                                        <?php }
                                                                        if($Renewlog['Returned_Cust_Signed'] != NULL) { 
                                                                            $retCust = new DateTime($Renewlog['Returned_Cust_Signed']); 
                                                                            if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                                <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $retCust->format('m/d/Y') ?></td>
                                                                            <?php }
                                                                            if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $retCust->format('m/d/Y') ?></td>
                                                                            <?php } 
                                                                        }
                                                                        if($Renewlog['Returned_Cust_Signed'] == NULL) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                                        <?php }
                                                                    }   
                                                                } 
                                                        }
                                                        if($date['Renewal_Date'] == NULL && $date['Sent_Customer'] != NULL && $date['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $date['TAP_PPAP_ID']) { 
                                                            if($Renewlog['Renewal_Date'] != NULL) { 
                                                                $renDate = new DateTime($Renewlog['Renewal_Date']); ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $renDate->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if($Renewlog['Renewal_Date'] == NULL) { ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                            <?php } 
                                                            if($Renewlog['Sent_Request_CTC'] != NULL) { 
                                                                $sendReq = new DateTime($Renewlog['Sent_Request_CTC']); ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $sendReq->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if($Renewlog['Sent_Request_CTC'] == NULL) { ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                            <?php }
                                                            if($Renewlog['Sent_Customer'] != NULL) { 
                                                                $sentCust = new DateTime($Renewlog['Sent_Customer']); ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $sentCust->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if($Renewlog['Sent_Customer'] == NULL) { ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                            <?php }
                                                            if($Renewlog['Returned_Cust_Signed'] != NULL) { 
                                                                $retCust = new DateTime($Renewlog['Returned_Cust_Signed']); ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $retCust->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if($Renewlog['Returned_Cust_Signed'] == NULL) { ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                            <?php }
                                                        }
                                                        if($date['Renewal_Date'] != NULL && $date['Sent_Customer'] == NULL && $date['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $date['TAP_PPAP_ID']) {
                                                            $rD = new DateTime($date['Renewal_Date']);
                                                            $limit = $rD->modify('+7 days');
                                                            if($Renewlog['Renewal_Date'] != NULL) {      
                                                                $renDate = new DateTime($Renewlog['Renewal_Date']);
                                                                if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                    <td style="color: #FF0000;"><?php echo  $renDate->format('m/d/Y') ?></td>
                                                                <?php }
                                                                if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                    <td><?php echo  $renDate->format('m/d/Y') ?></td>
                                                                <?php }
                                                            }
                                                            if($Renewlog['Renewal_Date'] == NULL) { ?>
                                                                <td></td>
                                                            <?php }
                                                            if($Renewlog['Sent_Request_CTC'] != NULL) { 
                                                                $sendReq = new DateTime($Renewlog['Sent_Request_CTC']); 
                                                                if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                    <td style="color: #FF0000;"><?php echo $sendReq->format('m/d/Y')?></td>
                                                                <?php }
                                                                if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                    <td><?php echo $sendReq->format('m/d/Y') ?></td>
                                                                <?php } 
                                                            }
                                                            if($Renewlog['Sent_Request_CTC'] == NULL) { ?>
                                                                <td></td>
                                                            <?php }
                                                            if($Renewlog['Sent_Customer'] != NULL) { 
                                                                $sentCust = new DateTime($Renewlog['Sent_Customer']); 
                                                                if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                    <td style="color: #FF0000;"><?php echo $sentCust->format('m/d/Y') ?></td>
                                                                <?php }
                                                                if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                    <td><?php echo $sentCust->format('m/d/Y') ?></td>
                                                                <?php } 
                                                            }
                                                            if($Renewlog['Sent_Customer'] == NULL) { ?>
                                                                <td></td>
                                                            <?php }
                                                            if($Renewlog['Returned_Cust_Signed'] != NULL) { 
                                                                $retCust = new DateTime($Renewlog['Returned_Cust_Signed']); 
                                                                if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                    <td style="color: #FF0000;"><?php echo $retCust->format('m/d/Y') ?></td>
                                                                <?php }
                                                                if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                    <td><?php echo $retCust->format('m/d/Y') ?></td>
                                                                <?php } 
                                                            }
                                                            if($Renewlog['Returned_Cust_Signed'] == NULL) { ?>
                                                                <td></td>
                                                            <?php }
                                                        }
                                            }          
                                        }
                                    }
                                } 
                            } 
                            else {
                                for($i = $pastyear; $i <= $newestyear; $i++) { 
                                    $Renewlogs = $model->searchRenew($log['TAP_PPAP_ID'], $i);
                                    $NRenewlogs = $model->searchNoRenew($log['TAP_PPAP_ID']);
                                    if($Renewlogs == NULL) { 
                                        foreach ($NRenewlogs as $NRenewlog) { 
                                            if($log['TAP_PPAP_ID'] == $NRenewlog['TAP_PPAP_ID']) { ?>
                                                <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                                <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                                <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                                <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <?php }
                                        }
                                        foreach ($dates2 as $date) { 
                                            if($date['Sent_Customer'] != NULL && $date['Returned_Cust_Signed'] != NULL && $log['TAP_PPAP_ID'] == $date['TAP_PPAP_ID']) { ?>
                                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                            <?php }
                                            if($date['Sent_Customer'] != NULL && $date['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $date['TAP_PPAP_ID']) { ?>
                                                    <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                    <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                    <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                    <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <?php }
                                            if($date['Sent_Customer'] == NULL && $date['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $date['TAP_PPAP_ID']) {
                                                if($date['Renewal_Date'] != NULL) {
                                                        $rD = new DateTime($date['Renewal_Date']);
                                                        $limit = $rD->modify('+7 days'); 
                                                        if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                            <td style="color: #FF0000;"></td>
                                                            <td style="color: #FF0000;"></td>
                                                            <td style="color: #FF0000;"></td>
                                                            <td style="color: #FF0000;"></td>
                                                        <?php }
                                                        if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                        <?php }
                                                }
                                            }
                                        }
                                    }
                                    else {
                                        foreach ($dates2 as $date) {
                                            foreach ($Renewlogs as $Renewlog) {  
                                                        
                                                        if($date['Sent_Customer'] != NULL && $date['Returned_Cust_Signed'] != NULL && $log['TAP_PPAP_ID'] == $date['TAP_PPAP_ID']) {
                                                            
                                                            if($Renewlog['Renewal_Date'] != NULL) { 
                                                                $renDate = new DateTime($Renewlog['Renewal_Date']); ?>
                                                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo  $renDate->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if($Renewlog['Renewal_Date'] == NULL) { ?>
                                                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                            <?php }
                                                            if($Renewlog['Sent_Request_CTC'] != NULL) { 
                                                                $sendReq = new DateTime($Renewlog['Sent_Request_CTC']); ?>
                                                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $sendReq->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if($Renewlog['Sent_Request_CTC'] == NULL) { ?>
                                                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                            <?php }
                                                            if($Renewlog['Sent_Customer'] != NULL) { 
                                                                $sentCust = new DateTime($Renewlog['Sent_Customer']); ?>
                                                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $sentCust->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if($Renewlog['Sent_Customer'] == NULL) { ?>
                                                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                            <?php }
                                                            if($Renewlog['Returned_Cust_Signed'] != NULL) { 
                                                                $retCust = new DateTime($Renewlog['Returned_Cust_Signed']); ?>
                                                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $retCust->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if($Renewlog['Returned_Cust_Signed'] == NULL) { ?>
                                                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                            <?php }
                                                        }
                                                        if($date['Renewal_Date'] != NULL && $date['Sent_Customer'] != NULL && $date['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $date['TAP_PPAP_ID']) {
                                                            $rD = new DateTime($date['Renewal_Date']);
                                                            $limit = $rD->modify('+7 days'); 
                                                            if($Renewlog['Renewal_Date'] != NULL) {
                                                                $rDrl = new DateTime($Renewlog['Renewal_Date']);

                                                                if($rDrl->format('Y') == $i) {
                                                                    if($Renewlog['Renewal_Date'] != NULL) { 
                                                                        if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $rDrl->format('m/d/Y') ?></td>
                                                                        <?php }
                                                                        if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $rDrl->format('m/d/Y') ?></td>
                                                                        <?php } 
                                                                    }
                                                                    if($Renewlog['Renewal_Date'] == NULL) { ?>
                                                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                                    <?php }
                                                                    if($Renewlog['Sent_Request_CTC'] != NULL) { 
                                                                        $sendReq = new DateTime($Renewlog['Sent_Request_CTC']);
                                                                        if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $sendReq->format('m/d/Y') ?></td>
                                                                        <?php }
                                                                        if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $sendReq->format('m/d/Y') ?></td>
                                                                        <?php }
                                                                    }
                                                                    if($Renewlog['Sent_Request_CTC'] == NULL) { ?>
                                                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                                    <?php }
                                                                    if($Renewlog['Sent_Customer'] != NULL) { 
                                                                        $sentCust = new DateTime($Renewlog['Sent_Customer']); 
                                                                        if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $sentCust->format('m/d/Y') ?></td>
                                                                        <?php }
                                                                        if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $sentCust->format('m/d/Y') ?></td>
                                                                        <?php } 
                                                                    }
                                                                    if($Renewlog['Sent_Customer'] == NULL) { ?>
                                                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                                    <?php }
                                                                    if($Renewlog['Returned_Cust_Signed'] != NULL) { 
                                                                        $retCust = new DateTime($Renewlog['Returned_Cust_Signed']); 
                                                                        if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $retCust->format('m/d/Y') ?></td>
                                                                        <?php }
                                                                        if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $retCust->format('m/d/Y') ?></td>
                                                                        <?php } 
                                                                    }
                                                                    if($Renewlog['Returned_Cust_Signed'] == NULL) { ?>
                                                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                                    <?php }
                                                                }
                                                            }
                                                                if($Renewlog['Sent_Customer'] != NULL && $Renewlog['Renewal_Date'] == NULL) {
                                                                    $sDrl = new DateTime($Renewlog['Sent_Customer']);
                                                                    if($sDrl->format('Y') == $i) {
                                                                        if($Renewlog['Renewal_Date'] == NULL) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                                        <?php }
                                                                        if($Renewlog['Sent_Request_CTC'] != NULL) { 
                                                                            $sendReq = new DateTime($Renewlog['Sent_Request_CTC']);
                                                                            if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                                <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $sendReq->format('m/d/Y') ?></td>
                                                                            <?php }
                                                                            if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $sendReq->format('m/d/Y') ?></td>
                                                                            <?php }
                                                                        }
                                                                        if($Renewlog['Sent_Request_CTC'] == NULL) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                                        <?php }
                                                                        if($Renewlog['Sent_Customer'] != NULL) { 
                                                                            $sentCust = new DateTime($Renewlog['Sent_Customer']); 
                                                                            if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                                <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $sentCust->format('m/d/Y') ?></td>
                                                                            <?php }
                                                                            if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $sentCust->format('m/d/Y') ?></td>
                                                                            <?php } 
                                                                        }
                                                                        if($Renewlog['Sent_Customer'] == NULL) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                                        <?php }
                                                                        if($Renewlog['Returned_Cust_Signed'] != NULL) { 
                                                                            $retCust = new DateTime($Renewlog['Returned_Cust_Signed']); 
                                                                            if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                                <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $retCust->format('m/d/Y') ?></td>
                                                                            <?php }
                                                                            if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $retCust->format('m/d/Y') ?></td>
                                                                            <?php } 
                                                                        }
                                                                        if($Renewlog['Returned_Cust_Signed'] == NULL) { ?>
                                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                                        <?php }
                                                                    }   
                                                                } 
                                                        }
                                                        if($date['Renewal_Date'] == NULL && $date['Sent_Customer'] != NULL && $date['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $date['TAP_PPAP_ID']) { 
                                                            if($Renewlog['Renewal_Date'] != NULL) { 
                                                                $renDate = new DateTime($Renewlog['Renewal_Date']); ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $renDate->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if($Renewlog['Renewal_Date'] == NULL) { ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                            <?php } 
                                                            if($Renewlog['Sent_Request_CTC'] != NULL) { 
                                                                $sendReq = new DateTime($Renewlog['Sent_Request_CTC']); ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $sendReq->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if($Renewlog['Sent_Request_CTC'] == NULL) { ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                            <?php }
                                                            if($Renewlog['Sent_Customer'] != NULL) { 
                                                                $sentCust = new DateTime($Renewlog['Sent_Customer']); ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $sentCust->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if($Renewlog['Sent_Customer'] == NULL) { ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                            <?php }
                                                            if($Renewlog['Returned_Cust_Signed'] != NULL) { 
                                                                $retCust = new DateTime($Renewlog['Returned_Cust_Signed']); ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $retCust->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if($Renewlog['Returned_Cust_Signed'] == NULL) { ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                            <?php }
                                                        }
                                                        if($date['Renewal_Date'] != NULL && $date['Sent_Customer'] == NULL && $date['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $date['TAP_PPAP_ID']) {
                                                            $rD = new DateTime($date['Renewal_Date']);
                                                            $limit = $rD->modify('+7 days'); 
                                                            if($Renewlog['Renewal_Date'] != NULL) { 
                                                                $renDate = new DateTime($Renewlog['Renewal_Date']);
                                                                if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                    <td style="color: #FF0000;"><?php echo  $renDate->format('m/d/Y') ?></td>
                                                                <?php }
                                                                if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                    <td><?php echo  $renDate->format('m/d/Y') ?></td>
                                                                <?php }
                                                            }
                                                            if($Renewlog['Renewal_Date'] == NULL) { ?>
                                                                <td></td>
                                                            <?php }
                                                            if($Renewlog['Sent_Request_CTC'] != NULL) { 
                                                                $sendReq = new DateTime($Renewlog['Sent_Request_CTC']); 
                                                                if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                    <td style="color: #FF0000;"><?php echo $sendReq->format('m/d/Y')?></td>
                                                                <?php }
                                                                if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                    <td><?php echo $sendReq->format('m/d/Y') ?></td>
                                                                <?php } 
                                                            }
                                                            if($Renewlog['Sent_Request_CTC'] == NULL) { ?>
                                                                <td></td>
                                                            <?php }
                                                            if($Renewlog['Sent_Customer'] != NULL) { 
                                                                $sentCust = new DateTime($Renewlog['Sent_Customer']); 
                                                                if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                    <td style="color: #FF0000;"><?php echo $sentCust->format('m/d/Y') ?></td>
                                                                <?php }
                                                                if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                    <td><?php echo $sentCust->format('m/d/Y') ?></td>
                                                                <?php } 
                                                            }
                                                            if($Renewlog['Sent_Customer'] == NULL) { ?>
                                                                <td></td>
                                                            <?php }
                                                            if($Renewlog['Returned_Cust_Signed'] != NULL) { 
                                                                $retCust = new DateTime($Renewlog['Returned_Cust_Signed']); 
                                                                if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                    <td style="color: #FF0000;"><?php echo $retCust->format('m/d/Y') ?></td>
                                                                <?php }
                                                                if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                    <td><?php echo $retCust->format('m/d/Y') ?></td>
                                                                <?php } 
                                                            }
                                                            if($Renewlog['Returned_Cust_Signed'] == NULL) { ?>
                                                                <td></td>
                                                            <?php }
                                                        }
                                            }          
                                        }
                                    }
                                } 
                            } ?> 
                            <td><?php echo $log['PPAP_from_shipments']; ?></td>
                            <td></td>
                            <td><?php echo $log['Comments']; ?></td>
                            <td></td>
                        </tr> 
                <?php } 
            } 
            
            if($logsTubes != NULL) {
                foreach ($logsTubes as $log) { ?>
                    <tr>
                        <td style="text-align: center; vertical-align: middle;">
                            <form action="?page=PPAPs" method="post" style="display:inline;">
                                <input type="hidden" name="edit" value="">
                                <input type="hidden" name="btnsearch" value="1">
                                <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                <input type="hidden" name="countrysearch" value="<?php if(isset($_POST['countrysearch'])) { echo $_POST['countrysearch']; } ?>">
                                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">
                                <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">
                                <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                <input type="hidden" name="IDedit" value="<?php echo $log['TUB_PPAPS_ID']; ?>">
                                <button type="submit" class="editar">Edit</button>
                            </form>
                        </td>
                        <?php if($_SESSION["Role"] == 'Administrator') { ?>
                            <td style="text-align: center; vertical-align: middle;">
                                <form action="?page=PPAPs" method="post" style="display:inline;">
                                    <input type="hidden" name="delete" value="">
                                    <input type="hidden" name="btnsearch" value="1">
                                    <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                    <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                    <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                    <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                    <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                    <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                    <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                    <input type="hidden" name="countrysearch" value="<?php if(isset($_POST['countrysearch'])) { echo $_POST['countrysearch']; } ?>">
                                    <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                    <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                    <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                    <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                    <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                    <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                    <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                    <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">
                                    <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">
                                    <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                    <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                    <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                    <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                    <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                    <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                    <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                    <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                    <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                    <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                    <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                    <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                    <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                    <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                    <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                    <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                    <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                    <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                    <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                    <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                    <input type="hidden" name="IDdelete" value="<?php echo $log['TUB_PPAPS_ID']; ?>">
                                    <button type="submit" class="eliminar">Delete</button>
                                </form>
                            </td>
                        <?php } ?>
                        <td></td>
                        <?php if($log['PPAP_Req_by_Cus_Date'] != NULL) { ?>
                            <?php if($log['Sent_Customer'] != NULL) { ?>
                                <?php if($log['PSW_Returned'] != NULL) { ?>
                                    <td 
                                        <?php if($log['Days to Submit'] <= 18) { ?>
                                            style="background-color: rgba(0, 255, 0, 0.7);"
                                        <?php } 
                                        if($log['Days to Submit'] >= 19 && $log['Days to Submit'] <= 30) { ?>
                                            style="background-color: rgba(255, 255, 26, 0.7);"
                                        <?php } 
                                        if($log['Days to Submit'] >= 31) { ?>
                                            style="background-color: rgba(204, 0, 34, 0.8); color:white;"
                                        <?php } ?>
                                    ><?php echo $log['Days to Submit']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['PPAP_Number']; ?></td>
                                    <?php if($log['PPAP_Req_by_Cus_Date'] != NULL) { 
                                        $reqDate = new DateTime($log['PPAP_Req_by_Cus_Date']); ?>
                                        <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $reqDate->format('m/d/Y') ?></td>
                                    <?php }
                                    if($log['PPAP_Req_by_Cus_Date'] == NULL) { ?>
                                        <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <?php } ?>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Current_Status']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Short_name']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Name']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Country']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Customer_PN']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['ET_Model']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['ET_Dwg']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Rev']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Eurotech_PN']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Description']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['IMDS_Number']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['IMDS_Status']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['PPAP_docs']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Level']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Samples_Status']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Reason_submission']; ?></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <?php if($log['Sent_Customer'] != NULL) { 
                                        $sentCust = new DateTime($log['Sent_Customer']); ?>
                                        <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $sentCust->format('m/d/Y') ?></td>
                                    <?php }
                                    if($log['Sent_Customer'] == NULL) { ?>
                                        <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <?php } 
                                    if($log['PSW_Returned'] != NULL) { 
                                        $pswRet = new DateTime($log['PSW_Returned']); ?>
                                        <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $pswRet->format('m/d/Y') ?></td>
                                    <?php }
                                    if($log['PSW_Returned'] == NULL) { ?>
                                        <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                    <?php } 
                                    if($submit1search != NULL && $submit2search != NULL) {
                                        for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { ?>
                                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                        <?php }
                                    } 
                                    else {
                                        for($i = $pastyear; $i <= $newestyear; $i++) { ?>
                                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                        <?php }
                                    } 
                                } 
                                else { ?>
                                    <td 
                                        <?php if($log['Days to Submit'] <= 18) { ?>
                                            style="background-color: rgba(0, 255, 0, 0.7);"
                                        <?php } 
                                        if($log['Days to Submit'] >= 19 && $log['Days to Submit'] <= 30) { ?>
                                            style="background-color: rgba(255, 255, 26, 0.7);"
                                        <?php } 
                                        if($log['Days to Submit'] >= 31) { ?>
                                            style="background-color: rgba(204, 0, 34, 0.8); color:white;"
                                        <?php } ?>
                                    ><?php echo $log['Days to Submit']; ?></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['PPAP_Number']; ?></td>
                                    <?php if($log['PPAP_Req_by_Cus_Date'] != NULL) { 
                                        $reqDate = new DateTime($log['PPAP_Req_by_Cus_Date']); ?>
                                        <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $reqDate->format('m/d/Y') ?></td>
                                    <?php }
                                    if($log['PPAP_Req_by_Cus_Date'] == NULL) { ?>
                                        <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <?php } ?>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Current_Status']; ?></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Short_name']; ?></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Name']; ?></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Country']; ?></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Customer_PN']; ?></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['ET_Model']; ?></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['ET_Dwg']; ?></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Rev']; ?></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Eurotech_PN']; ?></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Description']; ?></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['IMDS_Number']; ?></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['IMDS_Status']; ?></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['PPAP_docs']; ?></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Level']; ?></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Samples_Status']; ?></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Reason_submission']; ?></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <?php if($log['Sent_Customer'] != NULL) { 
                                        $sentCust = new DateTime($log['Sent_Customer']); ?>
                                        <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $sentCust->format('m/d/Y') ?></td>
                                    <?php }
                                    if($log['Sent_Customer'] == NULL) { ?>
                                        <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <?php } 
                                    if($log['PSW_Returned'] != NULL) { 
                                        $pswRet = new DateTime($log['PSW_Returned']); ?>
                                        <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $pswRet->format('m/d/Y') ?></td>
                                    <?php }
                                    if($log['PSW_Returned'] == NULL) { ?>
                                        <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                    <?php } 
                                    if($submit1search != NULL && $submit2search != NULL) {
                                        for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { ?>
                                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                        <?php }
                                    } 
                                    else {
                                        for($i = $pastyear; $i <= $newestyear; $i++) { ?>
                                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                        <?php }
                                    } 
                                }
                            } 
                            else { ?>
                            <td 
                                        <?php if($log['Days to Submit'] <= 18) { ?>
                                            style="background-color: rgba(0, 255, 0, 0.7);"
                                        <?php } 
                                        if($log['Days to Submit'] >= 19 && $log['Days to Submit'] <= 30) { ?>
                                            style="background-color: rgba(255, 255, 26, 0.7);"
                                        <?php } 
                                        if($log['Days to Submit'] >= 31) { ?>
                                            style="background-color: rgba(204, 0, 34, 0.8); color:white;"
                                        <?php } ?>
                                    ><?php echo $log['Days to Submit']; ?></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['PPAP_Number']; ?></td>
                                    <?php if($log['PPAP_Req_by_Cus_Date'] != NULL) { 
                                        $reqDate = new DateTime($log['PPAP_Req_by_Cus_Date']); ?>
                                        <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $reqDate->format('m/d/Y') ?></td>
                                    <?php }
                                    if($log['PPAP_Req_by_Cus_Date'] == NULL) { ?>
                                        <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <?php } ?>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Current_Status']; ?></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Short_name']; ?></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Name']; ?></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Country']; ?></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Customer_PN']; ?></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['ET_Model']; ?></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['ET_Dwg']; ?></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Rev']; ?></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Eurotech_PN']; ?></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Description']; ?></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['IMDS_Number']; ?></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['IMDS_Status']; ?></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['PPAP_docs']; ?></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Level']; ?></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Samples_Status']; ?></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Reason_submission']; ?></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <?php if($log['Sent_Customer'] != NULL) { 
                                        $sentCust = new DateTime($log['Sent_Customer']); ?>
                                        <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $sentCust->format('m/d/Y') ?></td>
                                    <?php }
                                    if($log['Sent_Customer'] == NULL) { ?>
                                        <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <?php } 
                                    if($log['PSW_Returned'] != NULL) { 
                                        $pswRet = new DateTime($log['PSW_Returned']); ?>
                                        <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $pswRet->format('m/d/Y') ?></td>
                                    <?php }
                                    if($log['PSW_Returned'] == NULL) { ?>
                                        <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                    <?php } 
                                    if($submit1search != NULL && $submit2search != NULL) {
                                        for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { ?>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                        <?php }
                                    } 
                                    else {
                                        for($i = $pastyear; $i <= $newestyear; $i++) { ?>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                            <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                        <?php }
                                    } ?>
                            <?php } 
                        } 
                        else { ?>
                            <td style="background-color: rgba(204, 0, 34, 0.8); color:white;"></td>
                                    <td><?php echo $log['PPAP_Number']; ?></td>
                                    <?php if($log['PPAP_Req_by_Cus_Date'] != NULL) { 
                                        $reqDate = new DateTime($log['PPAP_Req_by_Cus_Date']); ?>
                                        <td><?php echo $reqDate->format('m/d/Y') ?></td>
                                    <?php }
                                    if($log['PPAP_Req_by_Cus_Date'] == NULL) { ?>
                                        <td></td>
                                    <?php } ?>
                                    <td><?php echo $log['Current_Status']; ?></td>
                                    <td><?php echo $log['Short_name']; ?></td>
                                    <td></td>
                                    <td></td>
                                    <td><?php echo $log['Name']; ?></td>
                                    <td><?php echo $log['Country']; ?></td>
                                    <td><?php echo $log['Customer_PN']; ?></td>
                                    <td><?php echo $log['ET_Model']; ?></td>
                                    <td><?php echo $log['ET_Dwg']; ?></td>
                                    <td><?php echo $log['Rev']; ?></td>
                                    <td><?php echo $log['Eurotech_PN']; ?></td>
                                    <td><?php echo $log['Description']; ?></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><?php echo $log['IMDS_Number']; ?></td>
                                    <td><?php echo $log['IMDS_Status']; ?></td>
                                    <td><?php echo $log['PPAP_docs']; ?></td>
                                    <td><?php echo $log['Level']; ?></td>
                                    <td><?php echo $log['Samples_Status']; ?></td>
                                    <td><?php echo $log['Reason_submission']; ?></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <?php if($log['Sent_Customer'] != NULL) { 
                                        $sentCust = new DateTime($log['Sent_Customer']); ?>
                                        <td><?php echo $sentCust->format('m/d/Y') ?></td>
                                    <?php }
                                    if($log['Sent_Customer'] == NULL) { ?>
                                        <td></td>
                                    <?php } 
                                    if($log['PSW_Returned'] != NULL) { 
                                        $pswRet = new DateTime($log['PSW_Returned']); ?>
                                        <td><?php echo $pswRet->format('m/d/Y') ?></td>
                                    <?php }
                                    if($log['PSW_Returned'] == NULL) { ?>
                                        <td></td>
                                    <?php } 
                                    if($submit1search != NULL && $submit2search != NULL) {
                                        for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { ?>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        <?php }
                                    } 
                                    else {
                                        for($i = $pastyear; $i <= $newestyear; $i++) { ?>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        <?php }
                                    } 
                        } ?>
                        <td></td>
                        <td><?php echo $log['Origin_from_report']; ?></td>
                        <td><?php echo $log['Comments']; ?></td>
                        <td><?php echo $log['Inspection_rep_numb']; ?></td>
                    </tr> 
                <?php } 
            } ?>
        </table> 
    </div>
<?php } 

if (isset($_POST['noteB'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Note</h2>
    <form action="?page=PPAPs" method="post">
        <input type="hidden" name="confirmNoteB" value="1">
        <input type="hidden" name="confirmIDNote" value="<?php echo $_POST['IDnote']; ?>">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
        <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
        <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
        <div>
            <input style="width: 10px;" type="checkbox" name="PPAP_ET" <?php if($noteData['PPAP_ET'] != NULL) { echo "checked value='<?php echo 1; ?>'";  } else { echo "value=''"; } ?>> PPAP ET
        </div>

        <div>
            <input style="width: 10px;" type="checkbox" name="IMDS_ET" <?php if($noteData['IMDS_ET'] != NULL) { echo "checked value='<?php echo 1; ?>'";  } else { echo "value=''"; } ?>> IMDS ET
        </div>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if (isset($_POST['noteC'])) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Note</h2>
        <form action="?page=PPAPs" method="post">
            <input type="hidden" name="confirmNoteC" value="">
            <input type="hidden" name="confirmIDNote" value="<?php echo $_POST['IDnote']; ?>">
            <input type="hidden" name="btnsearch" value="1">
            <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
            <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
            <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
            <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
            <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
            <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
            <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
            <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
            <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
            <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
            <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
            <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
            <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
            <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
            <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
            <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
            <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
            <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
            <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
            <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
            <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
            <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
            <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
            <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
            <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
            <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
            <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
            <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
            <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
            <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
            <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
            <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
            <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
            <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
            <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
            <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
            <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
            <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
            <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
            <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
            <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
            <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
            <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
            <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
            <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
            <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
            <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
            <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
            <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
            <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
            <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
            <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
            <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
            <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
            <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
            <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
            <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
            <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">

            <div>
                <input style="width: 10px;" type="checkbox" name="PSW_ET" <?php if($noteData['PSW_ET'] != NULL) { echo "checked value='<?php echo 1; ?>'";  } else { echo "value=''"; } ?>> PSW ET
            </div>

            <div>
                <input style="width: 10px;" type="checkbox" name="IMDS_ET" <?php if($noteData['IMDS_ET'] != NULL) { echo "checked value='<?php echo 1; ?>'";  } else { echo "value=''"; } ?>> IMDS ET
            </div>

            <button type="submit">Save</button>
        </form>
    </div>
    </div>
<?php } 

if (isset($_POST['insertNP'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New PPAP</h2>
    <?php if (isset($error)) : ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form action="?page=PPAPs" method="post">
        <input type="hidden" name="confirmID" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
            <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
            <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
            <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
            <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
            <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
            <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
            <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
            <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
            <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
            <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
            <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
            <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
            <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
            <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
            <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
            <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
            <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
            <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
            <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
            <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
            <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
            <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
            <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
            <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
            <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
            <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
            <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
            <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
            <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
            <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
            <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
            <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
            <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
            <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
            <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
            <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
            <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
            <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
            <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
            <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
            <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
            <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
            <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
            <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
            <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
            <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
            <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
            <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
            <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
            <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
            <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
            <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
            <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
            <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
            <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
            <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
            <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
        <label><label style="color:red">*</label> Description:</label>
        <div class="camp">
            <input style="width: 22%;" maxlength="25" type="text" placeholder="Tape" name="Tape" list="Tape" value="<?php if(isset($_POST['Tape'])) { echo $_POST['Tape']; } ?>" required> -
            <input style="width: 22%;" maxlength="8" type="text" placeholder="Width" name="Width" list="Width" value="<?php if(isset($_POST['Width'])) { echo $_POST['Width']; } ?>" required> -
            <input style="width: 22%;" maxlength="8" type="text" placeholder="Length" name="Length" list="Length" value="<?php if(isset($_POST['Length'])) { echo $_POST['Length']; } ?>" required> -
            <input style="width: 22%;" maxlength="8" type="text" placeholder="Color" name="Color" list="Color" value="<?php if(isset($_POST['Color'])) { echo $_POST['Color']; } ?>" required>
        </div> <br>
        
        <label><label style="color:red">*</label> Customer:</label>
        <input type="text" maxlength="70" name="Name" list="Customer" value="<?php if(isset($_POST['Name'])) { echo $_POST['Name']; } ?>" required> <br>

        <label>OEM:</label>
        <input type="text" maxlength="255" name="OEM" list="OEM" value="<?php if(isset($_POST['OEM'])) { echo $_POST['OEM']; } ?>"> <br>

        <label>Country:</label>
        <input type="text" maxlength="30" name="Country" list="Country" value="<?php if(isset($_POST['Country'])) { echo $_POST['Country']; } ?>"> <br>

        <label>PPAP Level:</label>
        <select name="PPAP_level">
            <option value=""></option>
            <option value="1" <?php if(isset($_POST['PPAP_level']) && $_POST['PPAP_level'] == '1') { echo 'selected'; } ?>>1</option>
            <option value="2" <?php if(isset($_POST['PPAP_level']) && $_POST['PPAP_level'] == '2') { echo 'selected'; } ?>>2</option>
            <option value="3" <?php if(isset($_POST['PPAP_level']) && $_POST['PPAP_level'] == '3') { echo 'selected'; } ?>>3</option>
            <option value="4" <?php if(isset($_POST['PPAP_level']) && $_POST['PPAP_level'] == '4') { echo 'selected'; } ?>>4</option>
            <option value="5" <?php if(isset($_POST['PPAP_level']) && $_POST['PPAP_level'] == '5') { echo 'selected'; } ?>>5</option>
        </select> <br>

        <label>IMDS:</label>
        <input type="text" maxlength="8" name="IMDS" list="IMDS" value="<?php if(isset($_POST['IMDS'])) { echo $_POST['IMDS']; } ?>"> <br>

        <label style="font-size: 20px;">INITIAL</label>
        <label>Returned from CTC / Sent to Customer:</label>
        <input type="date" name="Returned_CTC-Sent_Cust" value="<?php if(isset($_POST['Returned_CTC-Sent_Cust'])) { echo $_POST['Returned_CTC-Sent_Cust']; } ?>"> <br>

        <label>PSW returned from Customer signed / Sent to CTC:</label>
        <input type="date" name="Cust_Signed-Sent_CTC" value="<?php if(isset($_POST['Cust_Signed-Sent_CTC'])) { echo $_POST['Cust_Signed-Sent_CTC']; } ?>"> <br>

        <label>PPAP from shipments:</label required>
        <div>
            <input type="radio" name="PPAP_from_shipments" value="no" <?php if(isset($_POST['PPAP_from_shipments']) && $_POST['PPAP_from_shipments'] == 'no') { echo 'checked'; } ?> checked> No 
        </div>
        <div>
            <input type="radio" name="PPAP_from_shipments" value="*" <?php if(isset($_POST['PPAP_from_shipments']) && $_POST['PPAP_from_shipments'] == '*') { echo 'checked'; } ?>> Yes 
        </div> <br>

        <label>Comments:</label>
        <textarea name="Comments" maxlength="255"><?php if(isset($_POST['Comments'])) { echo $_POST['Comments']; } ?></textarea>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if (isset($_POST['edit'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Update PPAP</h2>
    <?php if (isset($error)) : ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form action="?page=PPAPs" method="post">
        <input type="hidden" name="confirmU" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
            <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
            <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
            <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
            <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
            <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
            <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
            <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
            <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
            <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
            <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
            <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
            <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
            <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
            <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
            <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
            <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
            <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
            <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
            <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
            <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
            <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
            <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
            <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
            <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
            <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
            <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
            <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
            <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
            <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
            <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
            <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
            <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
            <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
            <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
            <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
            <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
            <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
            <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
            <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
            <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
            <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
            <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
            <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
            <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
            <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
            <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
            <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
            <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
            <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
            <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
            <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
            <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
            <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
            <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
            <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
            <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
            <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
        <input type="hidden" name="TAP_PPAP_ID" value="<?php if(isset($_POST['TAP_PPAP_ID'])) { echo $_POST['TAP_PPAP_ID']; } else { echo $tapeData['TAP_PPAP_ID']; } ?>">
        <label>OEM:</label>
        <input type="text" name="OEM" maxlength="255" list="OEM" value="<?php if(isset($_POST['OEM'])) { echo $_POST['OEM']; } else { echo $tapeData['OEM']; } ?>"> <br>

        <label>Country:</label>
        <input type="text" name="Country" maxlength="30" list="Country" value="<?php if(isset($_POST['Country'])) { echo $_POST['Country']; } else { echo $tapeData['Country']; }?>"> <br>

        <label>PPAP Level:</label>
        <select name="PPAP_level" >
            <option value=""></option>
            <option value="1" <?php if($tapeData['PPAP_level'] == '1') { echo 'selected'; } ?>>1</option>
            <option value="2" <?php if($tapeData['PPAP_level'] == '2') { echo 'selected'; } ?>>2</option>
            <option value="3" <?php if($tapeData['PPAP_level'] == '3') { echo 'selected'; } ?>>3</option>
            <option value="4" <?php if($tapeData['PPAP_level'] == '4') { echo 'selected'; } ?>>4</option>
            <option value="5" <?php if($tapeData['PPAP_level'] == '5') { echo 'selected'; } ?>>5</option>
        </select> <br>

        <label>IMDS:</label>
        <input type="text" name="IMDS" maxlength="8" list="IMDS" value="<?php if(isset($_POST['IMDS'])) { echo $_POST['IMDS']; } else { echo $tapeData['IMDS_ID_No']; }?>"> <br>

        <label style="font-size: 20px;">INITIAL</label>
        <label>Returned from CTC / Sent to Customer:</label>
        <input type="date" name="Returned_CTC-Sent_Cust" value="<?php if(isset($_POST['Returned_CTC-Sent_Cust'])) { echo $_POST['Returned_CTC-Sent_Cust']; } else { echo $tapeData['Returned_CTC-Sent_Cust']; }?>"> <br>

        <label>PSW returned from Customer signed / Sent to CTC:</label>
        <input type="date" name="Cust_Signed-Sent_CTC" value="<?php if(isset($_POST['Cust_Signed-Sent_CTC'])) { echo $_POST['Cust_Signed-Sent_CTC']; } else { echo $tapeData['Cust_Signed-Sent_CTC']; }?>"> <br>

        <?php for($j = 0; $j < count($tapeRenewData); $j++) { 
            if($tapeRenewData[$j] != NULL) { 
                if($tapeRenewData[$j][0]['Renewal_Date'] != NULL) {
                    $rD = new DateTime($tapeRenewData[$j][0]['Renewal_Date']);
                    $y = $rD->format('Y'); 
                }
                else {
                    if($tapeRenewData[$j][0]['Sent_Customer'] != NULL) {
                        $scD = new DateTime($tapeRenewData[$j][0]['Sent_Customer']);
                        $y = $scD->format('Y'); 
                    }
                    else {
                        if($tapeRenewData[$j][0]['Returned_Cust_Signed'] != NULL) {
                            $rcsD = new DateTime($tapeRenewData[$j][0]['Returned_Cust_Signed']);
                            $y = $rcsD->format('Y'); 
                        }
                    }
                } ?>
                <label style="font-size: 20px;"><?php echo $y; ?></label>
                <input type="hidden" name="<?php echo 'TAP_Renewal_ID'.$y?>" value="<?php if($tapeRenewData[$j] != NULL) { echo $tapeRenewData[$j][0]['TAP_Renewal_ID']; } ?>"> <br>
                <label>Renewal Date:</label>
                <input type="date" min="<?php echo $y; ?>-01-01" max="<?php echo $y; ?>-12-31" name="<?php echo 'Renewal_Date'.$y?>" value="<?php echo $tapeRenewData[$j][0]['Renewal_Date']; ?>"> <br>

                <label>When to send Request to CTC:</label>
                <input type="date" min="<?php $y2 = (int)$y - 1; echo $y2; ?>-10-01" max="<?php echo $y; ?>-12-31" name="<?php echo 'Sent_Request_CTC'.$y?>" value="<?php echo $tapeRenewData[$j][0]['Sent_Request_CTC']; ?>"> <br>

                <label>Sent to Customer:</label>
                <input type="date" name="<?php echo 'Sent_Customer'.$y?>" value="<?php echo $tapeRenewData[$j][0]['Sent_Customer']; ?>"> <br>

                <label>PSW returned from Customer signed:</label>
                <input type="date" min="<?php echo $y; ?>-01-01" name="<?php echo 'Returned_Cust_Signed'.$y?>" value="<?php echo $tapeRenewData[$j][0]['Returned_Cust_Signed']; ?>">
                <hr>
            <?php 
                $years[$j] = $y;
            } 
            $ys = implode(', ', $years);?>
            <input type="hidden" name="years" value="<?php echo $ys ?>">
            <input type="hidden" name="countyears" value="<?php echo count($years) ?>">
        <?php } 

        if(isset($_POST['years'])) {
            $ys = $_POST['years'];
            $years = explode(", ", $ys);
            for($j = 0; $j < (int)$_POST['countyears']; $j++) { 
                $y = $years[$j] ?>
                    <label style="font-size: 20px;"><?php echo $y; ?></label>
                    <input type="hidden" name="<?php echo 'TAP_Renewal_ID'.$y?>" value="<?php if(isset($_POST['TAP_Renewal_ID'.$y])) { echo $_POST['TAP_Renewal_ID'.$y]; } ?>"> <br>
                    <label>Renewal Date:</label>
                    <input type="date" min="<?php echo $y; ?>-01-01" max="<?php echo $y; ?>-12-31" name="<?php echo 'Renewal_Date'.$y?>" value="<?php if(isset($_POST['Renewal_Date'.$y])) { echo $_POST['Renewal_Date'.$y]; } ?>"> <br>

                    <label>When to send Request to CTC:</label>
                    <input type="date" min="<?php $y2 = (int)$y - 1; echo $y2; ?>-10-01" max="<?php echo $y; ?>-12-31" name="<?php echo 'Sent_Request_CTC'.$y?>" value="<?php if(isset($_POST['Sent_Request_CTC'.$y])) { echo $_POST['Sent_Request_CTC'.$y]; } ?>"> <br>

                    <label>Sent to Customer:</label>
                    <input type="date" name="<?php echo 'Sent_Customer'.$y?>" value="<?php if(isset($_POST['Sent_Customer'.$y])) { echo $_POST['Sent_Customer'.$y]; } ?>"> <br>

                    <label>PSW returned from Customer signed:</label>
                    <input type="date" min="<?php echo $y; ?>-01-01" name="<?php echo 'Returned_Cust_Signed'.$y?>" value="<?php if(isset($_POST['Returned_Cust_Signed'.$y])) { echo $_POST['Returned_Cust_Signed'.$y]; } ?>">
                    <hr>
                    <?php $years[$j] = $y;  
                }
                $ys = implode(', ', $years);?>
                <input type="hidden" name="years" value="<?php echo $ys ?>">
                <input type="hidden" name="countyears" value="<?php echo count($years) ?>">
        <?php } ?>

        <label>PPAP from shipments:</label required>
        <div>
            <input type="radio" name="PPAP_from_shipments" value="no" <?php if(isset($_POST['PPAP_from_shipments']) && $_POST['PPAP_from_shipments'] == 'no') { echo 'checked'; } ?> checked> No 
        </div>
        <div>
            <input type="radio" name="PPAP_from_shipments" value="*" <?php if(isset($_POST['PPAP_from_shipments']) && $_POST['PPAP_from_shipments'] == '*') { echo 'checked'; } else { if(isset($tapeData) && $tapeData['PPAP_from_shipments'] == '*') { echo 'checked'; } } ?>> Yes 
        </div> <br>

        <label>Comments:</label>
        <textarea name="Comments" maxlength="255"><?php if(isset($_POST['OEM'])) { echo $_POST['OEM']; } else { echo $tapeData['Comments']; } ?></textarea>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if (isset($_POST['delete'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Delete PPAP</h2>
    <form action="?page=PPAPs" method="post">
        <input type="hidden" name="confirmD" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
            <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
            <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
            <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
            <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
            <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
            <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
            <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
            <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
            <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
            <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
            <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
            <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
            <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
            <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
            <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
            <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
            <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
            <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
            <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
            <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
            <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
            <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
            <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
            <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
            <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
            <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
            <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
            <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
            <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
            <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
            <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
            <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
            <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
            <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
            <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
            <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
            <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
            <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
            <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
            <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
            <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
            <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
            <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
            <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
            <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
            <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
            <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
            <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
            <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
            <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
            <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
            <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
            <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
            <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
            <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
            <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
            <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
        <input type="hidden" name="IDdelete" value="<?php echo $tapeDataD['TAP_PPAP_ID']; ?>">
        <h5><b>Are you sure you want to delete the data of this PPAP?</b></h5> <br>
        <?php 
            if($tapeDataD['Returned_CTC-Sent_Cust'] != NULL) {
                $retD = new DateTime($tapeDataD['Returned_CTC-Sent_Cust']);
            }
            if($tapeDataD['Cust_Signed-Sent_CTC'] != NULL) {
                $sigD = new DateTime($tapeDataD['Cust_Signed-Sent_CTC']);
            }
        ?>
        <h6><b>Customer:</b> <?php echo $tapeDataD['Name']; ?></h6>
        <h6><b>OEM:</b> <?php echo $tapeDataD['OEM']; ?></h6>
        <h6><b>Country:</b> <?php echo $tapeDataD['Country']; ?></h6>
        <h6><b>PPAP Level:</b> <?php echo $tapeDataD['PPAP_level']; ?></h6>
        <h6><b>SAP No.:</b> <?php echo $tapeDataD['Supplier_PN']; ?></h6>
        <h6><b>Customer PN:</b> <?php echo $tapeDataD['FK_Customer_PN']; ?></h6>
        <h6><b>Tape:</b> <?php echo $tapeDataD['Tape']; ?></h6>
        <h6><b>Width (MM):</b> <?php echo $tapeDataD['Width']; ?></h6>
        <h6><b>Length (M):</b> <?php echo $tapeDataD['Length']; ?></h6>
        <h6><b>Color:</b> <?php echo $tapeDataD['Color']; ?></h6>
        <h6><b>IMDS ID no.:</b> <?php echo $tapeDataD['IMDS_ID_No']; ?></h6>
        <hr>
        <h6><b>INITIAL</b></h6>
        <h6><b>Returned from CTC / Sent to Customer:</b> <?php if($tapeDataD['Returned_CTC-Sent_Cust'] != NULL) { echo $retD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
        <h6><b>PSW returned from Customer signed / Sent to CTC:</b> <?php if($tapeDataD['Cust_Signed-Sent_CTC'] != NULL) { echo $sigD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
        <hr>
        <?php if($submit1search != NULL && $submit2search != NULL) {
            $year = (int)$submit1search;
        }    
        else {
            $year = (int)$pastyear; 
        } 

        for($j = 0; $j < count($tapeRenewDataD); $j++) { 
            if($tapeRenewDataD[$j] != NULL) {
                if($tapeRenewDataD[$j][0]['Renewal_Date'] != NULL) {
                    $renD = new DateTime($tapeRenewDataD[$j][0]['Renewal_Date']);
                }
                if($tapeRenewDataD[$j][0]['Sent_Request_CTC'] != NULL) {
                    $serD = new DateTime($tapeRenewDataD[$j][0]['Sent_Request_CTC']);
                }
                if($tapeRenewDataD[$j][0]['Sent_Customer'] != NULL) {
                    $secD = new DateTime($tapeRenewDataD[$j][0]['Sent_Customer']);
                }
                if($tapeRenewDataD[$j][0]['Returned_Cust_Signed'] != NULL) {
                    $resD = new DateTime($tapeRenewDataD[$j][0]['Returned_Cust_Signed']);
                }
             ?>
            <h6><b><?php echo $year; ?></b></h6>
            <h6><b>Renewal Date:</b> <?php if($tapeRenewDataD[$j][0]['Renewal_Date'] != NULL) { echo $renD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
            <h6><b>When to send Request to CTC:</b> <?php if($tapeRenewDataD[$j][0]['Sent_Request_CTC'] != NULL) { echo $serD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
            <h6><b>Sent to Customer:</b> <?php if($tapeRenewDataD[$j][0]['Sent_Customer'] != NULL) { echo $secD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
            <h6><b>PSW returned from Customer signed:</b> <?php if($tapeRenewDataD[$j][0]['Returned_Cust_Signed'] != NULL) { echo $resD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
            <hr>
            <?php }
            $year += 1;  
        } ?>

        <h6><b>PPAP from shipment:</b> <?php if($tapeDataD['PPAP_from_shipments'] == '*'){ echo 'Yes'; } else{ echo 'No'; } ?></h6>
        <h6><b>Comments:</b> <?php echo $tapeDataD['Comments']; ?></h6>
        <button type="submit">Confirm</button>
    </form>
  </div>
</div>
<?php }

if ($Deleted != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Register Deleted</h2>
        <form action="?page=PPAPs" method="post">
            <h6><b>The register was deleted correctly.</b></h6>
        </form>
    </div>
    </div>
<?php } 

if (isset($_POST['renewal'])) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
        <div class="modal-contenido">
            <span class="cerrar" onclick="closeForm()">&times;</span>
            <h2>New Renewal</h2>
            <?php if (isset($error)) : ?>
                <div class="error"><?= $error ?></div>
            <?php endif; ?>

            <form action="?page=PPAPs" method="post">
                <input type="hidden" name="confirmIR" value="1">
                <input type="hidden" name="btnsearch" value="1">
                <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">          
                <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">          
                <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">          
                <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">          
                <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">     
                <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">          
                <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>"> 
                <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">          
                <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">      
                <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                <input type="hidden" name="pswr1search" value="<?php if(isset($_POST['pswr1search'])) { echo $_POST['pswr1search']; } ?>">
                <input type="hidden" name="pswr2search" value="<?php if(isset($_POST['pswr2search'])) { echo $_POST['pswr2search']; } ?>">
                <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                <input type="hidden" name="FK_TAP_PPAP_ID" value="<?php if(isset($_POST['Renewal_Date'])) { echo $_POST['FK_TAP_PPAP_ID']; } else { echo $_POST['IDPPAP']; } ?>">
                <label>Renewal Date:</label>
                <input type="date" name="Renewal_Date" <?php 
                if(isset($_POST['Renewal_Date'])) { echo 'value="'.$_POST['Renewal_Date'].'"'; }
                else { if(isset($renewal_date) && $renewal_date != NULL) { echo 'value="'.$renewal_date->format('Y-m-d').'"'; } } ?>> <br>

                <label>When to send Request to CTC:</label>
                <input type="date" name="Sent_Request_CTC" value="<?php 
                if(isset($_POST['Sent_Request_CTC'])) { echo $_POST['Sent_Request_CTC']; }
                else { if(isset($sent_cust_date) && $sent_cust_date != NULL) { echo $sent_cust_date->format('Y-m-d'); } } ?>"> <br>

                <label>Sent to Customer:</label>
                <input type="date" name="Sent_Customer" value="<?php if(isset($_POST['Sent_Customer'])) { echo $_POST['Sent_Customer']; }?>"> <br>

                <label>PSW returned from Customer signed:</label>
                <input type="date" name="Returned_Cust_Signed" value="<?php if(isset($_POST['Returned_Cust_Signed'])) { echo $_POST['Returned_Cust_Signed']; }?>">

                <button type="submit">Save</button>
            </form>
        </div>
    </div>
<?php } ?>

<script>
    function closeForm() {
        document.getElementById('formularioModal').style.display = 'none';
    }

    function sendForm() {
        closeForm();
        return true;
    }

    function clearForm() {
        document.querySelectorAll("#form input[type='text']").forEach(input => input.value = "");
        document.querySelectorAll("#form input[type='date']").forEach(input => input.value = "");

        document.querySelectorAll("#days1search").forEach(input => input.value = "");
        document.querySelectorAll("#days2search").forEach(input => input.value = "");

        const radioButtons = document.querySelectorAll("#form input[type='radio']");
        const defaultValue = '';

        for (const radio of radioButtons) {
            if (radio.value === defaultValue) {
                radio.checked = true;
            }
        }

        const selects = document.querySelectorAll("#form select");

        for (const select of selects) {
            select.value = defaultValue;
        }
    }

    let sortOrder = {};

    function sortTable(columnIndex, type) {
        const table = document.getElementById("PPAP_table");
        const rows = Array.from(table.rows).slice(2);
        const isAscending = !sortOrder[columnIndex];
        const isNumeric = !isNaN(rows[0].cells[columnIndex].innerText);

        rows.sort((rowA, rowB) => {
            const cellA = rowA.cells[columnIndex].innerText.trim();
            const cellB = rowB.cells[columnIndex].innerText.trim();
            
            if (type === "date") {
                const dateA = new Date(cellA);
                const dateB = new Date(cellB);
                const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
                const dateformatedA = dateA.toLocaleDateString('ja-JP', options);
                const dateformatedB = dateB.toLocaleDateString('ja-JP', options);
                return isAscending ? dateformatedA.localeCompare(dateformatedB) : dateformatedB.localeCompare(dateformatedA);
            } else if (type === "text") {
                return isAscending ? cellA.localeCompare(cellB) : cellB.localeCompare(cellA);
            }
            else if (type === "number") {
                const cellA = rowA.cells[columnIndex].innerText.toLowerCase();
                const cellB = rowB.cells[columnIndex].innerText.toLowerCase();

                if (!isNaN(cellA) && !isNaN(cellB)) {
                return isAscending ? cellA - cellB : cellB - cellA;
                }
                return isAscending
                ? cellA.localeCompare(cellB) 
                : cellB.localeCompare(cellA);
            }

        });

        rows.forEach(row => table.tBodies[0].appendChild(row));
        sortOrder[columnIndex] = isAscending;
    }
</script>