<?php
    class model {                                        

        public  $mbd;
        
        function cn() {
            $this->mbd = new PDO('mysql:host=localhost;dbname=eurotechdb;port=3306', 'root', '');
            $this->mbd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
        }

        function search(){
            $logs = [];
            if (isset($_POST['btnsearch'])) {
                if (!empty($_POST['custsearch']) || !empty($_POST['etpnsearch']) || !empty($_POST['descsearch']) 
                    || !empty($_POST['cpnsearch']) || !empty($_POST['imdssearch']) || !empty($_POST['pisearch']) 
                    || !empty($_POST['sapsearch'])

                    || !empty($_POST['days1search']) || !empty($_POST['days2search'])
                    || !empty($_POST['ppapnsearch'])
                    || !empty($_POST['currentsearch'])
                    || isset($_POST['curn'])
                    || !empty($_POST['oemsearch'])
                    || !empty($_POST['counsearch'])
                    || !empty($_POST['counsearch'])
                    || !empty($_POST['revsearch'])
                    || !empty($_POST['issearch'])
                    || isset($_POST['imsn'])
                    || !empty($_POST['pdearch']) 
                    || isset($_POST['ppdn']) 
                    || !empty($_POST['levelearch']) 
                    || !empty($_POST['psssearch']) 
                    || isset($_POST['pssn']) 
                    || !empty($_POST['rssearch']) 
                    || isset($_POST['rosn'])
                    || !empty($_POST['ren1search']) || !empty($_POST['ren2search'])
                    || isset($_POST['renn']) 
                    || !empty($_POST['req1search']) || !empty($_POST['req2search'])
                    || isset($_POST['reqn']) 
                    || !empty($_POST['sent1search']) || !empty($_POST['sent2search'])
                    || isset($_POST['stcn']) 
                    || !empty($_POST['pswr1search']) || !empty($_POST['pswr2search'])
                    || isset($_POST['pcsn']) 
                    || isset($_POST['pfsn']) 
                    || isset($_POST['originsearch']) 
                    || isset($_POST['comsearch']) 
                    || isset($_POST['irnsearch']) 

                    || !empty($_POST['etmsearch'])
                    || !empty($_POST['etdsearch'])
                    || !empty($_POST['imdssearch'])
                    || isset($_POST['imdn'])
                    || (!empty($_POST['date1search']) && !empty($_POST['date2search'])) 
                    || (!empty($_POST['psw1search']) && !empty($_POST['psw2search']))
                    || (!empty($_POST['ret1search']) && !empty($_POST['ret2search']))
                    || (!empty($_POST['psw1search']) && !empty($_POST['psw2search']))
                    || isset($_POST['req1n'])
                    || isset($_POST['cusn']) || isset($_POST['imdn'])
                    || isset($_POST['recn']) || isset($_POST['retn']) || isset($_POST['pscn'])) {
                    $where = [];
                    $params = [];
                    
                    if(!empty($_POST['days1search']) && !empty($_POST['days2search'])) {
                        $where[] = "1 = 2";
                    }
                    if($_POST['days1search'] == '0' && !empty($_POST['days2search'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['ppapnsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['currentsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['curn']) && $_POST['curn'] == 'Y') {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['oemsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['counsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['revsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['issearch'])) {
                        $where[] = "1 = 2";
                    }
                    
                    if($_POST['imsn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['imdn'] == "" && !empty($_POST['imdssearch'])) {
                        $where[] = "IMDS = :imds";
                        $params[':imds'] = $_POST['imdssearch'];
                    }
                    if($_POST['imdn'] == "Y") {
                        $where[] = "IMDS IS NOT NULL";
                    }
                    if($_POST['imdn'] == "N") {
                        $where[] = "IMDS IS NULL";
                    }
                    
                    if(!empty($_POST['etmsearch'])) {
                        $where[] = "ET_Model LIKE :mod";
                        $params[':mod'] = $_POST['etmsearch']."%";
                    }

                    if(!empty($_POST['etdsearch'])) {
                        $where[] = "ET_Dwg LIKE :dwg";
                        $params[':dwg'] = $_POST['etdsearch']."%";
                    }

                    if(!empty($_POST['pdsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['ppdn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['levelsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['lvln'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['psssearch'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['pssn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['rssearch'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['rosn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['renn'] == "" && !empty($_POST['ren1search']) && !empty($_POST['ren2search'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['renn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['reqn'] == "" && !empty($_POST['req1search']) && !empty($_POST['req2search'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['reqn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['stcn'] == "" && !empty($_POST['sent1search']) && !empty($_POST['sent2search'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['stcn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['pcsn'] == "" && !empty($_POST['pswr1search']) && !empty($_POST['pswr2search'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['pcsn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['pfsn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['originsearch'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['comsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['irnsearch'])) {
                        $where[] = "1 = 2";
                    }



                    if($_POST['cusn'] == "" && !empty($_POST['custsearch'])) {
                        $where[] = "c.`Name` LIKE :cust";
                        $params[':cust'] = $_POST['custsearch']."%";
                    }
                    if($_POST['cusn'] == "Y") {
                        $where[] = "c.`Name` IS NOT NULL";
                    }
                    if($_POST['cusn'] == "N") {
                        $where[] = "c.`Name` IS NULL";
                    }

                    if (!empty($_POST['etpnsearch'])) {
                        $where[] = "Eurotech_PN = :etpn";
                        $params[':etpn'] = $_POST['etpnsearch'];
                    }

                    if (!empty($_POST['descsearch'])) {
                        $where[] = "`Description` = :desc";
                        $params[':desc'] = $_POST['descsearch'];
                    }

                    if (!empty($_POST['cpnsearch'])) {
                        $where[] = "Customer_PN = :cpn";
                        $params[':cpn'] = $_POST['cpnsearch'];
                    }

                    if (!empty($_POST['imdssearch'])) {
                        $where[] = "IMDS = :imds";
                        $params[':imds'] = $_POST['imdssearch'];
                    }

                    if (!empty($_POST['pisearch'])) {
                        $where[] = "Short_name = :sup";
                        $params[':sup'] = $_POST['pisearch'];
                    }

                    if (!empty($_POST['sapsearch'])) {
                        $where[] = "Supplier_PN = :spn";
                        $params[':spn'] = $_POST['sapsearch'];
                    }

                    if($_POST['req1n'] == "" && !empty($_POST['date1search']) && !empty($_POST['date2search'])) {
                        $where[] = "Request_Date BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['date1search'];
                        $params[':date2'] = $_POST['date2search'];
                    }
                    if($_POST['req1n'] == "Y") {
                        $where[] = "Request_Date IS NOT NULL";
                    }
                    if($_POST['req1n'] == "N") {
                        $where[] = "Request_Date IS NULL";
                    }

                    if($_POST['pscn'] == "" && !empty($_POST['psw1search']) && !empty($_POST['psw2search'])) {
                        $where[] = "PPAP_Signed_Date BETWEEN :date7 AND :date8";
                        $params[':date7'] = $_POST['psw1search'];
                        $params[':date8'] = $_POST['psw2search'];
                    }
                    if($_POST['pscn'] == "Y") {
                        $where[] = "PPAP_Signed_Date IS NOT NULL";
                    }
                    if($_POST['pscn'] == "N") {
                        $where[] = "PPAP_Signed_Date IS NULL";
                    }

                    if($_POST['recn'] == "" && !empty($_POST['date3search']) && !empty($_POST['date4search'])) {
                        $where[] = "PPAP_Received_Date BETWEEN :date3 AND :date4";
                        $params[':date3'] = $_POST['date3search'];
                        $params[':date4'] = $_POST['date4search'];
                    }
                    if($_POST['recn'] == "Y") {
                        $where[] = "PPAP_Received_Date IS NOT NULL";
                    }
                    if($_POST['recn'] == "N") {
                        $where[] = "PPAP_Received_Date IS NULL";
                    }

                    if($_POST['retn'] == "" && !empty($_POST['ret1search']) && !empty($_POST['ret2search'])) {
                        $where[] = "Sent_Customer BETWEEN :date5 AND :date6";
                        $params[':date5'] = $_POST['ret1search'];
                        $params[':date6'] = $_POST['ret2search'];
                    }
                    if($_POST['retn'] == "Y") {
                        $where[] = "Sent_Customer IS NOT NULL";
                    }
                    if($_POST['retn'] == "N") {
                        $where[] = "Sent_Customer IS NULL";
                    }

                    if(!empty($where)) {
                        $sql = "
                        SELECT 
                            bp.BS_PPAP_ID,
                            p.Eurotech_PN,
                            p.`Description`,
                            c.`Name`,
                            cp.Customer_PN,
                            bp.IMDS,
                            v.`Name` AS 'Vendor',
                            v.Short_name,
                            p.Supplier_PN,
                            bp.Request_Date,
                            bp.PPAP_Received_Date,
                            bp.PPAP_Signed_Date,
                            bp.Sent_Customer
                        FROM products p
                            LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                            LEFT JOIN bluseal_ppap bp ON cp.Customer_PN = bp.FK_Customer_PN
                            LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
                        WHERE " . implode(' AND ', $where) . "
                        AND Product = 'BluSeal'
                        ORDER BY Eurotech_PN;";
                    }
                    else {
                        $sql = "
                        SELECT 
                            bp.BS_PPAP_ID,
                            p.Eurotech_PN,
                            p.`Description`,
                            c.`Name`,
                            cp.Customer_PN,
                            bp.IMDS,
                            v.`Name` AS 'Vendor',
                            v.Short_name,
                            p.Supplier_PN,
                            bp.Request_Date,
                            bp.PPAP_Received_Date,
                            bp.PPAP_Signed_Date,
                            bp.Sent_Customer
                        FROM products p
                            LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                            LEFT JOIN bluseal_ppap bp ON cp.Customer_PN = bp.FK_Customer_PN
                            LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
                            WHERE Product = 'BluSeal'
                        ORDER BY Eurotech_PN;";
                    }

                    $stmt = $this->mbd->prepare($sql);
                    $stmt->execute($params);

                    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
                else {
                    foreach ($this->mbd->query(
                        "SELECT 
                            bp.BS_PPAP_ID,
                            p.Eurotech_PN,
                            p.`Description`,
                            c.`Name`,
                            cp.Customer_PN,
                            bp.IMDS,
                            v.`Name` AS 'Vendor',
                            v.Short_name,
                            p.Supplier_PN,
                            bp.Request_Date,
                            bp.PPAP_Received_Date,
                            bp.PPAP_Signed_Date,
                            bp.Sent_Customer
                        FROM products p
                            LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                            LEFT JOIN bluseal_ppap bp ON cp.Customer_PN = bp.FK_Customer_PN
                            LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
                            WHERE Product = 'BluSeal'
                        ORDER BY Eurotech_PN;"
                    ) as $log) {
                        $logs[] = $log;
                    }
                }
            } else {
                foreach ($this->mbd->query(
                    "SELECT 
                            if(PPAP_Sent_Customer IS NULL, datediff(NOW(), PPAP_Request_Date), datediff(PPAP_Sent_Customer, PPAP_Request_Date)) AS 'Days to Submit',
                            ppap.*,
                            cp.Customer_PN,
                            p.*,
                            c.`Name` AS 'Customer',
                            c.IMDS_ID_no,
                            v.`Name` AS 'Vendor',
                            v.Short_name,
                            cpn.*
                        FROM products p
                            LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                            LEFT JOIN ppap ON cp.Customer_PN = ppap.FK_Customer_PN
                            LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
                            LEFT JOIN customer_ppap_number cpn ON cpn.FK_Customer_ID = c.Customer_ID
                        ORDER BY Eurotech_PN;"
                ) as $log) {
                    $logs[] = $log;
                }
            }
            return $logs;
        }

        function searchBS(){
            $logsBluSeal = [];
            if (isset($_POST['btnsearch'])) {
                if (!empty($_POST['custsearch']) || !empty($_POST['etpnsearch']) || !empty($_POST['descsearch']) 
                    || !empty($_POST['cpnsearch']) || !empty($_POST['imdssearch']) || !empty($_POST['pisearch']) 
                    || !empty($_POST['sapsearch'])

                    || !empty($_POST['days1search']) || !empty($_POST['days2search'])
                    || !empty($_POST['ppapnsearch'])
                    || !empty($_POST['currentsearch'])
                    || isset($_POST['curn'])
                    || !empty($_POST['oemsearch'])
                    || !empty($_POST['counsearch'])
                    || !empty($_POST['counsearch'])
                    || !empty($_POST['revsearch'])
                    || !empty($_POST['issearch'])
                    || isset($_POST['imsn'])
                    || !empty($_POST['pdearch']) 
                    || isset($_POST['ppdn']) 
                    || !empty($_POST['levelearch']) 
                    || !empty($_POST['psssearch']) 
                    || isset($_POST['pssn']) 
                    || !empty($_POST['rssearch']) 
                    || isset($_POST['rosn'])
                    || !empty($_POST['ren1search']) || !empty($_POST['ren2search'])
                    || isset($_POST['renn']) 
                    || !empty($_POST['req1search']) || !empty($_POST['req2search'])
                    || isset($_POST['reqn']) 
                    || !empty($_POST['sent1search']) || !empty($_POST['sent2search'])
                    || isset($_POST['stcn']) 
                    || !empty($_POST['pswr1search']) || !empty($_POST['pswr2search'])
                    || isset($_POST['pcsn']) 
                    || isset($_POST['pfsn']) 
                    || isset($_POST['originsearch']) 
                    || isset($_POST['comsearch']) 
                    || isset($_POST['irnsearch']) 

                    || !empty($_POST['etmsearch'])
                    || !empty($_POST['etdsearch'])
                    || !empty($_POST['imdssearch'])
                    || isset($_POST['imdn'])
                    || (!empty($_POST['date1search']) && !empty($_POST['date2search'])) 
                    || (!empty($_POST['psw1search']) && !empty($_POST['psw2search']))
                    || (!empty($_POST['ret1search']) && !empty($_POST['ret2search']))
                    || (!empty($_POST['psw1search']) && !empty($_POST['psw2search']))
                    || isset($_POST['req1n'])
                    || isset($_POST['cusn']) || isset($_POST['imdn'])
                    || isset($_POST['recn']) || isset($_POST['retn']) || isset($_POST['pscn'])) {
                    $where = [];
                    $params = [];
                    
                    if(!empty($_POST['days1search']) && !empty($_POST['days2search'])) {
                        $where[] = "1 = 2";
                    }
                    if($_POST['days1search'] == '0' && !empty($_POST['days2search'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['ppapnsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['currentsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['curn']) && $_POST['curn'] == 'Y') {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['oemsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['counsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['revsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['issearch'])) {
                        $where[] = "1 = 2";
                    }
                    
                    if($_POST['imsn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['imdn'] == "" && !empty($_POST['imdssearch'])) {
                        $where[] = "IMDS = :imds";
                        $params[':imds'] = $_POST['imdssearch'];
                    }
                    if($_POST['imdn'] == "Y") {
                        $where[] = "IMDS IS NOT NULL";
                    }
                    if($_POST['imdn'] == "N") {
                        $where[] = "IMDS IS NULL";
                    }
                    
                    if(!empty($_POST['etmsearch'])) {
                        $where[] = "ET_Model LIKE :mod";
                        $params[':mod'] = $_POST['etmsearch']."%";
                    }

                    if(!empty($_POST['etdsearch'])) {
                        $where[] = "ET_Dwg LIKE :dwg";
                        $params[':dwg'] = $_POST['etdsearch']."%";
                    }

                    if(!empty($_POST['pdsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['ppdn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['levelsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['lvln'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['psssearch'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['pssn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['rssearch'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['rosn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['renn'] == "" && !empty($_POST['ren1search']) && !empty($_POST['ren2search'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['renn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['reqn'] == "" && !empty($_POST['req1search']) && !empty($_POST['req2search'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['reqn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['stcn'] == "" && !empty($_POST['sent1search']) && !empty($_POST['sent2search'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['stcn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['pcsn'] == "" && !empty($_POST['pswr1search']) && !empty($_POST['pswr2search'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['pcsn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['pfsn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['originsearch'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['comsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['irnsearch'])) {
                        $where[] = "1 = 2";
                    }



                    if($_POST['cusn'] == "" && !empty($_POST['custsearch'])) {
                        $where[] = "c.`Name` LIKE :cust";
                        $params[':cust'] = $_POST['custsearch']."%";
                    }
                    if($_POST['cusn'] == "Y") {
                        $where[] = "c.`Name` IS NOT NULL";
                    }
                    if($_POST['cusn'] == "N") {
                        $where[] = "c.`Name` IS NULL";
                    }

                    if (!empty($_POST['etpnsearch'])) {
                        $where[] = "Eurotech_PN = :etpn";
                        $params[':etpn'] = $_POST['etpnsearch'];
                    }

                    if (!empty($_POST['descsearch'])) {
                        $where[] = "`Description` = :desc";
                        $params[':desc'] = $_POST['descsearch'];
                    }

                    if (!empty($_POST['cpnsearch'])) {
                        $where[] = "Customer_PN = :cpn";
                        $params[':cpn'] = $_POST['cpnsearch'];
                    }

                    if (!empty($_POST['imdssearch'])) {
                        $where[] = "IMDS = :imds";
                        $params[':imds'] = $_POST['imdssearch'];
                    }

                    if (!empty($_POST['pisearch'])) {
                        $where[] = "Short_name = :sup";
                        $params[':sup'] = $_POST['pisearch'];
                    }

                    if (!empty($_POST['sapsearch'])) {
                        $where[] = "Supplier_PN = :spn";
                        $params[':spn'] = $_POST['sapsearch'];
                    }

                    if($_POST['req1n'] == "" && !empty($_POST['date1search']) && !empty($_POST['date2search'])) {
                        $where[] = "Request_Date BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['date1search'];
                        $params[':date2'] = $_POST['date2search'];
                    }
                    if($_POST['req1n'] == "Y") {
                        $where[] = "Request_Date IS NOT NULL";
                    }
                    if($_POST['req1n'] == "N") {
                        $where[] = "Request_Date IS NULL";
                    }

                    if($_POST['pscn'] == "" && !empty($_POST['psw1search']) && !empty($_POST['psw2search'])) {
                        $where[] = "PPAP_Signed_Date BETWEEN :date7 AND :date8";
                        $params[':date7'] = $_POST['psw1search'];
                        $params[':date8'] = $_POST['psw2search'];
                    }
                    if($_POST['pscn'] == "Y") {
                        $where[] = "PPAP_Signed_Date IS NOT NULL";
                    }
                    if($_POST['pscn'] == "N") {
                        $where[] = "PPAP_Signed_Date IS NULL";
                    }

                    if($_POST['recn'] == "" && !empty($_POST['date3search']) && !empty($_POST['date4search'])) {
                        $where[] = "PPAP_Received_Date BETWEEN :date3 AND :date4";
                        $params[':date3'] = $_POST['date3search'];
                        $params[':date4'] = $_POST['date4search'];
                    }
                    if($_POST['recn'] == "Y") {
                        $where[] = "PPAP_Received_Date IS NOT NULL";
                    }
                    if($_POST['recn'] == "N") {
                        $where[] = "PPAP_Received_Date IS NULL";
                    }

                    if($_POST['retn'] == "" && !empty($_POST['ret1search']) && !empty($_POST['ret2search'])) {
                        $where[] = "Sent_Customer BETWEEN :date5 AND :date6";
                        $params[':date5'] = $_POST['ret1search'];
                        $params[':date6'] = $_POST['ret2search'];
                    }
                    if($_POST['retn'] == "Y") {
                        $where[] = "Sent_Customer IS NOT NULL";
                    }
                    if($_POST['retn'] == "N") {
                        $where[] = "Sent_Customer IS NULL";
                    }

                    if(!empty($where)) {
                        $sql = "
                        SELECT 
                            bp.BS_PPAP_ID,
                            p.Eurotech_PN,
                            p.`Description`,
                            c.`Name`,
                            cp.Customer_PN,
                            bp.IMDS,
                            v.`Name` AS 'Vendor',
                            v.Short_name,
                            p.Supplier_PN,
                            bp.Request_Date,
                            bp.PPAP_Received_Date,
                            bp.PPAP_Signed_Date,
                            bp.Sent_Customer
                        FROM products p
                            LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                            LEFT JOIN bluseal_ppap bp ON cp.Customer_PN = bp.FK_Customer_PN
                            LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
                        WHERE " . implode(' AND ', $where) . "
                        AND Product = 'BluSeal'
                        ORDER BY Eurotech_PN;";
                    }
                    else {
                        $sql = "
                        SELECT 
                            bp.BS_PPAP_ID,
                            p.Eurotech_PN,
                            p.`Description`,
                            c.`Name`,
                            cp.Customer_PN,
                            bp.IMDS,
                            v.`Name` AS 'Vendor',
                            v.Short_name,
                            p.Supplier_PN,
                            bp.Request_Date,
                            bp.PPAP_Received_Date,
                            bp.PPAP_Signed_Date,
                            bp.Sent_Customer
                        FROM products p
                            LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                            LEFT JOIN bluseal_ppap bp ON cp.Customer_PN = bp.FK_Customer_PN
                            LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
                            WHERE Product = 'BluSeal'
                        ORDER BY Eurotech_PN;";
                    }

                    $stmt = $this->mbd->prepare($sql);
                    $stmt->execute($params);

                    $logsBluSeal = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
                else {
                    foreach ($this->mbd->query(
                        "SELECT 
                            bp.BS_PPAP_ID,
                            p.Eurotech_PN,
                            p.`Description`,
                            c.`Name`,
                            cp.Customer_PN,
                            bp.IMDS,
                            v.`Name` AS 'Vendor',
                            v.Short_name,
                            p.Supplier_PN,
                            bp.Request_Date,
                            bp.PPAP_Received_Date,
                            bp.PPAP_Signed_Date,
                            bp.Sent_Customer
                        FROM products p
                            LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                            LEFT JOIN bluseal_ppap bp ON cp.Customer_PN = bp.FK_Customer_PN
                            LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
                            WHERE Product = 'BluSeal'
                        ORDER BY Eurotech_PN;"
                    ) as $log) {
                        $logsBluSeal[] = $log;
                    }
                }
            } else {
                foreach ($this->mbd->query(
                    "SELECT 
                            bp.BS_PPAP_ID,
                            p.Eurotech_PN,
                            p.`Description`,
                            c.`Name`,
                            cp.Customer_PN,
                            bp.IMDS,
                            v.`Name` AS 'Vendor',
                            v.Short_name,
                            p.Supplier_PN,
                            bp.Request_Date,
                            bp.PPAP_Received_Date,
                            bp.PPAP_Signed_Date,
                            bp.Sent_Customer
                        FROM products p
                            LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                            LEFT JOIN bluseal_ppap bp ON cp.Customer_PN = bp.FK_Customer_PN
                            LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
                        WHERE Product = 'BluSeal'
                        ORDER BY Eurotech_PN;"
                ) as $log) {
                    $logsBluSeal[] = $log;
                }
            }
            return $logsBluSeal;
        }
    
        function searchTapes(){
            $logsTapes = [];
            if (isset($_POST['btnsearch'])) {
                if (!empty($_POST['submit1search']) || !empty($_POST['submit2search']) || !empty($_POST['custsearch']) ||
                    !empty($_POST['oemsearch']) || !empty($_POST['counsearch']) || !empty($_POST['levelsearch']) || !empty($_POST['sapsearch']) || 
                    !empty($_POST['cpnsearch']) || !empty($_POST['descsearch']) 
                    || !empty($_POST['imdssearch'])  || !empty($_POST['ret1search']) || !empty($_POST['ret2search']) ||
                    !empty($_POST['psw1search']) || !empty($_POST['psw2search']) || !empty($_POST['ren1search']) || !empty($_POST['ren2search']) || 
                    !empty($_POST['req1search']) || !empty($_POST['req2search']) || !empty($_POST['sent1search']) || !empty($_POST['sent2search']) || 
                    
                    !empty($_POST['days1search']) || !empty($_POST['days2search']) ||
                    !empty($_POST['ppapnsearch']) ||
                    !empty($_POST['currentsearch']) ||
                    isset($_POST['curn']) ||
                    (!empty($_POST['req1n']) && $_POST['req1n'] != "" && $_POST['req1n'] != NULL) ||
                    (!empty($_POST['pisearch']) && $_POST['pisearch'] != "" && $_POST['pisearch'] != NULL) ||
                    !empty($_POST['revsearch']) ||
                    !empty($_POST['issearch']) ||
                    isset($_POST['imsn']) ||
                    !empty($_POST['pdearch']) ||
                    isset($_POST['ppdn']) ||
                    !empty($_POST['psssearch']) ||
                    isset($_POST['pssn']) ||
                    !empty($_POST['rssearch']) ||
                    isset($_POST['rosn']) ||
                    isset($_POST['originsearch']) || 
                    isset($_POST['irnsearch']) || 
                    

                    

                    !empty($_POST['etmsearch']) ||
                    !empty($_POST['etdsearch']) ||
                    !empty($_POST['etpnsearch']) ||
                    (!empty($_POST['cusn']) && $_POST['cusn'] != "" && $_POST['cusn'] != NULL) ||
                    (!empty($_POST['pfsn']) && $_POST['pfsn'] != "" && $_POST['pfsn'] != NULL) || (!empty($_POST['comsearch']) && $_POST['comsearch'] != "" && $_POST['comsearch'] != NULL)
                    || (!empty($_POST['retn']) && $_POST['retn'] != "" && $_POST['retn'] != NULL) || (!empty($_POST['pscn']) && $_POST['pscn'] != "" && $_POST['pscn'] != NULL) || (!empty($_POST['renn']) && $_POST['renn'] != "" && $_POST['renn'] != NULL)  
                    || (!empty($_POST['reqn']) && $_POST['reqn'] != "" && $_POST['reqn'] != NULL) || (!empty($_POST['stcn']) && $_POST['stcn'] != "" && $_POST['stcn'] != NULL) || (!empty($_POST['pcsn']) && $_POST['pcsn'] != "" && $_POST['pcsn'] != NULL) 
                    ){
                    $where = [];
                    $where2 = [];
                    $or = [];
                    $and = [];
                    $params = [];

                    if(!empty($_POST['days1search']) && !empty($_POST['days2search'])) {
                        $where[] = "1 = 2";
                    }
                    if($_POST['days1search'] == '0' && !empty($_POST['days2search'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['ppapnsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['currentsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['curn']) && $_POST['curn'] == 'Y') {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['req1n']) && $_POST['req1n'] == 'Y') {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['pisearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['etmsearch'])) {
                        $where[] = "ET_Model LIKE :mod";
                        $params[':mod'] = $_POST['etmsearch']."%";
                    }

                    if(!empty($_POST['etdsearch'])) {
                        $where[] = "ET_Dwg LIKE :dwg";
                        $params[':dwg'] = $_POST['etdsearch']."%";
                    }

                    if(!empty($_POST['revsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['etpnsearch'])) {
                        $where[] = "Eurotech_PN = :etpn";
                        $params[':etpn'] = $_POST['etpnsearch'];
                    }

                    if(!empty($_POST['issearch'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['imsn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['pdsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['ppdn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['psssearch'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['pssn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['rssearch'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['rosn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['recn'] == "" && !empty($_POST['psw1search']) && !empty($_POST['psw2search'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['recn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['originsearch'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['irnsearch'])) {
                        $where[] = "1 = 2";
                    }





                    if($_POST['imdn'] == "" && !empty($_POST['imdssearch'])) {
                        $where[] = "IMDS_ID_No = :imds";
                        $params[':imds'] = $_POST['imdssearch'];
                    }
                    if($_POST['imdn'] == "Y") {
                        $where[] = "IMDS_ID_No IS NOT NULL";
                    }
                    if($_POST['imdn'] == "N") {
                        $where[] = "IMDS_ID_No IS NULL";
                    }
                     
                    if($_POST['cusn'] == "" && !empty($_POST['custsearch'])) {
                        $where[] = "c.`Name` LIKE :cust";
                        $params[':cust'] = $_POST['custsearch']."%";
                    }
                    if($_POST['cusn'] == "Y") {
                        $where[] = "c.`Name` IS NOT NULL";
                    }
                    if($_POST['cusn'] == "N") {
                        $where[] = "c.`Name` IS NULL";
                    }

                    if(!empty($_POST['oemsearch'])) {
                        $where[] = "`OEM` = :oem";
                        $params[':oem'] = $_POST['oemsearch'];
                    }

                    if(!empty($_POST['counsearch'])) {
                        $where[] = "Country = :coun";
                        $params[':coun'] = $_POST['counsearch'];
                    }

                    if($_POST['lvln'] == "" && !empty($_POST['levelsearch'])) {
                        $where[] = "PPAP_level = :lvl";
                        $params[':lvl'] = $_POST['levelsearch'];
                    }
                    if($_POST['lvln'] == "Y") {
                        $where[] = "PPAP_level IS NOT NULL";
                    }
                    if($_POST['lvln'] == "N") {
                        $where[] = "PPAP_level IS NULL";
                    }

                    if(!empty($_POST['sapsearch'])) {
                        $where[] = "Supplier_PN = :sap";
                        $params[':sap'] = $_POST['sapsearch'];
                    }

                    if(!empty($_POST['cpnsearch'])) {
                        $where[] = "Customer_PN = :cpn";
                        $params[':cpn'] = $_POST['cpnsearch'];
                    }

                    if(!empty($_POST['descsearch'])) {
                        $where[] = "`Description` = :desc";
                        $params[':desc'] = $_POST['descsearch'];
                    }

                    if(!empty($_POST['imdssearch'])) {
                        $where[] = "IMDS_ID_No = :imd";
                        $params[':imd'] = $_POST['imdssearch'];
                    }
                    
                    if($_POST['retn'] == "" && !empty($_POST['ret1search']) && !empty($_POST['ret2search'])) {
                        $where[] = "`Returned_CTC-Sent_Cust` BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['ret1search'];
                        $params[':date2'] = $_POST['ret2search'];
                    }
                    if($_POST['retn'] == "Y") {
                        $where[] = "`Returned_CTC-Sent_Cust` IS NOT NULL";
                    }
                    if($_POST['retn'] == "N") {
                        $where[] = "`Returned_CTC-Sent_Cust` IS NULL";
                    }
                    
                    if($_POST['pscn'] == "" && !empty($_POST['psw1search']) && !empty($_POST['psw2search'])) {
                        $where[] = "`Cust_Signed-Sent_CTC` BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['psw1search'];
                        $params[':date2'] = $_POST['psw2search'];
                    }
                    if($_POST['pscn'] == "Y") {
                        $where[] = "`Cust_Signed-Sent_CTC` IS NOT NULL";
                    }
                    if($_POST['pscn'] == "N") {
                        $where[] = "`Cust_Signed-Sent_CTC` IS NULL";
                    }
                    
                    if($_POST['renn'] == "" && !empty($_POST['ren1search']) && !empty($_POST['ren2search'])) {
                        $where[] = "Renewal_Date BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['ren1search'];
                        $params[':date2'] = $_POST['ren2search'];
                    }
                    if($_POST['renn'] == "Y") {
                        $where[] = "Renewal_Date IS NOT NULL AND (YEAR(Renewal_Date) = ".$_POST['submit2search']." OR YEAR(Sent_Request_CTC) = ".$_POST['submit2search']." OR YEAR(Sent_Customer) = ".$_POST['submit2search'].")";
                        $and[] = "YEAR(Renewal_Date) = ".$_POST['submit2search']."";
                    }
                    if($_POST['renn'] == "N") {
                        $where[] = "Renewal_Date IS NULL";
                        $or[] = "YEAR(Renewal_Date) = ".$_POST['submit2search']."";
                    }
                    
                    if($_POST['reqn'] == "" && !empty($_POST['req1search']) && !empty($_POST['req2search'])) {
                        $where[] = "Sent_Request_CTC BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['req1search'];
                        $params[':date2'] = $_POST['req2search'];
                    }
                    if($_POST['reqn'] == "Y") {
                        $where[] = "Sent_Request_CTC IS NOT NULL AND (YEAR(Renewal_Date) = ".$_POST['submit2search']." OR YEAR(Sent_Request_CTC) = ".$_POST['submit2search']." OR YEAR(Sent_Customer) = ".$_POST['submit2search'].")";
                        $and[] = "YEAR(Sent_Request_CTC) = ".$_POST['submit2search']."";
                    }
                    if($_POST['reqn'] == "N") {
                        $py = (int)$_POST['submit2search'] - 1;
                        $or[] = "YEAR(Sent_Request_CTC) = ".$_POST['submit2search']." OR YEAR(Sent_Request_CTC) = ".$py."";
                        $where[] = "Sent_Request_CTC IS NULL";
                    }
                    
                    if($_POST['stcn'] == "" && !empty($_POST['sent1search']) && !empty($_POST['sent2search'])) {
                        $where[] = "Sent_Customer BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['sent1search'];
                        $params[':date2'] = $_POST['sent2search'];
                    }
                    if($_POST['stcn'] == "Y") {
                        $where[] = "Sent_Customer IS NOT NULL AND (YEAR(Renewal_Date) = ".$_POST['submit2search']." OR YEAR(Sent_Request_CTC) = ".$_POST['submit2search']." OR YEAR(Sent_Customer) = ".$_POST['submit2search'].")";
                        $and[] = "YEAR(Sent_Customer) = ".$_POST['submit2search']."";
                    }
                    if($_POST['stcn'] == "N") {
                        $where[] = "Sent_Customer IS NULL";
                        $or[] = "YEAR(Sent_Customer) = ".$_POST['submit2search']."";
                    }
                    
                    if($_POST['pcsn'] == "" && !empty($_POST['pswr1search']) && !empty($_POST['pswr2search'])) {
                        $where[] = "Returned_Cust_Signed BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['pswr1search'];
                        $params[':date2'] = $_POST['pswr2search'];
                    }
                    if($_POST['pcsn'] == "Y") {
                        $where[] = "Returned_Cust_Signed IS NOT NULL AND (YEAR(Renewal_Date) = ".$_POST['submit2search']." OR YEAR(Sent_Request_CTC) = ".$_POST['submit2search']." OR YEAR(Sent_Customer) = ".$_POST['submit2search'].")";
                        $and[] = "YEAR(Returned_Cust_Signed) = ".$_POST['submit2search']."";
                    }
                    if($_POST['pcsn'] == "N") {
                        $where[] = "Returned_Cust_Signed IS NULL";
                        $or[] = "YEAR(Returned_Cust_Signed) = ".$_POST['submit2search']."";
                    }
                    
                    if(!empty($_POST['pfsn']) && $_POST['pfsn'] == "Y") {
                        $where[] = "PPAP_from_shipments IS NOT NULL";
                    }
                    if(!empty($_POST['pfsn']) && $_POST['pfsn'] == "N") {
                        $where[] = "PPAP_from_shipments IS NULL";
                    }

                    if (!empty($_POST['comsearch'])) {
                        $where[] = "Comments = :com";
                        $params[':com'] = $_POST['comsearch'];
                    }

                    if(empty($or) && empty($and) && empty($where)) {
                        $sql = "
                            SELECT DISTINCT
                                tp.TAP_PPAP_ID,
                                tp.OEM,
                                tp.Country,
                                c.`Name`,
                                tp.PPAP_level,
                                t.Supplier_PN,
                                tp.FK_Customer_PN,
                                t.Eurotech_PN,
                                t.Description,
                                t.Tape,
                                t.Width,
                                t.`Length`,
                                t.Color,
                                tp.IMDS_ID_No,
                                tp.`Returned_CTC-Sent_Cust`,
                                tp.`Cust_Signed-Sent_CTC`,
                                tp.PPAP_from_shipments,
                                tp.Comments
                            FROM tapes_ppap tp
                                INNER JOIN customer_pn cpn ON tp.FK_Customer_PN  = cpn.Customer_PN
                                INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                INNER JOIN products t ON cpn.FK_Eurotech_PN = t.Eurotech_PN
                                LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID 
                            ORDER BY `Name`;";
                    }

                    if(!empty($or) && empty($and) && empty($where)) {
                         $sql = "
                            SELECT DISTINCT
                                tp.TAP_PPAP_ID,
                                tp.OEM,
                                tp.Country,
                                c.`Name`,
                                tp.PPAP_level,
                                t.Supplier_PN,
                                tp.FK_Customer_PN,
                                t.Eurotech_PN,
                                t.Description,
                                t.Tape,
                                t.Width,
                                t.`Length`,
                                t.Color,
                                tp.IMDS_ID_No,
                                tp.`Returned_CTC-Sent_Cust`,
                                tp.`Cust_Signed-Sent_CTC`,
                                tp.PPAP_from_shipments,
                                tp.Comments
                            FROM tapes_ppap tp
                                INNER JOIN customer_pn cpn ON tp.FK_Customer_PN  = cpn.Customer_PN
                                INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                INNER JOIN products t ON cpn.FK_Eurotech_PN = t.Eurotech_PN
                                LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID AND (". implode(' OR ', $or) .")
                            ORDER BY `Name`;";
                    }

                    if(!empty($or) && !empty($and) && empty($where)) {
                        $resultado = array_slice($and, 0, 1);
                         
                        $sql = "
                            SELECT DISTINCT
                                tp.TAP_PPAP_ID,
                                tp.OEM,
                                tp.Country,
                                c.`Name`,
                                tp.PPAP_level,
                                t.Supplier_PN,
                                tp.FK_Customer_PN,
                                t.Eurotech_PN,
                                t.Description,
                                t.Tape,
                                t.Width,
                                t.`Length`,
                                t.Color,
                                tp.IMDS_ID_No,
                                tp.`Returned_CTC-Sent_Cust`,
                                tp.`Cust_Signed-Sent_CTC`,
                                tp.PPAP_from_shipments,
                                tp.Comments
                            FROM tapes_ppap tp
                                INNER JOIN customer_pn cpn ON tp.FK_Customer_PN  = cpn.Customer_PN
                                INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                INNER JOIN products t ON cpn.FK_Eurotech_PN = t.Eurotech_PN
                                LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID AND (". implode(' ', $resultado ) ." OR ". implode(' OR ', $or) .") 
                            ORDER BY `Name`;";
                    }

                    if(!empty($or) && empty($and) && !empty($where)) {
                         $sql = "
                            SELECT DISTINCT
                                tp.TAP_PPAP_ID,
                                tp.OEM,
                                tp.Country,
                                c.`Name`,
                                tp.PPAP_level,
                                t.Supplier_PN,
                                tp.FK_Customer_PN,
                                t.Eurotech_PN,
                                t.Description,
                                t.Tape,
                                t.Width,
                                t.`Length`,
                                t.Color,
                                tp.IMDS_ID_No,
                                tp.`Returned_CTC-Sent_Cust`,
                                tp.`Cust_Signed-Sent_CTC`,
                                tp.PPAP_from_shipments,
                                tp.Comments
                            FROM tapes_ppap tp
                                INNER JOIN customer_pn cpn ON tp.FK_Customer_PN  = cpn.Customer_PN
                                INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                INNER JOIN products t ON cpn.FK_Eurotech_PN = t.Eurotech_PN
                                LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID AND (". implode(' OR ', $or) .") WHERE " . implode(' AND ', $where) . "
                            ORDER BY `Name`;";
                    }

                    if(empty($or) && !empty($and) && empty($where)) {
                         $sql = "
                            SELECT DISTINCT
                                tp.TAP_PPAP_ID,
                                tp.OEM,
                                tp.Country,
                                c.`Name`,
                                tp.PPAP_level,
                                t.Supplier_PN,
                                tp.FK_Customer_PN,
                                t.Eurotech_PN,
                                t.Description,
                                t.Tape,
                                t.Width,
                                t.`Length`,
                                t.Color,
                                tp.IMDS_ID_No,
                                tp.`Returned_CTC-Sent_Cust`,
                                tp.`Cust_Signed-Sent_CTC`,
                                tp.PPAP_from_shipments,
                                tp.Comments
                            FROM tapes_ppap tp
                                INNER JOIN customer_pn cpn ON tp.FK_Customer_PN  = cpn.Customer_PN
                                INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                INNER JOIN products t ON cpn.FK_Eurotech_PN = t.Eurotech_PN
                                LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID AND (". implode(' AND ', $and) .")
                            ORDER BY `Name`;";
                    }

                    if(empty($or) && !empty($and) && !empty($where)) {
                         $sql = "
                            SELECT DISTINCT
                                tp.TAP_PPAP_ID,
                                tp.OEM,
                                tp.Country,
                                c.`Name`,
                                tp.PPAP_level,
                                t.Supplier_PN,
                                tp.FK_Customer_PN,
                                t.Eurotech_PN,
                                t.Description,
                                t.Tape,
                                t.Width,
                                t.`Length`,
                                t.Color,
                                tp.IMDS_ID_No,
                                tp.`Returned_CTC-Sent_Cust`,
                                tp.`Cust_Signed-Sent_CTC`,
                                tp.PPAP_from_shipments,
                                tp.Comments
                            FROM tapes_ppap tp
                                INNER JOIN customer_pn cpn ON tp.FK_Customer_PN  = cpn.Customer_PN
                                INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                INNER JOIN products t ON cpn.FK_Eurotech_PN = t.Eurotech_PN
                                LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID AND (". implode(' AND ', $and) .") WHERE " . implode(' AND ', $where) . "
                            ORDER BY `Name`;";
                    }

                    if(empty($or) && empty($and) && !empty($where)) {
                        $sql = "
                            SELECT DISTINCT
                                tp.TAP_PPAP_ID,
                                tp.OEM,
                                tp.Country,
                                c.`Name`,
                                tp.PPAP_level,
                                t.Supplier_PN,
                                tp.FK_Customer_PN,
                                t.Eurotech_PN,
                                t.Description,
                                t.Tape,
                                t.Width,
                                t.`Length`,
                                t.Color,
                                tp.IMDS_ID_No,
                                tp.`Returned_CTC-Sent_Cust`,
                                tp.`Cust_Signed-Sent_CTC`,
                                tp.PPAP_from_shipments,
                                tp.Comments
                            FROM tapes_ppap tp
                                INNER JOIN customer_pn cpn ON tp.FK_Customer_PN  = cpn.Customer_PN
                                INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                INNER JOIN products t ON cpn.FK_Eurotech_PN = t.Eurotech_PN
                                LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID 
                                WHERE " . implode(' AND ', $where) . "
                            ORDER BY `Name`;";
                    }

                    if(!empty($or) && !empty($and) && !empty($where)) {
                        $resultado = array_slice($and, 0, 1);
                         
                        $sql = "
                            SELECT DISTINCT
                                tp.TAP_PPAP_ID,
                                tp.OEM,
                                tp.Country,
                                c.`Name`,
                                tp.PPAP_level,
                                t.Supplier_PN,
                                tp.FK_Customer_PN,
                                t.Eurotech_PN,
                                t.Description,
                                t.Tape,
                                t.Width,
                                t.`Length`,
                                t.Color,
                                tp.IMDS_ID_No,
                                tp.`Returned_CTC-Sent_Cust`,
                                tp.`Cust_Signed-Sent_CTC`,
                                tp.PPAP_from_shipments,
                                tp.Comments
                            FROM tapes_ppap tp
                                INNER JOIN customer_pn cpn ON tp.FK_Customer_PN  = cpn.Customer_PN
                                INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                INNER JOIN products t ON cpn.FK_Eurotech_PN = t.Eurotech_PN
                                LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID AND (". implode(' ', $resultado ) ." OR ". implode(' OR ', $or) .") WHERE " . implode(' AND ', $where) . "
                            ORDER BY `Name`;";
                    }

                    $stmt = $this->mbd->prepare($sql);
                    $stmt->execute($params);
                    
                    $logsTapes = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
                else {
                    foreach ($this->mbd->query(
                        "SELECT DISTINCT
                                tp.TAP_PPAP_ID,
                                tp.OEM,
                                tp.Country,
                                c.`Name`,
                                tp.PPAP_level,
                                t.Supplier_PN,
                                tp.FK_Customer_PN,
                                t.Eurotech_PN,
                                t.Description,
                                t.Tape,
                                t.Width,
                                t.`Length`,
                                t.Color,
                                tp.IMDS_ID_No,
                                tp.`Returned_CTC-Sent_Cust`,
                                tp.`Cust_Signed-Sent_CTC`,
                                tp.PPAP_from_shipments,
                                tp.Comments
                            FROM tapes_ppap tp
                                INNER JOIN customer_pn cpn ON tp.FK_Customer_PN  = cpn.Customer_PN
                                INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                INNER JOIN products t ON cpn.FK_Eurotech_PN = t.Eurotech_PN
                                LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID
                            ORDER BY `Name`;"
                    ) as $log) {
                        $logsTapes[] = $log;
                    }
                }
            } else {
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                                tp.TAP_PPAP_ID,
                                tp.OEM,
                                tp.Country,
                                c.`Name`,
                                tp.PPAP_level,
                                t.Supplier_PN,
                                tp.FK_Customer_PN,
                                t.Eurotech_PN,
                                t.Description,
                                t.Tape,
                                t.Width,
                                t.`Length`,
                                t.Color,
                                tp.IMDS_ID_No,
                                tp.`Returned_CTC-Sent_Cust`,
                                tp.`Cust_Signed-Sent_CTC`,
                                tp.PPAP_from_shipments,
                                tp.Comments
                            FROM tapes_ppap tp
                                INNER JOIN customer_pn cpn ON tp.FK_Customer_PN  = cpn.Customer_PN
                                INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                INNER JOIN products t ON cpn.FK_Eurotech_PN = t.Eurotech_PN
                                LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID
                            ORDER BY `Name`;"
                ) as $log) {
                    $logsTapes[] = $log;
                }
            }
            return $logsTapes;
        }

        function searchCables(){
            $logsCables = [];
            if (isset($_POST['btnsearch'])) {
                if (!empty($_POST['custsearch']) || !empty($_POST['etpnsearch']) 
                    || !empty($_POST['sapsearch']) || !empty($_POST['cpnsearch']) || !empty($_POST['descsearch'])
                    || (!empty($_POST['date1search']) && !empty($_POST['date2search'])) 
                    || (!empty($_POST['psw1search']) && !empty($_POST['psw2search']))
                    || (!empty($_POST['date3search']) && !empty($_POST['date4search']))
                    || (!empty($_POST['ret1search']) && !empty($_POST['ret2search']))

                    || !empty($_POST['days1search']) || !empty($_POST['days2search'])
                    || !empty($_POST['ppapnsearch'])
                    || !empty($_POST['currentsearch']) 
                    || isset($_POST['curn'])
                    || !empty($_POST['pisearch'])
                    || !empty($_POST['oemsearch'])
                    || !empty($_POST['counsearch'])
                    || !empty($_POST['revsearch'])
                    || !empty($_POST['imdssearch']) 
                    || isset($_POST['imdn'])
                    || !empty($_POST['issearch'])
                    || isset($_POST['imsn'])
                    || !empty($_POST['pdearch']) 
                    || isset($_POST['ppdn']) 
                    || !empty($_POST['psssearch']) 
                    || isset($_POST['pssn']) 
                    || !empty($_POST['rssearch']) 
                    || isset($_POST['rosn'])
                    || !empty($_POST['ren1search']) || !empty($_POST['ren2search'])
                    || isset($_POST['renn']) 
                    || !empty($_POST['req1search']) || !empty($_POST['req2search'])
                    || isset($_POST['reqn']) 
                    || !empty($_POST['sent1search']) || !empty($_POST['sent2search'])
                    || isset($_POST['stcn']) 
                    || !empty($_POST['pswr1search']) || !empty($_POST['pswr2search'])
                    || isset($_POST['pcsn']) 
                    || isset($_POST['pfsn']) 
                    || isset($_POST['originsearch']) 
                    || isset($_POST['comsearch']) 
                    || isset($_POST['irnsearch']) 

                    || !empty($_POST['etmsearch'])
                    || !empty($_POST['etdsearch'])
                    || isset($_POST['cusn']) || isset($_POST['req1n']) 
                    || isset($_POST['reqn']) 
                    || isset($_POST['recn']) || isset($_POST['retn']) || isset($_POST['pscn'])) {
                    $where = [];
                    $params = [];

                    if(!empty($_POST['days1search']) && !empty($_POST['days2search'])) {
                        $where[] = "1 = 2";
                    }
                    if($_POST['days1search'] == '0' && !empty($_POST['days2search'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['ppapnsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['currentsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['curn']) && $_POST['curn'] == 'Y') {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['oemsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['imdssearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['pisearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['counsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['revsearch'])) {
                        $where[] = "1 = 2";
                    }
                    
                    if($_POST['imdn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['issearch'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['imsn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['pdsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['ppdn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['levelsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['lvln'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['psssearch'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['pssn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['rssearch'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['rosn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['renn'] == "" && !empty($_POST['ren1search']) && !empty($_POST['ren2search'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['renn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['reqn'] == "" && !empty($_POST['req1search']) && !empty($_POST['req2search'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['reqn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['stcn'] == "" && !empty($_POST['sent1search']) && !empty($_POST['sent2search'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['stcn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['pcsn'] == "" && !empty($_POST['pswr1search']) && !empty($_POST['pswr2search'])) {
                        $where[] = "1 = 2";
                    }

                    if($_POST['pcsn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['pfsn'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if($_POST['originsearch'] == "Y") {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['comsearch'])) {
                        $where[] = "1 = 2";
                    }

                    if(!empty($_POST['irnsearch'])) {
                        $where[] = "1 = 2";
                    }


                    if(!empty($_POST['etmsearch'])) {
                        $where[] = "ET_Model LIKE :mod";
                        $params[':mod'] = $_POST['etmsearch']."%";
                    }

                    if(!empty($_POST['etdsearch'])) {
                        $where[] = "ET_Dwg LIKE :dwg";
                        $params[':dwg'] = $_POST['etdsearch']."%";
                    }

                    if($_POST['cusn'] == "" && !empty($_POST['custsearch'])) {
                        $where[] = "`Name` LIKE :cust";
                        $params[':cust'] = $_POST['custsearch']."%";
                    }
                    if($_POST['cusn'] == "Y") {
                        $where[] = "`Name` IS NOT NULL";
                    }
                    if($_POST['cusn'] == "N") {
                        $where[] = "`Name` IS NULL";
                    }

                    if (!empty($_POST['cpnsearch'])) {
                        $where[] = "Customer_PN = :cpn";
                        $params[':cpn'] = $_POST['cpnsearch'];
                    }

                    if (!empty($_POST['etpnsearch'])) {
                        $where[] = "Eurotech_PN = :etpn";
                        $params[':etpn'] = $_POST['etpnsearch'];
                    }

                    if (!empty($_POST['sapsearch'])) {
                        $where[] = "Supplier_PN = :copn";
                        $params[':copn'] = $_POST['sapsearch'];
                    }

                    if (!empty($_POST['descsearch'])) {
                        $where[] = "`Description` = :desc";
                        $params[':desc'] = $_POST['descsearch'];
                    }

                    if($_POST['req1n'] == "" && !empty($_POST['date1search']) && !empty($_POST['date2search'])) {
                        $where[] = "PPAP_Requested_Date BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['date1search'];
                        $params[':date2'] = $_POST['date2search'];
                    }
                    if($_POST['req1n'] == "Y") {
                        $where[] = "PPAP_Requested_Date IS NOT NULL";
                    }
                    if($_POST['req1n'] == "N") {
                        $where[] = "PPAP_Requested_Date IS NULL";
                    }

                    if($_POST['pscn'] == "" && !empty($_POST['psw1search']) && !empty($_POST['psw2search'])) {
                        $where[] = "PPAP_Signed_Date BETWEEN :date3 AND :date4";
                        $params[':date3'] = $_POST['psw1search'];
                        $params[':date4'] = $_POST['psw2search'];
                    }
                    if($_POST['pscn'] == "Y") {
                        $where[] = "PPAP_Signed_Date IS NOT NULL";
                    }
                    if($_POST['pscn'] == "N") {
                        $where[] = "PPAP_Signed_Date IS NULL";
                    }

                    if($_POST['recn'] == "" && !empty($_POST['date3search']) && !empty($_POST['date4search'])) {
                        $where[] = "PPAP_Received_Date BETWEEN :date5 AND :date6";
                        $params[':date5'] = $_POST['date3search'];
                        $params[':date6'] = $_POST['date4search'];
                    }
                    if($_POST['recn'] == "Y") {
                        $where[] = "PPAP_Received_Date IS NOT NULL";
                    }
                    if($_POST['recn'] == "N") {
                        $where[] = "PPAP_Received_Date IS NULL";
                    }

                    if($_POST['retn'] == "" && !empty($_POST['ret1search']) && !empty($_POST['ret2search'])) {
                        $where[] = "PPAP_Sent_Date BETWEEN :date7 AND :date8";
                        $params[':date7'] = $_POST['ret1search'];
                        $params[':date8'] = $_POST['ret2search'];
                    }
                    if($_POST['retn'] == "Y") {
                        $where[] = "PPAP_Sent_Date IS NOT NULL";
                    }
                    if($_POST['retn'] == "N") {
                        $where[] = "PPAP_Sent_Date IS NULL";
                    }

                    if(!empty($where)){
                        $sql = "
                        SELECT 
                            CAB_PPAP_ID,
                            Eurotech_PN,
                            Supplier_PN,
                            Customer_PN, 
                            `Description`,
                            PPAP_Requested_Date,
                            PPAP_Received_Date,
                            PPAP_Sent_Date,
                            PPAP_Signed_Date,
                            `Name`
                        FROM products pd
                            LEFT JOIN customer_pn cp ON cp.FK_Eurotech_PN = pd.Eurotech_PN
                            LEFT JOIN cables_ppap p ON cp.Customer_PN = p.FK_Customer_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                        WHERE " . implode(' AND ', $where) . "
                        AND Product = 'Cable'
                        ORDER BY Eurotech_PN;";
                    }
                    else {
                        $sql = "
                        SELECT 
                            CAB_PPAP_ID,
                            Eurotech_PN,
                            Supplier_PN,
                            Customer_PN, 
                            `Description`,
                            PPAP_Requested_Date,
                            PPAP_Received_Date,
                            PPAP_Sent_Date,
                            PPAP_Signed_Date,
                            `Name`
                        FROM products pd
                            LEFT JOIN customer_pn cp ON cp.FK_Eurotech_PN = pd.Eurotech_PN
                            LEFT JOIN cables_ppap p ON cp.Customer_PN = p.FK_Customer_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                        WHERE Product = 'Cable'
                        ORDER BY Eurotech_PN;";
                    }

                    $stmt = $this->mbd->prepare($sql);
                    $stmt->execute($params);

                    $logsCables = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }

                else {
                    foreach ($this->mbd->query(
                        "SELECT 
                            CAB_PPAP_ID,
                            Eurotech_PN,
                            Supplier_PN,
                            Customer_PN, 
                            `Description`,
                            PPAP_Requested_Date,
                            PPAP_Received_Date,
                            PPAP_Sent_Date,
                            PPAP_Signed_Date,
                            `Name`
                        FROM products pd
                            LEFT JOIN customer_pn cp ON cp.FK_Eurotech_PN = pd.Eurotech_PN
                            LEFT JOIN cables_ppap p ON cp.Customer_PN = p.FK_Customer_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                        WHERE Product = 'Cable'
                        ORDER BY Eurotech_PN;"
                    ) as $log) {
                        $logsCables[] = $log;
                    }
                }
            } else {
                foreach ($this->mbd->query(
                    "SELECT 
                            CAB_PPAP_ID,
                            Eurotech_PN,
                            Supplier_PN,
                            Customer_PN, 
                            `Description`,
                            PPAP_Requested_Date,
                            PPAP_Received_Date,
                            PPAP_Sent_Date,
                            PPAP_Signed_Date,
                            `Name`
                        FROM products pd
                            LEFT JOIN customer_pn cp ON cp.FK_Eurotech_PN = pd.Eurotech_PN
                            LEFT JOIN cables_ppap p ON cp.Customer_PN = p.FK_Customer_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                        WHERE Product = 'Cable'
                        ORDER BY Eurotech_PN;"
                ) as $log) {
                    $logsCables[] = $log;
                }
            }
            return $logsCables;
        }

        function searchTubes(){
            $logs = [];
            if (isset($_POST['btnsearch'])) {
                if (!empty($_POST['days1search']) || !empty($_POST['days2search']) || !empty($_POST['ppapnsearch']) ||
                    !empty($_POST['date1search']) || !empty($_POST['date2search']) || !empty($_POST['pisearch']) || !empty($_POST['custsearch']) || 
                    !empty($_POST['counsearch']) || !empty($_POST['cpnsearch'])  || !empty($_POST['etmsearch']) || !empty($_POST['etdsearch']) ||
                    !empty($_POST['revsearch']) || !empty($_POST['etpnsearch'])  || !empty($_POST['descsearch']) || !empty($_POST['imdssearch']) ||
                    !empty($_POST['issearch']) || !empty($_POST['pdsearch']) || !empty($_POST['levelsearch']) || !empty($_POST['psssearch']) ||
                    !empty($_POST['rssearch']) || !empty($_POST['ret1search']) || !empty($_POST['ret2search']) || !empty($_POST['psw1search']) || 
                    !empty($_POST['psw2search']) || !empty($_POST['originsearch']) 

                    || !empty($_POST['sapsearch']) 
                    || !empty($_POST['oemsearch']) 
                    || isset($_POST['cusn'])
                    || !empty($_POST['ren1search']) || !empty($_POST['ren2search'])
                    || isset($_POST['renn']) 
                    || !empty($_POST['req1search']) || !empty($_POST['req2search'])
                    || isset($_POST['reqn']) 
                    || !empty($_POST['sent1search']) || !empty($_POST['sent2search'])
                    || isset($_POST['stcn']) 
                    || !empty($_POST['pswr1search']) || !empty($_POST['pswr2search'])
                    || isset($_POST['pcsn']) 
                    || isset($_POST['pfsn']) 

                    || !empty($_POST['comsearch']) || !empty($_POST['irnsearch'])
                    || isset($_POST['req1n']) || isset($_POST['reqn']) || isset($_POST['curn']) || isset($_POST['imdn']) || isset($_POST['imsn'])  
                    || isset($_POST['ppdn']) || isset($_POST['lvln']) || isset($_POST['pssn']) || isset($_POST['rosn']) 
                    || isset($_POST['stcn']) || isset($_POST['pcsn']) 
                    ){
                    $having = [];
                    $params = [];

                    if(!empty($_POST['sapsearch'])) {
                        $having[] = "1 = 2";
                    }

                    if(!empty($_POST['oemsearch'])) {
                        $having[] = "1 = 2";
                    }

                    if($_POST['recn'] == "" && !empty($_POST['date3search']) && !empty($_POST['date4search'])) {
                        $having[] = "1 = 2";
                    }

                    if($_POST['recn'] == "Y") {
                        $having[] = "1 = 2";
                    }

                    if($_POST['renn'] == "" && !empty($_POST['ren1search']) && !empty($_POST['ren2search'])) {
                        $having[] = "1 = 2";
                    }

                    if($_POST['renn'] == "Y") {
                        $having[] = "1 = 2";
                    }

                    if($_POST['reqn'] == "" && !empty($_POST['req1search']) && !empty($_POST['req2search'])) {
                        $having[] = "1 = 2";
                    }

                    if($_POST['reqn'] == "Y") {
                        $having[] = "1 = 2";
                    }

                    if($_POST['stcn'] == "" && !empty($_POST['sent1search']) && !empty($_POST['sent2search'])) {
                        $having[] = "1 = 2";
                    }

                    if($_POST['stcn'] == "Y") {
                        $having[] = "1 = 2";
                    }

                    if($_POST['pcsn'] == "" && !empty($_POST['pswr1search']) && !empty($_POST['pswr2search'])) {
                        $having[] = "1 = 2";
                    }

                    if($_POST['pcsn'] == "Y") {
                        $having[] = "1 = 2";
                    }

                    if($_POST['pfsn'] == "Y") {
                        $having[] = "1 = 2";
                    }


                    if($_POST['req1n'] == "" && (empty($_POST['date1search']) || empty($_POST['date2search']))) {
                        $having[] = "1 = 1";
                    }
                    if($_POST['req1n'] == "" && !empty($_POST['date1search']) && !empty($_POST['date2search'])) {
                        $having[] = "PPAP_Req_by_Cus_Date BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['date1search'];
                        $params[':date2'] = $_POST['date2search'];
                    }
                    if($_POST['req1n'] == "Y") {
                        $having[] = "PPAP_Req_by_Cus_Date IS NOT NULL";
                    }
                    if($_POST['req1n'] == "N") {
                        $having[] = "PPAP_Req_by_Cus_Date IS NULL";
                    }

                    if($_POST['curn'] == "" && empty($_POST['currentsearch'])) {
                        $having[] = "1 = 1";
                    }
                    if($_POST['curn'] == "" && !empty($_POST['currentsearch'])) {
                        $having[] = "Current_Status = :cur";
                        $params[':cur'] = $_POST['currentsearch'];
                    }
                    if($_POST['curn'] == "Y") {
                        $having[] = "Current_Status IS NOT NULL";
                    }
                    if($_POST['curn'] == "N") {
                        $having[] = "Current_Status IS NULL";
                    }
                    
                    if($_POST['imdn'] == "" && empty($_POST['imdssearch'])) {
                        $having[] = "1 = 1";
                    }
                    if($_POST['imdn'] == "" && !empty($_POST['imdssearch'])) {
                        $having[] = "IMDS_Number = :imd";
                        $params[':imd'] = $_POST['imdssearch'];
                    }
                    if($_POST['imdn'] == "Y") {
                        $having[] = "IMDS_Number IS NOT NULL";
                    }
                    if($_POST['imdn'] == "N") {
                        $having[] = "IMDS_Number IS NULL";
                    }

                    if($_POST['imsn'] == "" && empty($_POST['issearch'])) {
                        $having[] = "1 = 1";
                    }
                    if($_POST['imsn'] == "" && !empty($_POST['issearch'])) {
                        $having[] = "IMDS_Status = :ims";
                        $params[':ims'] = $_POST['issearch'];
                    }
                    if($_POST['imsn'] == "Y") {
                        $having[] = "IMDS_Status IS NOT NULL";
                    }
                    if($_POST['imsn'] == "N") {
                        $having[] = "IMDS_Status IS NULL";
                    }

                    if($_POST['ppdn'] == "" && empty($_POST['pdsearch'])) {
                        $having[] = "1 = 1";
                    }
                    if($_POST['ppdn'] == "" && !empty($_POST['pdsearch'])) {
                        $having[] = "PPAP_docs = :ppd";
                        $params[':ppd'] = $_POST['pdsearch'];
                    }
                    if($_POST['ppdn'] == "Y") {
                        $having[] = "PPAP_docs IS NOT NULL";
                    }
                    if($_POST['ppdn'] == "N") {
                        $having[] = "PPAP_docs IS NULL";
                    }

                    if($_POST['lvln'] == "" && empty($_POST['levelsearch'])) {
                        $having[] = "1 = 1";
                    }
                    if($_POST['lvln'] == "" && !empty($_POST['levelsearch'])) {
                        $having[] = "`Level` = :lvl";
                        $params[':lvl'] = $_POST['levelsearch'];
                    }
                    if($_POST['lvln'] == "Y") {
                        $having[] = "`Level` IS NOT NULL";
                    }
                    if($_POST['lvln'] == "N") {
                        $having[] = "`Level` IS NULL";
                    }

                    if($_POST['pssn'] == "" && empty($_POST['psssearch'])) {
                        $having[] = "1 = 1";
                    }
                    if($_POST['pssn'] == "" && !empty($_POST['psssearch'])) {
                        $having[] = "Samples_Status = :pss";
                        $params[':pss'] = $_POST['psssearch'];
                    }
                    if($_POST['pssn'] == "Y") {
                        $having[] = "Samples_Status IS NOT NULL";
                    }
                    if($_POST['pssn'] == "N") {
                        $having[] = "Samples_Status IS NULL";
                    }

                    if($_POST['rosn'] == "" && empty($_POST['rssearch'])) {
                        $having[] = "1 = 1";
                    }
                    if($_POST['rosn'] == "" && !empty($_POST['rssearch'])) {
                        $having[] = "Reason_submission = :ros";
                        $params[':ros'] = $_POST['rssearch'];
                    }
                    if($_POST['rosn'] == "Y") {
                        $having[] = "Reason_submission IS NOT NULL";
                    }
                    if($_POST['rosn'] == "N") {
                        $having[] = "Reason_submission IS NULL";
                    }

                    if($_POST['retn'] == "" && (empty($_POST['ret1search']) || empty($_POST['ret2search']))) {
                        $having[] = "1 = 1";
                    }
                    if($_POST['retn'] == "" && !empty($_POST['ret1search']) && !empty($_POST['ret2search'])) {
                        $having[] = "Sent_Customer BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['ret1search'];
                        $params[':date2'] = $_POST['ret2search'];
                    }
                    if($_POST['retn'] == "Y") {
                        $having[] = "Sent_Customer IS NOT NULL";
                    }
                    if($_POST['retn'] == "N") {
                        $having[] = "Sent_Customer IS NULL";
                    }

                    if($_POST['pscn'] == "" && (empty($_POST['psw1search']) || empty($_POST['psw2search']))) {
                        $having[] = "1 = 1";
                    }
                    if($_POST['pscn'] == "" && !empty($_POST['psw1search']) && !empty($_POST['psw2search'])) {
                        $having[] = "PSW_Returned BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['psw1search'];
                        $params[':date2'] = $_POST['psw2search'];
                    }
                    if($_POST['pscn'] == "Y") {
                        $having[] = "PSW_Returned IS NOT NULL";
                    }
                    if($_POST['pscn'] == "N") {
                        $having[] = "PSW_Returned IS NULL";
                    }

                    if(empty($_POST['days1search']) || empty($_POST['days2search'])) {
                        $having[] = "1 = 1";
                    }
                    if(!empty($_POST['days1search']) && !empty($_POST['days2search'])) {
                        $having[] = "`Days to Submit` BETWEEN :sub1 AND :sub2";
                        $params[':sub1'] = $_POST['days1search'];
                        $params[':sub2'] = $_POST['days2search'];
                    }
                    if($_POST['days1search'] == '0' && !empty($_POST['days2search'])) {
                        $having[] = "`Days to Submit` BETWEEN :sub1 AND :sub2";
                        $params[':sub1'] = $_POST['days1search'];
                        $params[':sub2'] = $_POST['days2search'];
                    }

                    if (!empty($_POST['ppapnsearch'])) {
                        $having[] = "PPAP_Number LIKE :ppapn";
                        $params[':ppapn'] = $_POST['ppapnsearch']."%";
                    }

                    // if(!empty($_POST['req1search']) && !empty($_POST['req2search'])) {
                    //     $having[] = "PPAP_Req_by_Cus_Date BETWEEN :req1 AND :req2";
                    //     $params[':req1'] = $_POST['req1search'];
                    //     $params[':req2'] = $_POST['req2search'];
                    // }

                    if (!empty($_POST['currentsearch'])) {
                        $having[] = "Current_Status = :current";
                        $params[':current'] = $_POST['currentsearch'];
                    }

                    if (!empty($_POST['pisearch'])) {
                        $having[] = "Short_name = :pi";
                        $params[':pi'] = $_POST['pisearch'];
                    }

                    if($_POST['cusn'] == "" && !empty($_POST['custsearch'])) {
                        $having[] = "`Name` LIKE :cust";
                        $params[':cust'] = $_POST['custsearch']."%";
                    }
                    if($_POST['cusn'] == "Y") {
                        $having[] = "`Name` IS NOT NULL";
                    }
                    if($_POST['cusn'] == "N") {
                        $having[] = "`Name` IS NULL";
                    }

                    if (!empty($_POST['counsearch'])) {
                        $having[] = "Country = :country";
                        $params[':country'] = $_POST['counsearch'];
                    }

                    if (!empty($_POST['cpnsearch'])) {
                        $having[] = "Customer_PN = :cpn";
                        $params[':cpn'] = $_POST['cpnsearch'];
                    }

                    if (!empty($_POST['etmsearch'])) {
                        $having[] = "ET_Model = :etm";
                        $params[':etm'] = $_POST['etmsearch'];
                    }

                    if (!empty($_POST['etdsearch'])) {
                        $having[] = "ET_Dwg = :etd";
                        $params[':etd'] = $_POST['etdsearch'];
                    }

                    if (!empty($_POST['revsearch'])) {
                        $having[] = "Rev = :rev";
                        $params[':rev'] = $_POST['revsearch'];
                    }

                    if (!empty($_POST['etpnsearch'])) {
                        $having[] = "Eurotech_PN = :etpn";
                        $params[':etpn'] = $_POST['etpnsearch'];
                    }

                    if (!empty($_POST['descsearch'])) {
                        $having[] = "`Description` = :desc";
                        $params[':desc'] = $_POST['descsearch'];
                    }

                    if (!empty($_POST['imdssearch'])) {
                        $having[] = "IMDS_Number = :imds";
                        $params[':imds'] = $_POST['imdssearch'];
                    }

                    if (!empty($_POST['issearch'])) {
                        $having[] = "IMDS_Status = :is";
                        $params[':is'] = $_POST['issearch'];
                    }

                    if (!empty($_POST['pdsearch'])) {
                        $having[] = "PPAP_docs = :pd";
                        $params[':pd'] = $_POST['pdsearch'];
                    }

                    if (!empty($_POST['levelsearch'])) {
                        $having[] = "`Level` = :lvl";
                        $params[':lvl'] = $_POST['levelsearch'];
                    }

                    if (!empty($_POST['psssearch'])) {
                        $having[] = "Samples_Status = :ps";
                        $params[':ps'] = $_POST['psssearch'];
                    }

                    if (!empty($_POST['rssearch'])) {
                        $having[] = "Reason_submission = :rs";
                        $params[':rs'] = $_POST['rssearch'];
                    }

                    // if(empty($_POST['sent1search']) || empty($_POST['sent2search'])) {
                    //     $having[] = "1 = 1";
                    // }
                    // if(!empty($_POST['sent1search']) && !empty($_POST['sent2search'])) {
                    //     $having[] = "Sent_Customer BETWEEN :sent1 AND :sent2";
                    //     $params[':sent1'] = $_POST['sent1search'];
                    //     $params[':sent2'] = $_POST['sent2search'];
                    // }

                    if(empty($_POST['psw1search']) || empty($_POST['psw2search'])) {
                        $having[] = "1 = 1";
                    }
                    if(!empty($_POST['psw1search']) && !empty($_POST['psw2search'])) {
                        $having[] = "PSW_Returned BETWEEN :psw1 AND :psw2";
                        $params[':psw1'] = $_POST['psw1search'];
                        $params[':psw2'] = $_POST['psw2search'];
                    }

                    if(!empty($_POST['originsearch']) && $_POST['originsearch'] == "") {
                        $having[] = "1 = 1";
                    }
                    if(!empty($_POST['originsearch']) && $_POST['originsearch'] == "Y") {
                        $having[] = "Origin_from_report IS NOT NULL";
                    }
                    if(!empty($_POST['originsearch']) && $_POST['originsearch'] == "N") {
                        $having[] = "Origin_from_report IS NULL";
                    }

                    if (!empty($_POST['comsearch'])) {
                        $having[] = "Comments = :com";
                        $params[':com'] = $_POST['comsearch'];
                    }

                    if (!empty($_POST['irnsearch'])) {
                        $having[] = "Inspection_rep_numb = :irn";
                        $params[':irn'] = $_POST['irnsearch'];
                    }

                    $sql = "
                        SELECT 
                            if(Sent_Customer IS NULL, datediff(NOW(), PPAP_Req_by_Cus_Date), datediff(Sent_Customer, PPAP_Req_by_Cus_Date)) AS 'Days to Submit',
                            tps.TUB_PPAPS_ID,
                            tp.PPAP_Number,
                            tps.PPAP_Req_by_Cus_Date,
                            tps.Current_Status,
                            v.Short_name,
                            c.`Name`,
                            cppapn.Country,
                            cpn.Customer_PN,
                            t.ET_Model,
                            t.ET_Dwg,
                            tps.Rev,
                            t.Eurotech_PN,
                            t.`Description`,
                            tps.IMDS_Number,
                            tps.IMDS_Status,
                            tps.PPAP_docs,
                            tps.`Level`,
                            tps.Samples_Status,
                            tps.Reason_submission,
                            tps.Sent_Customer,
                            tps.PSW_Returned,
                            tps.Origin_from_report,
                            tps.Comments,
                            tps.Inspection_rep_numb
                        FROM tubes_ppaps tps
                            INNER JOIN tubes_ppap tp ON tps.FK_PPAP_Number = tp.PPAP_Number
                            INNER JOIN customer_pn cpn ON tp.FK_Customer_PN = cpn.Customer_PN
                            INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                            INNER JOIN products t ON cpn.FK_Eurotech_PN = t.Eurotech_PN
                            INNER JOIN customer_ppap_number cppapn ON c.Customer_ID = cppapn.FK_Customer_ID
                            LEFT JOIN vendors v ON t.Supplier = v.Vendor_ID
                        HAVING " . implode(' AND ', $having) . "
                        ORDER BY PPAP_Number;";

                    $stmt = $this->mbd->prepare($sql);
                    $stmt->execute($params);
                    
                    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
                else {
                    foreach ($this->mbd->query(
                        "SELECT 
                            if(Sent_Customer IS NULL, datediff(NOW(), PPAP_Req_by_Cus_Date), datediff(Sent_Customer, PPAP_Req_by_Cus_Date)) AS 'Days to Submit',
                            tps.TUB_PPAPS_ID,
                            tp.PPAP_Number,
                            tps.PPAP_Req_by_Cus_Date,
                            tps.Current_Status,
                            v.Short_name,
                            c.`Name`,
                            cppapn.Country,
                            cpn.Customer_PN,
                            t.ET_Model,
                            t.ET_Dwg,
                            tps.Rev,
                            t.Eurotech_PN,
                            t.`Description`,
                            tps.IMDS_Number,
                            tps.IMDS_Status,
                            tps.PPAP_docs,
                            tps.`Level`,
                            tps.Samples_Status,
                            tps.Reason_submission,
                            tps.Sent_Customer,
                            tps.PSW_Returned,
                            tps.Origin_from_report,
                            tps.Comments,
                            tps.Inspection_rep_numb
                        FROM tubes_ppaps tps
                            INNER JOIN tubes_ppap tp ON tps.FK_PPAP_Number = tp.PPAP_Number
                            INNER JOIN customer_pn cpn ON tp.FK_Customer_PN = cpn.Customer_PN
                            INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                            INNER JOIN products t ON cpn.FK_Eurotech_PN = t.Eurotech_PN
                            INNER JOIN customer_ppap_number cppapn ON c.Customer_ID = cppapn.FK_Customer_ID
                            LEFT JOIN vendors v ON t.Supplier = v.Vendor_ID
                        ORDER BY PPAP_Number;"
                    ) as $log) {
                        $logs[] = $log;
                    }
                }
            } else {
                foreach ($this->mbd->query(
                    "SELECT 
                            if(Sent_Customer IS NULL, datediff(NOW(), PPAP_Req_by_Cus_Date), datediff(Sent_Customer, PPAP_Req_by_Cus_Date)) AS 'Days to Submit',
                            tps.TUB_PPAPS_ID,
                            tp.PPAP_Number,
                            tps.PPAP_Req_by_Cus_Date,
                            tps.Current_Status,
                            v.Short_name,
                            c.`Name`,
                            cppapn.Country,
                            cpn.Customer_PN,
                            t.ET_Model,
                            t.ET_Dwg,
                            tps.Rev,
                            t.Eurotech_PN,
                            t.`Description`,
                            tps.IMDS_Number,
                            tps.IMDS_Status,
                            tps.PPAP_docs,
                            tps.`Level`,
                            tps.Samples_Status,
                            tps.Reason_submission,
                            tps.Sent_Customer,
                            tps.PSW_Returned,
                            tps.Origin_from_report,
                            tps.Comments,
                            tps.Inspection_rep_numb
                        FROM tubes_ppaps tps
                            INNER JOIN tubes_ppap tp ON tps.FK_PPAP_Number = tp.PPAP_Number
                            INNER JOIN customer_pn cpn ON tp.FK_Customer_PN = cpn.Customer_PN
                            INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                            INNER JOIN products t ON cpn.FK_Eurotech_PN = t.Eurotech_PN
                            INNER JOIN customer_ppap_number cppapn ON c.Customer_ID = cppapn.FK_Customer_ID
                            LEFT JOIN vendors v ON t.Supplier = v.Vendor_ID
                        ORDER BY PPAP_Number;"
                ) as $log) {
                    $logs[] = $log;
                }
            }
            return $logs;
        }

        function searchRenew($ID, $i){
            $Renewlogs = [];
            foreach ($this->mbd->query(
                 "SELECT 
                    tr.Renewal_Date,
                    tr.Sent_Request_CTC,
                    tr.Sent_Customer,
                    tr.Returned_Cust_Signed,
                    tr.FK_TAP_PPAP_ID,
                    tp.TAP_PPAP_ID,
                    YEAR(tr.Renewal_Date) AS 'Year',
                    YEAR(tr.Sent_Customer) AS 'Year2'
                FROM tapes_ppap tp
                    LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID
                WHERE tp.TAP_PPAP_ID = $ID
                HAVING `Year` = $i OR (`Year` IS NULL AND `Year2` = $i);"
            ) as $Renewlog) {
                $Renewlogs[] = $Renewlog;
            }

            return $Renewlogs;
        }

        function searchNoRenew($id){
            $NRenewlogs = [];
            foreach ($this->mbd->query(
                 "SELECT
                    tp.TAP_PPAP_ID
                FROM tapes_ppap tp
                LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID
                WHERE tr.TAP_Renewal_ID IS NULL AND tp.TAP_PPAP_ID = $id;"
            ) as $NRenewlog) {
                $NRenewlogs[] = $NRenewlog;
            }

            return $NRenewlogs;
        }

        function searchMaxYearRD($id){
            $MaxYears = [];
            foreach ($this->mbd->query(
                "SELECT DISTINCT 
                    tp.TAP_PPAP_ID, 
                    YEAR(MAX(tr.Renewal_Date)) AS 'MAX'
                FROM tapes_ppap tp 
                    INNER JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID
                WHERE TAP_PPAP_ID = $id
                GROUP BY tp.TAP_PPAP_ID;"
            ) as $MaxYear) {
                $MaxYears[] = $MaxYear;
            }

            return $MaxYears;
        }

        function searchMaxYearSC($id){
            $MaxYearsSCS = [];
            foreach ($this->mbd->query(
                "SELECT DISTINCT 
                    tp.TAP_PPAP_ID, 
                    YEAR(MAX(tr.Sent_Customer)) AS 'MAX'
                FROM tapes_ppap tp 
                    INNER JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID
                WHERE TAP_PPAP_ID = $id AND tr.Renewal_Date IS NULL
                GROUP BY tp.TAP_PPAP_ID;"
            ) as $MaxYearsSC) {
                $MaxYearsSCS[] = $MaxYearsSC;
            }

            return $MaxYearsSCS;
        }

        function searchMaxY(){
            $MaxYs = [];
            foreach ($this->mbd->query(
                "SELECT
                    YEAR(MAX(tr.Renewal_Date)) AS 'Max'
                FROM tapes_renewal tr;"
            ) as $MaxY) {
                $MaxYs[] = $MaxY;
            }

            return $MaxYs;
        }

        function searchDates2($maxy, $id){
            $dates2 = [];
            
                foreach ($this->mbd->query(
                    "SELECT * FROM tapes_renewal tr
                        RIGHT JOIN tapes_ppap tp ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID AND (Year(tr.Renewal_Date) = $maxy OR (tr.Renewal_Date IS NULL AND Year(tr.Sent_Customer) = $maxy))
                        INNER JOIN customer_pn tcp ON tp.FK_Customer_PN  = tcp.Customer_PN
                        INNER JOIN customers c ON tcp.FK_Customer_ID = c.Customer_ID
                        INNER JOIN products t ON tcp.FK_Eurotech_PN = t.Eurotech_PN
                    WHERE TAP_PPAP_ID = $id"
                ) as $date) {
                    $dates2[] = $date;
                }
            
            return $dates2;
        }
        
        function searchDates($maxy, $id){
            $dates = [];
            if($maxy != NULL) {
                foreach ($this->mbd->query(
                    "SELECT 
                        tr.Renewal_Date, 
                        tr.Sent_Request_CTC, 
                        tr.Sent_Customer, 
                        tr.Returned_Cust_Signed 
                    FROM tapes_renewal tr
                    WHERE (Year(tr.Renewal_Date) = $maxy OR Year(tr.Sent_Customer) = $maxy) AND tr.FK_TAP_PPAP_ID = $id
                    UNION
                    SELECT 
                        tr.Renewal_Date, 
                        tr.Sent_Request_CTC, 
                        tr.Sent_Customer, 
                        tr.Returned_Cust_Signed 
                    FROM tapes_renewal tr
                    WHERE (Year(tr.Renewal_Date)IS NULL AND Year(tr.Sent_Customer) IS NULL) AND tr.FK_TAP_PPAP_ID = $id"
                ) as $date) {
                    $dates[] = $date;
                }
            }
            
            return $dates;
        }

        // CONTROLLER

        function searchPPAPN(){
            $PPAPNS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        PPAP_Number
                    FROM tubes_ppap
                    ORDER BY PPAP_Number;"
                ) as $PPAPN) {
                    $PPAPNS[] = $PPAPN;
                }
            return $PPAPNS;
        }

        function searchCS(){
            $Currents = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Current_Status
                    FROM tubes_ppaps
                    ORDER BY Current_Status;"
                ) as $Current) {
                    $Currents[] = $Current;
                }
            return $Currents;
        }

        function searchPIS(){
            $PIS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Short_name
                    FROM vendors
                    ORDER BY Short_name;"
                ) as $PI) {
                    $PIS[] = $PI;
                }
            return $PIS;
        }

        function searchSAP(){
            $SAPS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Supplier_PN
                    FROM products
                    ORDER BY Supplier_PN;"
                ) as $SAP) {
                    $SAPS[] = $SAP;
                }
            return $SAPS;
        }

        function searchOEM(){
            $OEMS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        `OEM`
                    FROM tapes_ppap
                    ORDER BY `OEM`;"
                ) as $OEM) {
                    $OEMS[] = $OEM;
                }
            return $OEMS;
        }

        function searchCust(){
            $Customers = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        `Name`
                    FROM customers
                    ORDER BY `Name`;"
                ) as $Customer) {
                    $Customers[] = $Customer;
                }
            return $Customers;
        }

        function searchCoun(){
            $Countries = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Country
                    FROM tapes_ppap
                    UNION 
                    SELECT DISTINCT
                        Country
                    FROM customer_ppap_number
                    ORDER BY Country;"
                ) as $Country) {
                    $Countries[] = $Country;
                }
            return $Countries;
        }

        function searchCPN(){
            $CPNS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Customer_PN
                    FROM customer_pn cpn
                    INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                    ORDER BY Customer_PN;"
                ) as $CPN) {
                    $CPNS[] = $CPN;
                }
            return $CPNS;
        }

        function searchETM(){
            $ETMS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        ET_Model
                    FROM products
                    WHERE Product = 'Tube'
                    ORDER BY ET_Model;"
                ) as $ETM) {
                    $ETMS[] = $ETM;
                }
            return $ETMS;
        }

        function searchETD(){
            $ETDS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        ET_Dwg
                    FROM products
                    WHERE Product = 'Tube'
                    ORDER BY ET_Dwg;"
                ) as $ETD) {
                    $ETDS[] = $ETD;
                }
            return $ETDS;
        }

        function searchRev(){
            $Revs = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Rev
                    FROM tubes_ppaps
                    ORDER BY Rev;"
                ) as $Rev) {
                    $Revs[] = $Rev;
                }
            return $Revs;
        }

        function searchETPN(){
            $ETPNS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Eurotech_PN
                    FROM products
                    ORDER BY Eurotech_PN;"
                ) as $ETPN) {
                    $ETPNS[] = $ETPN;
                }
            return $ETPNS;
        }

        function searchDesc(){
            $Descs = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        `Description`
                    FROM products
                    ORDER BY `Description`;"
                ) as $Desc) {
                    $Descs[] = $Desc;
                }
            return $Descs;
        }

        // function searchTape(){
        //     $Tapes = [];
        //         foreach ($this->mbd->query(
        //             "SELECT DISTINCT
        //                 `Tape`
        //             FROM products
        //             WHERE Product = 'Tape'
        //             ORDER BY `Tape`;"
        //         ) as $Tape) {
        //             $Tapes[] = $Tape;
        //         }
        //     return $Tapes;
        // }

        // function searchWidth(){
        //     $Widths = [];
        //         foreach ($this->mbd->query(
        //             "SELECT DISTINCT
        //                 Width
        //             FROM products
        //             WHERE Product = 'Tape'
        //             ORDER BY Width;"
        //         ) as $Width) {
        //             $Widths[] = $Width;
        //         }
        //     return $Widths;
        // }

        // function searchLength(){
        //     $Lengths = [];
        //         foreach ($this->mbd->query(
        //             "SELECT DISTINCT
        //                 `Length`
        //             FROM products
        //             WHERE Product = 'Tape'
        //             ORDER BY `Length`;"
        //         ) as $Length) {
        //             $Lengths[] = $Length;
        //         }
        //     return $Lengths;
        // }

        // function searchColor(){
        //     $Colors = [];
        //         foreach ($this->mbd->query(
        //             "SELECT DISTINCT
        //                 Color
        //             FROM products
        //             WHERE Product = 'Tape'
        //             ORDER BY Color;"
        //         ) as $Color) {
        //             $Colors[] = $Color;
        //         }
        //     return $Colors;
        // }

        function searchIMDS(){
            $IMDS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        IMDS_ID_No
                    FROM tapes_ppap
                    UNION 
                    SELECT DISTINCT
                        IMDS_Number
                    FROM tubes_ppaps;"
                ) as $IM) {
                    $IMDS[] = $IM;
                }
            return $IMDS;
        }

        function searchIS(){
            $ISS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        IMDS_Status
                    FROM tubes_ppaps
                    ORDER BY IMDS_Status;"
                ) as $IS) {
                    $ISS[] = $IS;
                }
            return $ISS;
        }

        function searchPD(){
            $PDS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        PPAP_docs
                    FROM tubes_ppaps
                    ORDER BY PPAP_docs;"
                ) as $PD) {
                    $PDS[] = $PD;
                }
            return $PDS;
        }

        function searchPS(){
            $PSSS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Samples_Status
                    FROM tubes_ppaps
                    ORDER BY Samples_Status;"
                ) as $PSS) {
                    $PSSS[] = $PSS;
                }
            return $PSSS;
        }

        function searchRS(){
            $RSS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Reason_submission
                    FROM tubes_ppaps
                    ORDER BY Reason_submission;"
                ) as $RS) {
                    $RSS[] = $RS;
                }
            return $RSS;
        }

        function searchCom(){
            $Coms = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Comments
                    FROM tapes_ppap
                    UNION
                    SELECT DISTINCT
                        Comments
                    FROM tubes_ppaps
                    ORDER BY Comments;"
                ) as $Com) {
                    $Coms[] = $Com;
                }
            return $Coms;
        }

        function searchIRN(){
            $IRNS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Inspection_rep_numb
                    FROM tubes_ppaps
                    ORDER BY Inspection_rep_numb;"
                ) as $IRN) {
                    $IRNS[] = $IRN;
                }
            return $IRNS;
        }
    }
?>