<?php 
    include "model.php";

    $model = new model();
    $model->cn();
    $logsTapes = [];
    $logsBluSeal = [];
    $logsCables = [];
    $Renewlogs = [];
    $NRenewlogs = [];
    $MaxYears = [];
    $MaxYs = [];
    $Regs = [];
    $dates = [];
    $datesNULL = [];

    if (isset($_POST["submit1search"]) && isset($_POST["submit2search"])){
        $submit1search = $_POST["submit1search"];
        $submit2search = $_POST["submit2search"];
    }    
    else {
        $submit1search = "";
        $submit2search = "";
    }

    if (isset($_POST["days1search"]) && isset($_POST["days2search"])){
        $days1search = $_POST["days1search"];
        $days2search = $_POST["days2search"];
    }    
    else {
        $days1search = "";
        $days2search = "";
    }

    if (isset($_POST["ppapnsearch"])){
        $ppapnsearch = $_POST["ppapnsearch"];
    }    
    else {
        $ppapnsearch = "";
    }

    if (isset($_POST["date1search"]) && isset($_POST["date2search"])){
        $date1search = $_POST["date1search"];
        $date2search = $_POST["date2search"];
    }    
    else {
        $date1search = "";
        $date2search = "";
    }

    if (isset($_POST["req1n"])){
        $req1n = $_POST["req1n"];
    }    
    else {
        $req1n = NULL;
    }

    if (isset($_POST["currentsearch"])){
        $currentsearch = $_POST["currentsearch"];
    }    
    else {
        $currentsearch = "";
    }

    if (isset($_POST["curn"])){
        $curn = $_POST["curn"];
    }    
    else {
        $curn = NULL;
    }

    if (isset($_POST["pisearch"])){
        $pisearch = $_POST["pisearch"];
    }    
    else {
        $pisearch = "";
    }

    if (isset($_POST["sapsearch"])){
        $sapsearch = $_POST["sapsearch"];
    }    
    else {
        $sapsearch = NULL;
    }

    if (isset($_POST["oemsearch"])){
        $oemsearch = $_POST["oemsearch"];
    }    
    else {
        $oemsearch = NULL;
    }
    
    if (isset($_POST["custsearch"])){
        $custsearch = $_POST["custsearch"];
    }    
    else {
        $custsearch = NULL;
    }

    if (isset($_POST["cusn"])){
        $cusn = $_POST["cusn"];
    }    
    else {
        $cusn = NULL;
    }

    if (isset($_POST["counsearch"])){
        $counsearch = $_POST["counsearch"];
    }    
    else {
        $counsearch = NULL;
    }

    if (isset($_POST["cpnsearch"])){
        $cpnsearch = $_POST["cpnsearch"];
    }    
    else {
        $cpnsearch = NULL;
    }

    if (isset($_POST["etmsearch"])){
        $etmsearch = $_POST["etmsearch"];
    }    
    else {
        $etmsearch = "";
    }

    if (isset($_POST["etdsearch"])){
        $etdsearch = $_POST["etdsearch"];
    }    
    else {
        $etdsearch = "";
    }

    if (isset($_POST["revsearch"])){
        $revsearch = $_POST["revsearch"];
    }    
    else {
        $revsearch = "";
    }

    if (isset($_POST["etpnsearch"])){
        $etpnsearch = $_POST["etpnsearch"];
    }    
    else {
        $etpnsearch = "";
    }

    // if (isset($_POST["tapesearch"])){
    //     $tapesearch = $_POST["tapesearch"];
    // }    
    // else {
    //     $tapesearch = NULL;
    // }

    // if (isset($_POST["widthsearch"])){
    //     $widthsearch = $_POST["widthsearch"];
    // }    
    // else {
    //     $widthsearch = NULL;
    // }

    // if (isset($_POST["lengthsearch"])){
    //     $lengthsearch = $_POST["lengthsearch"];
    // }    
    // else {
    //     $lengthsearch = NULL;
    // }

    // if (isset($_POST["colorsearch"])){
    //     $colorsearch = $_POST["colorsearch"];
    // }    
    // else {
    //     $colorsearch = NULL;
    // }

    if (isset($_POST["descsearch"])){
        $descsearch = $_POST["descsearch"];
    }    
    else {
        $descsearch = "";
    }

    if (isset($_POST["imdssearch"])){
        $imdssearch = $_POST["imdssearch"];
    }    
    else {
        $imdssearch = NULL;
    }

    if (isset($_POST["imdn"])){
        $imdn = $_POST["imdn"];
    }    
    else {
        $imdn = NULL;
    }

    if (isset($_POST["issearch"])){
        $issearch = $_POST["issearch"];
    }    
    else {
        $issearch = "";
    }

    if (isset($_POST["imsn"])){
        $imsn = $_POST["imsn"];
    }    
    else {
        $imsn = NULL;
    }

    if (isset($_POST["pdsearch"])){
        $pdsearch = $_POST["pdsearch"];
    }    
    else {
        $pdsearch = "";
    }

    if (isset($_POST["ppdn"])){
        $ppdn = $_POST["ppdn"];
    }    
    else {
        $ppdn = NULL;
    }

    if (isset($_POST["levelsearch"])){
        $levelsearch = $_POST["levelsearch"];
    }    
    else {
        $levelsearch = NULL;
    }

    if (isset($_POST["lvln"])){
        $lvln = $_POST["lvln"];
    }    
    else {
        $lvln = NULL;
    }

    if (isset($_POST["psssearch"])){
        $psssearch = $_POST["psssearch"];
    }    
    else {
        $psssearch = "";
    }

    if (isset($_POST["pssn"])){
        $pssn = $_POST["pssn"];
    }    
    else {
        $pssn = NULL;
    }

    if (isset($_POST["rssearch"])){
        $rssearch = $_POST["rssearch"];
    }    
    else {
        $rssearch = "";
    }  

    if (isset($_POST["rosn"])){
        $rosn = $_POST["rosn"];
    }    
    else {
        $rosn = NULL;
    }

    if (isset($_POST["date3search"]) && isset($_POST["date4search"])){
        $date3search = $_POST["date3search"];
        $date4search = $_POST["date4search"];
    }    
    else {
        $date3search = "";
        $date4search = "";
    }

    if (isset($_POST["recn"])){
        $recn = $_POST["recn"];
    }    
    else {
        $recn = NULL;
    }

    if (isset($_POST["ret1search"]) && isset($_POST["ret2search"])){
        $ret1search = $_POST["ret1search"];
        $ret2search = $_POST["ret2search"];
    }    
    else {
        $ret1search = "";
        $ret2search = "";
    }

    if (isset($_POST["retn"])){
        $retn = $_POST["retn"];
    }    
    else {
        $retn = NULL;
    }

    if (isset($_POST["psw1search"]) && isset($_POST["psw2search"])){
        $psw1search = $_POST["psw1search"];
        $psw2search = $_POST["psw2search"];
    }    
    else {
        $psw1search = "";
        $psw2search = "";
    }

    if (isset($_POST["pscn"])){
        $pscn = $_POST["pscn"];
    }    
    else {
        $pscn = NULL;
    }

    if (isset($_POST["ren1search"]) && isset($_POST["ren2search"])){
        $ren1search = $_POST["ren1search"];
        $ren2search = $_POST["ren2search"];
    }    
    else {
        $ren1search = "";
        $ren2search = "";
    }

    if (isset($_POST["renn"])){
        $renn = $_POST["renn"];
    }    
    else {
        $renn = NULL;
    }

    if (isset($_POST["req1search"]) && isset($_POST["req2search"])){
        $req1search = $_POST["req1search"];
        $req2search = $_POST["req2search"];
    }    
    else {
        $req1search = "";
        $req2search = "";
    }

    if (isset($_POST["reqn"])){
        $reqn = $_POST["reqn"];
    }    
    else {
        $reqn = NULL;
    }

    if (isset($_POST["sent1search"]) && isset($_POST["sent2search"])){
        $sent1search = $_POST["sent1search"];
        $sent2search = $_POST["sent2search"];
    }    
    else {
        $sent1search = "";
        $sent2search = "";
    }

    if (isset($_POST["stcn"])){
        $stcn = $_POST["stcn"];
    }    
    else {
        $stcn = NULL;
    }

    if (isset($_POST["pswr1search"]) && isset($_POST["pswr2search"])){
        $pswr1search = $_POST["pswr1search"];
        $pswr2search = $_POST["pswr2search"];
    }    
    else {
        $pswr1search = "";
        $pswr2search = "";
    }

    if (isset($_POST["pcsn"])){
        $pcsn = $_POST["pcsn"];
    }    
    else {
        $pcsn = NULL;
    }

    if (isset($_POST["pfsn"])){
        $pfsn = $_POST["pfsn"];
    }    
    else {
        $pfsn = NULL;
    }

    if (isset($_POST["originsearch"])){
        $originsearch = $_POST["originsearch"];
    }    
    else {
        $originsearch = "";
    } 

    if (isset($_POST["comsearch"])){
        $comsearch = $_POST["comsearch"];
    }    
    else {
        $comsearch = NULL;
    }

    if (isset($_POST["irnsearch"])){
        $irnsearch = $_POST["irnsearch"];
    }    
    else {
        $irnsearch = "";
    } 

    $selects = [];
    $years = [];
    $params = [];
    $tapeData = NULL;
    $tapeDataD = NULL;
    $tapeRenewData = [];
    $tapeRenewDataD = [];
    $tapeRenewD = NULL;
    $tapeRenewDDel = NULL;
    $Deleted = NULL;


    $pdo = new PDO("mysql:host=localhost;dbname=eurotechdb", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        if (isset($_POST['noteB'])) {
            $id = $_POST['IDnote'];
            $stmt = $pdo->prepare("SELECT BS_PPAP_ID, PPAP_ET, IMDS_ET FROM bluseal_ppap WHERE BS_PPAP_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $noteData = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmNoteB'])) {
            if(!isset($_POST['PPAP_ET']) &&  !isset($_POST['IMDS_ET'])) {
                $stmt = $pdo->prepare("UPDATE bluseal_ppap SET 
                                        PPAP_ET = NULL, 
                                        IMDS_ET = NULL 
                                        WHERE BS_PPAP_ID = ?");

                $stmt->execute([
                    $_POST['confirmIDNote']
                ]);
            }
            if(!isset($_POST['PPAP_ET']) && isset($_POST['IMDS_ET'])) {
                $stmt = $pdo->prepare("UPDATE bluseal_ppap SET 
                                        PPAP_ET = NULL, 
                                        IMDS_ET = '1' 
                                        WHERE BS_PPAP_ID = ?");

                $stmt->execute([
                    $_POST['confirmIDNote']
                ]);
            }
            if(isset($_POST['PPAP_ET']) && !isset($_POST['IMDS_ET'])) {
                $stmt = $pdo->prepare("UPDATE bluseal_ppap SET 
                                        PPAP_ET = '1', 
                                        IMDS_ET = NULL
                                        WHERE BS_PPAP_ID = ?");

                $stmt->execute([
                    $_POST['confirmIDNote']
                ]);
            }
            if(isset($_POST['PPAP_ET']) && isset($_POST['IMDS_ET']) ) {
                $stmt = $pdo->prepare("UPDATE bluseal_ppap SET 
                                        PPAP_ET = '1', 
                                        IMDS_ET = '1'
                                        WHERE BS_PPAP_ID = ?");

                $stmt->execute([
                    $_POST['confirmIDNote']
                ]);
            } 
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['noteC'])) {
            $id = $_POST['IDnote'];
            $stmt = $pdo->prepare("SELECT CAB_PPAP_ID, PSW_ET, IMDS_ET FROM cables_ppap WHERE CAB_PPAP_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $noteData = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmNoteC'])) {
            if(!isset($_POST['PSW_ET']) &&  !isset($_POST['IMDS_ET'])) {
                $stmt = $pdo->prepare("UPDATE cables_ppap SET 
                                        PSW_ET = NULL, 
                                        IMDS_ET = NULL 
                                        WHERE CAB_PPAP_ID = ?");

                $stmt->execute([
                    $_POST['confirmIDNote']
                ]);
            }
            if(!isset($_POST['PSW_ET']) && isset($_POST['IMDS_ET'])) {
                $stmt = $pdo->prepare("UPDATE cables_ppap SET 
                                        PSW_ET = NULL, 
                                        IMDS_ET = '1' 
                                        WHERE CAB_PPAP_ID = ?");

                $stmt->execute([
                    $_POST['confirmIDNote']
                ]);
            }
            if(isset($_POST['PSW_ET']) && !isset($_POST['IMDS_ET'])) {
                $stmt = $pdo->prepare("UPDATE cables_ppap SET 
                                        PSW_ET = '1', 
                                        IMDS_ET = NULL
                                        WHERE CAB_PPAP_ID = ?");

                $stmt->execute([
                    $_POST['confirmIDNote']
                ]);
            }
            if(isset($_POST['PSW_ET']) && isset($_POST['IMDS_ET']) ) {
                $stmt = $pdo->prepare("UPDATE cables_ppap SET 
                                        PSW_ET = '1', 
                                        IMDS_ET = '1'
                                        WHERE CAB_PPAP_ID = ?");

                $stmt->execute([
                    $_POST['confirmIDNote']
                ]);
            } 
           
            $_SESSION['saved'] = true;
        }


        if (isset($_POST['confirmID'])) {
            $stmt = $pdo->prepare("SELECT Eurotech_PN FROM products WHERE `Tape` = '".$_POST['Tape']."' 
                                    AND Width = '".$_POST['Width']."' AND Length = '".$_POST['Length']."' 
                                    AND Color = '".$_POST['Color']."';");
            $stmt->execute([]);
            $etpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT `Name` FROM customers WHERE `Name` = ?");
            $stmt->execute([
                $_POST['Name']
            ]);
            $cn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($etpn != NULL && $cn != NULL) {
                foreach ($etpn as $pn) {
                    $stmt = $pdo->prepare("SELECT Customer_PN FROM customer_pn cpn
                                                INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                                WHERE cpn.FK_Eurotech_PN = ? AND c.`Name` = ?");
                    $stmt->execute([
                        $pn,
                        $_POST['Name']
                    ]);
                    $cpn = $stmt->fetchAll(PDO::FETCH_COLUMN);
                }

                if($cpn != NULL) {
                    foreach ($cpn as $c) {
                        if(!empty($_POST['OEM'])) {
                            $inserts[] = "OEM";
                            $paramsI[] = "'".$_POST['OEM']."'";
                        }

                        if(!empty($_POST['Country'])) {
                            $inserts[] = "Country";
                            $paramsI[] = "'".$_POST['Country']."'";
                        }

                        if(!empty($_POST['PPAP_level'])) {
                            $inserts[] = "PPAP_level";
                            $paramsI[] = "'".$_POST['PPAP_level']."'";
                        }

                        if(!empty($_POST['IMDS'])) {
                            $inserts[] = "IMDS_ID_No";
                            $paramsI[] = "'".$_POST['IMDS']."'";
                        }

                        if(!empty($_POST['Returned_CTC-Sent_Cust'])) {
                            $inserts[] = "`Returned_CTC-Sent_Cust`";
                            $paramsI[] = "'".$_POST['Returned_CTC-Sent_Cust']."'";
                        }

                        if(!empty($_POST['Cust_Signed-Sent_CTC'])) {
                            $inserts[] = "`Cust_Signed-Sent_CTC`";
                            $paramsI[] = "'".$_POST['Cust_Signed-Sent_CTC']."'";
                        }

                        if(!empty($_POST['PPAP_from_shipments']) && $_POST['PPAP_from_shipments'] != 'no') {
                            $inserts[] = "PPAP_from_shipments";
                            $paramsI[] = "'".$_POST['PPAP_from_shipments']."'";
                        }

                        if(!empty($_POST['Comments'])) {
                            $inserts[] = "Comments";
                            $paramsI[] = "'".$_POST['Comments']."'";
                        }

                        $inserts[] = "FK_Customer_PN";
                        $paramsI[] = "'$c'";
                        
                        $stmt = $pdo->prepare("INSERT INTO tapes_ppap (". implode(', ', $inserts) .") 
                                                VALUES (". implode(', ', $paramsI) .")");
                        $stmt->execute([]);
                    }
                }
                else {
                    $_POST['insertD'] = 1;
                    $error = "Customer PN doesn't exist.";
                }
            }
            if($etpn == NULL && $cn != NULL) {
                $_POST['insertD'] = 1;
                $error = "The description <b>".$_POST['Tape']."-".$_POST['Width']."-".$_POST['Length']."-".$_POST['Color']."</b> doesn't exist.";
            }
            if($etpn != NULL && $cn == NULL) {
                $_POST['insertD'] = 1;
                $error = "The customer <b>".$_POST['Name']."</b> doesn't exist.";
            }
            if($etpn == NULL && $cn == NULL) {
                $_POST['insertD'] = 1;
                $error = "The description <b>".$_POST['Tape']."-".$_POST['Width']."-".$_POST['Length']."-".$_POST['Color']."</b> and the customer <b>".$_POST['Name']."</b> don't exist.";
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['confirmIE'])) {
            $stmt = $pdo->prepare("SELECT Eurotech_PN FROM products WHERE Eurotech_PN = ?;");
            $stmt->execute([
                $_POST['Eurotech_PN']
            ]);
            $etpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT `Name` FROM customers WHERE `Name` = ?");
            $stmt->execute([
                $_POST['Name']
            ]);
            $cn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($etpn != NULL && $cn != NULL) {
                foreach ($etpn as $pn) {
                    $stmt = $pdo->prepare("SELECT Customer_PN FROM customer_pn cpn
                                                INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                                WHERE cpn.FK_Eurotech_PN = ? AND c.`Name` = ?");
                    $stmt->execute([
                        $pn,
                        $_POST['Name']
                    ]);
                    $cpn = $stmt->fetchAll(PDO::FETCH_COLUMN);
                }

                if($cpn != NULL) {
                    foreach ($cpn as $c) {
                        if(!empty($_POST['OEM'])) {
                            $inserts[] = "OEM";
                            $paramsI[] = "'".$_POST['OEM']."'";
                        }

                        if(!empty($_POST['Country'])) {
                            $inserts[] = "Country";
                            $paramsI[] = "'".$_POST['Country']."'";
                        }

                        if(!empty($_POST['PPAP_level'])) {
                            $inserts[] = "PPAP_level";
                            $paramsI[] = "'".$_POST['PPAP_level']."'";
                        }

                        if(!empty($_POST['IMDS'])) {
                            $inserts[] = "IMDS_ID_No";
                            $paramsI[] = "'".$_POST['IMDS']."'";
                        }

                        if(!empty($_POST['Returned_CTC-Sent_Cust'])) {
                            $inserts[] = "`Returned_CTC-Sent_Cust`";
                            $paramsI[] = "'".$_POST['Returned_CTC-Sent_Cust']."'";
                        }

                        if(!empty($_POST['Cust_Signed-Sent_CTC'])) {
                            $inserts[] = "`Cust_Signed-Sent_CTC`";
                            $paramsI[] = "'".$_POST['Cust_Signed-Sent_CTC']."'";
                        }

                        if(!empty($_POST['PPAP_from_shipments']) && $_POST['PPAP_from_shipments'] != 'no') {
                            $inserts[] = "PPAP_from_shipments";
                            $paramsI[] = "'".$_POST['PPAP_from_shipments']."'";
                        }

                        if(!empty($_POST['Comments'])) {
                            $inserts[] = "Comments";
                            $paramsI[] = "'".$_POST['Comments']."'";
                        }

                        $inserts[] = "FK_Customer_PN";
                        $paramsI[] = "'$c'";
                        
                        $stmt = $pdo->prepare("INSERT INTO tapes_ppap (". implode(', ', $inserts) .") 
                                                VALUES (". implode(', ', $paramsI) .")");
                        $stmt->execute([]);
                    }
                }
                else {
                    $_POST['insertET'] = 1;
                    $error = "Customer PN doesn't exist.";
                }
            }
            if($etpn == NULL && $cn != NULL) {
                $_POST['insertET'] = 1;
                $error = "The Eurotech PN <b>".$_POST['Eurotech_PN']."</b> doesn't exist.";
            }
            if($etpn != NULL && $cn == NULL) {
                $_POST['insertET'] = 1;
                $error = "The customer <b>".$_POST['Name']."</b> doesn't exist.";
            }
            if($etpn == NULL && $cn == NULL) {
                $_POST['insertET'] = 1;
                $error = "The Eurotech PN <b>".$_POST['Eurotech_PN']."</b> and the customer <b>".$_POST['Name']."</b> don't exist.";
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['confirmIC'])) {
            $stmt = $pdo->prepare("SELECT Customer_PN FROM customer_pn WHERE Customer_PN = ?");
            $stmt->execute([
                $_POST['Customer_PN']
            ]);
            $cpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($cpn != NULL) {
                foreach ($cpn as $c) {
                        if(!empty($_POST['OEM'])) {
                            $inserts[] = "OEM";
                            $paramsI[] = "'".$_POST['OEM']."'";
                        }

                        if(!empty($_POST['Country'])) {
                            $inserts[] = "Country";
                            $paramsI[] = "'".$_POST['Country']."'";
                        }

                        if(!empty($_POST['PPAP_level'])) {
                            $inserts[] = "PPAP_level";
                            $paramsI[] = "'".$_POST['PPAP_level']."'";
                        }

                        if(!empty($_POST['IMDS'])) {
                            $inserts[] = "IMDS_ID_No";
                            $paramsI[] = "'".$_POST['IMDS']."'";
                        }

                        if(!empty($_POST['Returned_CTC-Sent_Cust'])) {
                            $inserts[] = "`Returned_CTC-Sent_Cust`";
                            $paramsI[] = "'".$_POST['Returned_CTC-Sent_Cust']."'";
                        }

                        if(!empty($_POST['Cust_Signed-Sent_CTC'])) {
                            $inserts[] = "`Cust_Signed-Sent_CTC`";
                            $paramsI[] = "'".$_POST['Cust_Signed-Sent_CTC']."'";
                        }

                        if(!empty($_POST['PPAP_from_shipments']) && $_POST['PPAP_from_shipments'] != 'no') {
                            $inserts[] = "PPAP_from_shipments";
                            $paramsI[] = "'".$_POST['PPAP_from_shipments']."'";
                        }

                        if(!empty($_POST['Comments'])) {
                            $inserts[] = "Comments";
                            $paramsI[] = "'".$_POST['Comments']."'";
                        }

                        $inserts[] = "FK_Customer_PN";
                        $paramsI[] = "'$c'";
                        
                        $stmt = $pdo->prepare("INSERT INTO tapes_ppap (". implode(', ', $inserts) .") 
                                                VALUES (". implode(', ', $paramsI) .")");
                        $stmt->execute([]);
                }
            }
            else {
                $_POST['insertC'] = 1;
                $error = "The Customer PN <b>".$_POST['Customer_PN']."</b> doesn't exist.";
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['edit'])) {
            $id = $_POST['IDedit'];
            $stmt = $pdo->prepare("SELECT DISTINCT
                                        tp.TAP_PPAP_ID,
                                        tp.OEM,
                                        tp.Country,
                                        c.`Name`,
                                        tp.PPAP_level,
                                        t.Supplier_PN,
                                        tp.FK_Customer_PN,
                                        t.Tape,
                                        t.Width,
                                        t.`Length`,
                                        t.Color,
                                        tp.IMDS_ID_No,
                                        tp.`Returned_CTC-Sent_Cust`,
                                        tp.`Cust_Signed-Sent_CTC`,
                                        tp.PPAP_from_shipments,
                                        tp.Comments
                                    FROM tapes_ppap tp
                                        INNER JOIN customer_pn tcp ON tp.FK_Customer_PN  = tcp.Customer_PN
                                        INNER JOIN customers c ON tcp.FK_Customer_ID = c.Customer_ID
                                        INNER JOIN products t ON tcp.FK_Eurotech_PN = t.Eurotech_PN
                                        LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID 
                                    WHERE TAP_PPAP_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $tapeData = $stmt->fetch(PDO::FETCH_ASSOC);

                $stmt = $pdo->prepare("SELECT MIN(YEAR(Renewal_Date)) AS 'MinR' FROM tapes_renewal WHERE FK_TAP_PPAP_ID = ?");
                $stmt->execute([$id]);
                $rmin = $stmt->fetchAll(PDO::FETCH_ASSOC);

                $stmt = $pdo->prepare("SELECT MAX(YEAR(Renewal_Date)) AS 'MaxR' FROM tapes_renewal WHERE FK_TAP_PPAP_ID = ?");
                $stmt->execute([$id]);
                $rmax = $stmt->fetchAll(PDO::FETCH_ASSOC);

                $stmt = $pdo->prepare("SELECT MIN(YEAR(Sent_Customer)) AS 'MinS' FROM tapes_renewal WHERE FK_TAP_PPAP_ID = ?");
                $stmt->execute([$id]);
                $smin = $stmt->fetchAll(PDO::FETCH_ASSOC);

                $stmt = $pdo->prepare("SELECT MAX(YEAR(Sent_Customer)) AS 'MaxS' FROM tapes_renewal WHERE FK_TAP_PPAP_ID = ?");
                $stmt->execute([$id]);
                $smax = $stmt->fetchAll(PDO::FETCH_ASSOC);

                foreach ($rmin as $rmi) {
                    $minmax[0] = $rmi['MinR'];
                }
                foreach ($rmax as $rma) {
                    $minmax[1] = $rma['MaxR'];
                }
                foreach ($smin as $smi) {
                    $minmax[2] = $smi['MinS'];
                }
                foreach ($smax as $sma) {
                    $minmax[3] = $sma['MaxS'];
                }

                if(min($minmax) == NULL && max($minmax) != NULL) {
                    $min = max($minmax);
                }
                if(min($minmax) != NULL)  {
                    $min = min($minmax);
                }

                if(max($minmax) == NULL && min($minmax) != NULL) {
                    $max = min($minmax);
                }
                if(max($minmax) != NULL) {
                    $max = max($minmax);
                }

                if(min($minmax) == NULL && max($minmax) == NULL) {
                    $min = NULL;
                    $max = NULL;
                }

                if($min != NULL && $max != NULL) {
                    for($i = $min; $i <= $max; $i++) { 
                        $stmt = $pdo->prepare("SELECT *
                                                FROM tapes_renewal 
                                                WHERE FK_TAP_PPAP_ID = ?
                                                AND (YEAR(Renewal_Date) = $i || YEAR(Sent_Request_CTC) = $i || YEAR(Sent_Customer) = $i 
                                                    || YEAR(Returned_Cust_Signed) = $i) 
                                                AND (YEAR(Renewal_Date) = $i || YEAR(Renewal_Date) IS NULL)");
                        $stmt->execute([$id]);
                        $tapeRenewD = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        array_push($tapeRenewData, $tapeRenewD);
                    }
                } 
            }
        }

        if (isset($_POST['confirmU'])) {
            $id = $_POST['TAP_PPAP_ID'];
            $stmt = $pdo->prepare("SELECT MAX(YEAR(Renewal_Date)) AS 'MaxR' FROM tapes_renewal WHERE FK_TAP_PPAP_ID = ?");
            $stmt->execute([$id]);
            $rmax = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rmax as $rma) {
                $max[0] = $rma['MaxR'];
            }

            $stmt = $pdo->prepare("SELECT MAX(YEAR(Sent_Customer)) AS 'MaxS' FROM tapes_renewal WHERE FK_TAP_PPAP_ID = ?");
            $stmt->execute([$id]);
            $smax = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($smax as $sma) {
                $max[1] = $sma['MaxS'];
            }

            $stmt = $pdo->prepare("SELECT MIN(YEAR(Renewal_Date)) AS 'MinR' FROM tapes_renewal WHERE FK_TAP_PPAP_ID = ?");
            $stmt->execute([$id]);
            $rmin = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rmin as $rmi) {
                $min[0] = $rmi['MinR'];
            }

            $stmt = $pdo->prepare("SELECT MIN(YEAR(Sent_Customer)) AS 'MinS' FROM tapes_renewal WHERE FK_TAP_PPAP_ID = ?");
            $stmt->execute([$id]);
            $smin = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($smin as $smi) {
                $min[1] = $smi['MinS'];
            }

            // if(max($max) != NULL) {
                $mx = max($max);
            // }

            // if(min($min) != NULL) {
                $mn = min($min);
                
                if($mn == NULL) {
                    $mn = max($min);
                }
            // }

            // var_dump($min);

            if(isset($mn) && isset($mx)) {
                for($i = $mn; $i <= $mx; $i++) {  
                    $y = (string)$i;
                    if(isset($_POST['Renewal_Date'.$y]) && isset($_POST['Sent_Request_CTC'.$y]) && isset($_POST['Sent_Customer'.$y]) && isset($_POST['Returned_Cust_Signed'.$y])) {
                        if($_POST['Renewal_Date'.$y] != "") {
                            $renD = new DateTime($_POST['Renewal_Date'.$y]);
                            $rD = $renD->format('Y-m-d');
                        }
                        else {
                            $rD = NULL; 
                        }
                        
                        if($_POST['Sent_Request_CTC'.$y] != "") {
                            $senD = new DateTime($_POST['Sent_Request_CTC'.$y]);
                            $sD = $senD->format('Y-m-d');
                        }
                        else {
                            $sD = NULL; 
                        }

                        if($_POST['Sent_Customer'.$y] != "") {
                            $sencD = new DateTime($_POST['Sent_Customer'.$y]);
                            $scD = $sencD->format('Y-m-d');
                        }
                        else {
                            $scD = NULL; 
                        }

                        if($_POST['Returned_Cust_Signed'.$y] != "") {
                            $retD = new DateTime($_POST['Returned_Cust_Signed'.$y]);
                            $rcD = $retD->format('Y-m-d');
                        }
                        else {
                            $rcD = NULL; 
                        }

                        if(($_POST['Renewal_Date'.$y] == "" && $_POST['Sent_Request_CTC'.$y] != "" && $_POST['Sent_Customer'.$y] == "" && $_POST['Returned_Cust_Signed'.$y] == "")
                            || ($_POST['Renewal_Date'.$y] == "" && $_POST['Sent_Request_CTC'.$y] == "" && $_POST['Sent_Customer'.$y] == "" && $_POST['Returned_Cust_Signed'.$y] != "")
                            || ($_POST['Renewal_Date'.$y] == "" && $_POST['Sent_Request_CTC'.$y] != "" && $_POST['Sent_Customer'.$y] == "" && $_POST['Returned_Cust_Signed'.$y] != "")) {
                            $_POST['edit'] = 1;
                            $error = "'Renewal Date' or 'Sent to Customer' can't be empty.";
                        }
                        else {
                            if($_POST['Renewal_Date'.$y] == "" && $_POST['Sent_Request_CTC'.$y] == "" && $_POST['Sent_Customer'.$y] == "" && $_POST['Returned_Cust_Signed'.$y] == "") {
                                $stmt = $pdo->prepare("DELETE FROM tapes_renewal WHERE TAP_Renewal_ID = ?");

                                $stmt->execute([
                                    $_POST['TAP_Renewal_ID'.$y]
                                ]);
                            }
                            else {
                                $stmt = $pdo->prepare("UPDATE tapes_renewal SET 
                                                        Renewal_Date = ?, 
                                                        Sent_Request_CTC = ?,
                                                        Sent_Customer = ?, 
                                                        Returned_Cust_Signed = ?
                                                    WHERE TAP_Renewal_ID = ?");

                                $stmt->execute([
                                    $rD,
                                    $sD,
                                    $scD,
                                    $rcD,
                                    $_POST['TAP_Renewal_ID'.$y]
                                ]);
                            }
                        }
                    }
                }
            }
            
            if(!isset($error)) {
                if($_POST['OEM'] != "") {
                    $oem = $_POST['OEM'];
                }
                else {
                    $oem = NULL;
                }

                if($_POST['Country'] != "") {
                    $cou = $_POST['Country'];
                }
                else {
                    $cou = NULL;
                }

                if($_POST['PPAP_level'] != "") {
                    $lvl = $_POST['PPAP_level'];
                }
                else {
                    $lvl = NULL;
                }

                if($_POST['IMDS'] != "") {
                    $imds = $_POST['IMDS'];
                }
                else {
                    $imds = NULL;
                }

                if($_POST['Returned_CTC-Sent_Cust'] != "") {
                    $custD = new DateTime($_POST['Returned_CTC-Sent_Cust']);
                    $cusD = $custD->format('Y-m-d');
                }
                else {
                    $cusD = NULL;
                }

                if($_POST['Cust_Signed-Sent_CTC'] != "") {
                    $ctcD = new DateTime($_POST['Cust_Signed-Sent_CTC']);
                    $ctD = $ctcD->format('Y-m-d');
                }
                else {
                    $ctD = NULL;
                }

                if($_POST['PPAP_from_shipments'] != "no") {
                    $pfs = $_POST['PPAP_from_shipments'];
                }
                else {
                    $pfs = NULL;
                }

                if($_POST['Comments'] != "") {
                    $com = $_POST['Comments'];
                }
                else {
                    $com = NULL;
                }

                $stmt = $pdo->prepare("UPDATE tapes_ppap SET 
                                                    `OEM` = ?, 
                                                    Country = ?, 
                                                    PPAP_level = ?, 
                                                    IMDS_ID_No = ?, 
                                                    `Returned_CTC-Sent_Cust` = ?, 
                                                    `Cust_Signed-Sent_CTC` = ?, 
                                                    PPAP_from_shipments = ?, 
                                                    Comments = ?
                                                WHERE TAP_PPAP_ID = ?");

                $stmt->execute([
                    $oem,
                    $cou,
                    $lvl,
                    $imds,
                    $cusD,
                    $ctD,
                    $pfs,
                    $com,
                    $_POST['TAP_PPAP_ID']
                ]);
            }
        }

        if (isset($_POST['delete'])) {
            $id = $_POST['IDdelete'];
            $stmt = $pdo->prepare("SELECT DISTINCT
                                        tp.TAP_PPAP_ID,
                                        tp.OEM,
                                        tp.Country,
                                        c.`Name`,
                                        tp.PPAP_level,
                                        t.Supplier_PN,
                                        tp.FK_Customer_PN,
                                        t.Tape,
                                        t.Width,
                                        t.`Length`,
                                        t.Color,
                                        tp.IMDS_ID_No,
                                        tp.`Returned_CTC-Sent_Cust`,
                                        tp.`Cust_Signed-Sent_CTC`,
                                        tp.PPAP_from_shipments,
                                        tp.Comments
                                    FROM tapes_ppap tp
                                        INNER JOIN customer_pn tcp ON tp.FK_Customer_PN  = tcp.Customer_PN
                                        INNER JOIN customers c ON tcp.FK_Customer_ID = c.Customer_ID
                                        INNER JOIN products t ON tcp.FK_Eurotech_PN = t.Eurotech_PN
                                        LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID 
                                    WHERE TAP_PPAP_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $tapeDataD = $stmt->fetch(PDO::FETCH_ASSOC);

                if($_POST['submit1search'] != NULL && $_POST['submit2search'] != NULL) {
                    for($i = (int)$_POST['submit1search']; $i <= (int)$_POST['submit2search']; $i++) { 
                        $stmt = $pdo->prepare("SELECT *
                                                FROM tapes_renewal 
                                                WHERE FK_TAP_PPAP_ID = ?
                                                AND (YEAR(Renewal_Date) = $i || YEAR(Sent_Request_CTC) = $i || YEAR(Sent_Customer) = $i 
                                                    || YEAR(Returned_Cust_Signed) = $i) 
                                                AND (YEAR(Renewal_Date) = $i || YEAR(Renewal_Date) IS NULL)");
                        $stmt->execute([$id]);


                        $year = (string)$i;
                        $tapeRenewDDel = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        array_push($tapeRenewDataD, $tapeRenewDDel);
                    }
                } 
                else {
                    $MaxYs = $model->searchMaxY();
                    for($i = (int)(date("Y", strtotime("-1 year"))); $i <= $MaxYs[0][0]; $i++) {  
                        $stmt = $pdo->prepare("SELECT *
                                                FROM tapes_renewal 
                                                WHERE FK_TAP_PPAP_ID = ?
                                                AND (YEAR(Renewal_Date) = $i || YEAR(Sent_Request_CTC) = $i || YEAR(Sent_Customer) = $i 
                                                    || YEAR(Returned_Cust_Signed) = $i) 
                                                AND (YEAR(Renewal_Date) = $i || YEAR(Renewal_Date) IS NULL)");
                        $stmt->execute([$id]);

                        $year = (string)$i;
                        $tapeRenewDDel = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        array_push($tapeRenewDataD, $tapeRenewDDel);
                    }
                }
            }
        }

        if (isset($_POST['confirmD'])) {
            $id = $_POST['IDdelete'];
            $stmt = $pdo->prepare("DELETE FROM tapes_renewal
                                    WHERE FK_TAP_PPAP_ID = ?");

            $stmt->execute([
                $id
            ]);

            $stmt = $pdo->prepare("DELETE FROM tapes_ppap
                                    WHERE TAP_PPAP_ID = ?");

            $stmt->execute([
                $id
            ]);
           
            $Deleted = 'Y';

            $_SESSION['saved'] = true;
        }

        if(isset($_POST['renewal'])) {
            $id = $_POST['IDPPAP'];
            $stmt = $pdo->prepare("SELECT MAX(YEAR(Renewal_Date)) AS 'MaxR' FROM tapes_renewal WHERE FK_TAP_PPAP_ID = ?");
            $stmt->execute([$id]);
            $rmax = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rmax as $rma) {
                $max[0] = $rma['MaxR'];
            }

            $stmt = $pdo->prepare("SELECT MAX(YEAR(Sent_Customer)) AS 'MaxR' FROM tapes_renewal WHERE FK_TAP_PPAP_ID = ?");
            $stmt->execute([$id]);
            $smax = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($smax as $sma) {
                $max[1] = $sma['MaxR'];
            }
            
            if(max($max) != NULL) {
                $mx = max($max);

                $stmt = $pdo->prepare("SELECT Renewal_Date FROM tapes_renewal WHERE FK_TAP_PPAP_ID = ? AND YEAR(Renewal_Date) = ?;");
                $stmt->execute([$id, $mx]);
                $dms = $stmt->fetchAll(PDO::FETCH_ASSOC);

                if($dms != NULL) {
                    foreach ($dms as $dm) {
                        $maxdate = $dm['Renewal_Date'];
                    }

                    $md = new DateTime($maxdate);
                    $mds = new DateTime($maxdate);
                    $renewal_date = $md->modify('+1 year');
                    $sent_cust_date = $mds->modify('-2 months +1 year');
                }
                else {
                    $stmt = $pdo->prepare("SELECT Sent_Customer FROM tapes_renewal WHERE FK_TAP_PPAP_ID = ? AND YEAR(Sent_Customer) = ?;");
                    $stmt->execute([$id, $mx]);
                    $dms = $stmt->fetchAll(PDO::FETCH_ASSOC);

                    if($dms != NULL) {
                        foreach ($dms as $dm) {
                            $maxdate = $dm['Sent_Customer'];
                        }

                        $md = new DateTime($maxdate);
                        $mds = new DateTime($maxdate);
                        $renewal_date = $md->modify('+1 year');
                        $sent_cust_date = $mds->modify('-2 months +1 year');
                    }
                }
            }
            
            if(max($max) == NULL)  {
                if(($_POST['InitialSCust'] != NULL && $_POST['InitialSCTC'] != NULL)
                    || ($_POST['InitialSCust'] != NULL && $_POST['InitialSCTC'] == NULL)
                    || ($_POST['InitialSCust'] == NULL && $_POST['InitialSCTC'] != NULL)) {
                    if(($_POST['InitialSCust'] != NULL && $_POST['InitialSCTC'] != NULL)
                        || ($_POST['InitialSCust'] != NULL && $_POST['InitialSCTC'] == NULL)) {
                        $initial = $_POST['InitialSCust'];
                    }
                    if($_POST['InitialSCust'] == NULL && $_POST['InitialSCTC'] != NULL) {
                        $initial = $_POST['InitialSCTC'];
                    }
                    $md = new DateTime($initial);
                    $mds = new DateTime($initial);
                    $renewal_date = $md->modify('+1 year');
                    $sent_cust_date = $mds->modify('-2 months +1 year');
                }  
            }
        }

        if(isset($_POST['confirmIR'])) {
            $id = $_POST['FK_TAP_PPAP_ID'];
            if($_POST['Renewal_Date'] != "") {
                $renewalDate = $_POST['Renewal_Date'];
            }
            else {
                $renewalDate = NULL;
            }
            if($_POST['Sent_Request_CTC'] != "") {
                $sentCTCDate = $_POST['Sent_Request_CTC'];
            }
            else {
                $sentCTCDate = NULL;
            }
            if($_POST['Sent_Customer'] != "") {
                $sentCustDate = $_POST['Sent_Customer'];
            }
            else {
                $sentCustDate = NULL;
            }
            if($_POST['Returned_Cust_Signed'] != "") {
                $signDate = $_POST['Returned_Cust_Signed'];
            }
            else {
                $signDate = NULL;
            }

            if(($_POST['Renewal_Date'] == "" && $_POST['Sent_Request_CTC'] != "" && $_POST['Sent_Customer'] == "" && $_POST['Returned_Cust_Signed'] == "")
                || ($_POST['Renewal_Date'] == "" && $_POST['Sent_Request_CTC'] == "" && $_POST['Sent_Customer'] == "" && $_POST['Returned_Cust_Signed'] != "")
                || ($_POST['Renewal_Date'] == "" && $_POST['Sent_Request_CTC'] != "" && $_POST['Sent_Customer'] == "" && $_POST['Returned_Cust_Signed'] != "")
                || ($_POST['Renewal_Date'] == "" && $_POST['Sent_Request_CTC'] == "" && $_POST['Sent_Customer'] == "" && $_POST['Returned_Cust_Signed'] == "")) {
                $_POST['renewal'] = 1;
                $error = "'Renewal Date' or 'Sent to Customer' can't be empty.";
            }
            else {
                if(($_POST['Renewal_Date'] != "" && $_POST['Sent_Customer'] != "" || $_POST['Renewal_Date'] != "" && $_POST['Sent_Customer'] == "")) {
                    $renDate = new DateTime($_POST['Renewal_Date']);
                    $yrD_ysD = $renDate->format('Y');
                }
                if($_POST['Renewal_Date'] == "" && $_POST['Sent_Customer'] != "") {
                    $sentDate = new DateTime($_POST['Sent_Customer']);
                    $yrD_ysD = $sentDate->format('Y');
                }
                if(isset($yrD_ysD)) {
                    $stmt = $pdo->prepare("SELECT tr.FK_TAP_PPAP_ID, tr.Renewal_Date, tr.Sent_Customer FROM tapes_renewal tr WHERE tr.FK_TAP_PPAP_ID = ? AND (YEAR(tr.Renewal_Date) = ? OR (YEAR(tr.Sent_Customer) = ? AND tr.Renewal_Date IS NULL));");
                    $stmt->execute([$id, $yrD_ysD, $yrD_ysD]);
                    $renewalExists = $stmt->fetchAll(PDO::FETCH_ASSOC);

                    if($renewalExists == NULL) {
                        $stmt = $pdo->prepare("INSERT INTO tapes_renewal (Renewal_Date, Sent_Request_CTC, Sent_Customer, Returned_Cust_Signed, FK_TAP_PPAP_ID) 
                                                            VALUES (?, ?, ?, ?, ?)");
                        $stmt->execute([
                            $renewalDate,
                            $sentCTCDate,
                            $sentCustDate,
                            $signDate,
                            $id
                        ]);
                    }
                    if($renewalExists != NULL) {
                        $_POST['renewal'] = 1;
                        $error = "Renewal for the year ".$yrD_ysD." already exists.";
                    }
                }
            }
        }
    }

    $logs = $model->search();
    $logsTapes = $model->searchTapes();
    $logsBluSeal = $model->searchBS();
    $logsCables = $model->searchCables();
    $logsTubes = $model->searchTubes();
    $PPAPNS = $model->searchPPAPN();
    $Currents = $model->searchCS();
    $PIS = $model->searchPIS();
    $Customers = $model->searchCust();
    $OEMS = $model->searchOEM();
    $Countries = $model->searchCoun();
    $SAPS = $model->searchSAP();
    $CPNS = $model->searchCPN();
    $ETMS = $model->searchETM();
    $ETDS = $model->searchETD();
    $Revs = $model->searchRev();
    $ETPNS = $model->searchETPN();
    $Descs = $model->searchDesc();
    // $Tapes = $model->searchTape();
    // $Widths = $model->searchWidth();
    // $Lengths = $model->searchLength();
    // $Colors = $model->searchColor();
    $IMDS = $model->searchIMDS();
    $ISS = $model->searchIS();
    $PDS = $model->searchPD();
    $PSSS = $model->searchPS();
    $RSS = $model->searchRS();
    $Coms = $model->searchCom();
    $IRNS = $model->searchIRN();

    include 'view.php';
?>