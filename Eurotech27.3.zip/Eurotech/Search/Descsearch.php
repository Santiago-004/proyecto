<?php
header('Content-Type: application/json');

$connection = new mysqli("localhost", "root", "", "eurotechdb");
if ($connection->connect_error) {
    echo json_encode(["success" => false, "error" => "Connection Error"]);
    exit;
}

$Eurotech_PN = $_POST['Eurotech_PN'] ?? '';

if ($Eurotech_PN !== '') {
    $stmt = $connection->prepare("
        SELECT Description, Short_name AS 'Vendor', Supplier_PN
        FROM products p
        LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
        WHERE Eurotech_PN = ?
        LIMIT 1
    ");
    $stmt->bind_param("s", $Eurotech_PN);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($fila = $resultado->fetch_assoc()) {
        echo json_encode([
            "success" => true,
            "Description" => $fila['Description'],
            "Vendor" => $fila['Vendor'],
            "Supplier_PN" => $fila['Supplier_PN']
        ]);
    } else {
        echo json_encode(["success" => false]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false]);
}

$connection->close();
?>