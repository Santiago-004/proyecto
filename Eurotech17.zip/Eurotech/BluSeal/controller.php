<?php 
    include "model.php";

    $model = new model();
    $model->cn();
    $logs = [];
    
    if (isset($_POST["modelsearch"])){
        $modelsearch = $_POST["modelsearch"];
    }    
    else {
        $modelsearch = NULL;
    }

    if (isset($_POST["descsearch"])){
        $descsearch = $_POST["descsearch"];
    }    
    else {
        $descsearch = NULL;
    }

    if (isset($_POST["custsearch"])){
        $custsearch = $_POST["custsearch"];
    }    
    else {
        $custsearch = NULL;
    }

    if (isset($_POST["cpnsearch"])){
        $cpnsearch = $_POST["cpnsearch"];
    }    
    else {
        $cpnsearch = NULL;
    }

    if (isset($_POST["imdssearch"])){
        $imdssearch = $_POST["imdssearch"];
    }    
    else {
        $imdssearch = NULL;
    }

    if (isset($_POST["suppsearch"])){
        $suppsearch = $_POST["suppsearch"];
    }    
    else {
        $suppsearch = NULL;
    }

    if (isset($_POST["spnsearch"])){
        $spnsearch = $_POST["spnsearch"];
    }    
    else {
        $spnsearch = NULL;
    }

    if (isset($_POST["date1search"]) && isset($_POST["date2search"])){
        $date1search = $_POST["date1search"];
        $date2search = $_POST["date2search"];
    }    
    else {
        $date1search = "";
        $date2search = "";
    }

    if (isset($_POST["date3search"]) && isset($_POST["date4search"])){
        $date3search = $_POST["date3search"];
        $date4search = $_POST["date4search"];
    }    
    else {
        $date3search = "";
        $date4search = "";
    }

    if (isset($_POST["date5search"]) && isset($_POST["date6search"])){
        $date5search = $_POST["date5search"];
        $date6search = $_POST["date6search"];
    }    
    else {
        $date5search = "";
        $date6search = "";
    }

    if (isset($_POST["date7search"]) && isset($_POST["date8search"])){
        $date7search = $_POST["date7search"];
        $date8search = $_POST["date8search"];
    }    
    else {
        $date7search = "";
        $date8search = "";
    }

    if (isset($_POST["cusn"])){
        $cusn = $_POST["cusn"];
    }    
    else {
        $cusn = NULL;
    }

    if (isset($_POST["imdn"])){
        $imdn = $_POST["imdn"];
    }    
    else {
        $imdn = NULL;
    }

    if (isset($_POST["reqn"])){
        $reqn = $_POST["reqn"];
    }    
    else {
        $reqn = NULL;
    }

    if (isset($_POST["recn"])){
        $recn = $_POST["recn"];
    }    
    else {
        $recn = NULL;
    }

    if (isset($_POST["psen"])){
        $psen = $_POST["psen"];
    }    
    else {
        $psen = NULL;
    }

    if (isset($_POST["psin"])){
        $psin = $_POST["psin"];
    }    
    else {
        $psin = NULL;
    }

    
    
    $Models = $model->searchModels();
    $Descs = $model->searchDescs();
    $Customers = $model->searchCustomers();
    $CPNS = $model->searchCPN();
    $IMDS = $model->searchIMDS();
    $Suppliers = $model->searchSupplier();
    $SPNS = $model->searchSupplierPN();
    $logs = $model->search();

    include 'view.php';
?>