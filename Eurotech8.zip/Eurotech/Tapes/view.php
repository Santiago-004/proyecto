<link href="./css/style.css" rel="stylesheet">
<style>
    .form-search .camp,
    .form-search .camp2 {
        flex: 1 1 30%;
    }

    .form-search .camp3 {
        flex: 1 1 20%;
    }

    .form-search input[type="date"],
    .form-search input[type="number"] {
        padding: 8px 10px;
        border: 1px solid #bbb;
        border-radius: 8px;
        width: 48%;
        box-sizing: border-box;
    }

    @media (max-width: 1530px) {
        .form-search .camp {
            flex: 1 1 40%; 
            min-width: 300px;
        }
    }

    @media (max-width: 1501px) {
        .form-search input[type="number"] {
            width: 46%;
        }
    }

    @media (max-width: 1330px) {
        .form-search .camp3 {
            flex: 1 1 30%;
        }
    }

    @media (max-width: 1040px) {
        .form-search .camp {
            flex: 1 1 100%; 
            min-width: 300px;
        }
    }
</style>
<form action="" method="post" class="form-search">
    <input type="hidden" name="page" value="Tapes">
    <div class="camp2"></div>
    <div class="camp2"></div>
    <div class="camp3">
        <label>**Period:</label>
        <input type="number" name="" value="<?php //if ($submit1search != NULL) { echo $submit1search;} ?>"> -
        <input type="number" name="" value="<?php //if ($submit2search != NULL) { echo $submit2search;} ?>">
    </div>
    <div class="camp">
        <label>**Customer:</label>
        <input type="text" name="custsearch" list="Customer" value="<?php // if ($custsearch != NULL) { echo $custsearch;} ?>">
        <datalist id="Customer">
            <?php /*foreach ($Customers as $Customer) {  ?>
                <option value="<?php echo $Customer['Name'] ?>">
            <?php } */?>
        </datalist>
    </div>

    <div class="camp">
        <label>**OEM:</label>
        <input type="text" name="custsearch" list="Customer" value="<?php // if ($custsearch != NULL) { echo $custsearch;} ?>">
        <datalist id="Customer">
            <?php /*foreach ($Customers as $Customer) {  ?>
                <option value="<?php echo $Customer['Name'] ?>">
            <?php } */?>
        </datalist>
    </div>

    <div class="camp">
        <label>**Country:</label>
        <input type="text" name="custsearch" list="Customer" value="<?php // if ($custsearch != NULL) { echo $custsearch;} ?>">
        <datalist id="Customer">
            <?php /*foreach ($Customers as $Customer) {  ?>
                <option value="<?php echo $Customer['Name'] ?>">
            <?php } */?>
        </datalist>
    </div>

    <div class="camp">
        <label>**PPAP Level:</label>
        <select name="levelsearch" >
            <option value="">All</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
        </select>
    </div>

    <div class="camp">
        <label>**SAP No.:</label>
        <input type="text" name="sapsearch" list="SAP" value="<?php // if ($sapsearch != NULL) { echo $sapsearch;} ?>">
        <datalist id="SAP">
            <?php /*foreach ($SAPS as $SAP) {  ?>
                <option value="<?php echo $SAP['SAP_Number'] ?>">
            <?php } */?>
        </datalist>
    </div>

    <div class="camp">
        <label>**Customer PN:</label>
        <input type="text" name="cpnsearch" list="CPN" value="<?php // if ($cpnsearch != NULL) { echo $cpnsearch;} ?>">
        <datalist id="CPN">
            <?php /*foreach ($CPNS as $CPN) {  ?>
                <option value="<?php echo $CPN['TAP_Customer_PN'] ?>">
            <?php }*/ ?>
        </datalist>
    </div>

    <div class="camp">
        <label>**Description:</label>
        <input style="width: 24%;" type="text" placeholder="Tape" name="tapesearch" list="Tape" value="<?php // if ($tapesearch != NULL) { echo $tapesearch;} ?>"> -
        <input style="width: 22%;" type="text" placeholder="Width (MM)" name="widthsearch" list="Width" value="<?php // if ($widthsearch != NULL) { echo $widthsearch;} ?>"> -
        <input style="width: 22%;" type="text" placeholder="Length (M)" name="lengthsearch" list="Length" value="<?php // if ($lengthsearch != NULL) { echo $lengthsearch;} ?>"> -
        <input style="width: 22%;" type="text" placeholder="Color" name="colorsearch" list="Color" value="<?php // if ($colorsearch != NULL) { echo $colorsearch;} ?>">
        <datalist id="Tape">
            <?php /*foreach ($Tapes as $Tape) {  ?>
                <option value="<?php echo $Tape['Tape'] ?>">
            <?php }*/ ?>
        </datalist>
        <datalist id="Width">
            <?php /*foreach ($Widths as $Width) {  ?>
                <option value="<?php echo $Width['Width'] ?>">
            <?php }*/ ?>
        </datalist>
        <datalist id="Length">
            <?php /*foreach ($Lengths as $Length) {  ?>
                <option value="<?php echo $Length['Length'] ?>">
            <?php }*/ ?>
        </datalist>
        <datalist id="Color">
            <?php /*foreach ($Colors as $Color) {  ?>
                <option value="<?php echo $Color['Color'] ?>">
            <?php }*/ ?>
        </datalist>
    </div>

    <div class="camp">
        <label>**IMDS ID No.:</label>
        <input type="text" name="imdssearch" list="IMDS" value="<?php // if ($imdssearch != NULL) { echo $imdssearch;} ?>">
        <datalist id="IMDS">
            <?php /* foreach ($IMDS as $IM) {  ?>
                <option value="<?php echo $IM['IMDS_ID_No'] ?>">
            <?php } */ ?>
        </datalist>
    </div>

    <div class="camp">
        <!-- <label><b>INITIAL</b></label> -->
        <label>**Returned from CTC / Sent to Customer:</label>
        <input type="date" name="ret1search" value="<?php // if ($ret1search != NULL) { echo $ret1search;} ?>"> - <input type="date" name="ret2search" value="<?php // if ($ret2search != NULL) { echo $ret2search;} ?>">
    </div>
    
    <div class="camp">
        <label>**PSW returned from Customer signed / Sent to CTC:</label>
        <input type="date" name="psw1search" value="<?php // if ($psw1search != NULL) { echo $psw1search;} ?>"> - <input type="date" name="psw2search" value="<?php // if ($psw2search != NULL) { echo $psw2search;} ?>">
    </div>
    
    <div class="camp">
        <label>**Renewal Date:</label>
        <input type="date" name="ren1search" value="<?php // if ($ren1search != NULL) { echo $ren1search;} ?>"> - <input type="date" name="ren2search" value="<?php // if ($ren2search != NULL) { echo $ren2search;} ?>">
    </div>
    
    <div class="camp">
        <label>**When to send Request to CTC:</label>
        <input type="date" name="req1search" value="<?php // if ($req1search != NULL) { echo $req1search;} ?>"> - <input type="date" name="req2search" value="<?php // if ($req2search != NULL) { echo $req2search;} ?>">
    </div>
    
    <div class="camp">
        <label>**Sent to Customer:</label>
        <input type="date" name="sent1search" value="<?php // if ($sent1search != NULL) { echo $sent1search;} ?>"> - <input type="date" name="sent2search" value="<?php // if ($sent2search != NULL) { echo $sent2search;} ?>">
    </div>
    
    <div class="camp">
        <label>**PSW returned from Customer signed:</label>
        <input type="date" name="pswr1search" value="<?php // if ($pswr1search != NULL) { echo $pswr1search;} ?>"> - <input type="date" name="pswr2search" value="<?php // if ($pswr2search != NULL) { echo $pswr2search;} ?>">
    </div>

    <div class="camp">
        <label>**PPAP from shipments:</label>
        <input type="radio" name="shipsearch" value="" checked> All <br>
        <input type="radio" name="shipsearch" value="no"> No <br>
        <input type="radio" name="shipsearch" value="*"> Yes
    </div>

    <div class="camp">
        <label>**Comments:</label>
        <input type="text" name="comsearch" list="Com" value="<?php // if ($comsearch != NULL) { echo $comsearch;} ?>">
        <datalist id="Com">
            <?php /* foreach ($Coms as $Com) {  ?>
                <option value="<?php echo $Com['Comments'] ?>">
            <?php } */ ?>
        </datalist>
    </div>

    <div class="camp"></div>
    <div class="camp"></div>

    <div class="campbtn">
        <button type="submit" name="btnsearch" class="insert">Search</button>
    </div>
</form>

<div style="display: flex;">
    <form action="?page=Tapes" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insert" value="1">
        <button type="submit" class="insert">New PPAP (Description)</button>
    </form>

    <form action="?page=Tapes" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insertET" value="1">
        <button type="submit" class="insert">New PPAP (ET PN)</button>
    </form>

    <form action="?page=Tapes" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insertC" value="1">
        <button type="submit" class="insert">New PPAP (Cust PN)</button>
    </form>
</div>


<?php if($logs == NULL) { ?>
    <br>
    <h1>No results.</h1>
<?php } ?>

<?php if($logs != NULL) { ?>
    <div class="table-responsive">
        <table class="table table-bordered">
            <tr>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2"></th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2"></th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">CUSTOMER</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">OEM</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">Country</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">PPAP Level</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">SAP No.</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">Customer Part No.</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">Tape</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">Width (MM)</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">Length (M)</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">Color</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">IMDS ID no.</th>
                <th style="background-color:#1c18AA; color:white" colspan="2">INITIAL</th>
                <?php for($i = 2024; $i <= date("Y"); $i++) { ?>
                    <th style="background-color:#1c18AA; color:white" colspan="4"><?php echo $i; ?></th>
                <?php } ?>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">PPAP from shipments</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">Comments</th>
            </tr>
            <tr>
                <th style="background-color:#1c18AA; color:white">Returned from CTC / Sent to Customer</th>
                <th style="background-color:#1c18AA; color:white">PSW returned from Customer signed / Sent to CTC</th>
                <?php for($i = 2024; $i <= date("Y"); $i++) { ?>
                    <th style="background-color:#1c18AA; color:white">Renewal Date</th>
                    <th style="background-color:#1c18AA; color:white">When to send Request to CTC</th>
                    <th style="background-color:#1c18AA; color:white">Sent to Customer</th>
                    <th style="background-color:#1c18AA; color:white">PSW returned from Customer signed</th>
                <?php } ?>
            </tr>
            
            <?php foreach ($logs as $log) { ?>
                <tr>
                    <td>
                        <form action="?page=Tapes" method="post" style="display:inline;">
                            <input type="hidden" name="edit" value="">
                            <button type="submit" class="editar">Edit</button>
                        </form>
                    </td>
                    <td>
                        <form action="?page=Tapes" method="post" style="display:inline;">
                            <input type="hidden" name="delete" value="">
                            <button type="submit" class="eliminar">Delete</button>
                        </form>
                    </td>
                    <td><?php echo $log['Name']; ?></td>
                    <td><?php echo $log['OEM']; ?></td>
                    <td><?php echo $log['Country']; ?></td>
                    <td><?php echo $log['PPAP_level']; ?></td>
                    <td><?php echo $log['SAP_Number']; ?></td>
                    <td><?php echo $log['FK_TAP_Customer_PN']; ?></td>
                    <td><?php echo $log['Tape']; ?></td>
                    <td><?php echo $log['Width']; ?></td>
                    <td><?php echo $log['Length']; ?></td>
                    <td><?php echo $log['Color']; ?></td>
                    <td><?php echo $log['IMDS_ID_No']; ?></td>
                    <?php if($log['Returned_CTC-Sent_Cust'] != NULL) { 
                        $retCtc = new DateTime($log['Returned_CTC-Sent_Cust']); ?>
                        <td><?php echo $retCtc->format('m/d/Y') ?></td>
                    <?php }
                    if($log['Returned_CTC-Sent_Cust'] == NULL) { ?>
                        <td></td>
                    <?php } 
                    if($log['Cust_Signed-Sent_CTC'] != NULL) { 
                        $custSign = new DateTime($log['Cust_Signed-Sent_CTC']); ?>
                        <td><?php echo $custSign->format('m/d/Y') ?></td>
                    <?php }
                    if($log['Cust_Signed-Sent_CTC'] == NULL) { ?>
                        <td></td>
                    <?php } 
                    for($i = 2024; $i <= date("Y"); $i++) {
                        $Renewlogs = $model->searchRenew($log['TAP_PPAP_ID'], $i);
                        if($Renewlogs == NULL) { ?>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        <?php }
                        foreach ($Renewlogs as $Renewlog) { 
                            if($Renewlog['Renewal_Date'] != NULL) { 
                                $renDate = new DateTime($Renewlog['Renewal_Date']); ?>
                                <td><?php echo $renDate->format('m/d/Y') ?></td>
                            <?php }
                            if($Renewlog['Renewal_Date'] == NULL) { ?>
                                <td></td>
                            <?php }
                            if($Renewlog['Sent_Request_CTC'] != NULL) { 
                                $sendReq = new DateTime($Renewlog['Sent_Request_CTC']); ?>
                                <td><?php echo $sendReq->format('m/d/Y') ?></td>
                            <?php }
                            if($Renewlog['Sent_Request_CTC'] == NULL) { ?>
                                <td></td>
                            <?php }
                            if($Renewlog['Sent_Customer'] != NULL) { 
                                $sentCust = new DateTime($Renewlog['Sent_Customer']); ?>
                                <td><?php echo $sentCust->format('m/d/Y') ?></td>
                            <?php }
                            if($Renewlog['Sent_Customer'] == NULL) { ?>
                                <td></td>
                            <?php }
                            if($Renewlog['Returned_Cust_Signed'] != NULL) { 
                                $retCust = new DateTime($Renewlog['Returned_Cust_Signed']); ?>
                                <td><?php echo $retCust->format('m/d/Y') ?></td>
                            <?php }
                            if($Renewlog['Returned_Cust_Signed'] == NULL) { ?>
                                <td></td>
                            <?php }             
                        }
                    } ?> 
                    <td><?php echo $log['PPAP_from_shipments']; ?></td>
                    <td><?php echo $log['Comments']; ?></td>
                </tr> 
            <?php } ?>
        </table> 
    </div>
<?php } 

if (isset($_POST['insert'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New PPAP</h2>
    <form action="?page=Tapes" method="post">
        <input type="hidden" name="confirmI" value="1">
        <label>Description:</label>
        <input type="text" name="Description" list="Desc" required>
        <datalist id="Desc">
            <?php /* foreach ($Descs as $Desc) {  ?>
                <option value="<?php echo $Desc['Description'] ?>">
            <?php } */?>
        </datalist> <br>
        
        <label>Customer:</label>
        <input type="text" name="Name" list="Customer" required>
        <datalist id="Customer">
            <?php /* foreach ($Customers as $Customer) {  ?>
                <option value="<?php echo $Customer['Name'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>OEM:</label>
        <input type="text" name="IMDS" list="IMDS">
        <datalist id="IMDS">
            <?php /* foreach ($IMDSS as $IMDS) {  ?>
                <option value="<?php echo $IMDS['IMDS'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Country:</label>
        <input type="text" name="IMDS" list="IMDS">
        <datalist id="IMDS">
            <?php /* foreach ($IMDSS as $IMDS) {  ?>
                <option value="<?php echo $IMDS['IMDS'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>PPAP Level:</label>
        <select name="levelsearch" >
            <option value=""></option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
        </select> <br>

        <label>IMDS:</label>
        <input type="text" name="IMDS" list="IMDS">
        <datalist id="IMDS">
            <?php /* foreach ($IMDSS as $IMDS) {  ?>
                <option value="<?php echo $IMDS['IMDS'] ?>">
            <?php } */?>
        </datalist> <br>

        <label style="font-size: 20px;">INITIAL</label>
        <label>Returned from CTC / Sent to Customer:</label>
        <input type="date" name="Returned_CTC-Sent_Cust"> <br>

        <label>PSW returned from Customer signed / Sent to CTC:</label>
        <input type="date" name="Cust_Signed-Sent_CTC"> <br>

        <label>PPAP from shipments:</label required>
        <div>
            <input type="radio" name="PPAP_from_shipments" value="no" checked> No 
        </div>
        <div>
            <input type="radio" name="PPAP_from_shipments" value="*"> Yes 
        </div> <br>

        <label>Comments:</label>
        <textarea name="Comments" id=""></textarea>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if (isset($_POST['insertET'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New PPAP</h2>
    <form action="?page=Tapes" method="post">
        <input type="hidden" name="confirmI" value="1">
        <label>Eurotech PN:</label>
        <input type="text" name="Description" list="Desc" required>
        <datalist id="Desc">
            <?php /* foreach ($Descs as $Desc) {  ?>
                <option value="<?php echo $Desc['Description'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Customer:</label>
        <input type="text" name="Name" list="Customer" required>
        <datalist id="Customer">
            <?php /* foreach ($Customers as $Customer) {  ?>
                <option value="<?php echo $Customer['Name'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>OEM:</label>
        <input type="text" name="IMDS" list="IMDS">
        <datalist id="IMDS">
            <?php /* foreach ($IMDSS as $IMDS) {  ?>
                <option value="<?php echo $IMDS['IMDS'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Country:</label>
        <input type="text" name="IMDS" list="IMDS">
        <datalist id="IMDS">
            <?php /* foreach ($IMDSS as $IMDS) {  ?>
                <option value="<?php echo $IMDS['IMDS'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>PPAP Level:</label>
        <select name="levelsearch" >
            <option value=""></option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
        </select> <br>

        <label>IMDS:</label>
        <input type="text" name="IMDS" list="IMDS">
        <datalist id="IMDS">
            <?php /* foreach ($IMDSS as $IMDS) {  ?>
                <option value="<?php echo $IMDS['IMDS'] ?>">
            <?php } */?>
        </datalist> <br>

        <label style="font-size: 20px;">INITIAL</label>
        <label>Returned from CTC / Sent to Customer:</label>
        <input type="date" name="Returned_CTC-Sent_Cust"> <br>

        <label>PSW returned from Customer signed / Sent to CTC:</label>
        <input type="date" name="Cust_Signed-Sent_CTC"> <br>

        <label>PPAP from shipments:</label required>
        <div>
            <input type="radio" name="PPAP_from_shipments" value="no" checked> No 
        </div>
        <div>
            <input type="radio" name="PPAP_from_shipments" value="*"> Yes 
        </div> <br>

        <label>Comments:</label>
        <textarea name="Comments" id=""></textarea>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if (isset($_POST['insertC'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New PPAP</h2>
    <form action="?page=Tapes" method="post">
        <input type="hidden" name="confirmI" value="1">
        <label>Customer PN:</label>
        <input type="text" name="Name" list="Customer" required>
        <datalist id="Customer">
            <?php /* foreach ($Customers as $Customer) {  ?>
                <option value="<?php echo $Customer['Name'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>OEM:</label>
        <input type="text" name="IMDS" list="IMDS">
        <datalist id="IMDS">
            <?php /* foreach ($IMDSS as $IMDS) {  ?>
                <option value="<?php echo $IMDS['IMDS'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Country:</label>
        <input type="text" name="IMDS" list="IMDS">
        <datalist id="IMDS">
            <?php /* foreach ($IMDSS as $IMDS) {  ?>
                <option value="<?php echo $IMDS['IMDS'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>PPAP Level:</label>
        <select name="levelsearch" >
            <option value=""></option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
        </select> <br>

        <label>IMDS:</label>
        <input type="text" name="IMDS" list="IMDS">
        <datalist id="IMDS">
            <?php /* foreach ($IMDSS as $IMDS) {  ?>
                <option value="<?php echo $IMDS['IMDS'] ?>">
            <?php } */?>
        </datalist> <br>

        <label style="font-size: 20px;">INITIAL</label>
        <label>Returned from CTC / Sent to Customer:</label>
        <input type="date" name="Returned_CTC-Sent_Cust"> <br>

        <label>PSW returned from Customer signed / Sent to CTC:</label>
        <input type="date" name="Cust_Signed-Sent_CTC"> <br>

        <label>PPAP from shipments:</label required>
        <div>
            <input type="radio" name="PPAP_from_shipments" value="no" checked> No 
        </div>
        <div>
            <input type="radio" name="PPAP_from_shipments" value="*"> Yes 
        </div> <br>

        <label>Comments:</label>
        <textarea name="Comments" id=""></textarea>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if (isset($_POST['edit'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Update PPAP</h2>
    <form action="?page=Tapes" method="post">
        <input type="hidden" name="confirmU" value="1">
        <label>OEM:</label>
        <input type="text" name="IMDS" list="IMDS">
        <datalist id="IMDS">
            <?php /* foreach ($IMDSS as $IMDS) {  ?>
                <option value="<?php echo $IMDS['IMDS'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Country:</label>
        <input type="text" name="IMDS" list="IMDS">
        <datalist id="IMDS">
            <?php /* foreach ($IMDSS as $IMDS) {  ?>
                <option value="<?php echo $IMDS['IMDS'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>PPAP Level:</label>
        <select name="levelsearch" >
            <option value=""></option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
        </select> <br>

        <label>IMDS:</label>
        <input type="text" name="IMDS" list="IMDS">
        <datalist id="IMDS">
            <?php /* foreach ($IMDSS as $IMDS) {  ?>
                <option value="<?php echo $IMDS['IMDS'] ?>">
            <?php } */?>
        </datalist> <br>

        <label style="font-size: 20px;">INITIAL</label>
        <label>Returned from CTC / Sent to Customer:</label>
        <input type="date" name="Returned_CTC-Sent_Cust"> <br>

        <label>PSW returned from Customer signed / Sent to CTC:</label>
        <input type="date" name="Cust_Signed-Sent_CTC"> <br>

        <?php for($i = 2024; $i <= date("Y"); $i++) { ?>
            <label style="font-size: 20px;"><?php echo $i; ?></label>
            <label>Renewal Date:</label>
            <input type="date" name="Renewal_Date"> <br>

            <label>When to send Request to CTC:</label>
            <input type="date" name="Sent_Request_CTC"> <br>

            <label>Sent to Customer:</label>
            <input type="date" name="Sent_Customer"> <br>

            <label>PSW returned from Customer signed:</label>
            <input type="date" name="Returned_Cust_Signed">
            <hr>
        <?php } ?>

        <label>PPAP from shipments:</label required>
        <div>
            <input type="radio" name="PPAP_from_shipments" value="no" checked> No 
        </div>
        <div>
            <input type="radio" name="PPAP_from_shipments" value="*"> Yes 
        </div> <br>

        <label>Comments:</label>
        <textarea name="Comments" id=""></textarea>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if (isset($_POST['delete'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Delete PPAP</h2>
    <form action="?page=Tapes" method="post">
        <input type="hidden" name="confirmD" value="1">
        <!-- <input type="hidden" name="id_animal" value="<?php // $_POST['eliminar'] ?>" required> <br> -->
        <h5>Are you sure you want to delete the data of this PPAP?</h5> <br>
        <h6>Customer : ...</h6>
        <h6>OEM : ...</h6>
        <h6>Country : ...</h6>
        <h6>PPAP Level : ...</h6>
        <h6>SAP No. : ...</h6>
        <h6>Customer PN : ...</h6>
        <h6>Tape : ...</h6>
        <h6>Width (MM) : ...</h6>
        <h6>Length (M) : ...</h6>
        <h6>Color : ...</h6>
        <h6>IMDS ID no. : ...</h6>
        <hr>
        <h6><b>INITIAL</b></h6>
        <h6>Returned from CTC / Sent to Customer : ...</h6>
        <h6>PSW returned from Customer signed / Sent to CTC : ...</h6>
        <hr>
        <h6><b>2024</b></h6>
        <h6>Renewal Date : ...</h6>
        <h6>When to send Request to CTC : ...</h6>
        <h6>Sent to Customer : ...</h6>
        <h6>PSW returned from Customer signed : ...</h6>
        <hr>
        <h6><b>2025</b></h6>
        <h6>Renewal Date : ...</h6>
        <h6>When to send Request to CTC : ...</h6>
        <h6>Sent to Customer : ...</h6>
        <h6>PSW returned from Customer signed : ...</h6>

        <h6> PPAP from shipment : ...</h6>
        <h6> Comments : ...</h6>
        <button type="submit">Confirm</button>
    </form>
  </div>
</div>
<?php } ?>

<script>
    function closeForm() {
        document.getElementById('formularioModal').style.display = 'none';
    }

    function sendForm() {
        closeForm();
        return true;
    }
</script>