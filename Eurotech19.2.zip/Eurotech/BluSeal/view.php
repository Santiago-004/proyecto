<link href="./css/style.css" rel="stylesheet">
<style>
    .clear {
        color: white;
        padding: 8px 14px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
        transition: background-color 0.2s;
        font-size: 14px;
        background-color: #16bacfff;
    }

    .clear:hover {
        background-color: #1dd1e8ff;
        color: white;
    }

    .form-search .camp {
        flex: 1 1 20%;
        min-width: 250px;
    }

    .form-search input[type="date"]{
        padding: 8px 10px;
        border: 1px solid #bbb;
        border-radius: 8px;
        width: 46%;
        box-sizing: border-box;
    }

    @media (max-width: 1630px) {
        .note {
            padding: 15px 10px;
        }
    }
    
    @media (max-width: 1300px) {
        .form-search .camp
        {
            flex: 1 1 40%;
        }
    }
</style>
<form action="" id="form" method="post" class="form-search">
    <input type="hidden" name="page" value="BluSeal">
    <div class="camp">
        <label>Model:</label>
        <select name="modelsearch" >
            <option value="">All</option>
            <?php foreach ($Models as $Model) {  ?>
                <option value="<?php echo $Model['BS_Eurotech_PN'] ?>" <?php if ($modelsearch == $Model['BS_Eurotech_PN']) { echo 'selected';} ?>><?php echo $Model['BS_Eurotech_PN'] ?></option>
            <?php } ?>
        </select>
    </div>

    <div class="camp">
        <label>Description:</label>
        <select name="descsearch" >
            <option value="">All</option>
            <?php foreach ($Descs as $Desc) {  ?>
                <option value="<?php echo $Desc['Description'] ?>" <?php if ($descsearch == $Desc['Description']) { echo 'selected';} ?>><?php echo $Desc['Description'] ?></option>
            <?php } ?>
        </select>
    </div>

    <div class="camp">
        <label>Customer:</label>
        <input type="text" maxlength="70" name="custsearch" list="Customer" value="<?php if ($custsearch != NULL) { echo $custsearch;} ?>">
        <datalist id="Customer">
            <?php foreach ($Customers as $Customer) {  ?>
                <option value="<?php echo $Customer['Name'] ?>">
            <?php } ?>
        </datalist>
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="cusn" id="" value="" <?php if ($cusn != "N" && $cusn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="cusn" id="" value="N" <?php if ($cusn == "N") { echo "checked";} ?>> No Customer
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="cusn" id="" value="Y" <?php if ($cusn == "Y") { echo "checked";} ?>> W/ Customer
    </div>

    <div class="camp">
        <label>Customer PN:</label>
        <input type="text" maxlength="20" name="cpnsearch" list="CPN" value="<?php if ($cpnsearch != NULL) { echo $cpnsearch;} ?>">
        <datalist id="CPN">
            <?php foreach ($CPNS as $CPN) {  ?>
                <option value="<?php echo $CPN['BS_Customer_PN'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>IMDS:</label>
        <input type="text" maxlength="15" name="imdssearch" list="IMDS" value="<?php if ($imdssearch != NULL) { echo $imdssearch;} ?>">
        <datalist id="IMDS">
            <?php foreach ($IMDS as $IM) {  ?>
                <option value="<?php echo $IM['IMDS'] ?>">
            <?php } ?>
        </datalist>
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="imdn" id="" value="" <?php if ($imdn != "N" && $imdn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="imdn" id="" value="N" <?php if ($imdn == "N") { echo "checked";} ?>> No IMDS
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="imdn" id="" value="Y" <?php if ($imdn == "Y") { echo "checked";} ?>> W/ IMDS
    </div>

    <div class="camp">
        <label>Supplier:</label>
        <select name="suppsearch" >
            <option value="">All</option>
            <?php foreach ($Suppliers as $Supplier) {  ?>
                <option value="<?php echo $Supplier['Supplier'] ?>" <?php if ($suppsearch == $Supplier['Supplier']) { echo 'selected';} ?>><?php echo $Supplier['Supplier'] ?></option>
            <?php } ?>
        </select>
    </div>

    <div class="camp">
        <label>Supplier PN:</label>
        <select name="spnsearch" >
            <option value="">All</option>
            <?php foreach ($SPNS as $SPN) {  ?>
                <option value="<?php echo $SPN['Supplier_PN'] ?>" <?php if ($spnsearch == $SPN['Supplier_PN']) { echo 'selected';} ?>><?php echo $SPN['Supplier_PN'] ?></option>
            <?php } ?>
        </select>
    </div>
    <div class="camp"></div>
    <div class="camp"></div>
    <div class="camp"></div>


    <div class="camp">
        <label>PPAP Requested Date:</label>
        <input type="date" name="date1search" value="<?php if ($date1search != NULL) { echo $date1search;} ?>"> - <input type="date" name="date2search" value="<?php if ($date2search != NULL) { echo $date2search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="reqn" id="" value="" <?php if ($reqn != "N" && $reqn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="reqn" id="" value="N" <?php if ($reqn == "N") { echo "checked";} ?>> No date        
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="reqn" id="" value="Y" <?php if ($reqn == "Y") { echo "checked";} ?>> W/ date
    </div>
    

    <div class="camp">
        <label>PPAP Received Date:</label>
        <input type="date" name="date3search" value="<?php if ($date3search != NULL) { echo $date3search;} ?>"> - <input type="date" name="date4search" value="<?php if ($date4search != NULL) { echo $date4search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="recn" id="" value="" <?php if ($recn != "N" && $recn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="recn" id="" value="N" <?php if ($recn == "N") { echo "checked";} ?>> No date        
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="recn" id="" value="Y" <?php if ($recn == "Y") { echo "checked";} ?>> W/ date
    </div>


    <div class="camp">
        <label>PPAP Sent Date:</label>
        <input type="date" name="date5search" value="<?php if ($date5search != NULL) { echo $date5search;} ?>"> - <input type="date" name="date6search" value="<?php if ($date6search != NULL) { echo $date6search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="psen" id="" value="" <?php if ($psen != "N" && $psen != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="psen" id="" value="N" <?php if ($psen == "N") { echo "checked";} ?>> No date        
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="psen" id="" value="Y" <?php if ($psen == "Y") { echo "checked";} ?>> W/ date
    </div>

    <div class="camp">
        <label>PPAP Signed Date:</label>
        <input type="date" name="date7search" value="<?php if ($date7search != NULL) { echo $date7search;} ?>"> - <input type="date" name="date8search" value="<?php if ($date8search != NULL) { echo $date8search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="psin" id="" value="" <?php if ($psin != "N" && $psin != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="psin" id="" value="N" <?php if ($psin == "N") { echo "checked";} ?>> No date        
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="psin" id="" value="Y" <?php if ($psin == "Y") { echo "checked";} ?>> W/ date
    </div>

    
    <div class="campbtn">
        <button type="submit" name="btnsearch" class="insert">Search</button>
        <button style="margin: 0px 0px 0px 15px;"  type="submit" name="btnsearch" class="clear" onclick="clearForm()">Clear All</button>
    </div>
</form>

<div style="display: flex;">
    <form action="?page=BluSeal" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insertD" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
        <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
        <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
        <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
        <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
        <button type="submit" class="insert">New PPAP (Description)</button>
    </form>

    <form action="?page=BluSeal" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insertET" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
        <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
        <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
        <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
        <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
        <button type="submit" class="insert">New PPAP (ET PN)</button>
    </form>

    <form action="?page=BluSeal" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insertC" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
        <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
        <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
        <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
        <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
        <button type="submit" class="insert">New PPAP (Cust PN)</button>
    </form>
</div>

<?php if($logs == NULL) { ?>
    <br>
    <h1>No results.</h1>
<?php } ?>

<?php if($logs != NULL) { ?>
    <div class="table-responsive">
        <table class="table table-bordered">
            <tr>    
                <th style="background-color:#1c18AA;"></th>
                <th style="background-color:#1c18AA;"></th>
                <th style="background-color:#1c18AA; color:white">Model</th>
                <th style="background-color:#1c18AA; color:white">Description</th>
                <th style="background-color:#1c18AA; color:white">Customer</th>
                <th style="background-color:#1c18AA; color:white">Customer PN</th>
                <th style="background-color:#1c18AA; color:white">IMDS</th>
                <th style="background-color:#1c18AA; color:white">Supplier</th>
                <th style="background-color:#1c18AA; color:white">Supplier PN</th>
                <th style="background-color:#1c18AA; color:white">Requested Date</th>
                <th style="background-color:#1c18AA; color:white">Received Date</th>
                <th style="background-color:#1c18AA; color:white">Sent to Customer</th>
                <th style="background-color:#1c18AA; color:white">Signed Date</th>
            </tr>
            
            <?php foreach ($logs as $log) { ?>
                <tr>
                    <?php if($log['Name'] != NULL && $log['PPAP_Signed_Date'] == NULL) { ?>
                        <td style="background-color: rgba(255, 235, 0, 0.7);">
                            <form action="?page=BluSeal" method="post" style="display:inline;">
                                <input type="hidden" name="edit" value="">
                                <input type="hidden" name="btnsearch" value="1">
                                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
                                <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
                                <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
                                <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
                                <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
                                <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
                                <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
                                <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
                                <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
                                <input type="hidden" name="IDedit" value="<?php echo $log['BS_PPAP_ID']; ?>">
                                <button type="submit" class="editar">Edit</button>
                            </form>
                        </td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);">
                            <form action="?page=BluSeal" method="post" style="display:inline;">
                                <input type="hidden" name="delete" value="">
                                <input type="hidden" name="btnsearch" value="1">
                                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
                                <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
                                <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
                                <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
                                <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
                                <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
                                <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
                                <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
                                <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
                                <input type="hidden" name="IDdelete" value="<?php echo $log['BS_PPAP_ID']; ?>">
                                <button type="submit" class="eliminar">Delete</button>
                            </form>
                        </td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['BS_Eurotech_PN']; ?></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Description']; ?></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Name']; ?></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['BS_Customer_PN']; ?></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['IMDS']; ?></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Supplier']; ?></td>
                        <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Supplier_PN']; ?></td>
                        <?php if($log['Request_Date'] != NULL) { 
                            $reqDate = new DateTime($log['Request_Date']); ?>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $reqDate->format('m/d/Y') ?></td>
                        <?php }
                        if($log['Request_Date'] == NULL) { ?>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                        <?php }
                        if($log['PPAP_Received_Date'] != NULL) { 
                            $recDate = new DateTime($log['PPAP_Received_Date']); ?>
                            <td style="display:flex; background-color: rgba(255, 235, 0, 0.7);">
                                <?php echo $recDate->format('m/d/Y') ?>
                                <form action="?page=BluSeal" method="POST" style="width:20px; margin: 0px 20px 0px 20px">
                                    <input type="hidden" name="note" value="">
                                    <input type="hidden" name="btnsearch" value="1">
                                    <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                    <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
                                    <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                    <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                    <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                    <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
                                    <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
                                    <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                    <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                    <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                    <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                    <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
                                    <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
                                    <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
                                    <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
                                    <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                    <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                    <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                    <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                    <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
                                    <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
                                    <input type="hidden" name="IDnote" value="<?php echo $log['BS_PPAP_ID'] ?>">
                                    <button type="submit"  class="note">Note</button>
                                </form>
                            </td>
                        <?php }
                        if($log['PPAP_Received_Date'] == NULL) { ?>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                        <?php }
                        if($log['Sent_Customer'] != NULL) { 
                            $sentCust = new DateTime($log['Sent_Customer']); ?>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $sentCust->format('m/d/Y') ?></td>
                        <?php }
                        if($log['Sent_Customer'] == NULL) { ?>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                        <?php } ?>
                            <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                    <?php } 
                    if($log['Name'] != NULL && $log['PPAP_Signed_Date'] != NULL) {?>
                        <td style="background-color: rgba(0, 255, 0, 0.7);">
                            <form action="?page=BluSeal" method="post" style="display:inline;">
                                <input type="hidden" name="edit" value="">
                                <input type="hidden" name="btnsearch" value="1">
                                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
                                <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
                                <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
                                <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
                                <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
                                <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
                                <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
                                <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
                                <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
                                <input type="hidden" name="IDedit" value="<?php echo $log['BS_PPAP_ID']; ?>">
                                <button type="submit" class="editar">Edit</button>
                            </form>
                        </td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);">
                            <form action="?page=BluSeal" method="post" style="display:inline;">
                                <input type="hidden" name="delete" value="">
                                <input type="hidden" name="btnsearch" value="1">
                                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
                                <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
                                <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
                                <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
                                <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
                                <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
                                <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
                                <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
                                <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
                                <input type="hidden" name="IDdelete" value="<?php echo $log['BS_PPAP_ID']; ?>">
                                <button type="submit" class="eliminar">Delete</button>
                            </form>
                        </td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"><?php echo $log['BS_Eurotech_PN']; ?></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"><?php echo $log['Description']; ?></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"><?php echo $log['Name']; ?></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"><?php echo $log['BS_Customer_PN']; ?></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"><?php echo $log['IMDS']; ?></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"><?php echo $log['Supplier']; ?></td>
                        <td style="background-color: rgba(0, 255, 0, 0.7);"><?php echo $log['Supplier_PN']; ?></td>
                        <?php if($log['Request_Date'] != NULL) { 
                            $reqDate = new DateTime($log['Request_Date']); ?>
                            <td style="background-color: rgba(0, 255, 0, 0.7);"><?php echo $reqDate->format('m/d/Y') ?></td>
                        <?php }
                        if($log['Request_Date'] == NULL) { ?>
                            <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                        <?php }
                        if($log['PPAP_Received_Date'] != NULL) { 
                            $recDate = new DateTime($log['PPAP_Received_Date']); ?>
                            <td style="display:flex; background-color: rgba(0, 255, 0, 0.7);">
                                <?php echo $recDate->format('m/d/Y') ?>
                                <form action="?page=BluSeal" method="POST" style="width:20px; margin: 0px 20px 0px 20px">
                                    <input type="hidden" name="note" value="">
                                    <input type="hidden" name="btnsearch" value="1">
                                    <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                    <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
                                    <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                    <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                    <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                    <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
                                    <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
                                    <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                    <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                    <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                    <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                    <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
                                    <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
                                    <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
                                    <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
                                    <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                    <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                    <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                    <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                    <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
                                    <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
                                    <input type="hidden" name="IDnote" value="<?php echo $log['BS_PPAP_ID'] ?>">
                                    <button type="submit"  class="note">Note</button>
                                </form>
                            </td>
                        <?php }
                        if($log['PPAP_Received_Date'] == NULL) { ?>
                            <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                        <?php }
                        if($log['Sent_Customer'] != NULL) { 
                            $sentCust = new DateTime($log['Sent_Customer']); ?>
                            <td style="background-color: rgba(0, 255, 0, 0.7);"><?php echo $sentCust->format('m/d/Y') ?></td>
                        <?php }
                        if($log['Sent_Customer'] == NULL) { ?>
                            <td style="background-color: rgba(0, 255, 0, 0.7);"></td>
                        <?php } 
                        if($log['PPAP_Signed_Date'] != NULL) { 
                            $signDate = new DateTime($log['PPAP_Signed_Date']); ?>
                            <td style="background-color: rgba(0, 255, 0, 0.7);"><?php echo $signDate->format('m/d/Y') ?></td>
                        <?php }
                    } 
                    if($log['Name'] == NULL) {?>
                        <td></td>
                        <td></td>
                        <td><?php echo $log['BS_Eurotech_PN']; ?></td>
                        <td><?php echo $log['Description']; ?></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td><?php echo $log['Supplier']; ?></td>
                        <td><?php echo $log['Supplier_PN']; ?></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    <?php } ?>
                </tr> 
            <?php } ?>
        </table> 
    </div>
<?php } 

if (isset($_POST['note'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Note</h2>
    <form action="?page=BluSeal" method="post">
        <input type="hidden" name="confirmNote" value="1">
        <input type="hidden" name="confirmIDNote" value="<?php echo $_POST['IDnote']; ?>">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
        <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
        <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
        <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
        <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
        <div>
            <input style="width: 10px;" type="checkbox" name="PPAP_ET" <?php if($noteData['PPAP_ET'] != NULL) { echo "checked value='<?php echo 1; ?>'";  } else { echo "value=''"; } ?>> PPAP ET
        </div>

        <div>
            <input style="width: 10px;" type="checkbox" name="IMDS_ET" <?php if($noteData['IMDS_ET'] != NULL) { echo "checked value='<?php echo 1; ?>'";  } else { echo "value=''"; } ?>> IMDS ET
        </div>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if (isset($_POST['insertD'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New PPAP</h2>
    <form action="?page=BluSeal" method="post">
        <input type="hidden" name="confirmID" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
        <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
        <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
        <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
        <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
        <label>Description:</label>
        <select name="Description" required>
            <option value=""></option>
            <?php foreach ($Descs as $Desc) {  ?>
                <option value="<?php echo $Desc['Description'] ?>"><?php echo $Desc['Description'] ?></option>
            <?php } ?>
        </select> <br>

        <label>Customer:</label>
        <input type="text" maxlength="70" name="Name" list="Customer" required> <br>

        <label>IMDS:</label>
        <input type="text" maxlength="15" name="IMDS" list="IMDS"> <br>

        <label>PPAP Requested Date:</label>
        <input type="date" name="Request_Date" required> <br>

        <label>PPAP Received Date:</label>
        <input type="date" name="PPAP_Received_Date"> <br>

        <label>PPAP Sent Date:</label>
        <input type="date" name="Sent_Customer"> <br>

        <label>PPAP Signed Date:</label>
        <input type="date" name="PPAP_Signed_Date">

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if ($custError != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Error</h2>
        <form action="?page=BluSeal" method="post">
            <h6><b>The customer's name "<?php echo $_POST['Name']; ?>" doesn't exist.</b></h6>
        </form>
    </div>
    </div>
<?php } 

if ($NocpnError != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Error</h2>
        <form action="?page=BluSeal" method="post">
            <h6><b>Customer's PN doesn't exist.</b></h6>
        </form>
    </div>
    </div>
<?php } 

if ($NoDatesError != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Error</h2>
        <form action="?page=BluSeal" method="post">
            <h6><b>There are dates missing.</b></h6>
        </form>
    </div>
    </div>
<?php } 

if (isset($_POST['insertET'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New PPAP</h2>
    <form action="?page=BluSeal" method="post">
        <input type="hidden" name="confirmIE" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
        <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
        <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
        <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
        <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
        <label>Eurotech PN:</label>
        <select name="BS_Eurotech_PN" required>
            <option value="">All</option>
            <?php foreach ($Models as $Model) {  ?>
                <option value="<?php echo $Model['BS_Eurotech_PN'] ?>"><?php echo $Model['BS_Eurotech_PN'] ?></option>
            <?php } ?>
        </select> <br>

        <label>Customer:</label>
        <input type="text" maxlength="70" name="Name" list="Customer" required> <br>

        <label>IMDS:</label>
        <input type="text" maxlength="15" name="IMDS" list="IMDS"> <br>

        <label>PPAP Requested Date:</label>
        <input type="date" name="Request_Date" required> <br>

        <label>PPAP Received Date:</label>
        <input type="date" name="PPAP_Received_Date" > <br>

        <label>PPAP Sent Date:</label>
        <input type="date" name="Sent_Customer" > <br>

        <label>PPAP Signed Date:</label>
        <input type="date" name="PPAP_Signed_Date" >

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if (isset($_POST['insertC'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New PPAP</h2>
    <form action="?page=BluSeal" method="post">
        <input type="hidden" name="confirmIC" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
        <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
        <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
        <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
        <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
        <label>Customer PN:</label>
        <input type="text" maxlength="20" name="BS_Customer_PN" list="CPN" required> <br>

        <label>IMDS:</label>
        <input type="text" maxlength="15" name="IMDS" list="IMDS"> <br>

        <label>PPAP Requested Date:</label>
        <input type="date" name="Request_Date"  required> <br>

        <label>PPAP Received Date:</label>
        <input type="date" name="PPAP_Received_Date" > <br>

        <label>PPAP Sent Date:</label>
        <input type="date" name="Sent_Customer" > <br>

        <label>PPAP Signed Date:</label>
        <input type="date" name="PPAP_Signed_Date" >

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if ($cpnError != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Error</h2>
        <form action="?page=BluSeal" method="post">
            <h6><b>The customer's PN "<?php echo $_POST['BS_Customer_PN']; ?>" doesn't exist.</b></h6>
        </form>
    </div>
    </div>
<?php } 

if (isset($_POST['edit'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Update PPAP</h2>
    <form action="?page=BluSeal" method="post">
        <input type="hidden" name="confirmU" value="1">
        <input type="hidden" name="BS_PPAP_ID" value="<?php echo $_POST['IDedit']; ?>">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
        <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
        <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
        <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
        <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
        <label>IMDS:</label>
        <input type="text" maxlength="15" name="IMDS" list="IMDS" value="<?php echo $bsData['IMDS']; ?>"> <br>

        <label>PPAP Requested Date:</label>
        <input type="date" name="Request_Date" value="<?php echo $bsData['Request_Date']; ?>" required> <br>

        <label>PPAP Received Date:</label>
        <input type="date" name="PPAP_Received_Date" value="<?php echo $bsData['PPAP_Received_Date']; ?>"> <br>

        <label>PPAP Sent Date:</label>
        <input type="date" name="Sent_Customer" value="<?php echo $bsData['Sent_Customer']; ?>"> <br>

        <label>PPAP Signed Date:</label>
        <input type="date" name="PPAP_Signed_Date" value="<?php echo $bsData['PPAP_Signed_Date']; ?>">

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php }

if (isset($_POST['delete'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Delete PPAP</h2>
    <form action="?page=BluSeal" method="post">
        <input type="hidden" name="confirmD" value="1">
        <input type="hidden" name="IDdelete" value="<?php echo $_POST['IDdelete']; ?>">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="modelsearch" value="<?php if(isset($_POST['modelsearch'])) { echo $_POST['modelsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="suppsearch" value="<?php if(isset($_POST['suppsearch'])) { echo $_POST['suppsearch']; } ?>">
        <input type="hidden" name="spnsearch" value="<?php if(isset($_POST['spnsearch'])) { echo $_POST['spnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="date5search" value="<?php if(isset($_POST['date5search'])) { echo $_POST['date5search']; } ?>">
        <input type="hidden" name="date6search" value="<?php if(isset($_POST['date6search'])) { echo $_POST['date6search']; } ?>">
        <input type="hidden" name="date7search" value="<?php if(isset($_POST['date7search'])) { echo $_POST['date7search']; } ?>">
        <input type="hidden" name="date8search" value="<?php if(isset($_POST['date8search'])) { echo $_POST['date8search']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="psen" value="<?php if(isset($_POST['psen'])) { echo $_POST['psen']; } ?>">
        <input type="hidden" name="psin" value="<?php if(isset($_POST['psin'])) { echo $_POST['psin']; } ?>">
        <?php 
            if($bsDataD['Request_Date'] != NULL) {
                $reqD = new DateTime($bsDataD['Request_Date']);
            }
            if($bsDataD['PPAP_Received_Date'] != "") {
                $recD = new DateTime($bsDataD['PPAP_Received_Date']);
            }
            if($bsDataD['Sent_Customer'] != "") {
                $senD = new DateTime($bsDataD['Sent_Customer']);
            }
            if($bsDataD['PPAP_Signed_Date'] != "") {
                $sigD = new DateTime($bsDataD['PPAP_Signed_Date']);
            }
        ?>
        <h5>Are you sure you want to delete the data of this PPAP?</h5> <br>
        <h6><b>Model:</b> <?php echo $bsDataD['BS_Eurotech_PN'] ?></h6>
        <h6><b>Description:</b> <?php echo $bsDataD['Description'] ?></h6>
        <h6><b>Customer:</b> <?php echo $bsDataD['Name'] ?></h6>
        <h6><b>Customer PN:</b> <?php echo $bsDataD['BS_Customer_PN'] ?></h6>
        <h6><b>IMDS:</b> <?php echo $bsDataD['IMDS'] ?></h6>
        <h6><b>Supplier:</b> <?php echo $bsDataD['Supplier'] ?></h6>
        <h6><b>Supplier PN:</b> <?php echo $bsDataD['Supplier_PN'] ?></h6>
        <h6><b>Requested Date:</b> <?php if($bsDataD['Request_Date'] != NULL) { echo $reqD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
        <h6><b>Received Date:</b> <?php if($bsDataD['PPAP_Received_Date'] != NULL) { echo $recD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
        <h6><b>Sent Date:</b> <?php if($bsDataD['Sent_Customer'] != NULL) { echo $senD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
        <h6><b>Signed Date:</b> <?php if($bsDataD['PPAP_Signed_Date'] != NULL) { echo $sigD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
        <button type="submit">Confirm</button>
    </form>
  </div>
</div>
<?php }

if ($Deleted != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Register Deleted</h2>
        <form action="?page=Cables" method="post">
            <h6><b>The register was delete correctly.</b></h6>
        </form>
    </div>
    </div>
<?php } ?>

<script>
    function closeForm() {
        document.getElementById('formularioModal').style.display = 'none';
    }

    function sendForm() {
        closeForm();
        return true;
    }

    function clearForm() {
        document.querySelectorAll("#form input[type='text']").forEach(input => input.value = "");
        document.querySelectorAll("#form input[type='date']").forEach(input => input.value = "");

        const radioButtons = document.querySelectorAll("#form input[type='radio']");
        const defaultValue = '';

        for (const radio of radioButtons) {
            if (radio.value === defaultValue) {
                radio.checked = true;
            }
        }

        const selects = document.querySelectorAll("#form select");

        for (const select of selects) {
            select.value = defaultValue;
        }
    }
</script>