<link href="./css/style.css" rel="stylesheet">
<style>
    .clear {
        color: white;
        padding: 8px 14px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
        transition: background-color 0.2s;
        font-size: 14px;
        background-color: #16bacfff;
    }

    .clear:hover {
        background-color: #1dd1e8ff;
        color: white;
    }

    .renewal {
        color: black;
        padding: 8px 14px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
        transition: background-color 0.2s;
        font-size: 14px;
        background-color: #e6df1dff;
    }

    .renewal:hover {
        background-color: #f9f110ff;
        /* color: white; */
    }

    .form-search .camp{
        flex: 1 1 20%;
    }

    .form-search .camp2 {
        flex: 1 1 40%;
    }

    .form-search .camp3 {
        flex: 1 1 15%;
    }

    .form-search .camp4 {
        flex: 1 1 100%;
    }

    .form-search input[type="date"],
    .form-search input[type="number"] {
        padding: 8px 10px;
        border: 1px solid #bbb;
        border-radius: 8px;
        width: 46%;
        box-sizing: border-box;
    }

    @media (max-width: 1530px) {
        .form-search .camp {
            flex: 1 1 40%; 
            min-width: 300px;
        }
    }

    @media (max-width: 1501px) {
        .form-search input[type="number"] {
            width: 46%;
        }

        .form-search .camp2 {
            flex: 1 1 30%;
        }

        .form-search .camp3 {
            flex: 1 1 20%;
        }
    }

    @media (max-width: 1040px) {
        .form-search .camp {
            flex: 1 1 100%; 
            min-width: 300px;
        }

        .form-search .camp2 {
            flex: 1 1 20%;
        }

        .form-search .camp3 {
            flex: 1 1 20%;
        }
    }
</style>
<form action="" id="form" method="post" class="form-search">
    <?php $MaxYs = $model->searchMaxY(); ?>
    <input type="hidden" name="page" value="Tapes">
    <div class="camp2"></div>
    <div class="camp2"></div>
    <div class="camp3">
        <label>Period:</label>
        <input type="number" name="submit1search" min="2020" max="<?php echo (int)(date("Y", strtotime("+2 year"))); ?>" value="<?php if ($submit1search != NULL) { echo $submit1search;} else { $pastyear = (int)(date("Y", strtotime("-1 year"))); echo $pastyear; }?>" required> -
        <!-- 
            //////////////////
            QUITAR $actualyear 
            //////////////////
         -->
        <input type="number" name="submit2search" min="2020" max="<?php echo (int)(date("Y", strtotime("+2 year"))); ?>" value="<?php if ($submit2search != NULL) { echo $submit2search;} else { $actualyear = (int)(date("Y")); echo $MaxYs[0][0]; }?>" required>
    </div>
    <div class="camp">
        <label>Customer:</label>
        <input type="text" name="custsearch" maxlength="70" list="Customer" value="<?php if ($custsearch != NULL) { echo $custsearch;} ?>">
        <datalist id="Customer">
            <?php foreach ($Customers as $Customer) {  ?>
                <option value="<?php echo $Customer['Name'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>OEM:</label>
        <input type="text" name="oemsearch" maxlength="255" list="OEM" value="<?php if ($oemsearch != NULL) { echo $oemsearch;} ?>">
        <datalist id="OEM">
            <?php foreach ($OEMS as $OEM) {  ?>
                <option value="<?php echo $OEM['OEM'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Country:</label>
        <input type="text" name="counsearch" maxlength="30" list="Country" value="<?php if ($counsearch != NULL) { echo $counsearch;} ?>">
        <datalist id="Country">
            <?php foreach ($Countries as $Country) {  ?>
                <option value="<?php echo $Country['Country'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>PPAP Level:</label>
        <select name="levelsearch">
            <option value="" <?php if($levelsearch == '') { echo 'selected'; }?>>All</option>
            <option value="1" <?php if($levelsearch == '1') { echo 'selected'; }?>>1</option>
            <option value="2" <?php if($levelsearch == '2') { echo 'selected'; }?>>2</option>
            <option value="3" <?php if($levelsearch == '3') { echo 'selected'; }?>>3</option>
            <option value="4" <?php if($levelsearch == '4') { echo 'selected'; }?>>4</option>
            <option value="5" <?php if($levelsearch == '5') { echo 'selected'; }?>>5</option>
            <option value="N" <?php if($levelsearch == 'N') { echo 'selected'; }?>>Blancks</option>
        </select>
    </div>

    <div class="camp">
        <label>SAP No.:</label>
        <input type="text" name="sapsearch" maxlength="8" list="SAP" value="<?php if ($sapsearch != NULL) { echo $sapsearch;} ?>">
        <datalist id="SAP">
            <?php foreach ($SAPS as $SAP) {  ?>
                <option value="<?php echo $SAP['SAP_Number'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Customer PN:</label>
        <input type="text" name="cpnsearch" maxlength="20" list="CPN" value="<?php if ($cpnsearch != NULL) { echo $cpnsearch;} ?>">
        <datalist id="CPN">
            <?php foreach ($CPNS as $CPN) {  ?>
                <option value="<?php echo $CPN['TAP_Customer_PN'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Description:</label> 
        <input style="width: 21%;" type="text" maxlength="25" placeholder="Tape" name="tapesearch" list="Tape" value="<?php if ($tapesearch != NULL) { echo $tapesearch;} ?>"> -
        <input style="width: 21%;" type="text" maxlength="8" placeholder="Width" name="widthsearch" list="Width" value="<?php if ($widthsearch != NULL) { echo $widthsearch;} ?>"> -
        <input style="width: 21%;" type="text" maxlength="8" placeholder="Length" name="lengthsearch" list="Length" value="<?php if ($lengthsearch != NULL) { echo $lengthsearch;} ?>"> -
        <input style="width: 20%;" type="text" maxlength="8" placeholder="Color" name="colorsearch" list="Color" value="<?php if ($colorsearch != NULL) { echo $colorsearch;} ?>">
        <datalist id="Tape">
            <?php foreach ($Tapes as $Tape) {  ?>
                <option value="<?php echo $Tape['Tape'] ?>">
            <?php } ?>
        </datalist>
        <datalist id="Width">
            <?php foreach ($Widths as $Width) {  ?>
                <option value="<?php echo $Width['Width'] ?>">
            <?php } ?>
        </datalist>
        <datalist id="Length">
            <?php foreach ($Lengths as $Length) {  ?>
                <option value="<?php echo $Length['Length'] ?>">
            <?php } ?>
        </datalist>
        <datalist id="Color">
            <?php foreach ($Colors as $Color) {  ?>
                <option value="<?php echo $Color['Color'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>IMDS ID No.:</label>
        <input type="text" name="imdssearch" maxlength="8" list="IMDS" value="<?php if ($imdssearch != NULL) { echo $imdssearch;} ?>">
        <datalist id="IMDS">
            <?php foreach ($IMDS as $IM) {  ?>
                <option value="<?php echo $IM['IMDS_ID_No'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <hr style="width: 100%;">
    <div class="camp4">
        <label style="font-size: 20px;"><b>Initial</b></label>
    </div>
    <div class="camp">
        <label>Returned from CTC / Sent to Customer:</label>
        <input type="date" name="ret1search" value="<?php if ($ret1search != NULL) { echo $ret1search;} ?>"> - <input type="date" name="ret2search" value="<?php if ($ret2search != NULL) { echo $ret2search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="retn" id="" value="" <?php if ($retn != "N" && $retn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="retn" id="" value="N" <?php if ($retn == "N") { echo "checked";} ?>> No date
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="retn" id="" value="Y" <?php if ($retn == "Y") { echo "checked";} ?>> W/ date
    </div>
    
    <div class="camp">
        <label>PSW returned from Customer signed / Sent to CTC:</label>
        <input type="date" name="psw1search" value="<?php if ($psw1search != NULL) { echo $psw1search;} ?>"> - <input type="date" name="psw2search" value="<?php if ($psw2search != NULL) { echo $psw2search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="pscn" id="" value="" <?php if ($pscn != "N" && $pscn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pscn" id="" value="N" <?php if ($pscn == "N") { echo "checked";} ?>> No date
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pscn" id="" value="Y" <?php if ($pscn == "Y") { echo "checked";} ?>> W/ date
    </div>

    <hr style="width: 100%;">
    <div class="camp4">
        <label style="font-size: 20px;"><b>Renewal</b></label>
    </div>
    <div class="camp">
        <label>Renewal Date:</label>
        <input type="date" name="ren1search" value="<?php if ($ren1search != NULL) { echo $ren1search;} ?>"> - <input type="date" name="ren2search" value="<?php if ($ren2search != NULL) { echo $ren2search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="renn" id="" value="" <?php if ($renn != "N" && $renn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="renn" id="" value="N" <?php if ($renn == "N") { echo "checked";} ?>> No date
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="renn" id="" value="Y" <?php if ($renn == "Y") { echo "checked";} ?>> W/ date
    </div>
    
    <div class="camp">
        <label>When to send Request to CTC:</label>
        <input type="date" name="req1search" value="<?php if ($req1search != NULL) { echo $req1search;} ?>"> - <input type="date" name="req2search" value="<?php if ($req2search != NULL) { echo $req2search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="reqn" id="" value="" <?php if ($reqn != "N" && $reqn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="reqn" id="" value="N" <?php if ($reqn == "N") { echo "checked";} ?>> No date
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="reqn" id="" value="Y" <?php if ($reqn == "Y") { echo "checked";} ?>> W/ date
    </div>
    
    <div class="camp">
        <label>Sent to Customer:</label>
        <input type="date" name="sent1search" value="<?php if ($sent1search != NULL) { echo $sent1search;} ?>"> - <input type="date" name="sent2search" value="<?php if ($sent2search != NULL) { echo $sent2search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="stcn" id="" value="" <?php if ($stcn != "N" && $stcn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="stcn" id="" value="N" <?php if ($stcn == "N") { echo "checked";} ?>> No date
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="stcn" id="" value="Y" <?php if ($stcn == "Y") { echo "checked";} ?>> W/ date
    </div>
    
    <div class="camp">
        <label>PSW returned from Customer signed:</label>
        <input type="date" name="pswr1search" value="<?php if ($pswr1search != NULL) { echo $pswr1search;} ?>"> - <input type="date" name="pswr2search" value="<?php if ($pswr2search != NULL) { echo $pswr2search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="pcsn" id="" value="" <?php if ($pcsn != "N" && $pcsn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pcsn" id="" value="N" <?php if ($pcsn == "N") { echo "checked";} ?>> No date
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pcsn" id="" value="Y" <?php if ($pcsn == "Y") { echo "checked";} ?>> W/ date
    </div>

    <hr style="width: 100%;">
    <div class="camp">
        <label>PPAP from shipments:</label>
        <input type="radio" name="pfsn" value="" <?php if ($pfsn != "N" && $pfsn != "Y") { echo "checked";} ?> checked> All <br>
        <input type="radio" name="pfsn" value="N" <?php if ($pfsn == "N") { echo "checked";} ?>> No <br>
        <input type="radio" name="pfsn" value="Y" <?php if ($pfsn == "Y") { echo "checked";} ?>> Yes
    </div>

    <div class="camp">
        <label>Comments:</label>
        <input type="text" name="comsearch" maxlength="255" list="Com" value="<?php if ($comsearch != NULL) { echo $comsearch;} ?>">
        <datalist id="Com">
            <?php foreach ($Coms as $Com) {  ?>
                <option value="<?php echo $Com['Comments'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp"></div>
    <div class="camp"></div>

    <div class="campbtn">
        <button type="submit" name="btnsearch" class="insert">Search</button>
        <button style="margin: 0px 0px 0px 15px;"  type="submit" name="btnsearch" class="clear" onclick="clearForm()">Clear All</button>
    </div>
</form>

<div style="display: flex;">
    <form action="?page=Tapes" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insertD" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
        <button type="submit" class="insert">New PPAP (Description)</button>
    </form>

    <form action="?page=Tapes" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insertET" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
        <button type="submit" class="insert">New PPAP (ET PN)</button>
    </form>

    <form action="?page=Tapes" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insertC" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
        <button type="submit" class="insert">New PPAP (Cust PN)</button>
    </form>
</div>


<?php if($logs == NULL) { ?>
    <br>
    <h1>No results.</h1>
<?php } ?>

<?php if($logs != NULL) { ?>
    <div class="table-responsive">
        <table class="table table-bordered">
            <tr>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2"></th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2"></th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2"></th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">CUSTOMER</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">OEM</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">Country</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">PPAP Level</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">SAP No.</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">Customer Part No.</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">Tape</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">Width (MM)</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">Length (M)</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">Color</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">IMDS ID no.</th>
                <th style="background-color:#1c18AA; color:white" colspan="2">INITIAL</th>
                <?php if($submit1search != NULL && $submit2search != NULL) {
                    for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { ?>
                        <th style="background-color:#1c18AA; color:white" colspan="4"><?php echo $i; ?></th>
                    <?php } 
                } 
                if($submit1search == NULL && $submit2search == NULL) {
                    for($i = $pastyear; $i <= $MaxYs[0][0]; $i++) { ?>
                        <th style="background-color:#1c18AA; color:white" colspan="4"><?php echo $i; ?></th>
                    <?php } 
                }?>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">PPAP from shipments</th>
                <th style="background-color:#1c18AA; color:white; border-bottom: 1px solid #1c18AA;" colspan="1" rowspan="2">Comments</th>
            </tr>
            <tr>
                <th style="background-color:#1c18AA; color:white">Returned from CTC / Sent to Customer</th>
                <th style="background-color:#1c18AA; color:white">PSW returned from Customer signed / Sent to CTC</th>
                <?php if($submit1search != NULL && $submit2search != NULL) {
                    for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { ?>
                        <th style="background-color:#1c18AA; color:white">Renewal Date</th>
                        <th style="background-color:#1c18AA; color:white">When to send Request to CTC</th>
                        <th style="background-color:#1c18AA; color:white">Sent to Customer</th>
                        <th style="background-color:#1c18AA; color:white">PSW returned from Customer signed</th>
                    <?php } 
                } 
                if($submit1search == NULL && $submit2search == NULL) {
                    for($i = $pastyear; $i <= $MaxYs[0][0]; $i++) { ?>
                        <th style="background-color:#1c18AA; color:white">Renewal Date</th>
                        <th style="background-color:#1c18AA; color:white">When to send Request to CTC</th>
                        <th style="background-color:#1c18AA; color:white">Sent to Customer</th>
                        <th style="background-color:#1c18AA; color:white">PSW returned from Customer signed</th>
                    <?php } 
                }?>
            </tr>
            
            <?php foreach ($logs as $log) { ?>
                    <tr>
                        <?php 
                        $MaxYear = $model->searchMaxYearRD($log['TAP_PPAP_ID']);
                        $MaxYearsSCS = $model->searchMaxYearSC($log['TAP_PPAP_ID']);
                        if($MaxYear != NULL && $MaxYearsSCS != NULL){
                            if($MaxYearsSCS[0][1] != NULL) {
                                $maxyearSD = $MaxYearsSCS[0][1];
                            }
                            else {
                                $maxyearSD = NULL;
                            }
                        }
                        if($MaxYear != NULL && $MaxYearsSCS == NULL){
                            if($MaxYear[0][1] != NULL) {
                                $maxyearSD = $MaxYear[0][1];
                            }
                            else {
                                $maxyearSD = NULL;
                            }
                        }
                        if($MaxYear == NULL && $MaxYearsSCS != NULL){
                            if($MaxYearsSCS[0][1] != NULL) {
                                $maxyearSD = $MaxYearsSCS[0][1];
                            }
                            else {
                                $maxyearSD = NULL;
                            }
                        }
                        if($MaxYear == NULL && $MaxYearsSCS == NULL){  
                            $maxyearSD = NULL;
                        }
                        
                        $dates2 = $model->searchDates2($MaxYs[0][0], $log['TAP_PPAP_ID']);
                        foreach ($dates2 as $dateN) { 
                            if($dateN['Sent_Customer'] != NULL && $dateN['Returned_Cust_Signed'] != NULL && $log['TAP_PPAP_ID'] == $dateN['TAP_PPAP_ID']) { ?>
                                <td style="background-color: rgba(0, 255, 0, 0.5);">
                                    <form action="?page=Tapes" method="post" style="display:inline;">
                                    <input type="hidden" name="edit" value="">
                                        <input type="hidden" name="IDedit" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                        <input type="hidden" name="btnsearch" value="1">
                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                        <button type="submit" class="editar">Edit</button>
                                    </form>
                                </td>
                                <td style="background-color: rgba(0, 255, 0, 0.5);">
                                    <form action="?page=Tapes" method="post" style="display:inline;">
                                    <input type="hidden" name="delete" value="">
                                        <input type="hidden" name="IDdelete" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                        <input type="hidden" name="btnsearch" value="1">
                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                        <button type="submit" class="eliminar">Delete</button>
                                    </form>
                                </td>
                                <td style="background-color: rgba(0, 255, 0, 0.5);">
                                    <form action="?page=Tapes" method="post" style="display:inline;">
                                    <input type="hidden" name="renewal" value="">
                                        <input type="hidden" name="IDPPAP" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                        <input type="hidden" name="Initial" value="<?php echo $log['Returned_CTC-Sent_Cust']; ?>">
                                        <input type="hidden" name="btnsearch" value="1">
                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                        <button type="submit" class="renewal">Add Renewal</button>
                                    </form>
                                </td>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Name']; ?></td>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['OEM']; ?></td>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Country']; ?></td>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['PPAP_level']; ?></td>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['SAP_Number']; ?></td>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['FK_TAP_Customer_PN']; ?></td>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Tape']; ?></td>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Width']; ?></td>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Length']; ?></td>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['Color']; ?></td>
                                <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $log['IMDS_ID_No']; ?></td>
                                <?php if($log['Returned_CTC-Sent_Cust'] != NULL) { 
                                    $retCtc = new DateTime($log['Returned_CTC-Sent_Cust']); ?>
                                            <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $retCtc->format('m/d/Y') ?></td>
                                <?php }
                                if($log['Returned_CTC-Sent_Cust'] == NULL) { ?>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                <?php } 
                                if($log['Cust_Signed-Sent_CTC'] != NULL) { 
                                    $custSign = new DateTime($log['Cust_Signed-Sent_CTC']); ?>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $custSign->format('m/d/Y') ?></td>
                                <?php }
                                if($log['Cust_Signed-Sent_CTC'] == NULL) { ?>
                                    <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                <?php } 
                            }
                            if($dateN['Sent_Customer'] != NULL && $dateN['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $dateN['TAP_PPAP_ID']) { ?>
                                <td style="background-color: rgba(204, 0, 34, 0.5);">
                                    <form action="?page=Tapes" method="post" style="display:inline;">
                                    <input type="hidden" name="edit" value="">
                                        <input type="hidden" name="IDedit" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                        <input type="hidden" name="btnsearch" value="1">
                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                        <button type="submit" class="editar">Edit</button>
                                    </form>
                                </td>
                                <td style="background-color: rgba(204, 0, 34, 0.5);">
                                    <form action="?page=Tapes" method="post" style="display:inline;">
                                    <input type="hidden" name="delete" value="">
                                        <input type="hidden" name="IDdelete" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                        <input type="hidden" name="btnsearch" value="1">
                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                        <button type="submit" class="eliminar">Delete</button>
                                    </form>
                                </td>
                                <td style="background-color: rgba(204, 0, 34, 0.5);">
                                    <form action="?page=Tapes" method="post" style="display:inline;">
                                    <input type="hidden" name="renewal" value="">
                                                <input type="hidden" name="IDPPAP" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                <input type="hidden" name="Initial" value="<?php echo $log['Returned_CTC-Sent_Cust']; ?>">
                                                <input type="hidden" name="btnsearch" value="1">
                                                <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                <button type="submit" class="renewal">Add Renewal</button>
                                    </form>
                                </td>
                                <?php if($dateN['Renewal_Date'] != NULL) { 
                                    $rD = new DateTime($dateN['Renewal_Date']);
                                    $limit = $rD->modify('+7 days'); 
                                    $renDate = new DateTime($dateN['Renewal_Date']); 
                                    if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                        <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['Name']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['OEM']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['Country']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['PPAP_level']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['SAP_Number']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['FK_TAP_Customer_PN']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['Tape']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['Width']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['Length']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['Color']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $log['IMDS_ID_No']; ?></td>
                                        <?php if($log['Returned_CTC-Sent_Cust'] != NULL) { 
                                            $retCtc = new DateTime($log['Returned_CTC-Sent_Cust']); ?>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $retCtc->format('m/d/Y') ?></td>
                                        <?php }
                                        if($log['Returned_CTC-Sent_Cust'] == NULL) { ?>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <?php } 
                                        if($log['Cust_Signed-Sent_CTC'] != NULL) { 
                                            $custSign = new DateTime($log['Cust_Signed-Sent_CTC']); ?>
                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo $custSign->format('m/d/Y') ?></td>
                                        <?php }
                                        if($log['Cust_Signed-Sent_CTC'] == NULL) { ?>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <?php }  
                                    }
                                    if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Name']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['OEM']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Country']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['PPAP_level']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['SAP_Number']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['FK_TAP_Customer_PN']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Tape']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Width']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Length']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Color']; ?></td>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['IMDS_ID_No']; ?></td>
                                        <?php if($log['Returned_CTC-Sent_Cust'] != NULL) { 
                                            $retCtc = new DateTime($log['Returned_CTC-Sent_Cust']); ?>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $retCtc->format('m/d/Y') ?></td>
                                        <?php }
                                        if($log['Returned_CTC-Sent_Cust'] == NULL) { ?>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <?php } 
                                        if($log['Cust_Signed-Sent_CTC'] != NULL) { 
                                            $custSign = new DateTime($log['Cust_Signed-Sent_CTC']); ?>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $custSign->format('m/d/Y') ?></td>
                                        <?php }
                                        if($log['Cust_Signed-Sent_CTC'] == NULL) { ?>
                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                        <?php }  
                                    } 
                                } 
                                else { ?>
                                    <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Name']; ?></td>
                                    <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['OEM']; ?></td>
                                    <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Country']; ?></td>
                                    <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['PPAP_level']; ?></td>
                                    <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['SAP_Number']; ?></td>
                                    <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['FK_TAP_Customer_PN']; ?></td>
                                    <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Tape']; ?></td>
                                    <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Width']; ?></td>
                                    <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Length']; ?></td>
                                    <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['Color']; ?></td>
                                    <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $log['IMDS_ID_No']; ?></td>
                                    <?php if($log['Returned_CTC-Sent_Cust'] != NULL) { 
                                        $retCtc = new DateTime($log['Returned_CTC-Sent_Cust']); ?>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $retCtc->format('m/d/Y') ?></td>
                                    <?php }
                                    if($log['Returned_CTC-Sent_Cust'] == NULL) { ?>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                    <?php } 
                                    if($log['Cust_Signed-Sent_CTC'] != NULL) { 
                                        $custSign = new DateTime($log['Cust_Signed-Sent_CTC']); ?>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $custSign->format('m/d/Y') ?></td>
                                    <?php }
                                    if($log['Cust_Signed-Sent_CTC'] == NULL) { ?>
                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                    <?php } 
                                } 
                            }
                            if($dateN['Sent_Customer'] == NULL && $dateN['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $dateN['TAP_PPAP_ID']) {
                                if($dateN['Renewal_Date'] != NULL) {
                                    $rD = new DateTime($dateN['Renewal_Date']);
                                    $limit = $rD->modify('+7 days'); 
                                    if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                        <td style="color: #FF0000;">
                                            <form action="?page=Tapes" method="post" style="display:inline;">
                                            <input type="hidden" name="edit" value="">
                                                        <input type="hidden" name="IDedit" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                        <input type="hidden" name="btnsearch" value="1">
                                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                        <button type="submit" class="editar">Edit</button>
                                            </form>
                                        </td>
                                        <td style="color: #FF0000;">
                                            <form action="?page=Tapes" method="post" style="display:inline;">
                                            <input type="hidden" name="delete" value="">
                                                        <input type="hidden" name="IDdelete" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                        <input type="hidden" name="btnsearch" value="1">
                                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                        <button type="submit" class="eliminar">Delete</button>
                                            </form>
                                        </td>
                                        <td style="color: #FF0000;">
                                            <form action="?page=Tapes" method="post" style="display:inline;">
                                            <input type="hidden" name="renewal" value="">
                                                        <input type="hidden" name="IDPPAP" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                        <input type="hidden" name="Initial" value="<?php echo $log['Returned_CTC-Sent_Cust']; ?>">
                                                        <input type="hidden" name="btnsearch" value="1">
                                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                        <button type="submit" class="renewal">Add Renewal</button>
                                            </form>
                                        </td>
                                        <td style="color: #FF0000;"><?php echo $log['Name']; ?></td>
                                        <td style="color: #FF0000;"><?php echo $log['OEM']; ?></td>
                                        <td style="color: #FF0000;"><?php echo $log['Country']; ?></td>
                                        <td style="color: #FF0000;"><?php echo $log['PPAP_level']; ?></td>
                                        <td style="color: #FF0000;"><?php echo $log['SAP_Number']; ?></td>
                                        <td style="color: #FF0000;"><?php echo $log['FK_TAP_Customer_PN']; ?></td>
                                        <td style="color: #FF0000;"><?php echo $log['Tape']; ?></td>
                                        <td style="color: #FF0000;"><?php echo $log['Width']; ?></td>
                                        <td style="color: #FF0000;"><?php echo $log['Length']; ?></td>
                                        <td style="color: #FF0000;"><?php echo $log['Color']; ?></td>
                                        <td style="color: #FF0000;"><?php echo $log['IMDS_ID_No']; ?></td>
                                        <?php if($log['Returned_CTC-Sent_Cust'] != NULL) { 
                                            $retCtc = new DateTime($log['Returned_CTC-Sent_Cust']); ?>
                                            <td style="color: #FF0000;"><?php echo $retCtc->format('m/d/Y') ?></td>
                                        <?php }
                                        if($log['Returned_CTC-Sent_Cust'] == NULL) { ?>
                                            <td style="color: #FF0000;"></td>
                                        <?php } 
                                        if($log['Cust_Signed-Sent_CTC'] != NULL) { 
                                            $custSign = new DateTime($log['Cust_Signed-Sent_CTC']); ?>
                                            <td style="color: #FF0000;"><?php echo $custSign->format('m/d/Y') ?></td>
                                        <?php }
                                        if($log['Cust_Signed-Sent_CTC'] == NULL) { ?>
                                            <td style="color: #FF0000;"></td>
                                        <?php } 
                                    }
                                    if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                        <td>
                                            <form action="?page=Tapes" method="post" style="display:inline;">
                                            <input type="hidden" name="edit" value="">
                                                        <input type="hidden" name="IDedit" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                        <input type="hidden" name="btnsearch" value="1">
                                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                        <button type="submit" class="editar">Edit</button>
                                            </form>
                                        </td>
                                        <td>
                                            <form action="?page=Tapes" method="post" style="display:inline;">
                                            <input type="hidden" name="delete" value="">
                                                        <input type="hidden" name="IDdelete" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                        <input type="hidden" name="btnsearch" value="1">
                                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                        <button type="submit" class="eliminar">Delete</button>
                                            </form>
                                        </td>
                                        <td>
                                            <form action="?page=Tapes" method="post" style="display:inline;">
                                            <input type="hidden" name="renewal" value="">
                                                        <input type="hidden" name="IDPPAP" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                        <input type="hidden" name="Initial" value="<?php echo $log['Returned_CTC-Sent_Cust']; ?>">
                                                        <input type="hidden" name="btnsearch" value="1">
                                                        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                        <button type="submit" class="renewal">Add Renewal</button>
                                            </form>
                                        </td>
                                        <td><?php echo $log['Name']; ?></td>
                                        <td><?php echo $log['OEM']; ?></td>
                                        <td><?php echo $log['Country']; ?></td>
                                        <td><?php echo $log['PPAP_level']; ?></td>
                                        <td><?php echo $log['SAP_Number']; ?></td>
                                        <td><?php echo $log['FK_TAP_Customer_PN']; ?></td>
                                        <td><?php echo $log['Tape']; ?></td>
                                        <td><?php echo $log['Width']; ?></td>
                                        <td><?php echo $log['Length']; ?></td>
                                        <td><?php echo $log['Color']; ?></td>
                                        <td><?php echo $log['IMDS_ID_No']; ?></td>
                                        <?php if($log['Returned_CTC-Sent_Cust'] != NULL) { 
                                            $retCtc = new DateTime($log['Returned_CTC-Sent_Cust']); ?>
                                            <td><?php echo $retCtc->format('m/d/Y') ?></td>
                                        <?php }
                                        if($log['Returned_CTC-Sent_Cust'] == NULL) { ?>
                                            <td></td>
                                        <?php } 
                                        if($log['Cust_Signed-Sent_CTC'] != NULL) { 
                                            $custSign = new DateTime($log['Cust_Signed-Sent_CTC']); ?>
                                            <td><?php echo $custSign->format('m/d/Y') ?></td>
                                        <?php }
                                        if($log['Cust_Signed-Sent_CTC'] == NULL) { ?>
                                            <td></td>
                                        <?php } 
                                    }
                                }
                                else { ?>
                                    <td>
                                        <form action="?page=Tapes" method="post" style="display:inline;">
                                        <input type="hidden" name="edit" value="">
                                                    <input type="hidden" name="IDedit" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                    <input type="hidden" name="btnsearch" value="1">
                                                    <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                    <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                    <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                    <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                    <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                    <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                    <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                    <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                    <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                    <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                    <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                    <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                    <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                    <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                    <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                    <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                    <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                    <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                    <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                    <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                    <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                    <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                    <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                    <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                    <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                    <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                    <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                    <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                    <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                    <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                    <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                    <button type="submit" class="editar">Edit</button>
                                        </form>
                                    </td>
                                    <td>
                                        <form action="?page=Tapes" method="post" style="display:inline;">
                                        <input type="hidden" name="delete" value="">
                                                    <input type="hidden" name="IDdelete" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                    <input type="hidden" name="btnsearch" value="1">
                                                    <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                    <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                    <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                    <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                    <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                    <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                    <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                    <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                    <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                    <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                    <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                    <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                    <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                    <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                    <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                    <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                    <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                    <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                    <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                    <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                    <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                    <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                    <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                    <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                    <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                    <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                    <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                    <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                    <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                    <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                    <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                    <button type="submit" class="eliminar">Delete</button>
                                        </form>
                                    </td>
                                    <td>
                                        <form action="?page=Tapes" method="post" style="display:inline;">
                                        <input type="hidden" name="renewal" value="">
                                                    <input type="hidden" name="IDPPAP" value="<?php echo $log['TAP_PPAP_ID']; ?>">
                                                    <input type="hidden" name="Initial" value="<?php echo $log['Returned_CTC-Sent_Cust']; ?>">
                                                    <input type="hidden" name="btnsearch" value="1">
                                                    <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                                    <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                                    <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                    <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                    <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                    <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                    <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                    <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                    <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                                                    <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                                                    <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                                                    <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                                                    <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                    <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                    <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                    <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                    <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                    <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                                                    <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                                                    <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                                    <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                                    <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                                    <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                                    <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                                                    <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                    <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                    <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                    <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                                                    <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                                    <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                                    <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                                    <button type="submit" class="renewal">Add Renewal</button>
                                        </form>
                                    </td>
                                    <td><?php echo $log['Name']; ?></td>
                                    <td><?php echo $log['OEM']; ?></td>
                                    <td><?php echo $log['Country']; ?></td>
                                    <td><?php echo $log['PPAP_level']; ?></td>
                                    <td><?php echo $log['SAP_Number']; ?></td>
                                    <td><?php echo $log['FK_TAP_Customer_PN']; ?></td>
                                    <td><?php echo $log['Tape']; ?></td>
                                    <td><?php echo $log['Width']; ?></td>
                                    <td><?php echo $log['Length']; ?></td>
                                    <td><?php echo $log['Color']; ?></td>
                                    <td><?php echo $log['IMDS_ID_No']; ?></td>
                                    <?php if($log['Returned_CTC-Sent_Cust'] != NULL) { 
                                        $retCtc = new DateTime($log['Returned_CTC-Sent_Cust']); ?>
                                        <td><?php echo $retCtc->format('m/d/Y') ?></td>
                                    <?php }
                                    if($log['Returned_CTC-Sent_Cust'] == NULL) { ?>
                                        <td></td>
                                    <?php } 
                                    if($log['Cust_Signed-Sent_CTC'] != NULL) { 
                                        $custSign = new DateTime($log['Cust_Signed-Sent_CTC']); ?>
                                        <td><?php echo $custSign->format('m/d/Y') ?></td>
                                    <?php }
                                    if($log['Cust_Signed-Sent_CTC'] == NULL) { ?>
                                        <td></td>
                                    <?php } 
                                }
                            }
                        }
                            
                        if($submit1search != NULL && $submit2search != NULL) {
                            for($i = (int)$submit1search; $i <= (int)$submit2search; $i++) { 
                                $Renewlogs = $model->searchRenew($log['TAP_PPAP_ID'], $i);
                                $NRenewlogs = $model->searchNoRenew($log['TAP_PPAP_ID']);
                                if($Renewlogs == NULL) { 
                                    foreach ($NRenewlogs as $NRenewlog) { 
                                        if($log['TAP_PPAP_ID'] == $NRenewlog['TAP_PPAP_ID']) { ?>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        <?php }
                                    }
                                    foreach ($MaxYear as $MY) { 
                                        $dates = $model->searchDates($MaxYs[0][0], $log['TAP_PPAP_ID']);
                                        foreach ($dates as $date) { 
                                            if($date['Sent_Customer'] != NULL && $date['Returned_Cust_Signed'] != NULL && $log['TAP_PPAP_ID'] == $MY['TAP_PPAP_ID']) { ?>
                                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                            <?php }
                                            if($date['Sent_Customer'] != NULL && $date['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $MY['TAP_PPAP_ID']) { ?>
                                                <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <?php }
                                            if($date['Sent_Customer'] == NULL && $date['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $MY['TAP_PPAP_ID']) {
                                                $rD = new DateTime($date['Renewal_Date']);
                                                $limit = $rD->modify('+7 days'); 
                                                if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                    <td style="color: #FF0000;"></td>
                                                    <td style="color: #FF0000;"></td>
                                                    <td style="color: #FF0000;"></td>
                                                    <td style="color: #FF0000;"></td>
                                                <?php }
                                                if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                <?php }
                                            }
                                        }
                                    }
                                }
                                else {
                                    foreach ($Renewlogs as $Renewlog) { 
                                        foreach ($MaxYear as $MY) { 
                                            foreach ($dates2 as $date) { 
                                                    if($date['Sent_Customer'] != NULL && $date['Returned_Cust_Signed'] != NULL && $log['TAP_PPAP_ID'] == $MY['TAP_PPAP_ID']) {
                                                        if($Renewlog['Renewal_Date'] != NULL) { 
                                                            $renDate = new DateTime($Renewlog['Renewal_Date']); ?>
                                                            <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo  $renDate->format('m/d/Y') ?></td>
                                                        <?php }
                                                        if($Renewlog['Renewal_Date'] == NULL) { ?>
                                                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                        <?php }
                                                        if($Renewlog['Sent_Request_CTC'] != NULL) { 
                                                            $sendReq = new DateTime($Renewlog['Sent_Request_CTC']); ?>
                                                            <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $sendReq->format('m/d/Y') ?></td>
                                                        <?php }
                                                        if($Renewlog['Sent_Request_CTC'] == NULL) { ?>
                                                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                        <?php }
                                                        if($Renewlog['Sent_Customer'] != NULL) { 
                                                            $sentCust = new DateTime($Renewlog['Sent_Customer']); ?>
                                                            <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $sentCust->format('m/d/Y') ?></td>
                                                        <?php }
                                                        if($Renewlog['Sent_Customer'] == NULL) { ?>
                                                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                        <?php }
                                                        if($Renewlog['Returned_Cust_Signed'] != NULL) { 
                                                            $retCust = new DateTime($Renewlog['Returned_Cust_Signed']); ?>
                                                            <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $retCust->format('m/d/Y') ?></td>
                                                        <?php }
                                                        if($Renewlog['Returned_Cust_Signed'] == NULL) { ?>
                                                            <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                        <?php }
                                                    }
                                                    if($date['Renewal_Date'] != NULL && $date['Sent_Customer'] != NULL && $date['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $MY['TAP_PPAP_ID']) {
                                                        if($Renewlog['Renewal_Date'] != NULL) { 
                                                            $rD = new DateTime($date['Renewal_Date']);
                                                            $limit = $rD->modify('+7 days'); 
                                                            $renDate = new DateTime($Renewlog['Renewal_Date']); 
                                                            if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $renDate->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $renDate->format('m/d/Y') ?></td>
                                                            <?php } 
                                                        }
                                                        if($Renewlog['Renewal_Date'] == NULL) { ?>
                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                        <?php }
                                                        if($Renewlog['Sent_Request_CTC'] != NULL) { 
                                                            $sendReq = new DateTime($Renewlog['Sent_Request_CTC']);
                                                            if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $sendReq->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $sendReq->format('m/d/Y') ?></td>
                                                            <?php }
                                                        }
                                                        if($Renewlog['Sent_Request_CTC'] == NULL) { ?>
                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                        <?php }
                                                        if($Renewlog['Sent_Customer'] != NULL) { 
                                                            $sentCust = new DateTime($Renewlog['Sent_Customer']); 
                                                            if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $sentCust->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $sentCust->format('m/d/Y') ?></td>
                                                            <?php } 
                                                        }
                                                        if($Renewlog['Sent_Customer'] == NULL) { ?>
                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                        <?php }
                                                        if($Renewlog['Returned_Cust_Signed'] != NULL) { 
                                                            $retCust = new DateTime($Renewlog['Returned_Cust_Signed']); 
                                                            if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $retCust->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $retCust->format('m/d/Y') ?></td>
                                                            <?php } 
                                                        }
                                                        if($Renewlog['Returned_Cust_Signed'] == NULL) { ?>
                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                        <?php }
                                                    }
                                                    if($date['Renewal_Date'] == NULL && $date['Sent_Customer'] != NULL && $date['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $MY['TAP_PPAP_ID']) { ?>
                                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                        <?php if($Renewlog['Sent_Request_CTC'] != NULL) { 
                                                            $sendReq = new DateTime($Renewlog['Sent_Request_CTC']); ?>
                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $sendReq->format('m/d/Y') ?></td>
                                                        <?php }
                                                        if($Renewlog['Sent_Request_CTC'] == NULL) { ?>
                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                        <?php }
                                                        if($Renewlog['Sent_Customer'] != NULL) { 
                                                            $sentCust = new DateTime($Renewlog['Sent_Customer']); ?>
                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $sentCust->format('m/d/Y') ?></td>
                                                        <?php }
                                                        if($Renewlog['Sent_Customer'] == NULL) { ?>
                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                        <?php }
                                                        if($Renewlog['Returned_Cust_Signed'] != NULL) { 
                                                            $retCust = new DateTime($Renewlog['Returned_Cust_Signed']); ?>
                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $retCust->format('m/d/Y') ?></td>
                                                        <?php }
                                                        if($Renewlog['Returned_Cust_Signed'] == NULL) { ?>
                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                        <?php }
                                                    }
                                                    if($date['Sent_Customer'] == NULL && $date['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $MY['TAP_PPAP_ID']) {
                                                        if($Renewlog['Renewal_Date'] != NULL) { 
                                                            $rD = new DateTime($date['Renewal_Date']);
                                                            $limit = $rD->modify('+7 days'); 
                                                            $renDate = new DateTime($Renewlog['Renewal_Date']);
                                                            if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                <td style="color: #FF0000;"><?php echo  $renDate->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                <td><?php echo  $renDate->format('m/d/Y') ?></td>
                                                            <?php }
                                                        }
                                                        if($Renewlog['Renewal_Date'] == NULL) { ?>
                                                            <td></td>
                                                        <?php }
                                                        if($Renewlog['Sent_Request_CTC'] != NULL) { 
                                                            $sendReq = new DateTime($Renewlog['Sent_Request_CTC']); 
                                                            if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                <td style="color: #FF0000;"><?php echo $sendReq->format('m/d/Y')?></td>
                                                            <?php }
                                                            if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                <td><?php echo $sendReq->format('m/d/Y') ?></td>
                                                            <?php } 
                                                        }
                                                        if($Renewlog['Sent_Request_CTC'] == NULL) { ?>
                                                            <td></td>
                                                        <?php }
                                                        if($Renewlog['Sent_Customer'] != NULL) { 
                                                            $sentCust = new DateTime($Renewlog['Sent_Customer']); 
                                                            if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                <td style="color: #FF0000;"><?php echo $sentCust->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                <td><?php echo $sentCust->format('m/d/Y') ?></td>
                                                            <?php } 
                                                        }
                                                        if($Renewlog['Sent_Customer'] == NULL) { ?>
                                                            <td></td>
                                                        <?php }
                                                        if($Renewlog['Returned_Cust_Signed'] != NULL) { 
                                                            $retCust = new DateTime($Renewlog['Returned_Cust_Signed']); 
                                                            if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                                <td style="color: #FF0000;"><?php echo $retCust->format('m/d/Y') ?></td>
                                                            <?php }
                                                            if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                                <td><?php echo $retCust->format('m/d/Y') ?></td>
                                                            <?php } 
                                                        }
                                                        if($Renewlog['Returned_Cust_Signed'] == NULL) { ?>
                                                            <td></td>
                                                        <?php }
                                                    }
                                            }
                                        }           
                                    }
                                }
                            } 
                        } 
                        else {
                            for($i = $pastyear; $i <= $actualyear; $i++) { 
                                $Renewlogs = $model->searchRenew($log['TAP_PPAP_ID'], $i);
                                $NRenewlogs = $model->searchNoRenew($log['TAP_PPAP_ID']);
                                if($Renewlogs == NULL) { 
                                    foreach ($NRenewlogs as $NRenewlog) { 
                                        if($log['TAP_PPAP_ID'] = $NRenewlog['TAP_PPAP_ID']) { ?>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        <?php }
                                    }
                                    foreach ($MaxYear as $MY) { 
                                        $dates = $model->searchDates($MaxYs[0][0], $log['TAP_PPAP_ID']);
                                        foreach ($dates as $date) { 
                                            if($date['Sent_Customer'] != NULL && $date['Returned_Cust_Signed'] != NULL && $log['TAP_PPAP_ID'] == $MY['TAP_PPAP_ID']) { ?>
                                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                            <?php }
                                            if($date['Sent_Customer'] != NULL && $date['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $MY['TAP_PPAP_ID']) { ?>
                                                <td style="background-color: rgba(206, 0, 34, 0.5);"></td>
                                                <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                            <?php } 
                                            if($date['Sent_Customer'] == NULL && $date['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $MY['TAP_PPAP_ID']) {
                                                $rD = new DateTime($date['Renewal_Date']);
                                                $limit = $rD->modify('+7 days'); 
                                                if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                    <td style="color: #FF0000;"></td>
                                                    <td style="color: #FF0000;"></td>
                                                    <td style="color: #FF0000;"></td>
                                                    <td style="color: #FF0000;"></td>
                                                <?php }
                                                if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                <?php }
                                            }
                                        }
                                    }
                                }
                                else {
                                    foreach ($Renewlogs as $Renewlog) { 
                                        foreach ($MaxYear as $MY) { 
                                            foreach ($dates2 as $date) {
                                                if($date['Sent_Customer'] != NULL && $date['Returned_Cust_Signed'] != NULL && $log['TAP_PPAP_ID'] == $MY['TAP_PPAP_ID']) {
                                                    if($Renewlog['Renewal_Date'] != NULL) { 
                                                        $renDate = new DateTime($Renewlog['Renewal_Date']); ?>
                                                        <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo  $renDate->format('m/d/Y') ?></td>
                                                    <?php }
                                                    if($Renewlog['Renewal_Date'] == NULL) { ?>
                                                        <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                    <?php }
                                                    if($Renewlog['Sent_Request_CTC'] != NULL) { 
                                                        $sendReq = new DateTime($Renewlog['Sent_Request_CTC']); ?>
                                                        <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $sendReq->format('m/d/Y') ?></td>
                                                    <?php }
                                                    if($Renewlog['Sent_Request_CTC'] == NULL) { ?>
                                                        <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                    <?php }
                                                    if($Renewlog['Sent_Customer'] != NULL) { 
                                                        $sentCust = new DateTime($Renewlog['Sent_Customer']); ?>
                                                        <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $sentCust->format('m/d/Y') ?></td>
                                                    <?php }
                                                    if($Renewlog['Sent_Customer'] == NULL) { ?>
                                                        <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                    <?php }
                                                    if($Renewlog['Returned_Cust_Signed'] != NULL) { 
                                                        $retCust = new DateTime($Renewlog['Returned_Cust_Signed']); ?>
                                                        <td style="background-color: rgba(0, 255, 0, 0.5);"><?php echo $retCust->format('m/d/Y') ?></td>
                                                    <?php }
                                                    if($Renewlog['Returned_Cust_Signed'] == NULL) { ?>
                                                        <td style="background-color: rgba(0, 255, 0, 0.5);"></td>
                                                    <?php }
                                                }
                                                if($date['Renewal_Date'] != NULL && $date['Sent_Customer'] != NULL && $date['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $MY['TAP_PPAP_ID']) {
                                                    if($Renewlog['Renewal_Date'] != NULL) { 
                                                        $rD = new DateTime($date['Renewal_Date']);
                                                        $limit = $rD->modify('+7 days'); 
                                                        $renDate = new DateTime($Renewlog['Renewal_Date']); 
                                                        if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $renDate->format('m/d/Y') ?></td>
                                                        <?php }
                                                        if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $renDate->format('m/d/Y') ?></td>
                                                        <?php } 
                                                    }
                                                    if($Renewlog['Renewal_Date'] == NULL) { ?>
                                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                    <?php }
                                                    if($Renewlog['Sent_Request_CTC'] != NULL) { 
                                                        $sendReq = new DateTime($Renewlog['Sent_Request_CTC']);
                                                        if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $sendReq->format('m/d/Y') ?></td>
                                                        <?php }
                                                        if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $sendReq->format('m/d/Y') ?></td>
                                                        <?php }
                                                    }
                                                    if($Renewlog['Sent_Request_CTC'] == NULL) { ?>
                                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                    <?php }
                                                    if($Renewlog['Sent_Customer'] != NULL) { 
                                                        $sentCust = new DateTime($Renewlog['Sent_Customer']); 
                                                        if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $sentCust->format('m/d/Y') ?></td>
                                                        <?php }
                                                        if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $sentCust->format('m/d/Y') ?></td>
                                                        <?php } 
                                                    }
                                                    if($Renewlog['Sent_Customer'] == NULL) { ?>
                                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                    <?php }
                                                    if($Renewlog['Returned_Cust_Signed'] != NULL) { 
                                                        $retCust = new DateTime($Renewlog['Returned_Cust_Signed']); 
                                                        if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                            <td style="background-color: rgba(204, 0, 34, 0.5); color: #a31616ff;"><?php echo  $retCust->format('m/d/Y') ?></td>
                                                        <?php }
                                                        if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                            <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $retCust->format('m/d/Y') ?></td>
                                                        <?php } 
                                                    }
                                                    if($Renewlog['Returned_Cust_Signed'] == NULL) { ?>
                                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                    <?php }
                                                }
                                                if($date['Renewal_Date'] == NULL && $date['Sent_Customer'] != NULL && $date['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $MY['TAP_PPAP_ID']) { ?>
                                                    <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                    <?php if($Renewlog['Sent_Request_CTC'] != NULL) { 
                                                        $sendReq = new DateTime($Renewlog['Sent_Request_CTC']); ?>
                                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $sendReq->format('m/d/Y') ?></td>
                                                    <?php }
                                                    if($Renewlog['Sent_Request_CTC'] == NULL) { ?>
                                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                    <?php }
                                                    if($Renewlog['Sent_Customer'] != NULL) { 
                                                        $sentCust = new DateTime($Renewlog['Sent_Customer']); ?>
                                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo $sentCust->format('m/d/Y') ?></td>
                                                    <?php }
                                                    if($Renewlog['Sent_Customer'] == NULL) { ?>
                                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                    <?php }
                                                    if($Renewlog['Returned_Cust_Signed'] != NULL) { 
                                                        $retCust = new DateTime($Renewlog['Returned_Cust_Signed']); ?>
                                                        <td style="background-color: rgba(204, 0, 34, 0.5);"><?php echo  $retCust->format('m/d/Y') ?></td>
                                                    <?php }
                                                    if($Renewlog['Returned_Cust_Signed'] == NULL) { ?>
                                                        <td style="background-color: rgba(204, 0, 34, 0.5);"></td>
                                                    <?php }
                                                }
                                                if($date['Sent_Customer'] == NULL && $date['Returned_Cust_Signed'] == NULL && $log['TAP_PPAP_ID'] == $MY['TAP_PPAP_ID']) {
                                                    if($Renewlog['Renewal_Date'] != NULL) { 
                                                        $rD = new DateTime($date['Renewal_Date']);
                                                        $limit = $rD->modify('+7 days'); 
                                                        $renDate = new DateTime($Renewlog['Renewal_Date']);
                                                        if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                            <td style="color: #FF0000;"><?php echo  $renDate->format('m/d/Y') ?></td>
                                                        <?php }
                                                        if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                            <td><?php echo  $renDate->format('m/d/Y') ?></td>
                                                        <?php }
                                                    }
                                                    if($Renewlog['Renewal_Date'] == NULL) { ?>
                                                        <td></td>
                                                    <?php }
                                                    if($Renewlog['Sent_Request_CTC'] != NULL) { 
                                                        $sendReq = new DateTime($Renewlog['Sent_Request_CTC']); 
                                                        if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                            <td style="color: #FF0000;"><?php echo $sendReq->format('m/d/Y')?></td>
                                                        <?php }
                                                        if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                            <td><?php echo $sendReq->format('m/d/Y') ?></td>
                                                        <?php } 
                                                    }
                                                    if($Renewlog['Sent_Request_CTC'] == NULL) { ?>
                                                        <td></td>
                                                    <?php }
                                                    if($Renewlog['Sent_Customer'] != NULL) { 
                                                        $sentCust = new DateTime($Renewlog['Sent_Customer']); 
                                                        if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                            <td style="color: #FF0000;"><?php echo $sentCust->format('m/d/Y') ?></td>
                                                        <?php }
                                                        if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                            <td><?php echo $sentCust->format('m/d/Y') ?></td>
                                                        <?php } 
                                                    }
                                                    if($Renewlog['Sent_Customer'] == NULL) { ?>
                                                        <td></td>
                                                    <?php }
                                                    if($Renewlog['Returned_Cust_Signed'] != NULL) { 
                                                        $retCust = new DateTime($Renewlog['Returned_Cust_Signed']); 
                                                        if(date("Y-m-d") > $limit->format('Y-m-d')) { ?>
                                                            <td style="color: #FF0000;"><?php echo $retCust->format('m/d/Y') ?></td>
                                                        <?php }
                                                        if(date("Y-m-d") <= $limit->format('Y-m-d')) { ?>
                                                            <td><?php echo $retCust->format('m/d/Y') ?></td>
                                                        <?php } 
                                                    }
                                                    if($Renewlog['Returned_Cust_Signed'] == NULL) { ?>
                                                        <td></td>
                                                    <?php }
                                                }
                                            }
                                        }           
                                    }
                                }
                            } 
                        } ?> 
                        <td><?php echo $log['PPAP_from_shipments']; ?></td>
                        <td><?php echo $log['Comments']; ?></td>
                    </tr> 
            <?php } ?>
        </table> 
    </div>
<?php } 

if (isset($_POST['insertD'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New PPAP</h2>
    <form action="?page=Tapes" method="post">
        <input type="hidden" name="confirmID" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
        <label>Description:</label>
        <div class="camp">
            <input style="width: 22%;" maxlength="25" type="text" placeholder="Tape" name="Tape" list="Tape" required> -
            <input style="width: 22%;" maxlength="8" type="text" placeholder="Width" name="Width" list="Width" required> -
            <input style="width: 22%;" maxlength="8" type="text" placeholder="Length" name="Length" list="Length" required> -
            <input style="width: 22%;" maxlength="8" type="text" placeholder="Color" name="Color" list="Color" required>
        </div> <br>
        
        <label>Customer:</label>
        <input type="text" maxlength="70" name="Name" list="Customer" required> <br>

        <label>OEM:</label>
        <input type="text" maxlength="255" name="OEM" list="OEM"> <br>

        <label>Country:</label>
        <input type="text" maxlength="30" name="Country" list="Country"> <br>

        <label>PPAP Level:</label>
        <select name="PPAP_level">
            <option value=""></option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
        </select> <br>

        <label>IMDS:</label>
        <input type="text" maxlength="8" name="IMDS" list="IMDS"> <br>

        <label style="font-size: 20px;">INITIAL</label>
        <label>Returned from CTC / Sent to Customer:</label>
        <input type="date" name="Returned_CTC-Sent_Cust"> <br>

        <label>PSW returned from Customer signed / Sent to CTC:</label>
        <input type="date" name="Cust_Signed-Sent_CTC"> <br>

        <label>PPAP from shipments:</label required>
        <div>
            <input type="radio" name="PPAP_from_shipments" value="no" checked> No 
        </div>
        <div>
            <input type="radio" name="PPAP_from_shipments" value="*"> Yes 
        </div> <br>

        <label>Comments:</label>
        <textarea name="Comments" maxlength="255"></textarea>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if ($descError != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Error</h2>
        <form action="?page=Tapes" method="post">
            <h6><b>The description "<?php echo $_POST['Tape']?>-<?php echo $_POST['Width']?>-<?php echo $_POST['Length']?>-<?php echo $_POST['Color']?>" doesn't exist.</b></h6>
        </form>
    </div>
    </div>
<?php } 

if ($custError != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Error</h2>
        <form action="?page=Tapes" method="post">
            <h6><b>The customer's name "<?php echo $_POST['Name']; ?>" doesn't exist.</b></h6>
        </form>
    </div>
    </div>
<?php } 

if ($dcError != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Error</h2>
        <form action="?page=Tapes" method="post">
            <h6><b>The description "<?php echo $_POST['Tape']?>-<?php echo $_POST['Width']?>-<?php echo $_POST['Length']?>-<?php echo $_POST['Color']?>" and the customer's name "<?php echo $_POST['Name']; ?>" don't exist.</b></h6>
        </form>
    </div>
    </div>
<?php } 

if ($NocpnError != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Error</h2>
        <form action="?page=Tapes" method="post">
            <h6><b>Customer's PN doesn't exist.</b></h6>
        </form>
    </div>
    </div>
<?php } 

if (isset($_POST['insertET'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New PPAP</h2>
    <form action="?page=Tapes" method="post">
        <input type="hidden" name="confirmIE" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
        <label>Eurotech PN:</label>
        <input type="text" maxlength="12" name="TAP_Eurotech_PN" list="ETPN" required>
        <datalist id="ETPN">
            <?php foreach ($ETPNS as $ETPN) {  ?>
                <option value="<?php echo $ETPN['TAP_Eurotech_PN'] ?>">
            <?php } ?>
        </datalist> <br>
        
        <label>Customer:</label>
        <input type="text" maxlength="70" name="Name" list="Customer" required> <br>

        <label>OEM:</label>
        <input type="text" maxlength="255" name="OEM" list="OEM"> <br>

        <label>Country:</label>
        <input type="text" maxlength="30" name="Country" list="Country"> <br>

        <label>PPAP Level:</label>
        <select name="PPAP_level" >
            <option value=""></option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
        </select> <br>

        <label>IMDS:</label>
        <input type="text" maxlength="8" name="IMDS" list="IMDS"> <br>

        <label style="font-size: 20px;">INITIAL</label>
        <label>Returned from CTC / Sent to Customer:</label>
        <input type="date" name="Returned_CTC-Sent_Cust"> <br>

        <label>PSW returned from Customer signed / Sent to CTC:</label>
        <input type="date" name="Cust_Signed-Sent_CTC"> <br>

        <label>PPAP from shipments:</label required>
        <div>
            <input type="radio" name="PPAP_from_shipments" value="no" checked> No 
        </div>
        <div>
            <input type="radio" name="PPAP_from_shipments" value="*"> Yes 
        </div> <br>

        <label>Comments:</label>
        <textarea name="Comments" maxlength="255"></textarea>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if ($ecError != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Error</h2>
        <form action="?page=Tapes" method="post">
            <h6><b>The Eurotech PN "<?php echo $_POST['TAP_Eurotech_PN']; ?>" and the customer's name "<?php echo $_POST['Name']; ?>" don't exist.</b></h6>
        </form>
    </div>
    </div>
<?php } 

if ($etpnError != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Error</h2>
        <form action="?page=Tapes" method="post">
            <h6><b>The Eurotech PN "<?php echo $_POST['TAP_Eurotech_PN']; ?>" doesn't exist.</b></h6>
        </form>
    </div>
    </div>
<?php } 

if (isset($_POST['insertC'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New PPAP</h2>
    <form action="?page=Tapes" method="post">
        <input type="hidden" name="confirmIC" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
        <label>Customer PN:</label>
        <input type="text" maxlength="20" name="TAP_Customer_PN" list="CPN" required> <br>

        <label>OEM:</label>
        <input type="text" maxlength="255" name="OEM" list="OEM"> <br>

        <label>Country:</label>
        <input type="text" maxlength="30" name="Country" list="Country"> <br>

        <label>PPAP Level:</label>
        <select name="PPAP_level" >
            <option value=""></option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
        </select> <br>

        <label>IMDS:</label>
        <input type="text" maxlength="8" name="IMDS" list="IMDS"> <br>

        <label style="font-size: 20px;">INITIAL</label>
        <label>Returned from CTC / Sent to Customer:</label>
        <input type="date" name="Returned_CTC-Sent_Cust"> <br>

        <label>PSW returned from Customer signed / Sent to CTC:</label>
        <input type="date" name="Cust_Signed-Sent_CTC"> <br>

        <label>PPAP from shipments:</label required>
        <div>
            <input type="radio" name="PPAP_from_shipments" value="no" checked> No 
        </div>
        <div>
            <input type="radio" name="PPAP_from_shipments" value="*"> Yes 
        </div> <br>

        <label>Comments:</label>
        <textarea name="Comments" maxlength="255"></textarea>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if ($cpnError != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Error</h2>
        <form action="?page=Tapes" method="post">
            <h6><b>The customer's PN "<?php echo $_POST['TAP_Customer_PN']; ?>" doesn't exist.</b></h6>
        </form>
    </div>
    </div>
<?php } 

if (isset($_POST['edit'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Update PPAP</h2>
    <form action="?page=Tapes" method="post">
        <input type="hidden" name="confirmU" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
        <input type="hidden" name="TAP_PPAP_ID" value="<?php echo $tapeData['TAP_PPAP_ID']; ?>"> <br>
        <label>OEM:</label>
        <input type="text" name="OEM" maxlength="255" list="OEM" value="<?php echo $tapeData['OEM']; ?>"> <br>

        <label>Country:</label>
        <input type="text" name="Country" maxlength="30" list="Country" value="<?php echo $tapeData['Country']; ?>"> <br>

        <label>PPAP Level:</label>
        <select name="PPAP_level" >
            <option value=""></option>
            <option value="1" <?php if($tapeData['PPAP_level'] == '1') { echo 'selected'; } ?>>1</option>
            <option value="2" <?php if($tapeData['PPAP_level'] == '2') { echo 'selected'; } ?>>2</option>
            <option value="3" <?php if($tapeData['PPAP_level'] == '3') { echo 'selected'; } ?>>3</option>
            <option value="4" <?php if($tapeData['PPAP_level'] == '4') { echo 'selected'; } ?>>4</option>
            <option value="5" <?php if($tapeData['PPAP_level'] == '5') { echo 'selected'; } ?>>5</option>
        </select> <br>

        <label>IMDS:</label>
        <input type="text" name="IMDS" maxlength="8" list="IMDS" value="<?php echo $tapeData['IMDS_ID_No']; ?>"> <br>

        <label style="font-size: 20px;">INITIAL</label>
        <label>Returned from CTC / Sent to Customer:</label>
        <input type="date" name="Returned_CTC-Sent_Cust" value="<?php echo $tapeData['Returned_CTC-Sent_Cust']; ?>"> <br>

        <label>PSW returned from Customer signed / Sent to CTC:</label>
        <input type="date" name="Cust_Signed-Sent_CTC" value="<?php echo $tapeData['Cust_Signed-Sent_CTC']; ?>"> <br>

        <?php for($j = 0; $j < count($tapeRenewData); $j++) { ?>
            <?php if($tapeRenewData[$j] != NULL) { 
                if($tapeRenewData[$j][0]['Renewal_Date'] != NULL) {
                    $rD = new DateTime($tapeRenewData[$j][0]['Renewal_Date']);
                    $y = $rD->format('Y'); 
                }
                else {
                    if($tapeRenewData[$j][0]['Sent_Customer'] != NULL) {
                        $scD = new DateTime($tapeRenewData[$j][0]['Sent_Customer']);
                        $y = $scD->format('Y'); 
                    }
                    else {
                        if($tapeRenewData[$j][0]['Returned_Cust_Signed'] != NULL) {
                            $rcsD = new DateTime($tapeRenewData[$j][0]['Returned_Cust_Signed']);
                            $y = $rcsD->format('Y'); 
                        }
                    }
                } ?>
                <label style="font-size: 20px;"><?php echo $y; ?></label>
                <input type="hidden" name="<?php echo 'TAP_Renewal_ID'.$y?>" value="<?php if($tapeRenewData[$j] != NULL) { echo $tapeRenewData[$j][0]['TAP_Renewal_ID']; } ?>"> <br>
                <label>Renewal Date:</label>
                <input type="date" name="<?php echo 'Renewal_Date'.$y?>" value="<?php echo $tapeRenewData[$j][0]['Renewal_Date']; ?>"> <br>

                <label>When to send Request to CTC:</label>
                <input type="date" name="<?php echo 'Sent_Request_CTC'.$y?>" value="<?php echo $tapeRenewData[$j][0]['Sent_Request_CTC']; ?>"> <br>

                <label>Sent to Customer:</label>
                <input type="date" name="<?php echo 'Sent_Customer'.$y?>" value="<?php echo $tapeRenewData[$j][0]['Sent_Customer']; ?>"> <br>

                <label>PSW returned from Customer signed:</label>
                <input type="date" name="<?php echo 'Returned_Cust_Signed'.$y?>" value="<?php echo $tapeRenewData[$j][0]['Returned_Cust_Signed']; ?>">
                <hr>
            <?php }
        } ?>

        <label>PPAP from shipments:</label required>
        <div>
            <input type="radio" name="PPAP_from_shipments" value="no" checked> No 
        </div>
        <div>
            <input type="radio" name="PPAP_from_shipments" value="*" <?php if($tapeData['PPAP_from_shipments'] == '*') { echo 'checked'; } ?>> Yes 
        </div> <br>

        <label>Comments:</label>
        <textarea name="Comments" maxlength="255"><?php echo $tapeData['Comments']; ?></textarea>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if ($NoDatesError != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Error</h2>
        <form action="?page=Tapes" method="post">
            <h6><b>There are dates missing.</b></h6>
        </form>
    </div>
    </div>
<?php } 

if (isset($_POST['delete'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Delete PPAP</h2>
    <form action="?page=Tapes" method="post">
        <input type="hidden" name="confirmD" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
        <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
        <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
        <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
        <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
        <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
        <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
        <input type="hidden" name="IDdelete" value="<?php echo $tapeDataD['TAP_PPAP_ID']; ?>"> <br>
        <h5>Are you sure you want to delete the data of this PPAP?</h5> <br>
        <?php 
            if($tapeDataD['Returned_CTC-Sent_Cust'] != NULL) {
                $retD = new DateTime($tapeDataD['Returned_CTC-Sent_Cust']);
            }
            if($tapeDataD['Cust_Signed-Sent_CTC'] != NULL) {
                $sigD = new DateTime($tapeDataD['Cust_Signed-Sent_CTC']);
            }
        ?>
        <h6><b>Customer:</b> <?php echo $tapeDataD['Name']; ?></h6>
        <h6><b>OEM:</b> <?php echo $tapeDataD['OEM']; ?></h6>
        <h6><b>Country:</b> <?php echo $tapeDataD['Country']; ?></h6>
        <h6><b>PPAP Level:</b> <?php echo $tapeDataD['PPAP_level']; ?></h6>
        <h6><b>SAP No.:</b> <?php echo $tapeDataD['SAP_Number']; ?></h6>
        <h6><b>Customer PN:</b> <?php echo $tapeDataD['FK_TAP_Customer_PN']; ?></h6>
        <h6><b>Tape:</b> <?php echo $tapeDataD['Tape']; ?></h6>
        <h6><b>Width (MM):</b> <?php echo $tapeDataD['Width']; ?></h6>
        <h6><b>Length (M):</b> <?php echo $tapeDataD['Length']; ?></h6>
        <h6><b>Color:</b> <?php echo $tapeDataD['Color']; ?></h6>
        <h6><b>IMDS ID no.:</b> <?php echo $tapeDataD['IMDS_ID_No']; ?></h6>
        <hr>
        <h6><b>INITIAL</b></h6>
        <h6><b>Returned from CTC / Sent to Customer:</b> <?php if($tapeDataD['Returned_CTC-Sent_Cust'] != NULL) { echo $retD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
        <h6><b>PSW returned from Customer signed / Sent to CTC:</b> <?php if($tapeDataD['Cust_Signed-Sent_CTC'] != NULL) { echo $sigD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
        <hr>
        <?php if($submit1search != NULL && $submit2search != NULL) {
            $year = (int)$submit1search;
        }    
        else {
            $year = (int)$pastyear; 
        } 

        for($j = 0; $j < count($tapeRenewDataD); $j++) { 
            if($tapeRenewDataD[$j] != NULL) {
                if($tapeRenewDataD[$j][0]['Renewal_Date'] != NULL) {
                    $renD = new DateTime($tapeRenewDataD[$j][0]['Renewal_Date']);
                }
                if($tapeRenewDataD[$j][0]['Sent_Request_CTC'] != NULL) {
                    $serD = new DateTime($tapeRenewDataD[$j][0]['Sent_Request_CTC']);
                }
                if($tapeRenewDataD[$j][0]['Sent_Customer'] != NULL) {
                    $secD = new DateTime($tapeRenewDataD[$j][0]['Sent_Customer']);
                }
                if($tapeRenewDataD[$j][0]['Returned_Cust_Signed'] != NULL) {
                    $resD = new DateTime($tapeRenewDataD[$j][0]['Returned_Cust_Signed']);
                }
             ?>
            <h6><b><?php echo $year; ?></b></h6>
            <h6><b>Renewal Date:</b> <?php if($tapeRenewDataD[$j][0]['Renewal_Date'] != NULL) { echo $renD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
            <h6><b>When to send Request to CTC:</b> <?php if($tapeRenewDataD[$j][0]['Sent_Request_CTC'] != NULL) { echo $serD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
            <h6><b>Sent to Customer:</b> <?php if($tapeRenewDataD[$j][0]['Sent_Customer'] != NULL) { echo $secD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
            <h6><b>PSW returned from Customer signed:</b> <?php if($tapeRenewDataD[$j][0]['Returned_Cust_Signed'] != NULL) { echo $resD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
            <hr>
            <?php }
            $year += 1;  
        } ?>

        <h6><b>PPAP from shipment:</b> <?php if($tapeDataD['PPAP_from_shipments'] == '*'){ echo 'Yes'; } else{ echo 'No'; } ?></h6>
        <h6><b>Comments:</b> <?php echo $tapeDataD['Comments']; ?></h6>
        <button type="submit">Confirm</button>
    </form>
  </div>
</div>
<?php }

if (isset($_POST['renewal'])) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
        <div class="modal-contenido">
            <span class="cerrar" onclick="closeForm()">&times;</span>
            <h2>New Renewal</h2>
            <form action="?page=Tapes" method="post">
                <input type="hidden" name="confirmIR" value="1">
                <input type="hidden" name="btnsearch" value="1">
                <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                <input type="hidden" name="tapesearch" value="<?php if(isset($_POST['tapesearch'])) { echo $_POST['tapesearch']; } ?>">
                <input type="hidden" name="widthsearch" value="<?php if(isset($_POST['widthsearch'])) { echo $_POST['widthsearch']; } ?>">
                <input type="hidden" name="lengthsearch" value="<?php if(isset($_POST['lengthsearch'])) { echo $_POST['lengthsearch']; } ?>">
                <input type="hidden" name="colorsearch" value="<?php if(isset($_POST['colorsearch'])) { echo $_POST['colorsearch']; } ?>">
                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                <input type="hidden" name="ren1search" value="<?php if(isset($_POST['ren1search'])) { echo $_POST['ren1search']; } ?>">
                <input type="hidden" name="ren2search" value="<?php if(isset($_POST['ren2search'])) { echo $_POST['ren2search']; } ?>">
                <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                <input type="hidden" name="shipsearch" value="<?php if(isset($_POST['shipsearch'])) { echo $_POST['shipsearch']; } ?>">
                <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                <input type="hidden" name="renn" value="<?php if(isset($_POST['renn'])) { echo $_POST['renn']; } ?>">
                <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                <input type="hidden" name="FK_TAP_PPAP_ID" value="<?php echo $_POST['IDPPAP']; ?>"> <br>
                <label>Renewal Date:</label>
                <input type="date" name="Renewal_Date" value="<?php if($renewal_date != NULL) { echo $renewal_date->format('Y-m-d'); } ?>" required> <br>

                <label>When to send Request to CTC:</label>
                <input type="date" name="Sent_Request_CTC" value="<?php if($sent_cust_date != NULL) { echo $sent_cust_date->format('Y-m-d'); } ?>"> <br>

                <label>Sent to Customer:</label>
                <input type="date" name="Sent_Customer"> <br>

                <label>PSW returned from Customer signed:</label>
                <input type="date" name="Returned_Cust_Signed">

                <button type="submit">Save</button>
            </form>
        </div>
    </div>
<?php } ?>

<script>
    function closeForm() {
        document.getElementById('formularioModal').style.display = 'none';
    }

    function sendForm() {
        closeForm();
        return true;
    }

    function clearForm() {
        document.querySelectorAll("#form input[type='text']").forEach(input => input.value = "");
        // document.querySelectorAll("#form input[type='number']").forEach(input => input.value = "");
        document.querySelectorAll("#form input[type='date']").forEach(input => input.value = "");

        const radioButtons = document.querySelectorAll("#form input[type='radio']");
        const defaultValue = '';

        for (const radio of radioButtons) {
            if (radio.value === defaultValue) {
                radio.checked = true;
            }
        }

        const selects = document.querySelectorAll("#form select");

        for (const select of selects) {
            select.value = defaultValue;
        }
    }
</script>