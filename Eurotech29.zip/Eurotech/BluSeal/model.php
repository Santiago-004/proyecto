<?php
    class model {                                        

        public  $mbd;
        
        function cn() {
            $this->mbd = new PDO('mysql:host=localhost;dbname=eurotechdb;port=3306', 'root', '');
            $this->mbd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
        }

        function search(){
            $logs = [];
            if (isset($_POST['btnsearch'])) {
                if (!empty($_POST['days1search']) && !empty($_POST['days2search'])
                    || !empty($_POST['ppapnsearch'])
                    || (!empty($_POST['date1search']) && !empty($_POST['date2search']))
                    || isset($_POST['req1n'])
                    || (!empty($_POST['reqv1search']) && !empty($_POST['reqv2search']))
                    || isset($_POST['reqvn']) 
                    || !empty($_POST['currentsearch'])
                    || isset($_POST['curn'])
                    || !empty($_POST['pisearch']) 
                    || !empty($_POST['sapsearch'])
                    || !empty($_POST['oemsearch'])                    
                    || !empty($_POST['custsearch']) 
                    || isset($_POST['cusn']) 
                    || !empty($_POST['counsearch'])
                    || !empty($_POST['cpnsearch']) 
                    || !empty($_POST['etmsearch'])
                    || !empty($_POST['etdsearch'])
                    || !empty($_POST['revsearch'])
                    || !empty($_POST['etpnsearch']) 
                    || !empty($_POST['descsearch']) 
                    || !empty($_POST['imdssearch']) 
                    || isset($_POST['imdn'])
                    || !empty($_POST['levelearch']) 
                    || isset($_POST['lvln']) 
                    || !empty($_POST['psssearch']) 
                    || isset($_POST['pssn']) 
                    || !empty($_POST['rssearch']) 
                    || isset($_POST['rosn'])
                    || (!empty($_POST['date3search']) && !empty($_POST['date4search']))
                    || isset($_POST['recn']) 
                    || (!empty($_POST['ret1search']) && !empty($_POST['ret2search']))
                    || isset($_POST['retn'])
                    || (!empty($_POST['psw1search']) && !empty($_POST['psw2search']))
                    || isset($_POST['pscn'])
                    || isset($_POST['pfsn']) 
                    || isset($_POST['originsearch']) 
                    || isset($_POST['comsearch']) 
                    || isset($_POST['irnsearch'])
                ) {
                    $having = [];
                    $params = [];
                    $products = [];
                    
                    if(!empty($_POST['days1search']) && !empty($_POST['days2search'])) {
                        $having[] = "`Days to Submit` BETWEEN :day1 AND :day2";
                        $params[':day1'] = $_POST['days1search'];
                        $params[':day2'] = $_POST['days2search'];
                    }
                    
                    if(!empty($_POST['ppapnsearch'])) {
                        $having[] = "PPAP_Number LIKE :pn";
                        $params[':pn'] = $_POST['ppapnsearch']."%";
                    }

                    if($_POST['req1n'] == '' && !empty($_POST['date1search']) && !empty($_POST['date2search'])) {
                        $having[] = "PPAP_Request_Date BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['date1search'];
                        $params[':date2'] = $_POST['date2search'];
                    }
                    if(!empty($_POST['req1n']) && $_POST['req1n'] == 'N') {
                        $having[] = "PPAP_Request_Date IS NULL";
                    }
                    if(!empty($_POST['req1n']) && $_POST['req1n'] == 'Y') {
                        $having[] = "PPAP_Request_Date IS NOT NULL";
                    }

                    if($_POST['reqvn'] == '' && !empty($_POST['reqv1search']) && !empty($_POST['reqv2search'])) {
                        $having[] = "PPAP_Requested_Vendor BETWEEN :rv1 AND :rv2";
                        $params[':rv1'] = $_POST['reqv1search'];
                        $params[':rv2'] = $_POST['reqv2search'];
                    }
                    if(!empty($_POST['reqvn']) && $_POST['reqvn'] == 'N') {
                        $having[] = "PPAP_Requested_Vendor IS NULL";
                    }
                    if(!empty($_POST['reqvn']) && $_POST['reqvn'] == 'Y') {
                        $having[] = "PPAP_Requested_Vendor IS NOT NULL";
                    }

                    if($_POST['curn'] == '' && !empty($_POST['currentsearch'])) {
                        $having[] = "Current_Status LIKE :cs";
                        $params[':cs'] = $_POST['currentsearch']."%";
                    }
                    if(!empty($_POST['curn']) && $_POST['curn'] == 'N') {
                        $having[] = "Current_Status IS NULL";
                    }
                    if(!empty($_POST['curn']) && $_POST['curn'] == 'Y') {
                        $having[] = "Current_Status IS NOT NULL";
                    }

                    if (!empty($_POST['pisearch'])) {
                        $having[] = "Short_name = :sup";
                        $params[':sup'] = $_POST['pisearch'];
                    }

                    if (!empty($_POST['sapsearch'])) {
                        $having[] = "Supplier_PN = :spn";
                        $params[':spn'] = $_POST['sapsearch'];
                    }

                    if(!empty($_POST['oemsearch'])) {
                        $having[] = "OEM = :oem";
                        $params[':oem'] = $_POST['oemsearch'];
                    }

                    if($_POST['cusn'] == '' && !empty($_POST['custsearch'])) {
                        $having[] = "Customer = :cs";
                        $params[':cs'] = $_POST['custsearch'];
                    }
                    if(!empty($_POST['cusn']) && $_POST['cusn'] == 'N') {
                        $having[] = "Customer IS NULL";
                    }
                    if(!empty($_POST['cusn']) && $_POST['cusn'] == 'Y') {
                        $having[] = "Customer IS NOT NULL";
                    }

                    if(!empty($_POST['counsearch'])) {
                        $having[] = "Country = :cs";
                        $params[':cs'] = $_POST['counsearch'];
                    }

                    if (!empty($_POST['cpnsearch'])) {
                        $having[] = "Customer_PN = :cpn";
                        $params[':cpn'] = $_POST['cpnsearch'];
                    }

                    if(!empty($_POST['etmsearch'])) {
                        $having[] = "ET_Model = :mod";
                        $params[':mod'] = $_POST['etmsearch'];
                    }

                    if(!empty($_POST['etdsearch'])) {
                        $having[] = "ET_Dwg = :dwg";
                        $params[':dwg'] = $_POST['etdsearch'];
                    }
                    
                    if(!empty($_POST['revsearch'])) {
                        $having[] = "Rev = :rev";
                        $params[':rev'] = $_POST['revsearch'];
                    }

                    if (!empty($_POST['etpnsearch'])) {
                        $having[] = "Eurotech_PN = :etpn";
                        $params[':etpn'] = $_POST['etpnsearch'];
                    }

                    if (!empty($_POST['descsearch'])) {
                        $having[] = "`Description` LIKE :desc";
                        $params[':desc'] = "%".$_POST['descsearch']."%";
                    }

                    if($_POST['imdn'] == '' && !empty($_POST['imdssearch'])) {
                        $having[] = "(IMDS = :imds || IMDS_ID_no = :imds)";
                        $params[':imds'] = $_POST['imdssearch'];
                    }
                    if(!empty($_POST['imdn']) && $_POST['imdn'] == 'N') {
                        $having[] = "(IMDS IS NULL AND Product = 'Tube') OR (IMDS_ID_no IS NULL AND Product = 'Tape') OR (Product != 'Tape' AND Product != 'Tube' AND IMDS IS NULL)";
                    }
                    if(!empty($_POST['imdn']) && $_POST['imdn'] == 'Y') {
                        $having[] = "(IMDS IS NOT NULL OR IMDS_ID_no IS NOT NULL) AND (Product = 'Tape' OR Product = 'Tube')";
                    }

                    if($_POST['lvln'] == '' && !empty($_POST['levelsearch'])) {
                        $having[] = "PPAP_Level = :lvl";
                        $params[':lvl'] = $_POST['levelsearch'];
                    }
                    if(!empty($_POST['lvln']) && $_POST['lvln'] == 'N') {
                        $having[] = "PPAP_Level IS NULL";
                    }
                    if(!empty($_POST['lvln']) && $_POST['lvln'] == 'Y') {
                        $having[] = "PPAP_Level IS NOT NULL";
                    }

                    if($_POST['pssn'] == '' && !empty($_POST['psssearch'])) {
                        $having[] = "Samples_Status = :pss";
                        $params[':pss'] = $_POST['psssearch'];
                    }
                    if(!empty($_POST['pssn']) && $_POST['pssn'] == 'N') {
                        $having[] = "Samples_Status IS NULL";
                    }
                    if(!empty($_POST['pssn']) && $_POST['pssn'] == 'Y') {
                        $having[] = "Samples_Status IS NOT NULL";
                    }

                    if($_POST['rosn'] == '' && !empty($_POST['rssearch'])) {
                        $having[] = "Reason_Submission = :rs";
                        $params[':rs'] = $_POST['rssearch'];
                    }
                    if(!empty($_POST['rosn']) && $_POST['rosn'] == 'N') {
                        $having[] = "Reason_Submission IS NULL";
                    }
                    if(!empty($_POST['rosn']) && $_POST['rosn'] == 'Y') {
                        $having[] = "Reason_Submission IS NOT NULL";
                    }

                    if($_POST['recn'] == '' && !empty($_POST['date3search']) && !empty($_POST['date4search'])) {
                        $having[] = "PPAP_Received_Date BETWEEN :rec1 AND :rec2";
                        $params[':rec1'] = $_POST['date3search'];
                        $params[':rec2'] = $_POST['date4search'];
                    }
                    if(!empty($_POST['recn']) && $_POST['recn'] == 'N') {
                        $having[] = "PPAP_Received_Date IS NULL";
                    }
                    if(!empty($_POST['recn']) && $_POST['recn'] == 'Y') {
                        $having[] = "PPAP_Received_Date IS NOT NULL";
                    }

                    if($_POST['retn'] == '' && !empty($_POST['ret1search']) && !empty($_POST['ret2search'])) {
                        $having[] = "PPAP_Sent_Customer BETWEEN :ret1 AND :ret2";
                        $params[':ret1'] = $_POST['ret1search'];
                        $params[':ret2'] = $_POST['ret2search'];
                    }
                    if(!empty($_POST['retn']) && $_POST['retn'] == 'N') {
                        $having[] = "PPAP_Sent_Customer IS NULL";
                    }
                    if(!empty($_POST['retn']) && $_POST['retn'] == 'Y') {
                        $having[] = "PPAP_Sent_Customer IS NOT NULL";
                    }

                    if($_POST['pscn'] == '' && !empty($_POST['psw1search']) && !empty($_POST['psw2search'])) {
                        $having[] = "PPAP_Signed_Date BETWEEN :psw1 AND :psw2";
                        $params[':psw1'] = $_POST['psw1search'];
                        $params[':psw2'] = $_POST['psw2search'];
                    }
                    if(!empty($_POST['pscn']) && $_POST['pscn'] == 'N') {
                        $having[] = "PPAP_Signed_Date IS NULL";
                    }
                    if(!empty($_POST['pscn']) && $_POST['pscn'] == 'Y') {
                        $having[] = "PPAP_Signed_Date IS NOT NULL";
                    }

                    if($_POST['pfsn'] == "N") {
                        $having[] = "PPAP_From_Shipments IS NULL";
                    }
                    if($_POST['pfsn'] == "Y") {
                        $having[] = "PPAP_From_Shipments IS NOT NULL";
                    }

                    if(!empty($_POST['comsearch'])) {
                        $having[] = "Comments = :com";
                        $params[':com'] = $_POST['comsearch'];
                    }

                    if(!empty($_POST['irnsearch'])) {
                        $having[] = "Inspection_Rep_Number = :irn";
                        $params[':irn'] = $_POST['irnsearch'];
                    }

                    if(!empty($having)) {
                        $sql = "SELECT 
                                    if(PPAP_Sent_Customer IS NULL, datediff(NOW(), PPAP_Request_Date), datediff(PPAP_Sent_Customer, PPAP_Request_Date)) AS 'Days to Submit',
                                    ppap.*,
                                    cp.Customer_PN,
                                    p.*,
                                    c.`Name` AS 'Customer',
                                    c.IMDS_ID_no,
                                    v.`Name` AS 'Vendor',
                                    v.Short_name,
                                    cpn.*
                                FROM products p
                                    LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
                                    LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                                    INNER JOIN ppap ON cp.Customer_PN = ppap.FK_Customer_PN
                                    LEFT JOIN vendors v ON ppap.FK_Vendor_ID = v.Vendor_ID
                                    LEFT JOIN customer_ppap_number cpn ON cpn.FK_Customer_ID = c.Customer_ID
                                HAVING " . implode(' AND ', $having) . " AND Product = 'BluSeal'
                                ORDER BY Eurotech_PN;";
                    }
                    else {
                        $sql = "SELECT 
                                    if(PPAP_Sent_Customer IS NULL, datediff(NOW(), PPAP_Request_Date), datediff(PPAP_Sent_Customer, PPAP_Request_Date)) AS 'Days to Submit',
                                    ppap.*,
                                    cp.Customer_PN,
                                    p.*,
                                    c.`Name` AS 'Customer',
                                    c.IMDS_ID_no,
                                    v.`Name` AS 'Vendor',
                                    v.Short_name,
                                    cpn.*
                                FROM products p
                                    LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
                                    LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                                    INNER JOIN ppap ON cp.Customer_PN = ppap.FK_Customer_PN
                                    LEFT JOIN vendors v ON ppap.FK_Vendor_ID = v.Vendor_ID
                                    LEFT JOIN customer_ppap_number cpn ON cpn.FK_Customer_ID = c.Customer_ID
                                WHERE Product = 'BluSeal'
                                ORDER BY Eurotech_PN;";
                    }

                    $stmt = $this->mbd->prepare($sql);
                    $stmt->execute($params);

                    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
                else {
                    foreach ($this->mbd->query(
                        "SELECT 
                            if(PPAP_Sent_Customer IS NULL, datediff(NOW(), PPAP_Request_Date), datediff(PPAP_Sent_Customer, PPAP_Request_Date)) AS 'Days to Submit',
                            ppap.*,
                            cp.Customer_PN,
                            p.*,
                            c.`Name` AS 'Customer',
                            c.IMDS_ID_no,
                            v.`Name` AS 'Vendor',
                            v.Short_name,
                            cpn.*
                        FROM products p
                            LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                            INNER JOIN ppap ON cp.Customer_PN = ppap.FK_Customer_PN
                            LEFT JOIN vendors v ON ppap.FK_Vendor_ID = v.Vendor_ID
                            LEFT JOIN customer_ppap_number cpn ON cpn.FK_Customer_ID = c.Customer_ID
                        WHERE Product = 'BluSeal'
                        ORDER BY Eurotech_PN;"
                    ) as $log) {
                        $logs[] = $log;
                    }
                }
            } else {
                foreach ($this->mbd->query(
                    "SELECT 
                            if(PPAP_Sent_Customer IS NULL, datediff(NOW(), PPAP_Request_Date), datediff(PPAP_Sent_Customer, PPAP_Request_Date)) AS 'Days to Submit',
                            ppap.*,
                            cp.Customer_PN,
                            p.*,
                            c.`Name` AS 'Customer',
                            c.IMDS_ID_no,
                            v.`Name` AS 'Vendor',
                            v.Short_name,
                            cpn.*
                        FROM products p
                            LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                            INNER JOIN ppap ON cp.Customer_PN = ppap.FK_Customer_PN
                            LEFT JOIN vendors v ON ppap.FK_Vendor_ID = v.Vendor_ID
                            LEFT JOIN customer_ppap_number cpn ON cpn.FK_Customer_ID = c.Customer_ID
                        WHERE Product = 'BluSeal'
                        ORDER BY Eurotech_PN;"
                ) as $log) {
                    $logs[] = $log;
                }
            }
            return $logs;
        }

        // function searchNoPPAP(){
        //     $logsNP = [];
        //     if (isset($_POST['btnsearch'])) {
        //         if ((!empty($_POST['days1search']) && !empty($_POST['days2search']))
        //             || !empty($_POST['ppapnsearch'])
        //             || (!empty($_POST['date1search']) && !empty($_POST['date2search']))
        //             || isset($_POST['req1n'])
        //             || !empty($_POST['currentsearch'])
        //             || isset($_POST['curn'])
        //             || !empty($_POST['pisearch']) 
        //             || !empty($_POST['sapsearch'])
        //             || !empty($_POST['oemsearch'])                    
        //             || !empty($_POST['custsearch']) 
        //             || !empty($_POST['counsearch'])
        //             || !empty($_POST['cpnsearch']) 
        //             || !empty($_POST['etmsearch'])
        //             || !empty($_POST['etdsearch'])
        //             || !empty($_POST['revsearch'])
        //             || !empty($_POST['etpnsearch']) 
        //             || !empty($_POST['descsearch']) 
        //             || !empty($_POST['imdssearch']) 
        //             || isset($_POST['imdn'])
        //             // || (!empty($_POST['pd1search']) && !empty($_POST['pd2search']))
        //             // || isset($_POST['ppdn']) 
        //             || !empty($_POST['levelsearch']) 
        //             || isset($_POST['lvln']) 
        //             || !empty($_POST['psssearch']) 
        //             || isset($_POST['pssn']) 
        //             || !empty($_POST['rssearch']) 
        //             || isset($_POST['rosn'])
        //             || (!empty($_POST['date3search']) && !empty($_POST['date4search']))
        //             || isset($_POST['recn']) 
        //             || (!empty($_POST['ret1search']) && !empty($_POST['ret2search']))
        //             || isset($_POST['retn'])
        //             || (!empty($_POST['psw1search']) && !empty($_POST['psw2search']))
        //             || isset($_POST['pscn'])
        //             || isset($_POST['pfsn']) 
        //             || isset($_POST['originsearch']) 
        //             || isset($_POST['comsearch']) 
        //             || isset($_POST['irnsearch'])
        //         ) {
        //             $where = [];
        //             $params = [];

        //             if(!empty($_POST['days1search']) && !empty($_POST['days2search'])) {
        //                 $where[] = "1 = 2";
        //             }
                    
        //             if(!empty($_POST['ppapnsearch'])) {
        //                 $where[] = "1 = 2";
        //             }

        //             if(!empty($_POST['date1search']) && !empty($_POST['date2search'])) {
        //                 $where[] = "1 = 2";
        //             }

        //             if(!empty($_POST['req1n']) && $_POST['req1n'] == 'Y') {
        //                 $where[] = "1 = 2";
        //             }

        //             if(!empty($_POST['currentsearch'])) {
        //                 $where[] = "1 = 2";
        //             }

        //             if(!empty($_POST['curn']) && $_POST['curn'] == 'Y') {
        //                 $where[] = "1 = 2";
        //             }

        //             if (!empty($_POST['pisearch'])) {
        //                 $where[] = "Short_name = :sup";
        //                 $params[':sup'] = $_POST['pisearch'];
        //             }

        //             if (!empty($_POST['sapsearch'])) {
        //                 $where[] = "Supplier_PN = :spn";
        //                 $params[':spn'] = $_POST['sapsearch'];
        //             }

        //             if(!empty($_POST['oemsearch'])) {
        //                 $where[] = "1 = 2";
        //             }

        //             if(!empty($_POST['custsearch'])) {
        //                 $where[] = "1 = 2";
        //             }

        //             if(!empty($_POST['cusn']) && $_POST['cusn'] == 'Y') {
        //                 $where[] = "1 = 2";
        //             }

        //             if(!empty($_POST['counsearch'])) {
        //                 $where[] = "1 = 2";
        //             }

        //             if (!empty($_POST['cpnsearch'])) {
        //                 $where[] = "1 = 2";
        //             }

        //             if(!empty($_POST['etmsearch'])) {
        //                 $where[] = "ET_Model = :mod";
        //                 $params[':mod'] = $_POST['etmsearch'];
        //             }

        //             if(!empty($_POST['etdsearch'])) {
        //                 $where[] = "ET_Dwg = :dwg";
        //                 $params[':dwg'] = $_POST['etdsearch'];
        //             }
                    
        //             if(!empty($_POST['revsearch'])) {
        //                 $where[] = "1 = 2";
        //             }

        //             if (!empty($_POST['etpnsearch'])) {
        //                 $where[] = "Eurotech_PN = :etpn";
        //                 $params[':etpn'] = $_POST['etpnsearch'];
        //             }

        //             if (!empty($_POST['descsearch'])) {
        //                 $where[] = "`Description` LIKE :desc";
        //                 $params[':desc'] = "%".$_POST['descsearch']."%";
        //             }

        //             if (!empty($_POST['imdssearch'])) {
        //                 $where[] = "1 = 2";
        //             }

        //             if(!empty($_POST['imdn']) && $_POST['imdn'] == 'Y') {
        //                 $where[] = "1 = 2";
        //             }
                    
        //             // if(!empty($_POST['pd1search']) && !empty($_POST['pd2search'])) {
        //             //     $where[] = "1 = 2";
        //             // }

        //             // if($_POST['ppdn'] == "Y") {
        //             //     $where[] = "1 = 2";
        //             // }

        //             if(!empty($_POST['levelsearch'])) {
        //                 $where[] = "1 = 2";
        //             }

        //             if($_POST['lvln'] == "Y") {
        //                 $where[] = "1 = 2";
        //             }

        //             if(!empty($_POST['psssearch'])) {
        //                 $where[] = "1 = 2";
        //             }

        //             if($_POST['pssn'] == "Y") {
        //                 $where[] = "1 = 2";
        //             }

        //             if(!empty($_POST['rssearch'])) {
        //                 $where[] = "1 = 2";
        //             }

        //             if($_POST['rosn'] == "Y") {
        //                 $where[] = "1 = 2";
        //             }

        //             if (!empty($_POST['date3search']) && !empty($_POST['date4search'])) {
        //                 $where[] = "1 = 2";
        //             }

        //             if(!empty($_POST['recn']) && $_POST['recn'] == 'Y') {
        //                 $where[] = "1 = 2";
        //             }

        //             if (!empty($_POST['ret1search']) && !empty($_POST['ret2search'])) {
        //                 $where[] = "1 = 2";
        //             }

        //             if(!empty($_POST['retn']) && $_POST['retn'] == 'Y') {
        //                 $where[] = "1 = 2";
        //             }

        //             if (!empty($_POST['psw1search']) && !empty($_POST['psw2search'])) {
        //                 $where[] = "1 = 2";
        //             }

        //             if(!empty($_POST['pscn']) && $_POST['pscn'] == 'Y') {
        //                 $where[] = "1 = 2";
        //             }

        //             if($_POST['pfsn'] == "Y") {
        //                 $where[] = "1 = 2";
        //             }

        //             if(!empty($_POST['comsearch'])) {
        //                 $where[] = "1 = 2";
        //             }

        //             if(!empty($_POST['irnsearch'])) {
        //                 $where[] = "1 = 2";
        //             }

        //             if(!empty($where)) {
        //                 $sql = "SELECT * FROM products p
        //                         LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
        //                         WHERE Eurotech_PN NOT IN
        //                             (
        //                                 SELECT 
        //                                     Eurotech_PN
        //                                 FROM products p
        //                                     LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
        //                                     LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
        //                                     INNER JOIN ppap ON cp.Customer_PN = ppap.FK_Customer_PN
        //                                     LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
        //                                     LEFT JOIN customer_ppap_number cpn ON cpn.FK_Customer_ID = c.Customer_ID
        //                             )
        //                             AND " . implode(' AND ', $where) . "
        //                             ORDER BY Eurotech_PN;";
        //             }
        //             else {
        //                 $sql = "SELECT * FROM products p
        //                         LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
        //                         WHERE Eurotech_PN NOT IN
        //                             (
        //                                 SELECT 
        //                                     Eurotech_PN
        //                                 FROM products p
        //                                     LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
        //                                     LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
        //                                     INNER JOIN ppap ON cp.Customer_PN = ppap.FK_Customer_PN
        //                                     LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
        //                                     LEFT JOIN customer_ppap_number cpn ON cpn.FK_Customer_ID = c.Customer_ID
        //                             )
        //                         ORDER BY Eurotech_PN;";
        //             }

        //             $stmt = $this->mbd->prepare($sql);
        //             $stmt->execute($params);

        //             $logsNP = $stmt->fetchAll(PDO::FETCH_ASSOC);
        //         }
        //         else {
        //             foreach ($this->mbd->query(
        //                 "SELECT * FROM products p
        //                 LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
        //                 WHERE Eurotech_PN NOT IN
        //                     (
        //                         SELECT 
        //                             Eurotech_PN
        //                         FROM products p
        //                             LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
        //                             LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
        //                             INNER JOIN ppap ON cp.Customer_PN = ppap.FK_Customer_PN
        //                             LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
        //                             LEFT JOIN customer_ppap_number cpn ON cpn.FK_Customer_ID = c.Customer_ID
        //                     )
        //                 ORDER BY Eurotech_PN;"
        //             ) as $log) {
        //                 $logsNP[] = $log;
        //             }
        //         }
        //     } else {
        //         foreach ($this->mbd->query(
        //             "SELECT * FROM products p
        //             LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
        //             WHERE Eurotech_PN NOT IN
        //                 (
        //                     SELECT 
        //                         Eurotech_PN
        //                     FROM products p
        //                         LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
        //                         LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
        //                         INNER JOIN ppap ON cp.Customer_PN = ppap.FK_Customer_PN
        //                         LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
        //                         LEFT JOIN customer_ppap_number cpn ON cpn.FK_Customer_ID = c.Customer_ID
        //                 )
        //             ORDER BY Eurotech_PN;"
        //         ) as $log) {
        //             $logsNP[] = $log;
        //         }
        //     }
        //     return $logsNP;
        // }

        function searchPPAPN(){
            $PPAPNS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        PPAP_Number
                    FROM ppap
                    INNER JOIN customer_pn cpn ON ppap.FK_Customer_PN = cpn.Customer_PN
                    INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                    WHERE Product = 'BluSeal'
                    ORDER BY PPAP_Number;"
                ) as $PPAPN) {
                    $PPAPNS[] = $PPAPN;
                }
            return $PPAPNS;
        }

        function searchCS(){
            $Currents = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Current_Status
                    FROM ppap
                    INNER JOIN customer_pn cpn ON ppap.FK_Customer_PN = cpn.Customer_PN
                    INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                    WHERE Product = 'BluSeal'
                    ORDER BY Current_Status;"
                ) as $Current) {
                    $Currents[] = $Current;
                }
            return $Currents;
        }

        function searchPIS(){
            $PIS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Short_name
                    FROM vendors v
                    INNER JOIN products p ON v.Vendor_ID = p.Supplier
                    WHERE Product = 'BluSeal'
                    ORDER BY Short_name;"
                ) as $PI) {
                    $PIS[] = $PI;
                }
            return $PIS;
        }

        function searchSAP(){
            $SAPS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Supplier_PN
                    FROM products
                    WHERE Product = 'BluSeal'
                    ORDER BY Supplier_PN;"
                ) as $SAP) {
                    $SAPS[] = $SAP;
                }
            return $SAPS;
        }

        function searchOEM(){
            $OEMS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        `OEM`
                    FROM ppap
                    INNER JOIN customer_pn cpn ON ppap.FK_Customer_PN = cpn.Customer_PN
                    INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                    WHERE Product = 'BluSeal'
                    ORDER BY `OEM`;"
                ) as $OEM) {
                    $OEMS[] = $OEM;
                }
            return $OEMS;
        }

        function searchCust(){
            $Customers = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        `Name`
                    FROM customers
                    WHERE Products LIKE '%BluSeal%'
                    ORDER BY `Name`;"
                ) as $Customer) {
                    $Customers[] = $Customer;
                }
            return $Customers;
        }

        function searchCoun(){
            $Countries = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Country
                    FROM customer_ppap_number
                    ORDER BY Country;"
                ) as $Country) {
                    $Countries[] = $Country;
                }
            return $Countries;
        }

        function searchCPN(){
            $CPNS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Customer_PN
                    FROM customer_pn cpn
                    INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                    WHERE Product = 'BluSeal'
                    ORDER BY Customer_PN;"
                ) as $CPN) {
                    $CPNS[] = $CPN;
                }
            return $CPNS;
        }

        function searchETM(){
            $ETMS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        ET_Model
                    FROM products
                    WHERE Product = 'BluSeal'
                    ORDER BY ET_Model;"
                ) as $ETM) {
                    $ETMS[] = $ETM;
                }
            return $ETMS;
        }

        function searchETD(){
            $ETDS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        ET_Dwg
                    FROM products
                    WHERE Product = 'BluSeal'
                    ORDER BY ET_Dwg;"
                ) as $ETD) {
                    $ETDS[] = $ETD;
                }
            return $ETDS;
        }

        function searchRev(){
            $Revs = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Rev
                    FROM ppap
                    INNER JOIN customer_pn cpn ON ppap.FK_Customer_PN = cpn.Customer_PN
                    INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                    WHERE Product = 'BluSeal'
                    ORDER BY Rev;"
                ) as $Rev) {
                    $Revs[] = $Rev;
                }
            return $Revs;
        }

        function searchETPN(){
            $ETPNS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Eurotech_PN
                    FROM products
                    WHERE Product = 'BluSeal'
                    ORDER BY Eurotech_PN;"
                ) as $ETPN) {
                    $ETPNS[] = $ETPN;
                }
            return $ETPNS;
        }

        function searchDesc(){
            $Descs = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        `Description`
                    FROM products
                    WHERE Product = 'BluSeal'
                    ORDER BY `Description`;"
                ) as $Desc) {
                    $Descs[] = $Desc;
                }
            return $Descs;
        }

        function searchIMDS(){
            $IMDS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        IMDS
                    FROM ppap
                    INNER JOIN customer_pn cpn ON ppap.FK_Customer_PN = cpn.Customer_PN
                    INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                    WHERE Product = 'BluSeal';"
                ) as $IM) {
                    $IMDS[] = $IM;
                }
            return $IMDS;
        }

        function searchPS(){
            $PSSS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Samples_Status
                    FROM ppap
                    INNER JOIN customer_pn cpn ON ppap.FK_Customer_PN = cpn.Customer_PN
                    INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                    WHERE Product = 'BluSeal'
                    ORDER BY Samples_Status;"
                ) as $PSS) {
                    $PSSS[] = $PSS;
                }
            return $PSSS;
        }

        function searchRS(){
            $RSS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Reason_Submission
                    FROM ppap
                    INNER JOIN customer_pn cpn ON ppap.FK_Customer_PN = cpn.Customer_PN
                    INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                    WHERE Product = 'BluSeal'
                    ORDER BY Reason_Submission;"
                ) as $RS) {
                    $RSS[] = $RS;
                }
            return $RSS;
        }

        function searchCom(){
            $Coms = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Comments
                    FROM ppap
                    INNER JOIN customer_pn cpn ON ppap.FK_Customer_PN = cpn.Customer_PN
                    INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                    WHERE Product = 'BluSeal'
                    ORDER BY Comments;"
                ) as $Com) {
                    $Coms[] = $Com;
                }
            return $Coms;
        }

        function searchIRN(){
            $IRNS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Inspection_Rep_Number
                    FROM ppap
                    INNER JOIN customer_pn cpn ON ppap.FK_Customer_PN = cpn.Customer_PN
                    INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                    WHERE Product = 'BluSeal'
                    ORDER BY Inspection_Rep_Number;"
                ) as $IRN) {
                    $IRNS[] = $IRN;
                }
            return $IRNS;
        }
    }
?>