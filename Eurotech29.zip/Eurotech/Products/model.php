<?php
    class model {                                        

        public  $mbd;
        
        function cn() {
            $this->mbd = new PDO('mysql:host=localhost;dbname=eurotechdb;port=3306', 'root', '');
            $this->mbd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
        }
    
        function search(){
            $logs = [];
            if (isset($_POST['btnsearch'])) {
                if (!empty($_POST['idsearch']) || !empty($_POST['descsearch']) || !empty($_POST['suppsearch']) || !empty($_POST['snsearch'])
                    || !empty($_POST['tapesearch']) || !empty($_POST['widthsearch']) || !empty($_POST['lengthsearch']) || !empty($_POST['colorsearch']) 
                    || !empty($_POST['modelsearch']) || !empty($_POST['dwgsearch']) 
                ) {
                    $where = [];
                    $params = [];

                    if (!empty($_POST['idsearch'])) {
                        $where[] = "Eurotech_PN = :id";
                        $params[':id'] = $_POST['idsearch'];
                    }
                    
                    if(!empty($_POST['descsearch'])) {
                        $where[] = "`Description` LIKE :desc";
                        $params[':desc'] = $_POST['descsearch']."%";
                    }

                    if (!empty($_POST['suppsearch'])) {
                        $where[] = "Short_name = :supp";
                        $params[':supp'] = $_POST['suppsearch'];
                    }

                    if (!empty($_POST['snsearch'])) {
                        $where[] = "Supplier_PN = :sn";
                        $params[':sn'] = $_POST['snsearch'];
                    }

                    if (!empty($_POST['tapesearch'])) {
                        $where[] = "Tape = :tape";
                        $params[':tape'] = $_POST['tapesearch'];
                    }

                    if (!empty($_POST['widthsearch'])) {
                        $where[] = "Width = :wd";
                        $params[':wd'] = $_POST['widthsearch'];
                    }

                    if (!empty($_POST['lengthsearch'])) {
                        $where[] = "Length = :lng";
                        $params[':lng'] = $_POST['lengthsearch'];
                    }

                    if (!empty($_POST['colorsearch'])) {
                        $where[] = "Color = :clr";
                        $params[':clr'] = $_POST['colorsearch'];
                    }

                    if (!empty($_POST['modelsearch'])) {
                        $where[] = "ET_Model = :mod";
                        $params[':mod'] = $_POST['modelsearch'];
                    }

                    if (!empty($_POST['dwgsearch'])) {
                        $where[] = "ET_Dwg = :dwg";
                        $params[':dwg'] = $_POST['dwgsearch'];
                    }

                    if(!empty($where)) {
                        $sql = "
                        SELECT 
                            *
                        FROM products p
                        LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
                        WHERE " . implode(' AND ', $where) . "
                        ORDER BY Eurotech_PN;";
                    }
                    else {
                        $sql = "
                        SELECT 
                            *
                        FROM products p
                        LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
                        ORDER BY Eurotech_PN;";
                    }

                    $stmt = $this->mbd->prepare($sql);
                    $stmt->execute($params);

                    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
                else {
                    foreach ($this->mbd->query(
                        "SELECT 
                            *
                        FROM products p
                        LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
                        ORDER BY Eurotech_PN;"
                    ) as $log) {
                        $logs[] = $log;
                    }
                }
            } else {
                foreach ($this->mbd->query(
                    "SELECT 
                        *
                    FROM products p
                    LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
                    ORDER BY Eurotech_PN;"
                ) as $log) {
                    $logs[] = $log;
                }
            }
            return $logs;
        }

        function searchETPNs(){
            $ETPNs = [];
                foreach ($this->mbd->query(
                    "SELECT
                        Eurotech_PN
                    FROM products
                    -- WHERE Product = 'BluSeal'
                    ORDER BY Eurotech_PN;"
                ) as $ETPN) {
                    $ETPNs[] = $ETPN;
                }
            return $ETPNs;
        }

        function searchDescriptions(){
            $Descriptions = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        `Description`
                    FROM products
                    -- WHERE Product = 'BluSeal'
                    ORDER BY `Description`;"
                ) as $Description) {
                    $Descriptions[] = $Description;
                }
            return $Descriptions;
        }

        function searchSuppliers(){
            $Suppliers = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Short_name
                    FROM vendors
                    ORDER BY Short_name;"
                ) as $Supplier) {
                    $Suppliers[] = $Supplier;
                }
            return $Suppliers;
        }

        function searchSuppliersPN(){
            $SuppliersPN = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        Supplier_PN
                    FROM products
                    -- WHERE Product = 'BluSeal'
                    ORDER BY Supplier_PN;"
                ) as $SupplierPN) {
                    $SuppliersPN[] = $SupplierPN;
                }
            return $SuppliersPN;
        }

        function searchTapes(){
            $Tapes = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        `Tape`
                    FROM products
                    ORDER BY `Tape`;"
                ) as $Tape) {
                    $Tapes[] = $Tape;
                }
            return $Tapes;
        }

        function searchWidths(){
            $Widths = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Width
                    FROM products
                    ORDER BY Width;"
                ) as $Width) {
                    $Widths[] = $Width;
                }
            return $Widths;
        }


        function searchLengths(){
            $Lengths = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        `Length`
                    FROM products
                    ORDER BY `Length`;"
                ) as $Length) {
                    $Lengths[] = $Length;
                }
            return $Lengths;
        }


        function searchColors(){
            $Colors = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Color
                    FROM products
                    ORDER BY Color;"
                ) as $Color) {
                    $Colors[] = $Color;
                }
            return $Colors;
        }

        function searchModels(){
            $Models = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        ET_Model
                    FROM products
                    ORDER BY ET_Model;"
                ) as $Model) {
                    $Models[] = $Model;
                }
            return $Models;
        }

        function searchDwgs(){
            $Dwgs = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        ET_Dwg
                    FROM products
                    ORDER BY ET_Dwg;"
                ) as $Dwg) {
                    $Dwgs[] = $Dwg;
                }
            return $Dwgs;
        }
    }
?>