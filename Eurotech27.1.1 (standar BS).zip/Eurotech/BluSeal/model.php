<?php
    class model {                                        

        public  $mbd;
        
        function cn() {
            $this->mbd = new PDO('mysql:host=localhost;dbname=eurotechdb;port=3306', 'root', '');
            $this->mbd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
        }
    
        function search(){
            $logs = [];
            if (isset($_POST['btnsearch'])) {
                if (!empty($_POST['custsearch']) || !empty($_POST['modelsearch']) || !empty($_POST['descsearch']) 
                    || !empty($_POST['cpnsearch']) || !empty($_POST['imdssearch']) || !empty($_POST['suppsearch']) 
                    || !empty($_POST['spnsearch'])
                    || (!empty($_POST['date1search']) && !empty($_POST['date2search'])) 
                    || (!empty($_POST['date3search']) && !empty($_POST['date4search']))
                    || (!empty($_POST['date5search']) && !empty($_POST['date6search']))
                    || (!empty($_POST['date7search']) && !empty($_POST['date8search']))
                    || isset($_POST['cusn']) || isset($_POST['imdn']) || isset($_POST['reqn']) 
                    || isset($_POST['recn']) || isset($_POST['psen']) || isset($_POST['psin'])) {
                    $where = [];
                    $params = [];
                    
                    if($_POST['cusn'] == "" && !empty($_POST['custsearch'])) {
                        $where[] = "`Name` LIKE :cust";
                        $params[':cust'] = $_POST['custsearch']."%";
                    }
                    if($_POST['cusn'] == "Y") {
                        $where[] = "`Name` IS NOT NULL";
                    }
                    if($_POST['cusn'] == "N") {
                        $where[] = "`Name` IS NULL";
                    }

                    if (!empty($_POST['modelsearch'])) {
                        $where[] = "Eurotech_PN = :etpn";
                        $params[':etpn'] = $_POST['modelsearch'];
                    }

                    if (!empty($_POST['descsearch'])) {
                        $where[] = "`Description` = :desc";
                        $params[':desc'] = $_POST['descsearch'];
                    }

                    if (!empty($_POST['cpnsearch'])) {
                        $where[] = "Customer_PN = :cpn";
                        $params[':cpn'] = $_POST['cpnsearch'];
                    }

                    if (!empty($_POST['imdssearch'])) {
                        $where[] = "IMDS = :imds";
                        $params[':imds'] = $_POST['imdssearch'];
                    }

                    if (!empty($_POST['suppsearch'])) {
                        $where[] = "Supplier = :sup";
                        $params[':sup'] = $_POST['suppsearch'];
                    }

                    if (!empty($_POST['spnsearch'])) {
                        $where[] = "Supplier_PN = :spn";
                        $params[':spn'] = $_POST['spnsearch'];
                    }

                    if($_POST['reqn'] == "" && !empty($_POST['date1search']) && !empty($_POST['date2search'])) {
                        $where[] = "Request_Date BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['date1search'];
                        $params[':date2'] = $_POST['date2search'];
                    }
                    if($_POST['reqn'] == "Y") {
                        $where[] = "Request_Date IS NOT NULL";
                    }
                    if($_POST['reqn'] == "N") {
                        $where[] = "Request_Date IS NULL";
                    }

                    if($_POST['psin'] == "" && !empty($_POST['date7search']) && !empty($_POST['date8search'])) {
                        $where[] = "PPAP_Signed_Date BETWEEN :date7 AND :date8";
                        $params[':date7'] = $_POST['date7search'];
                        $params[':date8'] = $_POST['date8search'];
                    }
                    if($_POST['psin'] == "Y") {
                        $where[] = "PPAP_Signed_Date IS NOT NULL";
                    }
                    if($_POST['psin'] == "N") {
                        $where[] = "PPAP_Signed_Date IS NULL";
                    }

                    if($_POST['recn'] == "" && !empty($_POST['date3search']) && !empty($_POST['date4search'])) {
                        $where[] = "PPAP_Received_Date BETWEEN :date3 AND :date4";
                        $params[':date3'] = $_POST['date3search'];
                        $params[':date4'] = $_POST['date4search'];
                    }
                    if($_POST['recn'] == "Y") {
                        $where[] = "PPAP_Received_Date IS NOT NULL";
                    }
                    if($_POST['recn'] == "N") {
                        $where[] = "PPAP_Received_Date IS NULL";
                    }

                    if($_POST['psen'] == "" && !empty($_POST['date5search']) && !empty($_POST['date6search'])) {
                        $where[] = "Sent_Customer BETWEEN :date5 AND :date6search";
                        $params[':date5'] = $_POST['date5search'];
                        $params[':date6search'] = $_POST['date6search'];
                    }
                    if($_POST['psen'] == "Y") {
                        $where[] = "Sent_Customer IS NOT NULL";
                    }
                    if($_POST['psen'] == "N") {
                        $where[] = "Sent_Customer IS NULL";
                    }

                    if(!empty($where)) {
                        $sql = "
                        SELECT 
                            bp.BS_PPAP_ID,
                            p.Eurotech_PN,
                            p.`Description`,
                            c.`Name`,
                            cp.Customer_PN,
                            bp.IMDS,
                            p.Supplier,
                            p.Supplier_PN,
                            bp.Request_Date,
                            bp.PPAP_Received_Date,
                            bp.PPAP_Signed_Date,
                            bp.Sent_Customer
                        FROM products p
                            LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                            LEFT JOIN bluseal_ppap bp ON cp.Customer_PN = bp.FK_Customer_PN
                        WHERE " . implode(' AND ', $where) . "
                        AND Product = 'BluSeal'
                        ORDER BY Eurotech_PN;";
                    }
                    else {
                        $sql = "
                        SELECT 
                            bp.BS_PPAP_ID,
                            p.Eurotech_PN,
                            p.`Description`,
                            c.`Name`,
                            cp.Customer_PN,
                            bp.IMDS,
                            p.Supplier,
                            p.Supplier_PN,
                            bp.Request_Date,
                            bp.PPAP_Received_Date,
                            bp.PPAP_Signed_Date,
                            bp.Sent_Customer
                        FROM products p
                            LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                            LEFT JOIN bluseal_ppap bp ON cp.Customer_PN = bp.FK_Customer_PN
                            WHERE Product = 'BluSeal'
                        ORDER BY Eurotech_PN;";
                    }

                    $stmt = $this->mbd->prepare($sql);
                    $stmt->execute($params);

                    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
                else {
                    foreach ($this->mbd->query(
                        "SELECT 
                            bp.BS_PPAP_ID,
                            p.Eurotech_PN,
                            p.`Description`,
                            c.`Name`,
                            cp.Customer_PN,
                            bp.IMDS,
                            p.Supplier,
                            p.Supplier_PN,
                            bp.Request_Date,
                            bp.PPAP_Received_Date,
                            bp.PPAP_Signed_Date,
                            bp.Sent_Customer
                        FROM products p
                            LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                            LEFT JOIN bluseal_ppap bp ON cp.Customer_PN = bp.FK_Customer_PN
                            WHERE Product = 'BluSeal'
                        ORDER BY Eurotech_PN;"
                    ) as $log) {
                        $logs[] = $log;
                    }
                }
            } else {
                foreach ($this->mbd->query(
                    "SELECT 
                            bp.BS_PPAP_ID,
                            p.Eurotech_PN,
                            p.`Description`,
                            c.`Name`,
                            cp.Customer_PN,
                            bp.IMDS,
                            p.Supplier,
                            p.Supplier_PN,
                            bp.Request_Date,
                            bp.PPAP_Received_Date,
                            bp.PPAP_Signed_Date,
                            bp.Sent_Customer
                        FROM products p
                            LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                            LEFT JOIN bluseal_ppap bp ON cp.Customer_PN = bp.FK_Customer_PN
                        WHERE Product = 'BluSeal'
                    ORDER BY Eurotech_PN;"
                ) as $log) {
                    $logs[] = $log;
                }
            }
            return $logs;
        }

        function searchModels(){
            $Models = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        Eurotech_PN
                    FROM products
                    WHERE Product = 'BluSeal'
                    ORDER BY Eurotech_PN;"
                ) as $Model) {
                    $Models[] = $Model;
                }
            return $Models;
        }

        function searchDescs(){
            $Descs = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        `Description`
                    FROM products
                    WHERE Product = 'BluSeal'
                    ORDER BY `Description`;"
                ) as $Desc) {
                    $Descs[] = $Desc;
                }
            return $Descs;
        }

        function searchCustomers(){
            $Customers = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        Customer_ID,
                        `Name`,
                        Products
                    FROM customers
                    WHERE Products LIKE '%BluSeal%'
                    ORDER BY `Name`;"
                ) as $Customer) {
                    $Customers[] = $Customer;
                }
            return $Customers;
        }

        function searchCPN(){
            $CPNS = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        Customer_PN
                    FROM customer_pn cpn
                    INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                    WHERE Product = 'BluSeal'
                    ORDER BY Customer_PN;"
                ) as $CPN) {
                    $CPNS[] = $CPN;
                }
            return $CPNS;
        }

        function searchIMDS(){
            $IMDS = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        IMDS
                    FROM bluseal_ppap
                    ORDER BY IMDS;"
                ) as $IM) {
                    $IMDS[] = $IM;
                }
            return $IMDS;
        }

        function searchSupplier(){
            $Suppliers = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Supplier
                    FROM products
                    ORDER BY Supplier;"
                ) as $Supplier) {
                    $Suppliers[] = $Supplier;
                }
            return $Suppliers;
        }

        function searchSupplierPN(){
            $SPNS = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        Supplier_PN
                    FROM products
                    ORDER BY Supplier_PN;"
                ) as $SPN) {
                    $SPNS[] = $SPN;
                }
            return $SPNS;
        }
    }
?>