<link href="./css/style.css" rel="stylesheet">
<style>
    .clear {
        color: white;
        padding: 8px 14px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
        transition: background-color 0.2s;
        font-size: 14px;
        background-color: #187783;
    }

    .clear:hover {
        background-color: #1e8f9e;
        color: white;
    }

    .form-search .camp {
        flex: 1 1 20%;
        min-width: 250px;
    }

    .form-search input[type="date"],
    .form-search input[type="number"]{
        padding: 8px 10px;
        border: 1px solid #bbb;
        border-radius: 8px;
        box-sizing: border-box;
        width: 46%;
    }


    @media (max-width: 1453px) {
        .form-search .camp {
            flex: 1 1 40%; 
            min-width: 300px;
        }
    }
</style>
<form action="" id="form" method="post" class="form-search">
    <input type="hidden" name="page" value="Tubes">
    <div class="camp">
        <label>Days to Submit:</label>
        <input type="number" name="submit1search" value="<?php if ($submit1search != NULL) { echo $submit1search;} ?>"> -
        <input type="number" name="submit2search" value="<?php if ($submit2search != NULL) { echo $submit2search;} ?>">
    </div>
    
    <div class="camp">
        <label>PPAP Number:</label>
        <input type="text" name="ppapnsearch" list="PPAPN" value="<?php if ($ppapnsearch != NULL) { echo $ppapnsearch;} ?>">
        <datalist id="PPAPN">
            <?php foreach ($PPAPNS as $PPAPN) {  ?>
                <option value="<?php echo $PPAPN['PPAP_Number'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>PPAP Req'd by Customer:</label>
        <input type="date" name="req1search" value="<?php if ($req1search != NULL) { echo $req1search;} ?>"> - <input type="date" name="req2search" value="<?php if ($req2search != NULL) { echo $req2search;} ?>">
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="reqn" id="" value="" <?php if ($reqn != "N" && $reqn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="reqn" id="" value="N" <?php if ($reqn == "N") { echo "checked";} ?>> No date
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="reqn" id="" value="Y" <?php if ($reqn == "Y") { echo "checked";} ?>> W/ date
    </div>
    
    <div class="camp">
        <label>Current Status:</label>
        <input type="text" name="currentsearch" list="Current" value="<?php  if ($currentsearch != NULL) { echo $currentsearch;} ?>">
        <datalist id="Current">
            <?php foreach ($Currents as $Current) {  ?>
                <option value="<?php echo $Current['Current_Status'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="curn" id="" value="" <?php if ($curn != "N" && $curn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="curn" id="" value="N" <?php if ($curn == "N") { echo "checked";} ?>> No current status
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="curn" id="" value="Y" <?php if ($curn == "Y") { echo "checked";} ?>> W/ current status
    </div>

    <div class="camp">
        <label>Vendor:</label>
        <input type="text" name="pisearch" list="PI" value="<?php if ($pisearch != NULL) { echo $pisearch;} ?>">
        <datalist id="PI">
            <?php foreach ($PIS as $PI) {  ?>
                <option value="<?php echo $PI['Vendor'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Customer:</label>
        <input type="text" name="custsearch" list="Customer" value="<?php if ($custsearch != NULL) { echo $custsearch;} ?>">
        <datalist id="Customer">
            <?php foreach ($Customers as $Customer) {  ?>
                <option value="<?php echo $Customer['Name'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Country:</label>
        <input type="text" name="countrysearch" list="Country" value="<?php if ($countrysearch != NULL) { echo $countrysearch;} ?>">
        <datalist id="Country">
            <?php foreach ($Countries as $Country) {  ?>
                <option value="<?php echo $Country['Country'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Customer PN:</label>
        <input type="text" name="cpnsearch" list="CPN" value="<?php if ($cpnsearch != NULL) { echo $cpnsearch;} ?>">
        <datalist id="CPN">
            <?php foreach ($CPNS as $CPN) {  ?>
                <option value="<?php echo $CPN['TUB_Customer_PN'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>ET Model:</label>
        <input type="text" name="etmsearch" list="ETM" value="<?php if ($etmsearch != NULL) { echo $etmsearch;} ?>">
        <datalist id="ETM">
            <?php foreach ($ETMS as $ETM) {  ?>
                <option value="<?php echo $ETM['ET_Model'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>ET Dwg:</label>
        <input type="text" name="etdsearch" list="ETD" value="<?php if ($etdsearch != NULL) { echo $etdsearch;} ?>">
        <datalist id="ETD">
            <?php foreach ($ETDS as $ETD) {  ?>
                <option value="<?php echo $ETD['ET_Dwg'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Rev:</label>
        <input type="number" name="revsearch" value="<?php if ($revsearch != NULL) { echo $revsearch;} ?>">
    </div>

    <div class="camp">
        <label>ET PN:</label>
        <input type="text" name="etpnsearch" list="ETPN" value="<?php if ($etpnsearch != NULL) { echo $etpnsearch;} ?>">
        <datalist id="ETPN">
            <?php foreach ($ETPNS as $ETPN) {  ?>
                <option value="<?php echo $ETPN['TUB_Eurotech_PN'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Description:</label>
        <input type="text" name="descsearch" list="Desc" value="<?php if ($descsearch != NULL) { echo $descsearch;} ?>">
        <datalist id="Desc">
            <?php foreach ($Descs as $Desc) {  ?>
                <option value="<?php echo $Desc['Description'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp"></div>

    <div class="camp">
        <label>IMDS Number:</label>
        <input type="text" name="imdssearch" list="IMDS" value="<?php if ($imdssearch != NULL) { echo $imdssearch;} ?>">
        <datalist id="IMDS">
            <?php foreach ($IMDS as $IM) {  ?>
                <option value="<?php echo $IM['IMDS_Number'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="imdn" id="" value="" <?php if ($imdn != "N" && $imdn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="imdn" id="" value="N" <?php if ($imdn == "N") { echo "checked";} ?>> No IMDS Number
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="imdn" id="" value="Y" <?php if ($imdn == "Y") { echo "checked";} ?>> W/ IMDS Number
    </div>

    <div class="camp">
        <label>IMDS Status:</label>
        <input type="text" name="issearch" list="IS" value="<?php if ($issearch != NULL) { echo $issearch;} ?>">
        <datalist id="IS">
            <?php foreach ($ISS as $IS) {  ?>
                <option value="<?php echo $IS['IMDS_Status'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="imsn" id="" value="" <?php if ($imsn != "N" && $imsn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="imsn" id="" value="N" <?php if ($imsn == "N") { echo "checked";} ?>> No IMDS status
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="imsn" id="" value="Y" <?php if ($imsn == "Y") { echo "checked";} ?>> W/ IMDS status
    </div>

    <div class="camp">
        <label>PPAP docs:</label>
        <input type="text" name="pdsearch" list="PD" value="<?php if ($pdsearch != NULL) { echo $pdsearch;} ?>">
        <datalist id="PD">
            <?php foreach ($PDS as $PD) {  ?>
                <option value="<?php echo $PD['PPAP_docs'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="ppdn" id="" value="" <?php if ($ppdn != "N" && $ppdn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="ppdn" id="" value="N" <?php if ($ppdn == "N") { echo "checked";} ?>> No PPAP docs
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="ppdn" id="" value="Y" <?php if ($ppdn == "Y") { echo "checked";} ?>> W/ PPAP docs
    </div>

    <div class="camp">
        <label>Level:</label>
        <input type="text" name="levelsearch" list="Level" value="<?php if ($levelsearch != NULL) { echo $levelsearch;} ?>">
        <datalist id="Level">
            <?php foreach ($Levels as $Level) {  ?>
                <option value="<?php echo $Level['Level'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="lvln" id="" value="" <?php if ($lvln != "N" && $lvln != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="lvln" id="" value="N" <?php if ($lvln == "N") { echo "checked";} ?>> No level
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="lvln" id="" value="Y" <?php if ($lvln == "Y") { echo "checked";} ?>> W/ level
    </div>

    <div class="camp">
        <label>PPAP samples status:</label>
        <input type="text" name="psssearch" list="PSS" value="<?php if ($psssearch != NULL) { echo $psssearch;} ?>">
        <datalist id="PSS">
            <?php foreach ($PSSS as $PSS) {  ?>
                <option value="<?php echo $PSS['Samples_Status'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="pssn" id="" value="" <?php if ($pssn != "N" && $pssn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pssn" id="" value="N" <?php if ($pssn == "N") { echo "checked";} ?>> No PPAP sample status
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pssn" id="" value="Y" <?php if ($pssn == "Y") { echo "checked";} ?>> W/ PPAP sample status
    </div>

    <div class="camp">
        <label>Reason of Submission:</label>
        <input type="text" name="rssearch" list="RS" value="<?php if ($rssearch != NULL) { echo $rssearch;} ?>">
        <datalist id="RS">
            <?php foreach ($RSS as $RS) {  ?>
                <option value="<?php echo $RS['Reason_submission'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="rosn" id="" value="" <?php if ($rosn != "N" && $rosn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="rosn" id="" value="N" <?php if ($rosn == "N") { echo "checked";} ?>> No reason of submission
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="rosn" id="" value="Y" <?php if ($rosn == "Y") { echo "checked";} ?>> W/ reason of submission
    </div>

    <div class="camp">
        <label>Sent to Customer:</label>
        <input type="date" name="sent1search" value="<?php if ($sent1search != NULL) { echo $sent1search;} ?>"> - <input type="date" name="sent2search" value="<?php if ($sent2search != NULL) { echo $sent2search;} ?>">
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="stcn" id="" value="" <?php if ($stcn != "N" && $stcn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="stcn" id="" value="N" <?php if ($stcn == "N") { echo "checked";} ?>> No date
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="stcn" id="" value="Y" <?php if ($stcn == "Y") { echo "checked";} ?>> W/ date
    </div>

    <div class="camp">
        <label>PSW returned from Customer Signed:</label>
        <input type="date" name="psw1search" value="<?php if ($psw1search != NULL) { echo $psw1search;} ?>"> - <input type="date" name="psw2search" value="<?php if ($psw2search != NULL) { echo $psw2search;} ?>">
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="pcsn" id="" value="" <?php if ($pcsn != "N" && $pcsn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pcsn" id="" value="N" <?php if ($pcsn == "N") { echo "checked";} ?>> No date
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pcsn" id="" value="Y" <?php if ($pcsn == "Y") { echo "checked";} ?>> W/ date
    </div>
    
    <div class="camp">
        <label>Origin from report:</label>
        <input type="radio" name="originsearch" value="" checked> All <br>
        <input type="radio" name="originsearch" value="N" <?php if ($originsearch == "N") { echo "checked";} ?>> No <br>
        <input type="radio" name="originsearch" value="Y" <?php if ($originsearch == "Y") { echo "checked";} ?>> Yes
    </div>

    <div class="camp">
        <label>Comments:</label>
        <input type="text" name="comsearch" list="Com" value="<?php if ($comsearch != NULL) { echo $comsearch;} ?>">
        <datalist id="Com">
            <?php foreach ($Coms as $Com) {  ?>
                <option value="<?php echo $Com['Comments'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Inspection Report Number:</label>
        <input type="text" name="irnsearch" list="IRN" value="<?php if ($irnsearch != NULL) { echo $irnsearch;} ?>">
        <datalist id="IRN">
            <?php foreach ($IRNS as $IRN) {  ?>
                <option value="<?php echo $IRN['Inspection_rep_numb'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp"></div>
    <div class="camp"></div>
    <div class="camp"></div>
    <div class="camp"></div>


    <div class="campbtn">
        <button type="submit" name="btnsearch" class="insert">Search</button>
        <button style="margin: 0px 0px 0px 15px;"  type="submit" name="btnsearch" class="clear" onclick="clearForm()">Clear All</button>
    </div>
</form>

<div style="display: flex;">
    <form action="?page=Tubes" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insertD" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="countrysearch" value="<?php if(isset($_POST['countrysearch'])) { echo $_POST['countrysearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">
        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
        <button type="submit" class="insert">New PPAP (Description)</button>
    </form>

    <form action="?page=Tubes" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insertET" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="countrysearch" value="<?php if(isset($_POST['countrysearch'])) { echo $_POST['countrysearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">
        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
        <button type="submit" class="insert">New PPAP (ET PN)</button>
    </form>

    <form action="?page=Tubes" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insertC" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="countrysearch" value="<?php if(isset($_POST['countrysearch'])) { echo $_POST['countrysearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">
        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
        <button type="submit" class="insert">New PPAP (Cust PN)</button>
    </form>
</div>

<?php if($logs == NULL) { ?>
    <br>
    <h1>No results.</h1>
<?php } ?>

<?php if($logs != NULL) { ?>
    <div class="table-responsive">
        <table class="table table-bordered">
            <tr>    
                <th style="background-color:#1c18AA;"></th>
                <th style="background-color:#1c18AA;"></th>
                <th style="background-color:#1c18AA; color:white">Days to Submit</th>
                <th style="background-color:#1c18AA; color:white">PPAP Number</th>
                <th style="background-color:#1c18AA; color:white">PPAP Req'd by Customer</th>
                <th style="background-color:#1c18AA; color:white">Current Status</th>
                <th style="background-color:#1c18AA; color:white">Vendor</th>
                <th style="background-color:#1c18AA; color:white">Customer</th>
                <th style="background-color:#1c18AA; color:white">Country</th>
                <th style="background-color:#1c18AA; color:white">Customer PN</th>
                <th style="background-color:#1c18AA; color:white">ET Model</th>
                <th style="background-color:#1c18AA; color:white">ET Dwg</th>
                <th style="background-color:#1c18AA; color:white">Rev</th>
                <th style="background-color:#1c18AA; color:white">ET PN</th>
                <th style="background-color:#1c18AA; color:white">Description</th>
                <th style="background-color:#1c18AA; color:white">IMDS Number</th>
                <th style="background-color:#1c18AA; color:white">IMDS Status</th>
                <th style="background-color:#1c18AA; color:white">PPAP docs</th>
                <th style="background-color:#1c18AA; color:white">Level</th>
                <th style="background-color:#1c18AA; color:white">PPAP samples status</th>
                <th style="background-color:#1c18AA; color:white">Reason of Submission</th>
                <th style="background-color:#1c18AA; color:white">Sent to Customer</th>
                <th style="background-color:#1c18AA; color:white">PSW returned from Cust Signed</th>
                <th style="background-color:#1c18AA; color:white">Origin from report</th>
                <th style="background-color:#1c18AA; color:white">Comments</th>
                <th style="background-color:#1c18AA; color:white">Inspection Report Number</th>
            </tr>
            
            <?php foreach ($logs as $log) { ?>
                <tr>
                    <td>
                        <form action="?page=Tubes" method="post" style="display:inline;">
                            <input type="hidden" name="edit" value="">
                            <input type="hidden" name="btnsearch" value="1">
                            <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                            <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                            <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                            <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                            <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                            <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                            <input type="hidden" name="countrysearch" value="<?php if(isset($_POST['countrysearch'])) { echo $_POST['countrysearch']; } ?>">
                            <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                            <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                            <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                            <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                            <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                            <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                            <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                            <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">
                            <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">
                            <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                            <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                            <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                            <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                            <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                            <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                            <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                            <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                            <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                            <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                            <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                            <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                            <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                            <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                            <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                            <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                            <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                            <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                            <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                            <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                            <input type="hidden" name="IDedit" value="<?php echo $log['TUB_PPAPS_ID']; ?>">
                            <button type="submit" class="editar">Edit</button>
                        </form>
                    </td>
                    <td>
                        <form action="?page=Tubes" method="post" style="display:inline;">
                            <input type="hidden" name="delete" value="">
                            <input type="hidden" name="btnsearch" value="1">
                            <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                            <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                            <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                            <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                            <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                            <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                            <input type="hidden" name="countrysearch" value="<?php if(isset($_POST['countrysearch'])) { echo $_POST['countrysearch']; } ?>">
                            <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                            <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                            <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                            <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                            <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                            <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                            <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                            <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">
                            <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">
                            <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                            <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                            <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                            <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                            <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                            <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                            <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                            <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                            <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                            <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                            <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                            <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                            <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                            <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                            <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                            <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                            <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                            <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                            <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                            <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                            <button type="submit" class="eliminar">Delete</button>
                        </form>
                    </td>
                    <td 
                        <?php if($log['Days to Submit'] <= 18) { ?>
                            style="background-color:#00D900; color:black"
                        <?php } 
                        if($log['Days to Submit'] >= 19 && $log['Days to Submit'] <= 30) { ?>
                            style="background-color:#FFEE00; color:black"
                        <?php } 
                        if($log['Days to Submit'] >= 31) { ?>
                            style="background-color:#FF0000; color:white"
                        <?php } ?>
                    ><?php echo $log['Days to Submit']; ?></td>
                    <td><?php echo $log['PPAP_Number']; ?></td>
                    <?php if($log['PPAP_Req_by_Cus_Date'] != NULL) { 
                        $reqDate = new DateTime($log['PPAP_Req_by_Cus_Date']); ?>
                        <td><?php echo $reqDate->format('d/m/Y') ?></td>
                    <?php }
                    if($log['PPAP_Req_by_Cus_Date'] == NULL) { ?>
                        <td></td>
                    <?php } ?>
                    <td><?php echo $log['Current_Status']; ?></td>
                    <td><?php echo $log['Vendor']; ?></td>
                    <td><?php echo $log['Name']; ?></td>
                    <td><?php echo $log['Country']; ?></td>
                    <td><?php echo $log['TUB_Customer_PN']; ?></td>
                    <td><?php echo $log['ET_Model']; ?></td>
                    <td><?php echo $log['ET_Dwg']; ?></td>
                    <td><?php echo $log['Rev']; ?></td>
                    <td><?php echo $log['TUB_Eurotech_PN']; ?></td>
                    <td><?php echo $log['Description']; ?></td>
                    <td><?php echo $log['IMDS_Number']; ?></td>
                    <td><?php echo $log['IMDS_Status']; ?></td>
                    <td><?php echo $log['PPAP_docs']; ?></td>
                    <td><?php echo $log['Level']; ?></td>
                    <td><?php echo $log['Samples_Status']; ?></td>
                    <td><?php echo $log['Reason_submission']; ?></td>
                    <?php if($log['Sent_Customer'] != NULL) { 
                        $sentCust = new DateTime($log['Sent_Customer']); ?>
                        <td><?php echo $sentCust->format('d/m/Y') ?></td>
                    <?php }
                    if($log['Sent_Customer'] == NULL) { ?>
                        <td></td>
                    <?php } 
                    if($log['PSW_Returned'] != NULL) { 
                        $pswRet = new DateTime($log['PSW_Returned']); ?>
                        <td><?php echo $pswRet->format('d/m/Y') ?></td>
                    <?php }
                    if($log['PSW_Returned'] == NULL) { ?>
                        <td></td>
                    <?php } ?>
                    <td><?php echo $log['Origin_from_report']; ?></td>
                    <td><?php echo $log['Comments']; ?></td>
                    <td><?php echo $log['Inspection_rep_numb']; ?></td>
                </tr> 
            <?php } ?>
        </table> 
    </div>
<?php } 

if (isset($_POST['insertD'])) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Register New PPAP</h2>
        <form action="?page=Tubes" method="post">
            <input type="hidden" name="confirmID" value="1">
            <label>PPAP Number:</label>
            <input type="text" name="PPAP_Number" list="PPAPN" required> <br>

            <label>PPAP Req'd by Customer:</label>
            <input type="date" name="PPAP_Req_by_Cus_Date"> <br>

            <label>Current Status:</label>
            <input type="text" name="Current_Status" list="Current"> <br>

            <label>Vendor:</label>
            <input type="text" name="Vendor" list="PI"> <br>

            <label>Customer:</label>
            <input type="text" name="Name" list="Customer" required> <br>

            <label>Country:</label>
            <input type="text" name="Country" list="Country"> <br>

            <label>Description:</label>
            <input type="text" name="Description" list="Desc" required> <br>

            <label>Rev:</label>
            <input type="text" name="Rev" list="Rev"> <br>

            <label>IMDS Number:</label>
            <input type="text" name="IMDS_Number" list="IMDS"> <br>

            <label>IMDS Status:</label>
            <input type="text" name="IMDS_Status" list="IS"> <br>

            <label>PPAP docs:</label>
            <input type="text" name="PPAP_docs" list="PD"> <br>

            <label>Level:</label>
            <input type="text" name="Level" list="Level"> <br>

            <label>PPAP samples status:</label>
            <input type="text" name="Samples_Status" list="PSS"> <br>

            <label>Reason of Submission:</label>
            <input type="text" name="Reason_submission" list="RS" required> <br>

            <label>Sent to Customer:</label>
            <input type="date" name="Sent_Customer" id=""> <br>

            <label>PSW returned from Cust Signed:</label>
            <input type="date" name="PSW_Returned" id=""> <br>

            <label>Origin from report:</label required>
            <div>
                <input type="radio" name="Origin_from_report" value="no" checked> No 
            </div>
            <div>
                <input type="radio" name="Origin_from_report" value="**"> Yes 
            </div> <br>

            <label>Comments:</label>
            <textarea name="Comments"></textarea> <br>

            <label>Inspection Report Number:</label>
            <input type="text" name="Inspection_rep_numb" list="IRN">

            <button type="submit">Save</button>
        </form>
    </div>
    </div>
<?php }

if ($descError != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Error</h2>
        <form action="?page=Tubes" method="post">
            <h6><b>The description "<?php echo $_POST['Description']; ?>" doesn't exist.</b></h6>
        </form>
    </div>
    </div>
<?php } 

if ($custError != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Error</h2>
        <form action="?page=Tubes" method="post">
            <h6><b>The customer's name "<?php echo $_POST['Name']; ?>" doesn't exist.</b></h6>
        </form>
    </div>
    </div>
<?php } 

if ($dcError != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Error</h2>
        <form action="?page=Tubes" method="post">
            <h6><b>The description "<?php echo $_POST['Description']; ?>" and the customer's name "<?php echo $_POST['Name']; ?>" don't exist.</b></h6>
        </form>
    </div>
    </div>
<?php } 

if ($NocpnError != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Error</h2>
        <form action="?page=Tubes" method="post">
            <h6><b>Customer's PN doesn't exist.</b></h6>
        </form>
    </div>
    </div>
<?php }

if (isset($_POST['insertET'])) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Register New PPAP</h2>
        <form action="?page=Tubes" method="post">
            <input type="hidden" name="confirmIE" value="1">
            <label>PPAP Number:</label>
            <input type="text" name="PPAP_Number" list="PPAPN" required> <br>

            <label>PPAP Req'd by Customer:</label>
            <input type="date" name="PPAP_Req_by_Cus_Date"> <br>

            <label>Current Status:</label>
            <input type="text" name="Current_Status" list="Current"> <br>

            <label>Vendor:</label>
            <input type="text" name="Vendor" list="PI"> <br>

            <label>Customer:</label>
            <input type="text" name="Name" list="Customer" required> <br>

            <label>Country:</label>
            <input type="text" name="Country" list="Country"> <br>

            <label>Eurotech PN:</label>
            <input type="text" name="TUB_Eurotech_PN" list="ETPN" required> <br>

            <label>Rev:</label>
            <input type="text" name="Rev" list="Rev"> <br>

            <label>IMDS Number:</label>
            <input type="text" name="IMDS_Number" list="IMDS"> <br>

            <label>IMDS Status:</label>
            <input type="text" name="IMDS_Status" list="IS"> <br>

            <label>PPAP docs:</label>
            <input type="text" name="PPAP_docs" list="PD"> <br>

            <label>Level:</label>
            <input type="text" name="Level" list="Level"> <br>

            <label>PPAP samples status:</label>
            <input type="text" name="Samples_Status" list="PSS"> <br>

            <label>Reason of Submission:</label>
            <input type="text" name="Reason_submission" list="RS" required> <br>

            <label>Sent to Customer:</label>
            <input type="date" name="Sent_Customer" id=""> <br>

            <label>PSW returned from Cust Signed:</label>
            <input type="date" name="PSW_Returned" id=""> <br>

            <label>Origin from report:</label required>
            <div>
                <input type="radio" name="Origin_from_report" value="no" checked> No 
            </div>
            <div>
                <input type="radio" name="Origin_from_report" value="**"> Yes 
            </div> <br>

            <label>Comments:</label>
            <textarea name="Comments"></textarea> <br>

            <label>Inspection Report Number:</label>
            <input type="text" name="Inspection_rep_numb" list="IRN">

            <button type="submit">Save</button>
        </form>
    </div>
    </div>
<?php }

if ($ecError != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Error</h2>
        <form action="?page=Tubes" method="post">
            <input type="hidden" name="insertET" value="1">
            <h6><b>The Eurotech PN "<?php echo $_POST['TUB_Eurotech_PN']; ?>" and the customer's name "<?php echo $_POST['Name']; ?>" don't exist.</b></h6>
        </form>
    </div>
    </div>
<?php } 

if ($etpnError != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Error</h2>
        <form action="?page=Tubes" method="post">
            <input type="hidden" name="insertET" value="1">
            <h6><b>The Eurotech PN "<?php echo $_POST['TUB_Eurotech_PN']; ?>" doesn't exist.</b></h6>
        </form>
    </div>
    </div>
<?php } 

if (isset($_POST['insertC'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New PPAP</h2>
    <form action="?page=Tubes" method="post">
        <input type="hidden" name="confirmIC" value="1">
        <label>PPAP Number:</label>
        <input type="text" name="PPAP_Number" list="PPAPN" required> <br>

        <label>PPAP Req'd by Customer:</label>
        <input type="date" name="PPAP_Req_by_Cus_Date"> <br>

        <label>Current Status:</label>
        <input type="text" name="Current_Status" list="Current"> <br>

        <label>Vendor:</label>
        <input type="text" name="Vendor" list="PI"> <br>

        <label>Customer PN:</label>
        <input type="text" name="TUB_Customer_PN" list="CPN" required> <br>

        <label>Country:</label>
        <input type="text" name="Country" list="Country"> <br>

        <label>Rev:</label>
        <input type="text" name="Rev" list="Rev"> <br>

        <label>IMDS Number:</label>
        <input type="text" name="IMDS_Number" list="IMDS"> <br>

        <label>IMDS Status:</label>
        <input type="text" name="IMDS_Status" list="IS"> <br>

        <label>PPAP docs:</label>
        <input type="text" name="PPAP_docs" list="PD"> <br>

        <label>Level:</label>
        <input type="text" name="Level" list="Level"> <br>

        <label>PPAP samples status:</label>
        <input type="text" name="Samples_Status" list="PSS"> <br>

        <label>Reason of Submission:</label>
        <input type="text" name="Reason_submission" list="RS" required> <br>

        <label>Sent to Customer:</label>
        <input type="date" name="Sent_Customer" id=""> <br>

        <label>PSW returned from Cust Signed:</label>
        <input type="date" name="PSW_Returned" id=""> <br>

        <label>Origin from report:</label required>
        <div>
            <input type="radio" name="Origin_from_report" value="no" checked> No 
        </div>
        <div>
            <input type="radio" name="Origin_from_report" value="**"> Yes 
        </div> <br>

        <label>Comments:</label>
        <textarea name="Comments"></textarea> <br>

        <label>Inspection Report Number:</label>
        <input type="text" name="Inspection_rep_numb" list="IRN">

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php }

if ($cpnError != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Error</h2>
        <form action="?page=Tubes" method="post">
            <h6><b>The customer's PN "<?php echo $_POST['TUB_Customer_PN']; ?>" doesn't exist.</b></h6>
        </form>
    </div>
    </div>
<?php } 

if (isset($_POST['edit'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Update PPAP</h2>
    <form action="?page=Tubes" method="post">
        <input type="hidden" name="confirmU" value="1">
        <label>PPAP Req'd by Customer:</label>
        <input type="date" name="PPAP_Req_by_Cus_Date" value="<?php echo $tubeData['PPAP_Req_by_Cus_Date']; ?>"> <br>

        <label>Current Status:</label>
        <input type="text" name="Current_Status" list="Current" value="<?php echo $tubeData['Current_Status']; ?>"> <br>

        <label>Vendor:</label>
        <input type="text" name="Vendor" list="PI"> <br>

        <label>Country:</label>
        <input type="text" name="Country" list="Country"> <br>

        <label>Rev:</label>
        <input type="text" name="Rev" list="Rev" value="<?php echo $tubeData['Rev']; ?>"> <br>

        <label>IMDS Number:</label>
        <input type="text" name="IMDS_Number" list="IMDS" value="<?php echo $tubeData['IMDS_Number']; ?>"> <br>

        <label>IMDS Status:</label>
        <input type="text" name="IMDS_Status" list="IS" value="<?php echo $tubeData['IMDS_Status']; ?>"> <br>

        <label>PPAP docs:</label>
        <input type="text" name="PPAP_docs" list="PD" value="<?php echo $tubeData['PPAP_docs']; ?>"> <br>

        <label>Level:</label>
        <input type="text" name="Level" list="Level" value="<?php echo $tubeData['Level']; ?>"> <br>

        <label>PPAP samples status:</label>
        <input type="text" name="Samples_Status" list="PSS" value="<?php echo $tubeData['Samples_Status']; ?>"> <br>

        <label>Reason of Submission:</label>
        <input type="text" name="Reason_submission" list="RS" value="<?php echo $tubeData['Reason_submission']; ?>" required> <br>

        <label>Sent to Customer:</label>
        <input type="date" name="Sent_Customer" value="<?php echo $tubeData['Sent_Customer']; ?>"> <br>

        <label>PSW returned from Cust Signed:</label>
        <input type="date" name="PSW_Returned" value="<?php echo $tubeData['PSW_Returned']; ?>"> <br>

        <label>Origin from report:</label required>
        <div>
            <input type="radio" name="Origin_from_report" value="no" <?php if($tubeData['Origin_from_report'] == NULL) { echo 'checked';} ?>> No 
        </div>
        <div>
            <input type="radio" name="Origin_from_report" value="**" <?php if($tubeData['Origin_from_report'] != NULL) { echo 'checked';} ?>> Yes 
        </div> <br>

        <label>Comments:</label>
        <textarea name="Comments"><?php echo $tubeData['Comments']; ?></textarea> <br>

        <label>Inspection Report Number:</label>
        <input type="text" name="Inspection_rep_numb" list="IRN" value="<?php echo $tubeData['Inspection_rep_numb']; ?>">

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php }

if (isset($_POST['delete'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Delete PPAP</h2>
    <form action="?page=Tubes" method="post">
        <input type="hidden" name="confirmD" value="1">
        <!-- <input type="hidden" name="id_animal" value="<?php // $_POST['eliminar'] ?>" required> <br> -->
        <h5>Are you sure you want to delete the data of this PPAP?</h5> <br>
        <h6>Days to Submit : ...</h6>
        <h6>PPAP Number : ...</h6>
        <h6>PPAP Req'd by Customer : ...</h6>
        <h6>Current Status : ...</h6>
        <h6>Vendor : ...</h6>
        <h6>Customer : ...</h6>
        <h6>Country : ...</h6>
        <h6>Customer PN : ...</h6>
        <h6>ET Model : ...</h6>
        <h6>ET Dwg : ...</h6>
        <h6>Rev : ...</h6>
        <h6>ET PN : ...</h6>
        <h6>Description : ...</h6>
        <h6>IMDS Number : ...</h6>
        <h6>IMDS Status : ...</h6>
        <h6>PPAP do : ...</h6>
        <h6>Level : ...</h6>
        <h6>PPAP samples status : ...</h6>
        <h6>Reason of submission : ...</h6>
        <h6>Sent to Customer : ...</h6>
        <h6>PSW returned from Cust Signed : ...</h6>
        <h6> Origin from report : ...</h6>
        <h6> Comments : ...</h6>
        <h6> Inspection Report Number : ...</h6>
        <button type="submit">Confirm</button>
    </form>
  </div>
</div>
<?php } ?>

<script>
    function closeForm() {
        document.getElementById('formularioModal').style.display = 'none';
    }

    function sendForm() {
        closeForm();
        return true;
    }

    function clearForm() {
        document.querySelectorAll("#form input[type='text']").forEach(input => input.value = "");
        document.querySelectorAll("#form input[type='number']").forEach(input => input.value = "");
        document.querySelectorAll("#form input[type='date']").forEach(input => input.value = "");

        const radioButtons = document.querySelectorAll("#form input[type='radio']");
        const defaultValue = '';

        for (const radio of radioButtons) {
            if (radio.value === defaultValue) {
                radio.checked = true;
            }
        }
    }
</script>