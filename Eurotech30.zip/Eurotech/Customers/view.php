<link href="./css/style.css" rel="stylesheet">
<style>
    details {
        background-color: #ffffff;
        border: 1px solid #d1d5db;
        border-radius: 10px;
        padding: 0.75rem 1rem;
        margin-bottom: 1rem;
    }

    details[open] {
        background-color: #ffffff;
        border-color: #9ca3af;
    }

    summary {
        cursor: pointer;
        font-size: 18px;
        font-weight: 600;
        color: #374151;
        list-style: none;
        display: flex;
        align-items: center;
    }

    summary::marker {
        display: none;
    }

    summary::after {
        content: "▸";
        font-size: 25px;
        margin-left: auto;
        color: #6b7280;
        transition: transform 0.3s ease;
    }

    details[open] summary::after {
        transform: rotate(90deg);
    }

    details summary:hover {
        color: #111827;
    }

    tr {
        border: 0.1px solid black;
    }
    
    .clear {
        color: white;
        padding: 8px 14px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
        transition: background-color 0.2s;
        font-size: 14px;
        background-color: #16bacfff;
    }

    .clear:hover {
        background-color: #1dd1e8ff;
        color: white;
    }

    .error {
        background-color: #ffe6e6;
        color: #d63031;
        padding: 10px;
        border-radius: 8px;
        margin-bottom: 15px;
        font-size: 0.9rem;
    }

    .form-search .camp {
        flex: 1 1 30%;
        min-width: 250px;
    }

    .form-search input[type="date"]{
        padding: 8px 10px;
        border: 1px solid #bbb;
        border-radius: 8px;
        width: 46%;
        box-sizing: border-box;
    }

    @media (max-width: 1630px) {
        .note {
            padding: 15px 10px;
        }
    }
    
    @media (max-width: 1300px) {
        .form-search .camp
        {
            flex: 1 1 40%;
        }
    }

    @media (max-width: 900px) {
        .form-search .camp
        {
            flex: 1 1 100%;
        }
    }
</style>
<?php $_SESSION["Search"] = $_COOKIE['open']; ?>
<details id="details"<?php if(isset($_SESSION["Search"]) && $_SESSION["Search"] == "Open") { echo "open"; } if(isset($_SESSION["Search"]) && $_SESSION["Search"] == "Close") { echo ""; } if(!isset($_SESSION["Search"])) { echo "open"; }?>>  
    <summary style="font-size: 20px;">Search Form</summary>
    <form action="" id="form" method="post" class="form-search">
        <input type="hidden" name="page" value="Customers">
        <div class="camp">
            <label>Customer ID:</label>
            <input type="text" maxlength="10" name="idsearch" list="IDs" value="<?php if ($idsearch != NULL) { echo $idsearch;} ?>">
            <datalist id="IDs">
                <?php foreach ($IDs as $ID) {  ?>
                    <option value="<?php echo $ID['Customer_ID'] ?>">
                <?php } ?>
            </datalist>
        </div>

        <div class="camp">
            <label>Customer:</label>
            <input type="text" maxlength="70" name="custsearch" list="Customer" value="<?php if ($custsearch != NULL) { echo $custsearch;} ?>">
            <datalist id="Customer">
                <?php foreach ($Customers as $Customer) {  ?>
                    <option value="<?php echo $Customer['Name'] ?>">
                <?php } ?>
            </datalist>
        </div>

        <div class="camp">
            <label>IMDS ID No.:</label>
            <input type="text" maxlength="8" name="imdssearch" list="IMDS" value="<?php if ($imdssearch != NULL) { echo $imdssearch;} ?>">
            <datalist id="IMDS">
                <?php foreach ($IMDSs as $IMDS) {  ?>
                    <option value="<?php echo $IMDS['IMDS_ID_no'] ?>">
                <?php } ?>
            </datalist>
        </div>

        <div class="camp">
            <label>Products:</label>
            <input type="checkbox" name="bssearch" value="1" <?php if (isset($bssearch) && $bssearch == "1") { echo "checked";} if(isset($_POST['bssearch']) && $_POST['bssearch'] == 'N') { echo "unchecked"; } if($bssearch == NULL) { echo "checked"; }?>> BluSeal
            <br> <input type="checkbox" name="cabsearch" value="1" <?php if (isset($cabsearch) && $cabsearch == "1") { echo "checked";} if(isset($_POST['cabsearch']) && $_POST['cabsearch'] == 'N') { echo "unchecked"; } if($cabsearch == NULL) { echo "checked"; }?>> Cables
            <br> <input type="checkbox" name="tapsearch" value="1" <?php if (isset($tapsearch) && $tapsearch == "1") { echo "checked";} if(isset($_POST['tapsearch']) && $_POST['tapsearch'] == 'N') { echo "unchecked"; } if($tapsearch == NULL) { echo "checked"; }?>> Tapes
            <br> <input type="checkbox" name="tubsearch" value="1" <?php if (isset($tubsearch) && $tubsearch == "1") { echo "checked";} if(isset($_POST['tubsearch']) && $_POST['tubsearch'] == 'N') { echo "unchecked"; } if($tubsearch == NULL) { echo "checked"; }?>> Tubes
        </div>

        <div class="camp"></div>
        <div class="camp"></div>
        
        <div class="campbtn">
            <button type="submit" name="btnsearch" class="insert">Search</button>
            <button style="margin: 0px 0px 0px 15px;"  type="submit" name="btnsearch" class="clear" onclick="clearForm()">Clear All</button>
        </div>
    </form>
</details>
<br>
<div style="display: flex;">
    <form action="?page=Customers" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insert" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="idsearch" value="<?php if(isset($_POST['idsearch'])) { echo $_POST['idsearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="bssearch" value="<?php if(isset($_POST['bssearch'])) { echo $_POST['bssearch']; } ?>">
        <input type="hidden" name="cabsearch" value="<?php if(isset($_POST['cabsearch'])) { echo $_POST['cabsearch']; } ?>">
        <input type="hidden" name="tapsearch" value="<?php if(isset($_POST['tapsearch'])) { echo $_POST['tapsearch']; } ?>">
        <input type="hidden" name="tubsearch" value="<?php if(isset($_POST['tubsearch'])) { echo $_POST['tubsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <button type="submit" class="insert">New Customer</button>
    </form>
</div>

<?php if($logs == NULL) { ?>
    <br>
    <h1>No results.</h1>
<?php } ?>

<?php if($logs != NULL) { ?>
    <div class="table-responsive">
        <table class="table table-bordered" id="Customer_table">
            <tr>    
                <th style="background-color:#1c18AA;"></th>
                <th style="background-color:#1c18AA;"></th>
                <th style="background-color:#1c18AA; color:white" onclick="sortTable(2, 'text')">Customer ID</th>
                <th style="background-color:#1c18AA; color:white" onclick="sortTable(3, 'text')">Customer</th>
                <th style="background-color:#1c18AA; color:white" onclick="sortTable(4, 'text')">IMDS ID No.</th>
                <th style="background-color:#1c18AA; color:white" onclick="sortTable(5, 'text')">Products</th>
            </tr>
            
            <?php foreach ($logs as $log) { ?>
                <tr>
                    <td style="text-align: center; vertical-align: middle;">
                        <form action="?page=Customers" method="post" style="display:inline;">
                            <input type="hidden" name="edit" value="">
                            <input type="hidden" name="btnsearch" value="1">
                            <input type="hidden" name="idsearch" value="<?php if(isset($_POST['idsearch'])) { echo $_POST['idsearch']; } ?>">
                            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                            <input type="hidden" name="bssearch" value="<?php if(isset($_POST['bssearch'])) { echo $_POST['bssearch']; } ?>">
                            <input type="hidden" name="cabsearch" value="<?php if(isset($_POST['cabsearch'])) { echo $_POST['cabsearch']; } ?>">
                            <input type="hidden" name="tapsearch" value="<?php if(isset($_POST['tapsearch'])) { echo $_POST['tapsearch']; } ?>">
                            <input type="hidden" name="tubsearch" value="<?php if(isset($_POST['tubsearch'])) { echo $_POST['tubsearch']; } ?>">
                            <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                            <input type="hidden" name="IDedit" value="<?php echo $log['Customer_ID']; ?>">
                            <button type="submit" class="editar">Edit</button>
                        </form>
                    </td>
                    <td style="text-align: center; vertical-align: middle;">
                        <form action="?page=Customers" method="post" style="display:inline;">
                            <input type="hidden" name="delete" value="">
                            <input type="hidden" name="btnsearch" value="1">
                            <input type="hidden" name="idsearch" value="<?php if(isset($_POST['idsearch'])) { echo $_POST['idsearch']; } ?>">
                            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                            <input type="hidden" name="bssearch" value="<?php if(isset($_POST['bssearch'])) { echo $_POST['bssearch']; } ?>">
                            <input type="hidden" name="cabsearch" value="<?php if(isset($_POST['cabsearch'])) { echo $_POST['cabsearch']; } ?>">
                            <input type="hidden" name="tapsearch" value="<?php if(isset($_POST['tapsearch'])) { echo $_POST['tapsearch']; } ?>">
                            <input type="hidden" name="tubsearch" value="<?php if(isset($_POST['tubsearch'])) { echo $_POST['tubsearch']; } ?>">
                            <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                            <input type="hidden" name="IDdelete" value="<?php echo $log['Customer_ID']; ?>">
                            <button type="submit" class="eliminar">Delete</button>
                        </form>
                    </td>
                    <td><?php echo $log['Customer_ID']; ?></td>
                    <td><?php echo $log['Name']; ?></td>
                    <td><?php echo $log['IMDS_ID_no']; ?></td>
                    <td><?php echo $log['Products']; ?></td>
                </tr> 
            <?php } ?>
        </table> 
    </div>
<?php } 

 if (isset($_POST['insert'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New Customer</h2>
    <?php if (isset($error)) : ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form action="?page=Customers" method="post">
        <input type="hidden" name="confirmI" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="idsearch" value="<?php if(isset($_POST['idsearch'])) { echo $_POST['idsearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="bssearch" value="<?php if(isset($_POST['bssearch'])) { echo $_POST['bssearch']; } ?>">
        <input type="hidden" name="cabsearch" value="<?php if(isset($_POST['cabsearch'])) { echo $_POST['cabsearch']; } ?>">
        <input type="hidden" name="tapsearch" value="<?php if(isset($_POST['tapsearch'])) { echo $_POST['tapsearch']; } ?>">
        <input type="hidden" name="tubsearch" value="<?php if(isset($_POST['tubsearch'])) { echo $_POST['tubsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <label><label style="color:red">*</label> Customer ID:</label>
        <input type="text" maxlength="10" name="Customer_ID" value="<?php if(isset($_POST['Customer_ID'])) { echo $_POST['Customer_ID']; } ?>" required> <br>

        <label><label style="color:red">*</label> Customer:</label>
        <input type="text" maxlength="70" name="Name" value="<?php if(isset($_POST['Name'])) { echo $_POST['Name']; } ?>" required> <br>

        <label>IMDS ID No.:</label>
        <input type="text" maxlength="8" name="IMDS_ID_no" value="<?php if(isset($_POST['IMDS_ID_no'])) { echo $_POST['IMDS_ID_no']; } ?>"> <br>
        
        <label><label style="color:red">*</label> Products:</label>
        <?php foreach ($Products as $Prod) {  ?>
            <div>
                <input style="width: 10px;" type="checkbox" name="<?php echo $Prod; ?>" value="<?php echo $Prod; ?>"  <?php if(isset($_POST[$Prod])) { echo "checked";  } ?>> <?php echo $Prod ?>
            </div>
        <?php } ?>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if (isset($_POST['edit'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Update Customer</h2>
    <?php if (isset($error)) : ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form action="?page=Customers" method="post">
        <input type="hidden" name="confirmU" value="1">
        <input type="hidden" name="Customer_ID" value="<?php if(isset($_POST['Customer_ID'])) { echo $_POST['Customer_ID']; } else { echo $_POST['IDedit']; } ?>">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="idsearch" value="<?php if(isset($_POST['idsearch'])) { echo $_POST['idsearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="bssearch" value="<?php if(isset($_POST['bssearch'])) { echo $_POST['bssearch']; } ?>">
        <input type="hidden" name="cabsearch" value="<?php if(isset($_POST['cabsearch'])) { echo $_POST['cabsearch']; } ?>">
        <input type="hidden" name="tapsearch" value="<?php if(isset($_POST['tapsearch'])) { echo $_POST['tapsearch']; } ?>">
        <input type="hidden" name="tubsearch" value="<?php if(isset($_POST['tubsearch'])) { echo $_POST['tubsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <label><label style="color:red">*</label> Customer:</label>
        <input type="text" maxlength="70" name="Name" value="<?php if(isset($customerData['Name'])) { echo $customerData['Name']; } else { echo $_POST['Name']; } ?>" required> <br>

        <label>IMDS ID No.:</label>
        <input type="text" maxlength="8" name="IMDS_ID_no" value="<?php if(isset($customerData['IMDS_ID_no'])) { echo $customerData['IMDS_ID_no']; } else { if(isset($_POST['IMDS_ID_no'])) { echo $_POST['IMDS_ID_no']; } } ?>"> <br>
        
        <label><label style="color:red">*</label> Products:</label>
        <?php if(isset($productsData)) {
            $AllProducts = [];
            foreach ($Products as $Prod) {  
                $AllProducts[] = $Prod;
            }
            for($i = 0; $i < count($AllProducts); $i++) {
                if(str_contains($productsData['Products'], $AllProducts[$i])) { ?>
                    <div>
                        <input style="width: 10px;" type="checkbox" name="<?php echo $AllProducts[$i]; ?>" value="<?php echo $AllProducts[$i]; ?>" checked disabled> <?php echo $AllProducts[$i] ?>
                        <input type="hidden" name="<?php echo $AllProducts[$i]; ?>" value="<?php echo $AllProducts[$i]; ?>">
                    </div>
                <?php }
                else { ?>
                    <div>
                        <input style="width: 10px;" type="checkbox" name="<?php echo $AllProducts[$i]; ?>" value="<?php echo $AllProducts[$i]; ?>"> <?php echo $AllProducts[$i] ?>
                    </div>
                <?php }
            }
        } 
        else {
            $AllProducts = [];
            foreach ($Products as $Prod) {  
                $AllProducts[] = $Prod;
            }
            for($i = 0; $i < count($AllProducts); $i++) {
                if(isset($_POST[$AllProducts[$i]])) {
                    if(str_contains($_POST[$AllProducts[$i]], $AllProducts[$i])) { ?>
                        <div>
                            <input style="width: 10px;" type="checkbox" name="<?php echo $AllProducts[$i]; ?>" value="<?php echo $AllProducts[$i]; ?>" checked disabled> <?php echo $AllProducts[$i] ?>
                            <input type="hidden" name="<?php echo $AllProducts[$i]; ?>" value="<?php echo $AllProducts[$i]; ?>">
                        </div>
                    <?php }
                }
                else { ?>
                    <div>
                        <input style="width: 10px;" type="checkbox" name="<?php echo $AllProducts[$i]; ?>" value="<?php echo $AllProducts[$i]; ?>"> <?php echo $AllProducts[$i] ?>
                    </div>
                <?php }
            }
    
        } ?>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php }

if (isset($_POST['delete'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Delete Customer</h2>
    

    <form action="?page=Customers" method="post">
        <input type="hidden" name="confirmD" value="1">
        <input type="hidden" name="Customer_ID" value="<?php if(isset($_POST['Customer_ID'])) { echo $_POST['Customer_ID']; } else { echo $_POST['IDdelete']; } ?>">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="idsearch" value="<?php if(isset($_POST['idsearch'])) { echo $_POST['idsearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="bssearch" value="<?php if(isset($_POST['bssearch'])) { echo $_POST['bssearch']; } ?>">
        <input type="hidden" name="cabsearch" value="<?php if(isset($_POST['cabsearch'])) { echo $_POST['cabsearch']; } ?>">
        <input type="hidden" name="tapsearch" value="<?php if(isset($_POST['tapsearch'])) { echo $_POST['tapsearch']; } ?>">
        <input type="hidden" name="tubsearch" value="<?php if(isset($_POST['tubsearch'])) { echo $_POST['tubsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <h5><b>Are you sure you want to delete the data of this Customer?</b></h5> 
        <?php if (!isset($error)) : ?>
            <br>
        <?php endif; ?>
        <?php if (isset($error)) : ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>
        <h6><b>Customer ID:</b> <?php echo $customerDataD['Customer_ID'] ?></h6>
        <h6><b>Customer:</b> <?php echo $customerDataD['Name'] ?></h6>
        <h6><b>IMDS ID No.:</b> <?php echo $customerDataD['IMDS_ID_no'] ?></h6>
        <h6><b>Products:</b> <?php echo $customerDataD['Products'] ?></h6>

        <button type="submit">Confirm</button>
    </form>
  </div>
</div>
<?php }

if ($Deleted != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Register Deleted</h2>
        
        <form action="?page=Customers" method="post">
            <h6><b>The register was deleted correctly.</b></h6>
        </form>
    </div>
    </div>
<?php }   ?>

<script>
    function closeForm() {
        document.getElementById('formularioModal').style.display = 'none';
    }

    function sendForm() {
        closeForm();
        return true;
    }

    function clearForm() {
        document.querySelectorAll("#form input[type='text']").forEach(input => input.value = "");
        document.querySelectorAll("#form input[type='date']").forEach(input => input.value = "");

        const radioButtons = document.querySelectorAll("#form input[type='radio']");
        const defaultValue = '';

        for (const radio of radioButtons) {
            if (radio.value === defaultValue) {
                radio.checked = true;
            }
        }

        const selects = document.querySelectorAll("#form select");

        for (const select of selects) {
            select.value = defaultValue;
        }
        
        const checks = document.querySelectorAll("#form input[type='checkbox']");
        
        for (const check of checks) {
            check.checked = true;
        }
    }

    let sortOrder = {};

    function sortTable(columnIndex, type) {
        const table = document.getElementById("Customer_table");
        const rows = Array.from(table.rows).slice(1);
        const isAscending = !sortOrder[columnIndex];
        
        rows.sort((rowA, rowB) => {
            const cellA = rowA.cells[columnIndex].innerText.trim();
            const cellB = rowB.cells[columnIndex].innerText.trim();
            
            if (type === "date") {
                const dateA = new Date(cellA);
                const dateB = new Date(cellB);
                const options = { year: 'numeric', month: 'short', day: '2-digit' };
                const dateformatedA = dateA.toLocaleDateString('en-GB', options);
                const dateformatedB = dateB.toLocaleDateString('en-GB', options);
                return isAscending ? dateformatedA.localeCompare(dateformatedB) : dateformatedB.localeCompare(dateformatedA);
            } else if (type === "text") {
                return isAscending ? cellA.localeCompare(cellB) : cellB.localeCompare(cellA);
            }
        });

        rows.forEach(row => table.tBodies[0].appendChild(row));
        sortOrder[columnIndex] = isAscending;
    }

    const details = document.getElementById("details");
    details.addEventListener("toggle", () => { 
        if (details.open) {
            document.cookie = "open=Open";
        } 
        else {
            document.cookie = "open=Close";
        }
    });
</script>