<?php 
    include "model.php";

    $model = new model();
    $model->cn();
    $logsTapes = [];
    $logsBluSeal = [];
    $logsCables = [];
    $Renewlogs = [];
    $NRenewlogs = [];
    $MaxYears = [];
    $MaxYs = [];
    $Regs = [];
    $dates = [];
    $datesNULL = [];

    if (isset($_POST["submit1search"]) && isset($_POST["submit2search"])){
        $submit1search = $_POST["submit1search"];
        $submit2search = $_POST["submit2search"];
    }    
    else {
        $submit1search = "";
        $submit2search = "";
    }

    if (isset($_POST["days1search"]) && isset($_POST["days2search"])){
        $days1search = $_POST["days1search"];
        $days2search = $_POST["days2search"];
    }    
    else {
        $days1search = "";
        $days2search = "";
    }

    if (isset($_POST["ppapnsearch"])){
        $ppapnsearch = $_POST["ppapnsearch"];
    }    
    else {
        $ppapnsearch = "";
    }

    if (isset($_POST["date1search"]) && isset($_POST["date2search"])){
        $date1search = $_POST["date1search"];
        $date2search = $_POST["date2search"];
    }    
    else {
        $date1search = "";
        $date2search = "";
    }

    if (isset($_POST["req1n"])){
        $req1n = $_POST["req1n"];
    }    
    else {
        $req1n = NULL;
    }

    if (isset($_POST["reqv1search"]) && isset($_POST["reqv2search"])){
        $reqv1search = $_POST["reqv1search"];
        $reqv2search = $_POST["reqv2search"];
    }    
    else {
        $reqv1search = "";
        $reqv2search = "";
    }

    if (isset($_POST["reqvn"])){
        $reqvn = $_POST["reqvn"];
    }    
    else {
        $reqvn = NULL;
    }

    if (isset($_POST["currentsearch"])){
        $currentsearch = $_POST["currentsearch"];
    }    
    else {
        $currentsearch = "";
    }

    if (isset($_POST["curn"])){
        $curn = $_POST["curn"];
    }    
    else {
        $curn = NULL;
    }

    if (isset($_POST["pisearch"])){
        $pisearch = $_POST["pisearch"];
    }    
    else {
        $pisearch = "";
    }

    if (isset($_POST["sapsearch"])){
        $sapsearch = $_POST["sapsearch"];
    }    
    else {
        $sapsearch = NULL;
    }

    if (isset($_POST["oemsearch"])){
        $oemsearch = $_POST["oemsearch"];
    }    
    else {
        $oemsearch = NULL;
    }
    
    if (isset($_POST["custsearch"])){
        $custsearch = $_POST["custsearch"];
    }    
    else {
        $custsearch = NULL;
    }

    if (isset($_POST["cusn"])){
        $cusn = $_POST["cusn"];
    }    
    else {
        $cusn = NULL;
    }

    if (isset($_POST["counsearch"])){
        $counsearch = $_POST["counsearch"];
    }    
    else {
        $counsearch = NULL;
    }

    if (isset($_POST["cpnsearch"])){
        $cpnsearch = $_POST["cpnsearch"];
    }    
    else {
        $cpnsearch = NULL;
    }

    if (isset($_POST["etmsearch"])){
        $etmsearch = $_POST["etmsearch"];
    }    
    else {
        $etmsearch = "";
    }

    if (isset($_POST["etdsearch"])){
        $etdsearch = $_POST["etdsearch"];
    }    
    else {
        $etdsearch = "";
    }

    if (isset($_POST["revsearch"])){
        $revsearch = $_POST["revsearch"];
    }    
    else {
        $revsearch = "";
    }

    if (isset($_POST["etpnsearch"])){
        $etpnsearch = $_POST["etpnsearch"];
    }    
    else {
        $etpnsearch = "";
    }

    if (isset($_POST["descsearch"])){
        $descsearch = $_POST["descsearch"];
    }    
    else {
        $descsearch = "";
    }

    if (isset($_POST["imdssearch"])){
        $imdssearch = $_POST["imdssearch"];
    }    
    else {
        $imdssearch = NULL;
    }

    if (isset($_POST["imdn"])){
        $imdn = $_POST["imdn"];
    }    
    else {
        $imdn = NULL;
    }

    if (isset($_POST["issearch"])){
        $issearch = $_POST["issearch"];
    }    
    else {
        $issearch = "";
    }

    if (isset($_POST["imsn"])){
        $imsn = $_POST["imsn"];
    }    
    else {
        $imsn = NULL;
    }

    if (isset($_POST["levelsearch"])){
        $levelsearch = $_POST["levelsearch"];
    }    
    else {
        $levelsearch = NULL;
    }

    if (isset($_POST["lvln"])){
        $lvln = $_POST["lvln"];
    }    
    else {
        $lvln = NULL;
    }

    if (isset($_POST["psssearch"])){
        $psssearch = $_POST["psssearch"];
    }    
    else {
        $psssearch = "";
    }

    if (isset($_POST["pssn"])){
        $pssn = $_POST["pssn"];
    }    
    else {
        $pssn = NULL;
    }

    if (isset($_POST["rssearch"])){
        $rssearch = $_POST["rssearch"];
    }    
    else {
        $rssearch = "";
    }  

    if (isset($_POST["rosn"])){
        $rosn = $_POST["rosn"];
    }    
    else {
        $rosn = NULL;
    }

    if (isset($_POST["date3search"]) && isset($_POST["date4search"])){
        $date3search = $_POST["date3search"];
        $date4search = $_POST["date4search"];
    }    
    else {
        $date3search = "";
        $date4search = "";
    }

    if (isset($_POST["recn"])){
        $recn = $_POST["recn"];
    }    
    else {
        $recn = NULL;
    }

    if (isset($_POST["ret1search"]) && isset($_POST["ret2search"])){
        $ret1search = $_POST["ret1search"];
        $ret2search = $_POST["ret2search"];
    }    
    else {
        $ret1search = "";
        $ret2search = "";
    }

    if (isset($_POST["retn"])){
        $retn = $_POST["retn"];
    }    
    else {
        $retn = NULL;
    }

    if (isset($_POST["psw1search"]) && isset($_POST["psw2search"])){
        $psw1search = $_POST["psw1search"];
        $psw2search = $_POST["psw2search"];
    }    
    else {
        $psw1search = "";
        $psw2search = "";
    }

    if (isset($_POST["pscn"])){
        $pscn = $_POST["pscn"];
    }    
    else {
        $pscn = NULL;
    }

    if (isset($_POST["ren1search"]) && isset($_POST["ren2search"])){
        $ren1search = $_POST["ren1search"];
        $ren2search = $_POST["ren2search"];
    }    
    else {
        $ren1search = "";
        $ren2search = "";
    }

    if (isset($_POST["renn"])){
        $renn = $_POST["renn"];
    }    
    else {
        $renn = NULL;
    }

    if (isset($_POST["req1search"]) && isset($_POST["req2search"])){
        $req1search = $_POST["req1search"];
        $req2search = $_POST["req2search"];
    }    
    else {
        $req1search = "";
        $req2search = "";
    }

    if (isset($_POST["reqn"])){
        $reqn = $_POST["reqn"];
    }    
    else {
        $reqn = NULL;
    }

    if (isset($_POST["sent1search"]) && isset($_POST["sent2search"])){
        $sent1search = $_POST["sent1search"];
        $sent2search = $_POST["sent2search"];
    }    
    else {
        $sent1search = "";
        $sent2search = "";
    }

    if (isset($_POST["stcn"])){
        $stcn = $_POST["stcn"];
    }    
    else {
        $stcn = NULL;
    }

    if (isset($_POST["pswr1search"]) && isset($_POST["pswr2search"])){
        $pswr1search = $_POST["pswr1search"];
        $pswr2search = $_POST["pswr2search"];
    }    
    else {
        $pswr1search = "";
        $pswr2search = "";
    }

    if (isset($_POST["pcsn"])){
        $pcsn = $_POST["pcsn"];
    }    
    else {
        $pcsn = NULL;
    }

    if (isset($_POST["pfsn"])){
        $pfsn = $_POST["pfsn"];
    }    
    else {
        $pfsn = NULL;
    }

    if (isset($_POST["originsearch"])){
        $originsearch = $_POST["originsearch"];
    }    
    else {
        $originsearch = "";
    } 

    if (isset($_POST["comsearch"])){
        $comsearch = $_POST["comsearch"];
    }    
    else {
        $comsearch = NULL;
    }

    if (isset($_POST["irnsearch"])){
        $irnsearch = $_POST["irnsearch"];
    }    
    else {
        $irnsearch = "";
    } 

    if (isset($_POST["bssearch"])){
        $bssearch = $_POST["bssearch"];
    }    
    else {
        $bssearch = "";
    } 

    if (isset($_POST["cabsearch"])){
        $cabsearch = $_POST["cabsearch"];
    }    
    else {
        $cabsearch = "";
    } 

    if (isset($_POST["tapsearch"])){
        $tapsearch = $_POST["tapsearch"];
    }    
    else {
        $tapsearch = "";
    } 

    if (isset($_POST["tubsearch"])){
        $tubsearch = $_POST["tubsearch"];
    }    
    else {
        $tubsearch = "";
    } 

    $selects = [];
    $years = [];
    $params = [];
    $exist = NULL;
    $noteData = NULL;
    $ppapData = NULL;
    $cpnData = NULL;
    $custData = NULL;
    $venData = NULL;
    $supData = NULL;
    $etpnData = NULL;
    $descData = NULL;
    $sentData = NULL;
    $ppapDataD = NULL;
    $Deleted = NULL;


    $pdo = new PDO("mysql:host=localhost;dbname=eurotechdb", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        if (isset($_POST['note'])) {
            $id = $_POST['IDnote'];
            $stmt = $pdo->prepare("SELECT PPAP_ID, PPAP_ET, IMDS_ET FROM ppap WHERE PPAP_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $noteData = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmNote'])) {
            if(!isset($_POST['PPAP_ET']) &&  !isset($_POST['IMDS_ET'])) {
                $stmt = $pdo->prepare("UPDATE ppap SET 
                                        PPAP_ET = NULL, 
                                        IMDS_ET = NULL 
                                        WHERE PPAP_ID = ?");

                $stmt->execute([
                    $_POST['confirmIDNote']
                ]);
            }
            if(!isset($_POST['PPAP_ET']) && isset($_POST['IMDS_ET'])) {
                $stmt = $pdo->prepare("UPDATE ppap SET 
                                        PPAP_ET = NULL, 
                                        IMDS_ET = '1' 
                                        WHERE PPAP_ID = ?");

                $stmt->execute([
                    $_POST['confirmIDNote']
                ]);
            }
            if(isset($_POST['PPAP_ET']) && !isset($_POST['IMDS_ET'])) {
                $stmt = $pdo->prepare("UPDATE ppap SET 
                                        PPAP_ET = '1', 
                                        IMDS_ET = NULL
                                        WHERE PPAP_ID = ?");

                $stmt->execute([
                    $_POST['confirmIDNote']
                ]);
            }
            if(isset($_POST['PPAP_ET']) && isset($_POST['IMDS_ET']) ) {
                $stmt = $pdo->prepare("UPDATE ppap SET 
                                        PPAP_ET = '1', 
                                        IMDS_ET = '1'
                                        WHERE PPAP_ID = ?");

                $stmt->execute([
                    $_POST['confirmIDNote']
                ]);
            } 
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['confirmI'])) {
            $stmt = $pdo->prepare("SELECT p.Supplier_PN, c.`Name`, Customer_PN, Eurotech_PN, `Description` FROM customer_pn cpn
                                        INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                                        INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                        HAVING p.Supplier_PN = ? AND c.`Name` = ? AND Customer_PN = ? AND Eurotech_PN = ? AND `Description` = ?;");
            $stmt->execute([$_POST['Supplier_PN'], $_POST['Customer'], $_POST['Customer_PN'], $_POST['Eurotech_PN'], $_POST['Description']]);

            if ($stmt->rowCount() > 0) {
                $exist = $stmt->fetch(PDO::FETCH_ASSOC);
            }

            if($exist == NULL) {
                $_POST['insert'] = 1;
                $error = "The fields <b>'Supplier PN'</b>, <b>'Customer'</b>, <b>'Customer PN'</b>, <b>'Eurotech PN'</b> and <b>'Description'</b> don't match."; 
            }

            if(!isset($error)) {
                if(!empty($_POST['PPAP_Number'])) {
                    if(isset($_POST['PPAP_Number'][11])) {
                        $PP = $_POST['PPAP_Number'][0].''.$_POST['PPAP_Number'][1];
                        $hyphen = $_POST['PPAP_Number'][7];
                        if($PP == 'PP' && $hyphen == '-') {
                            $ID = explode("PP", $_POST['PPAP_Number']);
                            $ID_number = explode("-", $ID[1]);
                            if(ctype_digit($ID_number[0]) && ctype_digit($ID_number[1])) {
                                $inserts[] = "PPAP_Number";
                                $insertsR[] = "PPAP_Number";
                                $paramsI[] = "'".$_POST['PPAP_Number']."'";
                                $paramsIR[] = "'".$_POST['PPAP_Number']."'";
                            }
                            else {
                                $_POST['insert'] = 1;
                                $error = "PPAP Number must have the form 'PP00000-0000'.";
                            }
                        }
                        else {
                            $_POST['insert'] = 1;
                            $error = "PPAP Number must have the form 'PP00000-0000'.";
                        }
                    }
                    else {
                        $_POST['insert'] = 1;
                        $error = "PPAP Number must have the form 'PP00000-0000'.";
                    }                
                }

                if(!empty($_POST['PPAP_Request_Date'])) {
                    $inserts[] = "PPAP_Request_Date";
                    $paramsI[] = "'".$_POST['PPAP_Request_Date']."'";
                }

                if(!empty($_POST['PPAP_Requested_Vendor'])) {
                    $inserts[] = "PPAP_Requested_Vendor";
                    $paramsI[] = "'".$_POST['PPAP_Requested_Vendor']."'";
                }

                if(!empty($_POST['Current_Status'])) {
                    $inserts[] = "Current_Status";
                    $paramsI[] = "'".$_POST['Current_Status']."'";
                }

                if(!empty($_POST['OEM'])) {
                    $inserts[] = "OEM";
                    $insertsR[] = "OEM";
                    $paramsI[] = "'".$_POST['OEM']."'";
                    $paramsIR[] = "'".$_POST['OEM']."'";
                }

                if(!empty($_POST['Vendor'])) {
                    $stmt = $pdo->prepare("SELECT Vendor_ID FROM vendors
                                            WHERE Short_name = ?;");
                    $stmt->execute([$_POST['Vendor']]);

                    if ($stmt->rowCount() > 0) {
                        $venData = $stmt->fetch(PDO::FETCH_ASSOC);
                    }

                    if($venData == NULL) {
                        $_POST['insert'] = 1;
                        $error = "Vendor <b>".$_POST['Vendor']."</b> doesn't exist."; 
                    }
                    else {
                        $inserts[] = "FK_Vendor_ID";
                        $insertsR[] = "FK_Vendor_ID";
                        $paramsI[] = "'".$venData['Vendor_ID']."'";
                        $paramsIR[] = "'".$venData['Vendor_ID']."'";
                    }
                }

                if(!empty($_POST['Supplier_PN'])) {
                    $stmt = $pdo->prepare("SELECT Supplier_PN FROM products
                                            WHERE Supplier_PN = ?;");
                    $stmt->execute([$_POST['Supplier_PN']]);

                    if ($stmt->rowCount() > 0) {
                        $supData = $stmt->fetch(PDO::FETCH_ASSOC);
                    }

                    if($supData == NULL) {
                        $_POST['insert'] = 1;
                        $error = "Supplier PN <b>".$_POST['Supplier_PN']."</b> doesn't exist."; 
                    }
                }

                if(!empty($_POST['Customer'])) {
                    $stmt = $pdo->prepare("SELECT `Name` FROM customers
                                            HAVING `Name` = ?;");
                    $stmt->execute([$_POST['Customer']]);

                    if ($stmt->rowCount() > 0) {
                        $custData = $stmt->fetch(PDO::FETCH_ASSOC);
                    }

                    if($custData == NULL) {
                        $_POST['insert'] = 1;
                        $error = "Customer <b>".$_POST['Customer']."</b> doesn't exist."; 
                    }
                }

                if(!empty($_POST['Customer_PN'])) {
                    $stmt = $pdo->prepare("SELECT Customer_PN FROM customer_pn 
                                            HAVING Customer_PN = ?;");
                    $stmt->execute([$_POST['Customer_PN']]);

                    if ($stmt->rowCount() > 0) {
                        $cpnData = $stmt->fetch(PDO::FETCH_ASSOC);
                    }

                    if($cpnData != NULL) {
                        $inserts[] = "FK_Customer_PN";
                        $insertsR[] = "FK_Customer_PN";
                        $paramsI[] = "'".$_POST['Customer_PN']."'";
                        $paramsIR[] = "'".$_POST['Customer_PN']."'";
                    }
                    else {
                        $_POST['insert'] = 1;
                        $error = "Customer PN <b>".$_POST['Customer_PN']."</b> doesn't exist.";
                    }
                }

                if(!empty($_POST['Eurotech_PN'])) {
                    $stmt = $pdo->prepare("SELECT Eurotech_PN FROM products
                                            HAVING Eurotech_PN = ?;");
                    $stmt->execute([$_POST['Eurotech_PN']]);

                    if ($stmt->rowCount() > 0) {
                        $etpnData = $stmt->fetch(PDO::FETCH_ASSOC);
                    }

                    if($etpnData == NULL) {
                        $_POST['insert'] = 1;
                        $error = "Eurotech PN <b>".$_POST['Eurotech_PN']."</b> doesn't exist."; 
                    }
                }

                if(!empty($_POST['Description'])) {
                    $stmt = $pdo->prepare("SELECT `Description` FROM products
                                            HAVING `Description` = ?;");
                    $stmt->execute([$_POST['Description']]);

                    if ($stmt->rowCount() > 0) {
                        $descData = $stmt->fetch(PDO::FETCH_ASSOC);
                    }

                    if($descData == NULL) {
                        $_POST['insert'] = 1;
                        $error = "Description <b>".$_POST['Description']."</b> doesn't exist."; 
                    }
                }

                if(!empty($_POST['Rev'])) {
                    $inserts[] = "Rev";
                    $paramsI[] = "'".$_POST['Rev']."'";
                }

                if(!empty($_POST['IMDS'])) {
                    $inserts[] = "IMDS";
                    $insertsR[] = "IMDS";
                    $paramsI[] = "'".$_POST['IMDS']."'";
                    $paramsIR[] = "'".$_POST['IMDS']."'";
                }

                if(!empty($_POST['PPAP_Level']) && $_POST['PPAP_Level'] != '') {
                    $inserts[] = "PPAP_Level";
                    $insertsR[] = "PPAP_Level";
                    $paramsI[] = "'".$_POST['PPAP_Level']."'";
                    $paramsIR[] = "'".$_POST['PPAP_Level']."'";
                }

                if(!empty($_POST['Samples_Status'])) {
                    $inserts[] = "Samples_Status";
                    $paramsI[] = "'".$_POST['Samples_Status']."'";
                }

                if(!empty($_POST['Reason_Submission'])) {
                    $inserts[] = "Reason_Submission";
                    $paramsI[] = "'".$_POST['Reason_Submission']."'";
                }

                if(!empty($_POST['PPAP_Received_Date'])) {
                    $inserts[] = "PPAP_Received_Date";
                    $paramsI[] = "'".$_POST['PPAP_Received_Date']."'";
                }

                if(!empty($_POST['PPAP_Sent_Customer'])) {
                    $inserts[] = "PPAP_Sent_Customer";
                    $insertsR[] = "PPAP_Request_Date";
                    $paramsI[] = "'".$_POST['PPAP_Sent_Customer']."'";
                    $SC = new DateTime($_POST['PPAP_Sent_Customer']);
                    $renewal = $SC->modify('+10 months'); 
                    $result = $renewal->format('Y-m-d');
                    $paramsIR[] = "'".$result."'";
                }

                if(!empty($_POST['PPAP_Signed_Date'])) {
                    $inserts[] = "PPAP_Signed_Date";
                    $paramsI[] = "'".$_POST['PPAP_Signed_Date']."'";
                }

                if(!empty($_POST['PPAP_From_Shipments']) && $_POST['PPAP_From_Shipments'] != 'no') {
                    $inserts[] = "PPAP_From_Shipments";
                    $insertsR[] = "PPAP_From_Shipments";
                    $paramsI[] = "'".$_POST['PPAP_From_Shipments']."'";
                    $paramsIR[] = "'".$_POST['PPAP_From_Shipments']."'";
                }

                if(!empty($_POST['Comments'])) {
                    $inserts[] = "Comments";
                    $paramsI[] = "'".$_POST['Comments']."'";
                }

                if(!empty($_POST['Inspection_Rep_Number'])) {
                    $inserts[] = "Inspection_Rep_Number";
                    $paramsI[] = "'".$_POST['Inspection_Rep_Number']."'";
                }
                    
                if(!isset($error)) {
                    $stmt = $pdo->prepare("INSERT INTO ppap (". implode(', ', $inserts) .") 
                                                        VALUES (". implode(', ', $paramsI) .")");
                    $stmt->execute([]);
                
                    if(!empty($_POST['PPAP_Sent_Customer'])) {
                        $insertsR[] = "Reason_Submission";
                        $paramsIR[] = "'Renewal'";
                        
                        $stmt = $pdo->prepare("INSERT INTO ppap (". implode(', ', $insertsR) .") 
                                                        VALUES (". implode(', ', $paramsIR) .")");
                        $stmt->execute([]);
                    }
                }
            }

            $_SESSION['saved'] = true;
        }

        if (isset($_POST['edit'])) {
            $id = $_POST['IDedit'];
            $stmt = $pdo->prepare("SELECT DISTINCT
                                        ppap.*,
                                        cp.Customer_PN,
                                        p.*,
                                        c.`Name` AS 'Customer',
                                        c.IMDS_ID_no,
                                        v.`Name` AS 'Vendor',
                                        v.Short_name,
                                        cpn.*
                                    FROM products p
                                        LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
                                        LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                                        INNER JOIN ppap ON cp.Customer_PN = ppap.FK_Customer_PN
                                        LEFT JOIN vendors v ON ppap.FK_Vendor_ID = v.Vendor_ID
                                        LEFT JOIN customer_ppap_number cpn ON cpn.FK_Customer_ID = c.Customer_ID
                                    HAVING PPAP_ID = ?;");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $ppapData = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmU'])) {
            $id = $_POST['PPAP_ID'];

            $stmt = $pdo->prepare("SELECT p.Supplier_PN, c.`Name`, Customer_PN, Eurotech_PN, `Description` FROM customer_pn cpn
                                        INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                                        INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                        HAVING p.Supplier_PN = ? AND c.`Name` = ? AND Customer_PN = ? AND Eurotech_PN = ? AND `Description` = ?;");
            $stmt->execute([$_POST['Supplier_PN'], $_POST['Customer'], $_POST['Customer_PN'], $_POST['Eurotech_PN'], $_POST['Description']]);

            if ($stmt->rowCount() > 0) {
                $exist = $stmt->fetch(PDO::FETCH_ASSOC);
            }

            if($exist == NULL) {
                $_POST['edit'] = 1;
                $error = "The fields <b>'Supplier PN'</b>, <b>'Customer'</b>, <b>'Customer PN'</b>, <b>'Eurotech PN'</b> and <b>'Description'</b> don't match."; 
            }

            if(!isset($error)) {
                if(!empty($_POST['PPAP_Number'])) {
                    if(isset($_POST['PPAP_Number'][11])) {
                        $PP = $_POST['PPAP_Number'][0].''.$_POST['PPAP_Number'][1];
                        $hyphen = $_POST['PPAP_Number'][7];
                        if($PP == 'PP' && $hyphen == '-') {
                            $ID = explode("PP", $_POST['PPAP_Number']);
                            $ID_number = explode("-", $ID[1]);
                            if(ctype_digit($ID_number[0]) && ctype_digit($ID_number[1])) {
                                $pppapn = $_POST['PPAP_Number'];
                            }
                            else {
                                $_POST['edit'] = 1;
                                $error = "PPAP Number must have the form 'PP00000-0000'.";
                            }
                        }
                        else {
                            $_POST['edit'] = 1;
                            $error = "PPAP Number must have the form 'PP00000-0000'.";
                        }
                    }
                    else {
                        $_POST['edit'] = 1;
                        $error = "PPAP Number must have the form 'PP00000-0000'.";
                    }                
                }
                else {
                    $pppapn = NULL;
                }

                if($_POST['PPAP_Request_Date'] != "") {
                    $reqD = new DateTime($_POST['PPAP_Request_Date']);
                    $rqD = $reqD->format('Y-m-d');
                }
                else {
                    $rqD = NULL; 
                }

                if($_POST['PPAP_Requested_Vendor'] != "") {
                    $rqvD = new DateTime($_POST['PPAP_Requested_Vendor']);
                    $rvD = $rqvD->format('Y-m-d');
                }
                else {
                    $rvD = NULL; 
                }

                if($_POST['Current_Status'] != "") {
                    $curSt = $_POST['Current_Status'];
                }
                else {
                    $curSt = NULL; 
                }

                if($_POST['OEM'] != "") {
                    $oem = $_POST['OEM'];
                }
                else {
                    $oem = NULL; 
                }

                if(!empty($_POST['Vendor'])) {
                    $stmt = $pdo->prepare("SELECT Vendor_ID FROM vendors
                                            WHERE Short_name = ?;");
                    $stmt->execute([$_POST['Vendor']]);

                    if ($stmt->rowCount() > 0) {
                        $venData = $stmt->fetch(PDO::FETCH_ASSOC);
                    }

                    if($venData == NULL) {
                        $_POST['edit'] = 1;
                        $error = "Vendor <b>".$_POST['Vendor']."</b> doesn't exist."; 
                    }
                    else {
                        $vend = $venData['Vendor_ID'];
                    }
                }
                else {
                    $vend = NULL;
                }

                if(!empty($_POST['Supplier_PN'])) {
                    $stmt = $pdo->prepare("SELECT Supplier_PN FROM products
                                            WHERE Supplier_PN = ?;");
                    $stmt->execute([$_POST['Supplier_PN']]);

                    if ($stmt->rowCount() > 0) {
                        $supData = $stmt->fetch(PDO::FETCH_ASSOC);
                    }

                    if($supData == NULL) {
                        $_POST['edit'] = 1;
                        $error = "Supplier PN <b>".$_POST['Supplier_PN']."</b> doesn't exist."; 
                    }
                }

                if(!empty($_POST['Customer'])) {
                    $stmt = $pdo->prepare("SELECT `Name` FROM customers
                                            HAVING `Name` = ?;");
                    $stmt->execute([$_POST['Customer']]);

                    if ($stmt->rowCount() > 0) {
                        $custData = $stmt->fetch(PDO::FETCH_ASSOC);
                    }

                    if($custData == NULL) {
                        $_POST['edit'] = 1;
                        $error = "Customer <b>".$_POST['Customer']."</b> doesn't exist."; 
                    }
                }

                if(!empty($_POST['Customer_PN'])) {
                    $stmt = $pdo->prepare("SELECT Customer_PN FROM customer_pn 
                                            HAVING Customer_PN = ?;");
                    $stmt->execute([$_POST['Customer_PN']]);

                    if ($stmt->rowCount() > 0) {
                        $cpnData = $stmt->fetch(PDO::FETCH_ASSOC);
                    }

                    if($cpnData != NULL) {
                        $cpn = $_POST['Customer_PN'];
                    }
                    else {
                        $_POST['edit'] = 1;
                        $error = "Customer PN <b>".$_POST['Customer_PN']."</b> doesn't exist.";
                    }
                }
                else {
                    $cpn = NULL;
                }

                if(!empty($_POST['Eurotech_PN'])) {
                    $stmt = $pdo->prepare("SELECT Eurotech_PN FROM products
                                            HAVING Eurotech_PN = ?;");
                    $stmt->execute([$_POST['Eurotech_PN']]);

                    if ($stmt->rowCount() > 0) {
                        $etpnData = $stmt->fetch(PDO::FETCH_ASSOC);
                    }

                    if($etpnData == NULL) {
                        $_POST['edit'] = 1;
                        $error = "Eurotech PN <b>".$_POST['Eurotech_PN']."</b> doesn't exist."; 
                    }
                }

                if(!empty($_POST['Description'])) {
                    $stmt = $pdo->prepare("SELECT `Description` FROM products
                                            HAVING `Description` = ?;");
                    $stmt->execute([$_POST['Description']]);

                    if ($stmt->rowCount() > 0) {
                        $descData = $stmt->fetch(PDO::FETCH_ASSOC);
                    }

                    if($descData == NULL) {
                        $_POST['edit'] = 1;
                        $error = "Description <b>".$_POST['Description']."</b> doesn't exist."; 
                    }
                }

                if($_POST['Rev'] != "") {
                    $rev = $_POST['Rev'];
                }
                else {
                    $rev = NULL; 
                }

                if($_POST['IMDS'] != "") {
                    $imds = $_POST['IMDS'];
                }
                else {
                    $imds = NULL; 
                }

                if($_POST['PPAP_Level'] != "") {
                    $lvl = $_POST['PPAP_Level'];
                }
                else {
                    $lvl = NULL; 
                }

                if($_POST['Samples_Status'] != "") {
                    $samSt = $_POST['Samples_Status'];
                }
                else {
                    $samSt = NULL; 
                }

                if($_POST['Reason_Submission'] != "") {
                    $reaSu = $_POST['Reason_Submission'];
                }
                else {
                    $reaSu = NULL; 
                }
                            
                if($_POST['PPAP_Received_Date'] != "") {
                    $recD = new DateTime($_POST['PPAP_Received_Date']);
                    $rcD = $recD->format('Y-m-d');
                }
                else {
                    $rcD = NULL; 
                }

                if($_POST['PPAP_Sent_Customer'] != "") {
                    $senD = new DateTime($_POST['PPAP_Sent_Customer']);
                    $snD = $senD->format('Y-m-d');

                    $stmt = $pdo->prepare("SELECT PPAP_ID FROM ppap WHERE PPAP_ID = ? AND PPAP_Sent_Customer IS NULL");
                    $stmt->execute([$id]);

                    if ($stmt->rowCount() > 0) {
                        $sentData = $stmt->fetch(PDO::FETCH_ASSOC);
                    }
                }
                else {
                    $snD = NULL; 
                }

                if($_POST['PPAP_Signed_Date'] != "") {
                    $sigD = new DateTime($_POST['PPAP_Signed_Date']);
                    $sgD = $sigD->format('Y-m-d');
                }
                else {
                    $sgD = NULL; 
                }

                if($_POST['PPAP_From_Shipments'] == "*") {
                    $ppapfs = $_POST['PPAP_From_Shipments'];
                }
                if($_POST['PPAP_From_Shipments'] == "no") {
                    $ppapfs = NULL; 
                }

                if($_POST['Comments'] != "") {
                    $com = $_POST['Comments'];
                }
                else {
                    $com = NULL; 
                }

                if($_POST['Inspection_Rep_Number'] != "") {
                    $irn = $_POST['Inspection_Rep_Number'];
                }
                else {
                    $irn = NULL; 
                }

                if(!isset($error)) {
                    $stmt = $pdo->prepare("UPDATE ppap SET 
                                                PPAP_Number = ?, 
                                                FK_Customer_PN = ?, 
                                                PPAP_Request_Date = ?, 
                                                PPAP_Requested_Vendor = ?,
                                                Current_Status = ?,
                                                OEM = ?,
                                                Rev = ?,
                                                IMDS = ?,
                                                PPAP_Level = ?,
                                                Samples_Status = ?,
                                                Reason_Submission = ?,
                                                PPAP_Received_Date = ?,
                                                PPAP_Sent_Customer = ?, 
                                                PPAP_Signed_Date = ?,
                                                PPAP_From_Shipments = ?,
                                                Comments = ?,
                                                FK_Vendor_ID = ?,
                                                Inspection_Rep_Number = ?
                                            WHERE PPAP_ID = ?");

                    $stmt->execute([
                        $pppapn,
                        $cpn,
                        $rqD,
                        $rvD,
                        $curSt,
                        $oem,
                        $rev,
                        $imds,
                        $lvl,
                        $samSt,
                        $reaSu,
                        $rcD,
                        $snD,
                        $sgD,
                        $ppapfs,
                        $com,
                        $vend,
                        $irn,
                        $id
                    ]);

                    if($_POST['PPAP_Sent_Customer'] != "") {
                        if($sentData != NULL) {
                            if(!empty($_POST['PPAP_Number'])) {
                                $insertsR[] = "PPAP_Number";
                                $paramsIR[] = "'".$_POST['PPAP_Number']."'";
                            }

                            if(!empty($_POST['OEM'])) {
                                $insertsR[] = "OEM";
                                $paramsIR[] = "'".$_POST['OEM']."'";
                            }

                            if(!empty($_POST['Customer_PN'])) {
                                $insertsR[] = "FK_Customer_PN";
                                $paramsIR[] = "'".$_POST['Customer_PN']."'";
                            }

                            if(!empty($_POST['IMDS'])) {
                                $insertsR[] = "IMDS";
                                $paramsIR[] = "'".$_POST['IMDS']."'";
                            }

                            if(!empty($_POST['PPAP_Level']) && $_POST['PPAP_Level'] != '') {
                                $insertsR[] = "PPAP_Level";
                                $paramsIR[] = "'".$_POST['PPAP_Level']."'";
                            }
                            
                            if(!empty($_POST['PPAP_Sent_Customer'])) {
                                $insertsR[] = "PPAP_Request_Date";
                                $SC = new DateTime($_POST['PPAP_Sent_Customer']);
                                $renewal = $SC->modify('+10 months'); 
                                $result = $renewal->format('Y-m-d');
                                $paramsIR[] = "'".$result."'";
                            }

                            if(!empty($_POST['PPAP_From_Shipments']) && $_POST['PPAP_From_Shipments'] != 'no') {
                                $insertsR[] = "PPAP_From_Shipments";
                                $paramsIR[] = "'".$_POST['PPAP_From_Shipments']."'";
                            }

                            if(!empty($_POST['Vendor'])) {
                                $insertsR[] = "FK_Vendor_ID";
                                $paramsIR[] = "'".$vend."'";
                            }

                            $insertsR[] = "Reason_Submission";
                            $paramsIR[] = "'Renewal'";
                            
                            $stmt = $pdo->prepare("INSERT INTO ppap (". implode(', ', $insertsR) .") 
                                                        VALUES (". implode(', ', $paramsIR) .")");
                            $stmt->execute([]);
                        }
                    }
                }
            }
        }

        if (isset($_POST['delete'])) {
            $id = $_POST['IDdelete'];
            $stmt = $pdo->prepare("SELECT DISTINCT
                                        if(PPAP_Sent_Customer IS NULL, datediff(NOW(), PPAP_Request_Date), datediff(PPAP_Sent_Customer, PPAP_Request_Date)) AS 'Days to Submit',
                                        ppap.*,
                                        cp.Customer_PN,
                                        p.*,
                                        c.`Name` AS 'Customer',
                                        c.IMDS_ID_no,
                                        v.`Name` AS 'Vendor',
                                        v.Short_name,
                                        cpn.*
                                    FROM products p
                                        LEFT JOIN customer_pn cp ON p.Eurotech_PN = cp.FK_Eurotech_PN
                                        LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                                        INNER JOIN ppap ON cp.Customer_PN = ppap.FK_Customer_PN
                                        LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
                                        LEFT JOIN customer_ppap_number cpn ON cpn.FK_Customer_ID = c.Customer_ID
                                    HAVING PPAP_ID = ?;");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $ppapDataD = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmD'])) {
            $id = $_POST['IDdelete'];
            $stmt = $pdo->prepare("DELETE FROM ppap
                                    WHERE PPAP_ID = ?");

            $stmt->execute([
                $id
            ]);
           
            $Deleted = 'Y';

            $_SESSION['saved'] = true;
        }
    }

    $logs = $model->search();
    // $logsNP = $model->searchNoPPAP();

    $PPAPNS = $model->searchPPAPN();
    $Currents = $model->searchCS();
    $PIS = $model->searchPIS();
    $Customers = $model->searchCust();
    $OEMS = $model->searchOEM();
    $Countries = $model->searchCoun();
    $SAPS = $model->searchSAP();
    $CPNS = $model->searchCPN();
    $ETMS = $model->searchETM();
    $ETDS = $model->searchETD();
    $Revs = $model->searchRev();
    $ETPNS = $model->searchETPN();
    $Descs = $model->searchDesc();
    $IMDS = $model->searchIMDS();
    $PSSS = $model->searchPS();
    $RSS = $model->searchRS();
    $Coms = $model->searchCom();
    $IRNS = $model->searchIRN();

    include 'view.php';
?>