<?php
session_start();
require 'connection.php';

if (isset($_POST['btn_login'])) {
    $username = $_POST["Username"];
    $password = $_POST["Password"];

    $sql = "SELECT * FROM users
            WHERE Username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$username]);

    $userBD = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($userBD && ($password === $userBD['Password'])) {
        $_SESSION["Username"] = $userBD['Username'];
        $_SESSION["Role"] = $userBD['Role'];
        $_SESSION["ID_User"] = $userBD['ID'];
        header("Location: ./");
        exit;
    } else {
        $error = "Username or password are incorrects.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #dff1ffff, #2575fc);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 1rem;
        }

        .login-box {
            background-color: #ffffff;
            padding: 2rem;
            border-radius: 1rem;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 420px;
        }

        .login-box h2 {
            text-align: center;
            color: #2d3436;
            margin-bottom: 1.5rem;
            font-size: 1.8rem;
        }

        .btn-primary {
            background-color: #2575fc;
            border: none;
        }

        .btn-primary:hover {
            background-color: #1b63e1;
        }

        .btn-outline-primary {
            border-color: #2575fc;
            color: #2575fc;
        }

        .btn-outline-primary:hover {
            background-color: #2575fc;
            color: #fff;
        }

        .form-label {
            font-weight: 500;
        }

        .error {
            background-color: #ffe6e6;
            color: #d63031;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-size: 0.9rem;
        }

        @media (max-width: 480px) {
            .login-box {
                padding: 1.5rem;
            }

            .login-box h2 {
                font-size: 1.5rem;
            }

            .form-label {
                font-size: 0.95rem;
            }
        }
    </style>
</head>
<body>
    <div class="login-box">
    <h2>Welcome</h2>

    <?php if (isset($error)) : ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label for="nombre_usuario" class="form-label">Username</label>
            <input type="text" name="Username" class="form-control">
        </div>

        <div class="mb-3">
            <label for="contraseña" class="form-label">Password</label>
            <input type="password" name="Password" class="form-control">
        </div>

        <div class="d-grid gap-2">
            <input type="submit" name="btn_login" class="btn btn-primary" value="Log In">
        </div>
    </form>
</div>
</body>
</html>