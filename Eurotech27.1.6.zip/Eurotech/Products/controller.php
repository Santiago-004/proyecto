<?php 
    include "model.php";

    $model = new model();
    $model->cn();
    $logs = [];
    
    if (isset($_POST["idsearch"])){
        $idsearch = $_POST["idsearch"];
    }    
    else {
        $idsearch = NULL;
    }

    if (isset($_POST["descsearch"])){
        $descsearch = $_POST["descsearch"];
    }    
    else {
        $descsearch = NULL;
    }

    if (isset($_POST["suppsearch"])){
        $suppsearch = $_POST["suppsearch"];
    }    
    else {
        $suppsearch = NULL;
    }

    if (isset($_POST["snsearch"])){
        $snsearch = $_POST["snsearch"];
    }    
    else {
        $snsearch = NULL;
    }

    if (isset($_POST["tapesearch"])){
        $tapesearch = $_POST["tapesearch"];
    }    
    else {
        $tapesearch = NULL;
    }

    if (isset($_POST["widthsearch"])){
        $widthsearch = $_POST["widthsearch"];
    }    
    else {
        $widthsearch = NULL;
    }

    if (isset($_POST["lengthsearch"])){
        $lengthsearch = $_POST["lengthsearch"];
    }    
    else {
        $lengthsearch = NULL;
    }

    if (isset($_POST["colorsearch"])){
        $colorsearch = $_POST["colorsearch"];
    }    
    else {
        $colorsearch = NULL;
    }

    if (isset($_POST["modelsearch"])){
        $modelsearch = $_POST["modelsearch"];
    }    
    else {
        $modelsearch = NULL;
    }

    if (isset($_POST["dwgsearch"])){
        $dwgsearch = $_POST["dwgsearch"];
    }    
    else {
        $dwgsearch = NULL;
    }

    $cus = NULL;
    $customerData = NULL;
    $customerDataD = NULL;
    $Deleted = NULL;

    $pdo = new PDO("mysql:host=localhost;dbname=eurotechdb", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        if (isset($_POST['confirmI'])) {
            if($_POST['product'] == 'Tape') {
                $desc = explode("-", $_POST['Description']);
                $tape = $desc[0];
                $width = $desc[1];
                $length = $desc[2];
                $color = $desc[3];
            }

            $_SESSION['saved'] = true;
        }

        if (isset($_POST['edit'])) {
            $id = $_POST['IDedit'];
            $stmt = $pdo->prepare("SELECT Customer_ID, `Name` FROM customers WHERE Customer_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $customerData = $stmt->fetch(PDO::FETCH_ASSOC);
            }

            $stmt = $pdo->prepare("SELECT Products FROM customers WHERE Customer_ID = ?");
            $stmt->execute([$id]);
            $productsData = $stmt->fetch(PDO::FETCH_ASSOC);
        }

        if (isset($_POST['confirmU'])) {
            $stmt = $pdo->prepare("SELECT `Name` FROM customers WHERE `Name` = ? AND Customer_ID != ?");
            $stmt->execute([
                $_POST['Name'],
                $_POST['Customer_ID']
            ]);
            $name = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($name != NULL) {
                $_POST['edit'] = 1;
                $error = "The customer <b>".$_POST['Name']."</b> already exists.";
            }
            if(!isset($error)) {
                $prods_array = [];
                foreach($Products as $Prod) {
                    if(isset($_POST[$Prod]) && $_POST[$Prod] != NULL) {
                        $prods_array[] = $_POST[$Prod];
                    }
                }

                $prods = implode(', ', $prods_array);

                if($prods != "") {
                    $stmt = $pdo->prepare("UPDATE customers SET 
                                                `Name` = ?, 
                                                Products = ?
                                            WHERE Customer_ID = ?");
                    $stmt->execute([
                        $_POST['Name'],
                        $prods,
                        $_POST['Customer_ID']
                    ]);
                }
                else {
                    $_POST['edit'] = 1;
                    $error = "You should select at least 1 more product for the customer.";
                }
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['delete'])) {
            $id = $_POST['IDdelete'];
            $stmt = $pdo->prepare("SELECT * FROM customers WHERE Customer_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $customerDataD = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmD'])) {
            $id = $_POST['Customer_ID'];
            $stmt = $pdo->prepare("SELECT Customer_ID FROM customers c
                                        INNER JOIN bluseal_customer_pn cpn ON c.Customer_ID = cpn.FK_Customer_ID
                                    WHERE Customer_ID = ?");
            $stmt->execute([$id]);
            $bs = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT Customer_ID FROM customers c
                                        INNER JOIN cables_customer_pn cpn ON c.Customer_ID = cpn.FK_Customer_ID
                                    WHERE Customer_ID = ?");
            $stmt->execute([$id]);
            $cab = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT Customer_ID FROM customers c
                                        INNER JOIN tapes_customer_pn cpn ON c.Customer_ID = cpn.FK_Customer_ID
                                    WHERE Customer_ID = ?");
            $stmt->execute([$id]);
            $tap = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT Customer_ID FROM customers c
                                        INNER JOIN tubes_customer_pn cpn ON c.Customer_ID = cpn.FK_Customer_ID
                                    WHERE Customer_ID = ?");
            $stmt->execute([$id]);
            $tub = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($bs == NULL && $cab == NULL && $tap == NULL && $tub == NULL) {
                $stmt = $pdo->prepare("DELETE FROM customers
                                        WHERE Customer_ID = ?");

                $stmt->execute([$id]);
            
                $Deleted = 'Y';
            }
            else {
                $_POST['delete'] = 1;
                $error = "This customer can't be deleted, because it already has registers.";

                $stmt = $pdo->prepare("SELECT * FROM customers WHERE Customer_ID = ?");
                $stmt->execute([$id]);

                if ($stmt->rowCount() > 0) {
                    $customerDataD = $stmt->fetch(PDO::FETCH_ASSOC);
                }
            }

            $_SESSION['saved'] = true;
        }
    }
    
    
    $ETPNs = $model->searchETPNs();
    $Descriptions = $model->searchDescriptions();
    $Suppliers = $model->searchSuppliers();
    $SuppliersPN = $model->searchSuppliersPN();
    $Tapes = $model->searchTapes();
    $Widths = $model->searchWidths();
    $Lengths = $model->searchLengths();
    $Colors = $model->searchColors();
    $Models = $model->searchModels();
    $Dwgs = $model->searchDwgs();
    $logs = $model->search();

    include 'view.php';
?>