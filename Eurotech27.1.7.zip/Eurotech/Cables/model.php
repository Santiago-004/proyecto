<?php
    class model {                                        

        public  $mbd;
        
        function cn() {
            $this->mbd = new PDO('mysql:host=localhost;dbname=eurotechdb;port=3306', 'root', '');
            $this->mbd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
        }
    
        function search(){
            $logs = [];
            if (isset($_POST['btnsearch'])) {
                if (!empty($_POST['custsearch']) || !empty($_POST['etpnsearch']) 
                    || !empty($_POST['copnsearch']) || !empty($_POST['cpnsearch']) || !empty($_POST['descsearch'])
                    || (!empty($_POST['date1search']) && !empty($_POST['date2search'])) 
                    || (!empty($_POST['date3search']) && !empty($_POST['date4search']))
                    || (!empty($_POST['date5search']) && !empty($_POST['date6search']))
                    || (!empty($_POST['date7search']) && !empty($_POST['date8search']))
                    || isset($_POST['cusn']) || isset($_POST['reqn']) 
                    || isset($_POST['recn']) || isset($_POST['senn']) || isset($_POST['sign'])) {
                    $where = [];
                    $params = [];

                    if($_POST['cusn'] == "" && !empty($_POST['custsearch'])) {
                        $where[] = "`Name` LIKE :cust";
                        $params[':cust'] = $_POST['custsearch']."%";
                    }
                    if($_POST['cusn'] == "Y") {
                        $where[] = "`Name` IS NOT NULL";
                    }
                    if($_POST['cusn'] == "N") {
                        $where[] = "`Name` IS NULL";
                    }

                    if (!empty($_POST['cpnsearch'])) {
                        $where[] = "Customer_PN = :cpn";
                        $params[':cpn'] = $_POST['cpnsearch'];
                    }

                    if (!empty($_POST['etpnsearch'])) {
                        $where[] = "Eurotech_PN = :etpn";
                        $params[':etpn'] = $_POST['etpnsearch'];
                    }

                    if (!empty($_POST['copnsearch'])) {
                        $where[] = "Supplier_PN = :copn";
                        $params[':copn'] = $_POST['copnsearch'];
                    }

                    if (!empty($_POST['descsearch'])) {
                        $where[] = "`Description` = :desc";
                        $params[':desc'] = $_POST['descsearch'];
                    }

                    if($_POST['reqn'] == "" && !empty($_POST['date1search']) && !empty($_POST['date2search'])) {
                        $where[] = "PPAP_Requested_Date BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['date1search'];
                        $params[':date2'] = $_POST['date2search'];
                    }
                    if($_POST['reqn'] == "Y") {
                        $where[] = "PPAP_Requested_Date IS NOT NULL";
                    }
                    if($_POST['reqn'] == "N") {
                        $where[] = "PPAP_Requested_Date IS NULL";
                    }

                    if($_POST['sign'] == "" && !empty($_POST['date3search']) && !empty($_POST['date4search'])) {
                        $where[] = "PPAP_Signed_Date BETWEEN :date3 AND :date4";
                        $params[':date3'] = $_POST['date3search'];
                        $params[':date4'] = $_POST['date4search'];
                    }
                    if($_POST['sign'] == "Y") {
                        $where[] = "PPAP_Signed_Date IS NOT NULL";
                    }
                    if($_POST['sign'] == "N") {
                        $where[] = "PPAP_Signed_Date IS NULL";
                    }

                    if($_POST['recn'] == "" && !empty($_POST['date5search']) && !empty($_POST['date6search'])) {
                        $where[] = "PPAP_Received_Date BETWEEN :date5 AND :date6";
                        $params[':date5'] = $_POST['date5search'];
                        $params[':date6'] = $_POST['date6search'];
                    }
                    if($_POST['recn'] == "Y") {
                        $where[] = "PPAP_Received_Date IS NOT NULL";
                    }
                    if($_POST['recn'] == "N") {
                        $where[] = "PPAP_Received_Date IS NULL";
                    }

                    if($_POST['senn'] == "" && !empty($_POST['date7search']) && !empty($_POST['date8search'])) {
                        $where[] = "PPAP_Sent_Date BETWEEN :date7 AND :date8";
                        $params[':date7'] = $_POST['date7search'];
                        $params[':date8'] = $_POST['date8search'];
                    }
                    if($_POST['senn'] == "Y") {
                        $where[] = "PPAP_Sent_Date IS NOT NULL";
                    }
                    if($_POST['senn'] == "N") {
                        $where[] = "PPAP_Sent_Date IS NULL";
                    }

                    if(!empty($where)){
                        $sql = "
                        SELECT 
                            CAB_PPAP_ID,
                            Eurotech_PN,
                            Supplier_PN,
                            Customer_PN, 
                            `Description`,
                            PPAP_Requested_Date,
                            PPAP_Received_Date,
                            PPAP_Sent_Date,
                            PPAP_Signed_Date,
                            `Name`
                        FROM products pd
                            LEFT JOIN customer_pn cp ON cp.FK_Eurotech_PN = pd.Eurotech_PN
                            LEFT JOIN cables_ppap p ON cp.Customer_PN = p.FK_Customer_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                        WHERE " . implode(' AND ', $where) . "
                        AND Product = 'Cable'
                        ORDER BY Eurotech_PN;";
                    }
                    else {
                        $sql = "
                        SELECT 
                            CAB_PPAP_ID,
                            Eurotech_PN,
                            Supplier_PN,
                            Customer_PN, 
                            `Description`,
                            PPAP_Requested_Date,
                            PPAP_Received_Date,
                            PPAP_Sent_Date,
                            PPAP_Signed_Date,
                            `Name`
                        FROM products pd
                            LEFT JOIN customer_pn cp ON cp.FK_Eurotech_PN = pd.Eurotech_PN
                            LEFT JOIN cables_ppap p ON cp.Customer_PN = p.FK_Customer_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                        WHERE Product = 'Cable'
                        ORDER BY Eurotech_PN;";
                    }

                    $stmt = $this->mbd->prepare($sql);
                    $stmt->execute($params);

                    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }

                else {
                    foreach ($this->mbd->query(
                        "SELECT 
                            CAB_PPAP_ID,
                            Eurotech_PN,
                            Supplier_PN,
                            Customer_PN, 
                            `Description`,
                            PPAP_Requested_Date,
                            PPAP_Received_Date,
                            PPAP_Sent_Date,
                            PPAP_Signed_Date,
                            `Name`
                        FROM products pd
                            LEFT JOIN customer_pn cp ON cp.FK_Eurotech_PN = pd.Eurotech_PN
                            LEFT JOIN cables_ppap p ON cp.Customer_PN = p.FK_Customer_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                        WHERE Product = 'Cable'
                        ORDER BY Eurotech_PN;"
                    ) as $log) {
                        $logs[] = $log;
                    }
                }
            } else {
                foreach ($this->mbd->query(
                    "SELECT 
                            CAB_PPAP_ID,
                            Eurotech_PN,
                            Supplier_PN,
                            Customer_PN, 
                            `Description`,
                            PPAP_Requested_Date,
                            PPAP_Received_Date,
                            PPAP_Sent_Date,
                            PPAP_Signed_Date,
                            `Name`
                        FROM products pd
                            LEFT JOIN customer_pn cp ON cp.FK_Eurotech_PN = pd.Eurotech_PN
                            LEFT JOIN cables_ppap p ON cp.Customer_PN = p.FK_Customer_PN
                            LEFT JOIN customers c ON cp.FK_Customer_ID = c.Customer_ID
                        WHERE Product = 'Cable'
                        ORDER BY Eurotech_PN;"
                ) as $log) {
                    $logs[] = $log;
                }
            }
            return $logs;
        }

        function searchCustomers(){
            $Customers = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        Customer_ID,
                        `Name`,
                        Products
                    FROM customers
                    WHERE Products LIKE '%Cables%'
                    ORDER BY `Name`;"
                ) as $Customer) {
                    $Customers[] = $Customer;
                }
            return $Customers;
        }

        function searchETPN(){
            $ETPNS = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        Eurotech_PN
                    FROM products
                    WHERE Product = 'Cable'
                    ORDER BY Eurotech_PN;"
                ) as $ETPN) {
                    $ETPNS[] = $ETPN;
                }
            return $ETPNS;
        }

        function searchCOPN(){
            $COPNS = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        Supplier_PN
                    FROM products
                    WHERE Product = 'Cable'
                    ORDER BY Supplier_PN;"
                ) as $COPN) {
                    $COPNS[] = $COPN;
                }
            return $COPNS;
        }

        function searchCPN(){
            $CPNS = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        Customer_PN
                    FROM customer_pn cpn
                    INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                    WHERE Product = 'Cable'
                    ORDER BY Customer_PN;"
                ) as $CPN) {
                    $CPNS[] = $CPN;
                }
            return $CPNS;
        }

        function searchDesc(){
            $Descs = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        `Description`
                    FROM products
                    WHERE Product = 'Cable'
                    ORDER BY `Description`;"
                ) as $Desc) {
                    $Descs[] = $Desc;
                }
            return $Descs;
        }
    }
?>