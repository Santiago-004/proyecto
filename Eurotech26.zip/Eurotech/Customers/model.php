<?php
    class model {                                        

        public  $mbd;
        
        function cn() {
            $this->mbd = new PDO('mysql:host=localhost;dbname=eurotechdb;port=3306', 'root', '');
            $this->mbd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
        }
    
        function search(){
            $logs = [];
            if (isset($_POST['btnsearch'])) {
                if (!empty($_POST['idsearch']) || !empty($_POST['custsearch']) || !empty($_POST['prodsearch'])) {
                    $where = [];
                    $params = [];

                    if (!empty($_POST['idsearch'])) {
                        $where[] = "Customer_ID LIKE :id";
                        $params[':id'] = $_POST['idsearch']."%";
                    }
                    
                    if(!empty($_POST['custsearch'])) {
                        $where[] = "`Name` LIKE :cust";
                        $params[':cust'] = $_POST['custsearch']."%";
                    }

                    if (!empty($_POST['prodsearch'])) {
                        $where[] = "Products LIKE :prod";
                        $params[':prod'] = "%".$_POST['prodsearch']."%";
                    }

                    if(!empty($where)) {
                        $sql = "
                        SELECT 
                            *
                        FROM customers
                        WHERE " . implode(' AND ', $where) . "
                        ORDER BY Customer_ID;";
                    }
                    else {
                        $sql = "
                        SELECT 
                            *
                        FROM customers
                        ORDER BY Customer_ID;";
                    }

                    $stmt = $this->mbd->prepare($sql);
                    $stmt->execute($params);

                    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
                else {
                    foreach ($this->mbd->query(
                        "SELECT 
                            *
                        FROM customers
                        ORDER BY Customer_ID;"
                    ) as $log) {
                        $logs[] = $log;
                    }
                }
            } else {
                foreach ($this->mbd->query(
                    "SELECT 
                        *
                    FROM customers
                    ORDER BY Customer_ID;"
                ) as $log) {
                    $logs[] = $log;
                }
            }
            return $logs;
        }

        function searchIDs(){
            $IDs = [];
                foreach ($this->mbd->query(
                    "SELECT
                        Customer_ID
                    FROM customers
                    ORDER BY Customer_ID;"
                ) as $ID) {
                    $IDs[] = $ID;
                }
            return $IDs;
        }

        function searchCustomers(){
            $Customers = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        `Name`
                    FROM customers
                    ORDER BY `Name`;"
                ) as $Customer) {
                    $Customers[] = $Customer;
                }
            return $Customers;
        }

        function searchProducts(){
            $Products = [];
            $Products = ['BluSeal', 'Cables', 'Tapes', 'Tubes'];
            return $Products;
        }
    }
?>