<?php
    try {
        $conn = new PDO('mysql:host=localhost;dbname=eurotechdb;port=3306', 'root', '');
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(PDOException $e) {
        die("Connection Error: " . $e->getMessage());
    }

    $input = json_decode(file_get_contents("php://input"), true);
    if (!$input) {
        echo json_encode(["error" => "Error"]);
        exit;
    }
    $Date1 = $input["Date1"];
    $Date2 = $input["Date2"];
    $Product = $input["Product"];
    $data = [];

    $r1 = $conn->query("SELECT COUNT(*) AS 'New_PPAPs' FROM ppap p
                            INNER JOIN customer_pn cpn ON p.FK_Customer_PN_ID = cpn.Customer_PN_ID
                            INNER JOIN products pr ON cpn.FK_Eurotech_PN = pr.Eurotech_PN
                            WHERE p.PPAP_Request_Date BETWEEN '$Date1' AND '$Date2'
                            AND pr.Product = '$Product'");
    $row = $r1->fetch(PDO::FETCH_ASSOC);
    $data["new_ppaps_total"] = $row["New_PPAPs"];

    $r2 = $conn->query("SELECT COUNT(*) AS 'PFS_Y' FROM ppap p
                            INNER JOIN customer_pn cpn ON p.FK_Customer_PN_ID = cpn.Customer_PN_ID
                            INNER JOIN products pr ON cpn.FK_Eurotech_PN = pr.Eurotech_PN
                            WHERE p.PPAP_From_Shipments = '*'
                            AND p.PPAP_Request_Date BETWEEN '$Date1' AND '$Date2'
                            AND pr.Product = '$Product'");
    $row = $r2->fetch(PDO::FETCH_ASSOC);
    $data["requested_system"] = $row["PFS_Y"];

    $r3 = $conn->query("SELECT COUNT(*) AS 'PFS_N' FROM ppap p
                            INNER JOIN customer_pn cpn ON p.FK_Customer_PN_ID = cpn.Customer_PN_ID
                            INNER JOIN products pr ON cpn.FK_Eurotech_PN = pr.Eurotech_PN
                            WHERE p.PPAP_From_Shipments IS NULL
                            AND p.PPAP_Request_Date BETWEEN '$Date1' AND '$Date2'
                            AND pr.Product = '$Product'");
    $row = $r3->fetch(PDO::FETCH_ASSOC);
    $data["requested_customer"] = $row["PFS_N"];




    $r4 = $conn->query("SELECT COUNT(*) AS 'Sent' FROM ppap p
                            INNER JOIN customer_pn cpn ON p.FK_Customer_PN_ID = cpn.Customer_PN_ID
                            INNER JOIN products pr ON cpn.FK_Eurotech_PN = pr.Eurotech_PN
                            WHERE p.PPAP_Sent_Customer IS NOT NULL
                            AND (p.Reason_Submission = 'Annual Validation' OR p.Reason_Submission = 'Initial Submission')
                            AND p.PPAP_Request_Date BETWEEN '$Date1' AND '$Date2'
                            AND pr.Product = '$Product'");
    $row = $r4->fetch(PDO::FETCH_ASSOC);
    $data["sent_total"] = $row["Sent"];

    $r5 = $conn->query("SELECT COUNT(*) AS 'Sent_Annual' FROM ppap p
                            INNER JOIN customer_pn cpn ON p.FK_Customer_PN_ID = cpn.Customer_PN_ID
                            INNER JOIN products pr ON cpn.FK_Eurotech_PN = pr.Eurotech_PN
                            WHERE p.Reason_Submission = 'Annual Validation'
                            AND p.PPAP_Sent_Customer IS NOT NULL
                            AND p.PPAP_Request_Date BETWEEN '$Date1' AND '$Date2'
                            AND pr.Product = '$Product'");
    $row = $r5->fetch(PDO::FETCH_ASSOC);
    $data["sent_annual"] = $row["Sent_Annual"];

    $r6 = $conn->query("SELECT COUNT(*) AS 'Sent_Initial' FROM ppap p
                            INNER JOIN customer_pn cpn ON p.FK_Customer_PN_ID = cpn.Customer_PN_ID
                            INNER JOIN products pr ON cpn.FK_Eurotech_PN = pr.Eurotech_PN
                            WHERE p.Reason_Submission = 'Initial Submission'
                            AND p.PPAP_Sent_Customer IS NOT NULL
                            AND p.PPAP_Request_Date BETWEEN '$Date1' AND '$Date2'
                            AND pr.Product = '$Product'");
    $row = $r6->fetch(PDO::FETCH_ASSOC);
    $data["sent_initial"] = $row["Sent_Initial"];





    $r7 = $conn->query("SELECT COUNT(*) AS 'Not_Sent' FROM ppap p
                            INNER JOIN customer_pn cpn ON p.FK_Customer_PN_ID = cpn.Customer_PN_ID
                            INNER JOIN products pr ON cpn.FK_Eurotech_PN = pr.Eurotech_PN
                            WHERE p.PPAP_Sent_Customer IS NULL
                            AND pr.Product = '$Product'");
    $row = $r7->fetch(PDO::FETCH_ASSOC);
    $data["not_sent_total"] = $row["Not_Sent"];

    $r8 = $conn->query("SELECT COUNT(*) AS 'Not_Sent_Vendor' FROM (
                            SELECT pr.Product, p.*, if(PPAP_Sent_Customer IS NULL, datediff(NOW(), PPAP_Request_Date), datediff(PPAP_Sent_Customer, PPAP_Request_Date)) AS 'Days to Submit' FROM ppap p
                            INNER JOIN customer_pn cpn ON p.FK_Customer_PN_ID = cpn.Customer_PN_ID
                            INNER JOIN products pr ON cpn.FK_Eurotech_PN = pr.Eurotech_PN
                            HAVING `Days to Submit` < 30
                                AND p.PPAP_Sent_Customer IS NULL
                                AND p.PPAP_Requested_Vendor IS NULL
                                AND pr.Product = '$Product'
                        ) AS Not_Sent");
    $row = $r8->fetch(PDO::FETCH_ASSOC);
    $data["not_sent_vendor_n"] = $row["Not_Sent_Vendor"];

    $r8 = $conn->query("SELECT COUNT(*) AS 'Sent_Vendor' FROM (
                            SELECT pr.Product, p.*, if(PPAP_Sent_Customer IS NULL, datediff(NOW(), PPAP_Request_Date), datediff(PPAP_Sent_Customer, PPAP_Request_Date)) AS 'Days to Submit' FROM ppap p
                            INNER JOIN customer_pn cpn ON p.FK_Customer_PN_ID = cpn.Customer_PN_ID
                            INNER JOIN products pr ON cpn.FK_Eurotech_PN = pr.Eurotech_PN
                            HAVING `Days to Submit` < 30
                                AND p.PPAP_Sent_Customer IS NULL
                                AND p.PPAP_Requested_Vendor IS NOT NULL
                                AND pr.Product = '$Product'
                        ) AS Not_Sent");
    $row = $r8->fetch(PDO::FETCH_ASSOC);
    $data["not_sent_vendor_y"] = $row["Sent_Vendor"];

    $r9 = $conn->query("SELECT COUNT(*) AS 'Not_Sent_Expired' FROM (
                            SELECT pr.Product, p.*, if(PPAP_Sent_Customer IS NULL, datediff(NOW(), PPAP_Request_Date), datediff(PPAP_Sent_Customer, PPAP_Request_Date)) AS 'Days to Submit' FROM ppap p
                            INNER JOIN customer_pn cpn ON p.FK_Customer_PN_ID = cpn.Customer_PN_ID
                            INNER JOIN products pr ON cpn.FK_Eurotech_PN = pr.Eurotech_PN
                            HAVING `Days to Submit` >= 30
                                AND p.PPAP_Sent_Customer IS NULL
                                AND pr.Product = '$Product'
                        ) AS Not_Sent");
    $row = $r9->fetch(PDO::FETCH_ASSOC);
    $data["not_sent_expired"] = $row["Not_Sent_Expired"];

    echo json_encode($data);
?>