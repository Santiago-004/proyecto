<?php 
    include "model.php";

    $model = new model();
    $model->cn();
    $logs = [];
    
    if (isset($_POST["submit1search"]) && isset($_POST["submit2search"])){
        $submit1search = $_POST["submit1search"];
        $submit2search = $_POST["submit2search"];
    }    
    else {
        $submit1search = "";
        $submit2search = "";
    }

    if (isset($_POST["ppapnsearch"])){
        $ppapnsearch = $_POST["ppapnsearch"];
    }    
    else {
        $ppapnsearch = "";
    }
    
    if (isset($_POST["req1search"]) && isset($_POST["req2search"])){
        $req1search = $_POST["req1search"];
        $req2search = $_POST["req2search"];
    }    
    else {
        $req1search = "";
        $req2search = "";
    }

    if (isset($_POST["currentsearch"])){
        $currentsearch = $_POST["currentsearch"];
    }    
    else {
        $currentsearch = "";
    }

    if (isset($_POST["pisearch"])){
        $pisearch = $_POST["pisearch"];
    }    
    else {
        $pisearch = "";
    }

    if (isset($_POST["custsearch"])){
        $custsearch = $_POST["custsearch"];
    }    
    else {
        $custsearch = "";
    }

    if (isset($_POST["countrysearch"])){
        $countrysearch = $_POST["countrysearch"];
    }    
    else {
        $countrysearch = "";
    }

    if (isset($_POST["cpnsearch"])){
        $cpnsearch = $_POST["cpnsearch"];
    }    
    else {
        $cpnsearch = "";
    }

    if (isset($_POST["etmsearch"])){
        $etmsearch = $_POST["etmsearch"];
    }    
    else {
        $etmsearch = "";
    }

    if (isset($_POST["etdsearch"])){
        $etdsearch = $_POST["etdsearch"];
    }    
    else {
        $etdsearch = "";
    }

    if (isset($_POST["revsearch"])){
        $revsearch = $_POST["revsearch"];
    }    
    else {
        $revsearch = "";
    }

    if (isset($_POST["etpnsearch"])){
        $etpnsearch = $_POST["etpnsearch"];
    }    
    else {
        $etpnsearch = "";
    }

    if (isset($_POST["descsearch"])){
        $descsearch = $_POST["descsearch"];
    }    
    else {
        $descsearch = "";
    }

    if (isset($_POST["imdssearch"])){
        $imdssearch = $_POST["imdssearch"];
    }    
    else {
        $imdssearch = "";
    }

    if (isset($_POST["issearch"])){
        $issearch = $_POST["issearch"];
    }    
    else {
        $issearch = "";
    }

    if (isset($_POST["pdsearch"])){
        $pdsearch = $_POST["pdsearch"];
    }    
    else {
        $pdsearch = "";
    }

    if (isset($_POST["levelsearch"])){
        $levelsearch = $_POST["levelsearch"];
    }    
    else {
        $levelsearch = "";
    }

    if (isset($_POST["psssearch"])){
        $psssearch = $_POST["psssearch"];
    }    
    else {
        $psssearch = "";
    }

    if (isset($_POST["rssearch"])){
        $rssearch = $_POST["rssearch"];
    }    
    else {
        $rssearch = "";
    }  

    if (isset($_POST["sent1search"]) && isset($_POST["sent2search"])){
        $sent1search = $_POST["sent1search"];
        $sent2search = $_POST["sent2search"];
    }    
    else {
        $sent1search = "";
        $sent2search = "";
    }

    if (isset($_POST["psw1search"]) && isset($_POST["psw2search"])){
        $psw1search = $_POST["psw1search"];
        $psw2search = $_POST["psw2search"];
    }    
    else {
        $psw1search = "";
        $psw2search = "";
    }

    if (isset($_POST["originsearch"])){
        $originsearch = $_POST["originsearch"];
    }    
    else {
        $originsearch = "";
    } 

    if (isset($_POST["comsearch"])){
        $comsearch = $_POST["comsearch"];
    }    
    else {
        $comsearch = "";
    }

    if (isset($_POST["irnsearch"])){
        $irnsearch = $_POST["irnsearch"];
    }    
    else {
        $irnsearch = "";
    } 

    if (isset($_POST["reqn"])){
        $reqn = $_POST["reqn"];
    }    
    else {
        $reqn = NULL;
    }

    if (isset($_POST["curn"])){
        $curn = $_POST["curn"];
    }    
    else {
        $curn = NULL;
    }

    if (isset($_POST["imdn"])){
        $imdn = $_POST["imdn"];
    }    
    else {
        $imdn = NULL;
    }

    if (isset($_POST["imsn"])){
        $imsn = $_POST["imsn"];
    }    
    else {
        $imsn = NULL;
    }

    if (isset($_POST["ppdn"])){
        $ppdn = $_POST["ppdn"];
    }    
    else {
        $ppdn = NULL;
    }

    if (isset($_POST["lvln"])){
        $lvln = $_POST["lvln"];
    }    
    else {
        $lvln = NULL;
    }

    if (isset($_POST["pssn"])){
        $pssn = $_POST["pssn"];
    }    
    else {
        $pssn = NULL;
    }

    if (isset($_POST["rosn"])){
        $rosn = $_POST["rosn"];
    }    
    else {
        $rosn = NULL;
    }

    if (isset($_POST["stcn"])){
        $stcn = $_POST["stcn"];
    }    
    else {
        $stcn = NULL;
    }

    if (isset($_POST["pcsn"])){
        $pcsn = $_POST["pcsn"];
    }    
    else {
        $pcsn = NULL;
    }



    $logs = $model->search();
    $PPAPNS = $model->searchPPAPN();
    $Currents = $model->searchCS();
    $PIS = $model->searchPIS();
    $Customers = $model->searchCust();
    $Countries = $model->searchCountry();
    $CPNS = $model->searchCPN();
    $ETMS = $model->searchETM();
    $ETDS = $model->searchETD();
    $ETPNS = $model->searchETPN();
    $Descs = $model->searchDesc();
    $IMDS = $model->searchIMDS();
    $ISS = $model->searchIS();
    $PDS = $model->searchPD();
    $Levels = $model->searchLevel();
    $PSSS = $model->searchPS();
    $RSS = $model->searchRS();
    $Coms = $model->searchCom();
    $IRNS = $model->searchIRN();

    include 'view.php';
?>