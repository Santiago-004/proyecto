<?php 
    include "model.php";

    $model = new model();
    $model->cn();
    $logs = [];
    $Renewlogs = [];

    if (isset($_POST["submit1search"]) && isset($_POST["submit2search"])){
        $submit1search = $_POST["submit1search"];
        $submit2search = $_POST["submit2search"];
    }    
    else {
        $submit1search = "";
        $submit2search = "";
    }

    if (isset($_POST["custsearch"])){
        $custsearch = $_POST["custsearch"];
    }    
    else {
        $custsearch = NULL;
    }

    if (isset($_POST["oemsearch"])){
        $oemsearch = $_POST["oemsearch"];
    }    
    else {
        $oemsearch = NULL;
    }

    if (isset($_POST["counsearch"])){
        $counsearch = $_POST["counsearch"];
    }    
    else {
        $counsearch = NULL;
    }

    if (isset($_POST["levelsearch"])){
        $levelsearch = $_POST["levelsearch"];
    }    
    else {
        $levelsearch = NULL;
    }

    if (isset($_POST["sapsearch"])){
        $sapsearch = $_POST["sapsearch"];
    }    
    else {
        $sapsearch = NULL;
    }

    if (isset($_POST["cpnsearch"])){
        $cpnsearch = $_POST["cpnsearch"];
    }    
    else {
        $cpnsearch = NULL;
    }

    if (isset($_POST["tapesearch"])){
        $tapesearch = $_POST["tapesearch"];
    }    
    else {
        $tapesearch = NULL;
    }

    if (isset($_POST["widthsearch"])){
        $widthsearch = $_POST["widthsearch"];
    }    
    else {
        $widthsearch = NULL;
    }

    if (isset($_POST["lengthsearch"])){
        $lengthsearch = $_POST["lengthsearch"];
    }    
    else {
        $lengthsearch = NULL;
    }

    if (isset($_POST["colorsearch"])){
        $colorsearch = $_POST["colorsearch"];
    }    
    else {
        $colorsearch = NULL;
    }
    
    if (isset($_POST["imdssearch"])){
        $imdssearch = $_POST["imdssearch"];
    }    
    else {
        $imdssearch = NULL;
    }

    if (isset($_POST["ret1search"]) && isset($_POST["ret2search"])){
        $ret1search = $_POST["ret1search"];
        $ret2search = $_POST["ret2search"];
    }    
    else {
        $ret1search = "";
        $ret2search = "";
    }

    if (isset($_POST["psw1search"]) && isset($_POST["psw2search"])){
        $psw1search = $_POST["psw1search"];
        $psw2search = $_POST["psw2search"];
    }    
    else {
        $psw1search = "";
        $psw2search = "";
    }

    if (isset($_POST["ren1search"]) && isset($_POST["ren2search"])){
        $ren1search = $_POST["ren1search"];
        $ren2search = $_POST["ren2search"];
    }    
    else {
        $ren1search = "";
        $ren2search = "";
    }

    if (isset($_POST["req1search"]) && isset($_POST["req2search"])){
        $req1search = $_POST["req1search"];
        $req2search = $_POST["req2search"];
    }    
    else {
        $req1search = "";
        $req2search = "";
    }

    if (isset($_POST["sent1search"]) && isset($_POST["sent2search"])){
        $sent1search = $_POST["sent1search"];
        $sent2search = $_POST["sent2search"];
    }    
    else {
        $sent1search = "";
        $sent2search = "";
    }

    if (isset($_POST["pswr1search"]) && isset($_POST["pswr2search"])){
        $pswr1search = $_POST["pswr1search"];
        $pswr2search = $_POST["pswr2search"];
    }    
    else {
        $pswr1search = "";
        $pswr2search = "";
    }

    if (isset($_POST["retn"])){
        $retn = $_POST["retn"];
    }    
    else {
        $retn = NULL;
    }

    if (isset($_POST["pscn"])){
        $pscn = $_POST["pscn"];
    }    
    else {
        $pscn = NULL;
    }

    if (isset($_POST["renn"])){
        $renn = $_POST["renn"];
    }    
    else {
        $renn = NULL;
    }

    if (isset($_POST["reqn"])){
        $reqn = $_POST["reqn"];
    }    
    else {
        $reqn = NULL;
    }
    
    if (isset($_POST["stcn"])){
        $stcn = $_POST["stcn"];
    }    
    else {
        $stcn = NULL;
    }

    if (isset($_POST["pcsn"])){
        $pcsn = $_POST["pcsn"];
    }    
    else {
        $pcsn = NULL;
    }

    if (isset($_POST["comsearch"])){
        $comsearch = $_POST["comsearch"];
    }    
    else {
        $comsearch = NULL;
    }

    $logs = $model->search();
    $Customers = $model->searchCust();
    $OEMS = $model->searchOEM();
    $Countries = $model->searchCoun();
    $SAPS = $model->searchSAP();
    $CPNS = $model->searchCPN();
    $Tapes = $model->searchTape();
    $Widths = $model->searchWidth();
    $Lengths = $model->searchLength();
    $Colors = $model->searchColor();
    $IMDS = $model->searchIMDS();
    $Coms = $model->searchCom();

    include 'view.php';
?>