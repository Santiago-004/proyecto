<link href="./css/style.css" rel="stylesheet">
<style>
    tr {
        border: 0.1px solid black;
    }
    
    .clear {
        color: white;
        padding: 8px 14px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
        transition: background-color 0.2s;
        font-size: 14px;
        background-color: #16bacfff;
    }

    .clear:hover {
        background-color: #1dd1e8ff;
        color: white;
    }

    .error {
        background-color: #ffe6e6;
        color: #d63031;
        padding: 10px;
        border-radius: 8px;
        margin-bottom: 15px;
        font-size: 0.9rem;
    }

    .form-search .camp {
        flex: 1 1 30%;
        min-width: 250px;
    }

    .form-search input[type="date"]{
        padding: 8px 10px;
        border: 1px solid #bbb;
        border-radius: 8px;
        width: 46%;
        box-sizing: border-box;
    }

    @media (max-width: 1630px) {
        .note {
            padding: 15px 10px;
        }
    }
    
    @media (max-width: 1300px) {
        .form-search .camp
        {
            flex: 1 1 40%;
        }
    }

    @media (max-width: 900px) {
        .form-search .camp
        {
            flex: 1 1 100%;
        }
    }
</style>
<form action="" id="form" method="post" class="form-search">
    <input type="hidden" name="page" value="Products">
    <div class="camp">
        <label>Customer PN:</label>
        <input type="text" maxlength="30" name="idsearch" list="CPNs" value="<?php if ($idsearch != NULL) { echo $idsearch;} ?>">
        <datalist id="CPNs">
            <?php foreach ($CPNs as $CPN) {  ?>
                <option value="<?php echo $CPN['Customer_PN'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Customer:</label>
        <input type="text" maxlength="70" name="custsearch" list="Customers" value="<?php if ($custsearch != NULL) { echo $custsearch;} ?>">
        <datalist id="Customers">
            <?php foreach ($Customers as $Customer) {  ?>
                <option value="<?php echo $Customer['Name'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Eurotech PN:</label>
        <input type="text" maxlength="12" name="etpnsearch" list="ETPNs" value="<?php if ($etpnsearch != NULL) { echo $etpnsearch;} ?>">
        <datalist id="ETPNs">
            <?php foreach ($ETPNs as $ETPN) {  ?>
                <option value="<?php echo $ETPN['Eurotech_PN'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp"></div>
    
    <div class="campbtn">
        <button type="submit" name="btnsearch" class="insert">Search</button>
        <button style="margin: 0px 0px 0px 15px;"  type="submit" name="btnsearch" class="clear" onclick="clearForm()">Clear All</button>
    </div>
</form>

<div style="display: flex;">
    <form action="?page=CustomersPN" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insert" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="idsearch" value="<?php if(isset($_POST['idsearch'])) { echo $_POST['idsearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
        <button type="submit" class="insert">New Customer PN</button>
    </form>
</div>

<?php if($logs == NULL) { ?>
    <br>
    <h1>No results.</h1>
<?php } ?>

<?php if($logs != NULL) { ?>
    <div class="table-responsive">
        <table class="table table-bordered" id="Customer_table">
            <tr>    
                <th style="background-color:#1c18AA;"></th>
                <th style="background-color:#1c18AA;"></th>
                <th style="background-color:#1c18AA; color:white" onclick="sortTable(2, 'text')">Customer PN</th>
                <th style="background-color:#1c18AA; color:white" onclick="sortTable(3, 'text')">Customer</th>
                <th style="background-color:#1c18AA; color:white" onclick="sortTable(4, 'text')">Eurotech PN</th>
            </tr>
            
            <?php foreach ($logs as $log) { ?>
                <tr>
                    <td style="text-align: center; vertical-align: middle;">
                        <form action="?page=CustomersPN" method="post" style="display:inline;">
                            <input type="hidden" name="edit" value="">
                            <input type="hidden" name="btnsearch" value="1">
                            <input type="hidden" name="idsearch" value="<?php if(isset($_POST['idsearch'])) { echo $_POST['idsearch']; } ?>">
                            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                            <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                            <input type="hidden" name="IDedit" value="<?php echo $log['Customer_PN']; ?>">
                            <button type="submit" class="editar">Edit</button>
                        </form>
                    </td>
                    <td style="text-align: center; vertical-align: middle;">
                        <form action="?page=CustomersPN" method="post" style="display:inline;">
                            <input type="hidden" name="delete" value="">
                            <input type="hidden" name="btnsearch" value="1">
                            <input type="hidden" name="idsearch" value="<?php if(isset($_POST['idsearch'])) { echo $_POST['idsearch']; } ?>">
                            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                            <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                            <input type="hidden" name="IDdelete" value="<?php echo $log['Customer_PN']; ?>">
                            <button type="submit" class="eliminar">Delete</button>
                        </form>
                    </td>
                    <td><?php echo $log['Customer_PN']; ?></td>
                    <td><?php echo $log['Name']; ?></td>
                    <td><?php echo $log['Eurotech_PN']; ?></td>
                </tr> 
            <?php } ?>
        </table> 
    </div>
<?php } 

 if (isset($_POST['insert'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New Customer PN</h2>
    <?php if (isset($error)) : ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form action="?page=CustomersPN" method="post">
        <input type="hidden" name="confirmI" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="idsearch" value="<?php if(isset($_POST['idsearch'])) { echo $_POST['idsearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
        <label><label style="color:red">*</label> Customer PN:</label>
        <input type="text" maxlength="30" name="Customer_PN" list="CPNs" value="<?php if(isset($_POST['Customer_PN'])) { echo $_POST['Customer_PN']; } ?>" required> <br>

        <label><label style="color:red">*</label> Customer:</label>
        <input type="text" maxlength="70" name="Name" list="Customers" value="<?php if(isset($_POST['Name'])) { echo $_POST['Name']; } ?>" required> <br>

        <label><label style="color:red">*</label> Eurotech PN:</label>
        <input type="text" maxlength="12" name="Eurotech_PN" list="ETPNs" value="<?php if(isset($_POST['Eurotech_PN'])) { echo $_POST['Eurotech_PN']; } ?>" required>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if (isset($_POST['edit'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Update Customer PN</h2>
    <?php if (isset($error)) : ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form action="?page=CustomersPN" method="post">
        <input type="hidden" name="confirmU" value="1">
        <input type="hidden" name="Customer_PN" value="<?php if(isset($_POST['Customer_PN'])) { echo $_POST['Customer_PN']; } else { echo $_POST['IDedit']; } ?>">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="idsearch" value="<?php if(isset($_POST['idsearch'])) { echo $_POST['idsearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">

        <label><label style="color:red">*</label> Customer:</label>
        <input type="text" maxlength="70" name="Name" list="Customers" value="<?php if(isset($cpnData['Name'])) { echo $cpnData['Name']; } else { if(isset($_POST['Name'])) { echo $_POST['Name'];  } } ?>" required> <br>

        <label><label style="color:red">*</label> Eurotech PN:</label>
        <input type="text" maxlength="12" name="Eurotech_PN" list="ETPNs" value="<?php if(isset($cpnData['Eurotech_PN'])) { echo $cpnData['Eurotech_PN']; } else { if(isset($_POST['Eurotech_PN'])) { echo $_POST['Eurotech_PN'];  } } ?>" required>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php }

if (isset($_POST['delete'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Delete Customer PN</h2>
    <?php if (isset($error)) : ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form action="?page=CustomersPN" method="post">
        <input type="hidden" name="confirmD" value="1">
        <input type="hidden" name="Customer_PN" value="<?php if(isset($_POST['Customer_PN'])) { echo $_POST['Customer_PN']; } else { echo $_POST['IDdelete']; } ?>">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="idsearch" value="<?php if(isset($_POST['idsearch'])) { echo $_POST['idsearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
        <h5><b>Are you sure you want to delete the data of this Customer PN?</b></h5> <br>
        <h6><b>Customer PN:</b> <?php echo $cpnDataD['Customer_PN'] ?></h6>
        <h6><b>Customer:</b> <?php echo $cpnDataD['Name'] ?></h6>
        <h6><b>Eurotech PN:</b> <?php echo $cpnDataD['Eurotech_PN'] ?></h6>

        <button type="submit">Confirm</button>
    </form>
  </div>
</div>
<?php }

if ($Deleted != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Register Deleted</h2>
        
        <form action="?page=CustomersPN" method="post">
            <h6><b>The register was deleted correctly.</b></h6>
        </form>
    </div>
    </div>
<?php }   ?>

<script>
    function closeForm() {
        document.getElementById('formularioModal').style.display = 'none';
    }

    function sendForm() {
        closeForm();
        return true;
    }

    function clearForm() {
        document.querySelectorAll("#form input[type='text']").forEach(input => input.value = "");
        document.querySelectorAll("#form input[type='date']").forEach(input => input.value = "");

        const radioButtons = document.querySelectorAll("#form input[type='radio']");
        const defaultValue = '';

        for (const radio of radioButtons) {
            if (radio.value === defaultValue) {
                radio.checked = true;
            }
        }

        const selects = document.querySelectorAll("#form select");

        for (const select of selects) {
            select.value = defaultValue;
        }
    }

    let sortOrder = {};

    function sortTable(columnIndex, type) {
        const table = document.getElementById("Customer_table");
        const rows = Array.from(table.rows).slice(1);
        const isAscending = !sortOrder[columnIndex];
        
        rows.sort((rowA, rowB) => {
            const cellA = rowA.cells[columnIndex].innerText.trim();
            const cellB = rowB.cells[columnIndex].innerText.trim();
            
            if (type === "date") {
                const dateA = new Date(cellA);
                const dateB = new Date(cellB);
                const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
                const dateformatedA = dateA.toLocaleDateString('ja-JP', options);
                const dateformatedB = dateB.toLocaleDateString('ja-JP', options);
                return isAscending ? dateformatedA.localeCompare(dateformatedB) : dateformatedB.localeCompare(dateformatedA);
            } else if (type === "text") {
                return isAscending ? cellA.localeCompare(cellB) : cellB.localeCompare(cellA);
            }
        });

        rows.forEach(row => table.tBodies[0].appendChild(row));
        sortOrder[columnIndex] = isAscending;
    }
</script>