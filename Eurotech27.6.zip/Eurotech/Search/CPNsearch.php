<?php
header('Content-Type: application/json');

$connection = new mysqli("localhost", "root", "", "eurotechdb");
if ($connection->connect_error) {
    echo json_encode(["success" => false, "error" => "Connection Error"]);
    exit;
}

$Customer_PN = $_POST['Customer_PN'] ?? '';

if ($Customer_PN !== '') {
    $stmt = $connection->prepare("SELECT Eurotech_PN,  Description, c.Name AS 'Customer', v.Short_name AS 'Vendor', Supplier_PN, IMDS_ID_no FROM customer_pn cpn
                                    INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                                    INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                    LEFT JOIN vendors v ON p.Supplier = v.Vendor_ID
                                    WHERE Customer_PN = ? LIMIT 1");
    $stmt->bind_param("s", $Customer_PN);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($fila = $resultado->fetch_assoc()) {
        echo json_encode([
            "success" => true, 
            "Eurotech_PN" => $fila['Eurotech_PN'],
            "Description" => $fila['Description'],
            "Customer" => $fila['Customer'],
            "Vendor" => $fila['Vendor'],
            "Supplier_PN" => $fila['Supplier_PN'],
            "IMDS_ID_no" => $fila['IMDS_ID_no']
        ]);
    } else {
        echo json_encode(["success" => false]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false]);
}

$connection->close();
?>