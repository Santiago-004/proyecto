<?php
header('Content-Type: application/json');

$connection = new mysqli("localhost", "root", "", "eurotechdb");
if ($connection->connect_error) {
    echo json_encode(["success" => false, "error" => "Connection Error"]);
    exit;
}

$Customer = $_POST['Customer'] ?? '';
$Country = $_POST['Country'] ?? '';

if ($Customer !== '' && $Country !== '') {
    $stmt = $connection->prepare("
        SELECT PPAP_Number
        FROM ppap p
        INNER JOIN customer_pn cpn ON p.FK_Customer_PN = cpn.Customer_PN
        INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
        LEFT JOIN customer_ppap_number cppn ON c.Customer_ID = cppn.FK_Customer_ID
        WHERE Name = ? AND Country = ?
        ORDER BY PPAP_Number DESC LIMIT 1
    ");
    $stmt->bind_param("ss", $Customer, $Country);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($fila = $resultado->fetch_assoc()) {
        if($fila['PPAP_Number'] != NULL) {
            $PPAP_N = explode("-", $fila['PPAP_Number']);
            $PPAP_Num = $PPAP_N[1];
            $next = (int)$PPAP_Num + 1;

            $length = 4;
            $new_right_number = str_pad($next, $length, "0", STR_PAD_LEFT);
            $fila['PPAP_Number'] = $PPAP_N[0]."-".$new_right_number;

            echo json_encode([
                "success" => true,
                "PPAP_Number" => $fila['PPAP_Number']
            ]);
        }
        else {
            echo json_encode(["success" => false]);
        }        
    } else {
        echo json_encode(["success" => false]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false]);
}

$connection->close();
?>