<link href="./css/style.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
    .clear {
        color: white;
        padding: 8px 14px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
        transition: background-color 0.2s;
        font-size: 14px;
        background-color: #16bacfff;
    }

    .clear:hover {
        background-color: #1dd1e8ff;
        color: white;
    }

    .error {
        background-color: #ffe6e6;
        color: #d63031;
        padding: 10px;
        border-radius: 8px;
        margin-bottom: 15px;
        font-size: 0.9rem;
    }

    .copy {
        color: black;
        padding: 8px 14px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
        transition: background-color 0.2s;
        font-size: 14px;
        background-color: #e6df1dff;
    }

    .copy:hover {
        background-color: #f9f110ff;
    }

    .form-search .camp{
        flex: 1 1 20%;
    }

    .form-search .camp2 {
        display: none;
    }

    .form-search .camp3 {
        flex: 1 1 20%;
    }

    .form-search input[type="date"],
    .form-search input[type="number"] {
        padding: 8px 10px;
        border: 1px solid #bbb;
        border-radius: 8px;
        width: 46%;
        box-sizing: border-box;
    }
    
    tr {
        border: 0.1px solid black;
    }

    @media (max-width: 1530px) {
        .form-search .camp {
            flex: 1 1 40%; 
            min-width: 300px;
        }

        .form-search .camp2 {
            display: flex;
            flex: 1 1 40%;
        }

        .form-search .camp3 {
            display: none;
        }
    }

    @media (max-width: 1501px) {
        .form-search input[type="number"] {
            width: 46%;
        }
    }

    @media (max-width: 1040px) {
        .form-search .camp {
            flex: 1 1 100%; 
            min-width: 300px;
        }
    }
</style>
<form action="" id="form" method="post" class="form-search">
    <input type="hidden" name="page" value="Tapes">
    <div class="camp">
        <label>Days to Submit:</label>
        <input type="number" name="days1search" id="days1search" value="<?php if ($days1search != NULL) { echo $days1search;} ?>"> -
        <input type="number" name="days2search" id="days2search" value="<?php if ($days2search != NULL) { echo $days2search;} ?>">
    </div>
    
    <div class="camp">
        <label>PPAP Number:</label>
        <input type="text" name="ppapnsearch" maxlength="12" list="PPAPN" value="<?php if ($ppapnsearch != NULL) { echo $ppapnsearch;} ?>">
        <datalist id="PPAPN">
            <?php foreach ($PPAPNS as $PPAPN) {  ?>
                <option value="<?php echo $PPAPN['PPAP_Number'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>PPAP Req'd by Customer:</label>
        <input type="date" name="date1search" value="<?php if ($date1search != NULL) { echo $date1search;} ?>"> - <input type="date" name="date2search" value="<?php if ($date2search != NULL) { echo $date2search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="req1n" id="" value="" <?php if ($req1n != "N" && $req1n != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="req1n" id="" value="N" <?php if ($req1n == "N") { echo "checked";} ?>> No date        
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="req1n" id="" value="Y" <?php if ($req1n == "Y") { echo "checked";} ?>> W/ date
    </div>

    <div class="camp">
        <label>PPAP Requested to Vendor:</label>
        <input type="date" name="reqv1search" value="<?php if ($reqv1search != NULL) { echo $reqv1search;} ?>"> - <input type="date" name="reqv2search" value="<?php if ($reqv2search != NULL) { echo $reqv2search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="reqvn" id="" value="" <?php if ($reqvn != "N" && $reqvn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="reqvn" id="" value="N" <?php if ($reqvn == "N") { echo "checked";} ?>> No date        
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="reqvn" id="" value="Y" <?php if ($reqvn == "Y") { echo "checked";} ?>> W/ date
    </div>

    <div class="camp">
        <label>Current Status:</label>
        <input type="text" name="currentsearch" maxlength="255" list="Current" value="<?php  if ($currentsearch != NULL) { echo $currentsearch;} ?>">
        <datalist id="Current">
            <?php foreach ($Currents as $Current) {  ?>
                <option value="<?php echo $Current['Current_Status'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="curn" id="" value="" <?php if ($curn != "N" && $curn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="curn" id="" value="N" <?php if ($curn == "N") { echo "checked";} ?>> No current status
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="curn" id="" value="Y" <?php if ($curn == "Y") { echo "checked";} ?>> W/ current status
    </div>

    <div class="camp">
        <label>Vendor:</label>
        <input type="text" name="pisearch" maxlength="20" list="PI" value="<?php if ($pisearch != NULL) { echo $pisearch;} ?>">
        <datalist id="PI">
            <?php foreach ($PIS as $PI) {  ?>
                <option value="<?php echo $PI['Short_name'] ?>">
            <?php } ?>
        </datalist>
    </div>
    
    <div class="camp">
        <label>Supplier PN:</label>
        <input type="text" name="sapsearch" maxlength="6" list="SAP" value="<?php if ($sapsearch != NULL) { echo $sapsearch;} ?>">
        <datalist id="SAP">
            <?php foreach ($SAPS as $SAP) {  ?>
                <option value="<?php echo $SAP['Supplier_PN'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>OEM:</label>
        <input type="text" name="oemsearch" maxlength="255" list="OEM" value="<?php if ($oemsearch != NULL) { echo $oemsearch;} ?>">
        <datalist id="OEM">
            <?php foreach ($OEMS as $OEM) {  ?>
                <option value="<?php echo $OEM['OEM'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp"></div>

    <div class="camp">
        <label>Customer:</label>
        <input type="text" name="custsearch" maxlength="70" list="Customer" value="<?php if ($custsearch != NULL) { echo $custsearch;} ?>">
        <datalist id="Customer">
            <?php foreach ($Customers as $Customer) {  ?>
                <option value="<?php echo $Customer['Name'] ?>">
            <?php } ?>
        </datalist>
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="cusn" id="" value="" <?php if ($cusn != "N" && $cusn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="cusn" id="" value="N" <?php if ($cusn == "N") { echo "checked";} ?>> No Customer
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="cusn" id="" value="Y" <?php if ($cusn == "Y") { echo "checked";} ?>> W/ Customer
    </div>

    <div class="camp">
        <label>Country:</label>
        <input type="text" name="counsearch" maxlength="30" list="Country" value="<?php if ($counsearch != NULL) { echo $counsearch;} ?>">
        <datalist id="Country">
            <?php foreach ($Countries as $Country) {  ?>
                <option value="<?php echo $Country['Country'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Customer PN:</label>
        <input type="text" name="cpnsearch" maxlength="30" list="CPN" value="<?php if ($cpnsearch != NULL) { echo $cpnsearch;} ?>">
        <datalist id="CPN">
            <?php foreach ($CPNS as $CPN) {  ?>
                <option value="<?php echo $CPN['Customer_PN'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>ET Model:</label>
        <input type="text" name="etmsearch" maxlength="10" list="ETM" value="<?php if ($etmsearch != NULL) { echo $etmsearch;} ?>">
        <datalist id="ETM">
            <?php foreach ($ETMS as $ETM) {  ?>
                <option value="<?php echo $ETM['ET_Model'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>ET Dwg:</label>
        <input type="text" name="etdsearch" maxlength="8" list="ETD" value="<?php if ($etdsearch != NULL) { echo $etdsearch;} ?>">
        <datalist id="ETD">
            <?php foreach ($ETDS as $ETD) {  ?>
                <option value="<?php echo $ETD['ET_Dwg'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Rev:</label>
        <input type="text" name="revsearch" maxlength="5" list="Rev" value="<?php if ($revsearch != NULL) { echo $revsearch;} ?>">
        <datalist id="Rev">
            <?php foreach ($Revs as $Rev) {  ?>
                <option value="<?php echo $Rev['Rev'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>ET PN:</label>
        <input type="text" name="etpnsearch" maxlength="12" list="ETPN" value="<?php if ($etpnsearch != NULL) { echo $etpnsearch;} ?>">
        <datalist id="ETPN">
            <?php foreach ($ETPNS as $ETPN) {  ?>
                <option value="<?php echo $ETPN['Eurotech_PN'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Description:</label> 
        <input type="text" name="descsearch" maxlength="255" list="Desc" value="<?php if ($descsearch != NULL) { echo $descsearch;} ?>">
        <datalist id="Desc">
            <?php foreach ($Descs as $Desc) {  ?>
                <option value="<?php echo $Desc['Description'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp2"></div>

    <div class="camp">
        <label>IMDS Number:</label>
        <input type="text" name="imdssearch" maxlength="15" list="IMDS" value="<?php if ($imdssearch != NULL) { echo $imdssearch;} ?>">
        <datalist id="IMDS">
            <?php foreach ($IMDS as $IM) {  ?>
                <option value="<?php echo $IM['IMDS'] ?>">
            <?php } ?>
        </datalist>
    </div>
    
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="imdn" id="" value="" <?php if ($imdn != "N" && $imdn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="imdn" id="" value="N" <?php if ($imdn == "N") { echo "checked";} ?>> No IMDS
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="imdn" id="" value="Y" <?php if ($imdn == "Y") { echo "checked";} ?>> W/ IMDS
    </div>

    <div class="camp3"></div>

    <div class="camp">
        <label>Level:</label>
        <select name="levelsearch">
            <option value="">All</option>
            <option value="1" <?php if ($levelsearch != NULL && $levelsearch == '1') { echo 'selected';} ?>>1</option>
            <option value="2" <?php if ($levelsearch != NULL && $levelsearch == '2') { echo 'selected';} ?>>2</option>
            <option value="3" <?php if ($levelsearch != NULL && $levelsearch == '3') { echo 'selected';} ?>>3</option>
            <option value="4" <?php if ($levelsearch != NULL && $levelsearch == '4') { echo 'selected';} ?>>4</option>
            <option value="5" <?php if ($levelsearch != NULL && $levelsearch == '5') { echo 'selected';} ?>>5</option>
        </select>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="lvln" id="" value="" <?php if ($lvln != "N" && $lvln != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="lvln" id="" value="N" <?php if ($lvln == "N") { echo "checked";} ?>> No level
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="lvln" id="" value="Y" <?php if ($lvln == "Y") { echo "checked";} ?>> W/ level
    </div>

    <div class="camp">
        <label>PPAP Samples Status:</label>
        <input type="text" name="psssearch" maxlength="20" list="PSS" value="<?php if ($psssearch != NULL) { echo $psssearch;} ?>">
        <datalist id="PSS">
            <?php foreach ($PSSS as $PSS) {  ?>
                <option value="<?php echo $PSS['Samples_Status'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="pssn" id="" value="" <?php if ($pssn != "N" && $pssn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pssn" id="" value="N" <?php if ($pssn == "N") { echo "checked";} ?>> No PPAP sample status
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pssn" id="" value="Y" <?php if ($pssn == "Y") { echo "checked";} ?>> W/ PPAP sample status
    </div>

    <div class="camp">
        <label>Reason of Submission:</label>
        <input type="text" name="rssearch" maxlength="20" list="RS" value="<?php if ($rssearch != NULL) { echo $rssearch;} ?>">
        <datalist id="RS">
            <?php foreach ($RSS as $RS) {  ?>
                <option value="<?php echo $RS['Reason_Submission'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="rosn" id="" value="" <?php if ($rosn != "N" && $rosn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="rosn" id="" value="N" <?php if ($rosn == "N") { echo "checked";} ?>> No reason of submission
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="rosn" id="" value="Y" <?php if ($rosn == "Y") { echo "checked";} ?>> W/ reason of submission
    </div>

    <div class="camp">
        <label>Received Date:</label>
        <input type="date" name="date3search" value="<?php if ($date3search != NULL) { echo $date3search;} ?>"> - <input type="date" name="date4search" value="<?php if ($date4search != NULL) { echo $date4search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="recn" id="" value="" <?php if ($recn != "N" && $recn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="recn" id="" value="N" <?php if ($recn == "N") { echo "checked";} ?>> No date        
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="recn" id="" value="Y" <?php if ($recn == "Y") { echo "checked";} ?>> W/ date
    </div>

    <div class="camp">
        <label>Sent to Customer:</label>
        <input type="date" name="ret1search" value="<?php if ($ret1search != NULL) { echo $ret1search;} ?>"> - <input type="date" name="ret2search" value="<?php if ($ret2search != NULL) { echo $ret2search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="retn" id="" value="" <?php if ($retn != "N" && $retn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="retn" id="" value="N" <?php if ($retn == "N") { echo "checked";} ?>> No date
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="retn" id="" value="Y" <?php if ($retn == "Y") { echo "checked";} ?>> W/ date
    </div>

    <div class="camp">
        <label>PSW returned from Customer Signed:</label>
        <input type="date" name="psw1search" value="<?php if ($psw1search != NULL) { echo $psw1search;} ?>"> - <input type="date" name="psw2search" value="<?php if ($psw2search != NULL) { echo $psw2search;} ?>">
    </div>
    <div class="camp">
        <input style="margin: 10px 0px 0px 10px;" type="radio" name="pscn" id="" value="" <?php if ($pscn != "N" && $pscn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pscn" id="" value="N" <?php if ($pscn == "N") { echo "checked";} ?>> No date
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pscn" id="" value="Y" <?php if ($pscn == "Y") { echo "checked";} ?>> W/ date
    </div>

    <div class="camp">
        <label>PPAP from Shipments / Origin from Report:</label>
        <input type="radio" name="pfsn" value="" <?php if ($pfsn != "N" && $pfsn != "Y") { echo "checked";} ?> checked> All <br>
        <input type="radio" name="pfsn" value="N" <?php if ($pfsn == "N") { echo "checked";} ?>> No <br>
        <input type="radio" name="pfsn" value="Y" <?php if ($pfsn == "Y") { echo "checked";} ?>> Yes
    </div>

    <div class="camp">
        <label>Comments:</label>
        <input type="text" name="comsearch" maxlength="255" list="Com" value="<?php if ($comsearch != NULL) { echo $comsearch;} ?>">
        <datalist id="Com">
            <?php foreach ($Coms as $Com) {  ?>
                <option value="<?php echo $Com['Comments'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Inspection Report Number:</label>
        <input type="text" name="irnsearch" maxlength="10" list="IRN" value="<?php if ($irnsearch != NULL) { echo $irnsearch;} ?>">
        <datalist id="IRN">
            <?php foreach ($IRNS as $IRN) {  ?>
                <option value="<?php echo $IRN['Inspection_Rep_Number'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp"></div>
    <div class="camp"></div>
    <div class="camp"></div>
    <div class="camp"></div>

    <div class="campbtn">
        <button type="submit" name="btnsearch" class="insert">Search</button>
        <button style="margin: 0px 0px 0px 15px;"  type="submit" name="btnsearch" class="clear" onclick="clearForm()">Clear All</button>
    </div>
</form>

<div style="display: flex;">
    <form action="?page=Tapes" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insert" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
        <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
        <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
        <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
        
        
        
        
        <button type="submit" class="insert">New PPAP</button>
    </form>
</div>


<?php  if(
    $logs == NULL 
    // && $logsNP == NULL
    ) { ?>
    <br>
    <h1>No results.</h1>
<?php }

if(
$logs != NULL 
// || $logsNP != NULL
) { ?>
    <div class="table-responsive">
        <table class="table table-bordered" id="PPAP_table">
                <tr>
                    <?php if($_SESSION["Role"] == 'Administrator') { ?>
                            <th style="background-color:#1c18AA; color:white"></th>
                            <th style="background-color:#1c18AA; color:white"></th>
                            <th style="background-color:#1c18AA; color:white"></th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(3, 'number')">Days to Submit</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(4, 'text')">PPAP Number</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(5, 'date')">PPAP Req'd by Customer</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(6, 'date')">PPAP Requested to Vendor</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(7, 'text')">Current Status</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(8, 'text')">Vendor</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(9, 'text')">Supplier PN</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(10, 'text')">OEM</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(11, 'text')">Customer</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(12, 'text')">Country</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(13, 'text')">Customer PN</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(14, 'text')">ET Model</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(15, 'text')">ET Dwg</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(16, 'text')">Rev</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(17, 'text')">ET PN</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(18, 'text')">Description</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(19, 'text')">Tape</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(20, 'text')">Width (MM)</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(21, 'text')">Length (M)</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(22, 'text')">Color</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(23, 'text')">IMDS Number</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(24, 'text')">Level</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(25, 'text')">PPAP Samples Status</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(26, 'text')">Reason of Submission</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(27, 'date')">Received Date</th>
                            <th style="background-color:#1c18AA; color:white">PPAP ET & IMDS ET / PSW ET & IMDS ET</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(29, 'date')">Sent to Customer</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(30, 'date')">PSW returned from Cust Signed</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(31, 'text')">PPAP from Shipments / Origin from Report</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(32, 'text')">Comments</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(33, 'text')">Inspection Report Number</th>
                    <?php } 
                    else { ?>
                            <th style="background-color:#1c18AA; color:white"></th>
                            <th style="background-color:#1c18AA; color:white"></th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(2, 'number')">Days to Submit</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(3, 'text')">PPAP Number</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(4, 'date')">PPAP Req'd by Customer</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(5, 'date')">PPAP Requested to Vendor</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(6, 'text')">Current Status</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(7, 'text')">Vendor</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(8, 'text')">Supplier PN</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(9, 'text')">OEM</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(10, 'text')">Customer</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(11, 'text')">Country</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(12, 'text')">Customer PN</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(13, 'text')">ET Model</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(14, 'text')">ET Dwg</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(15, 'text')">Rev</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(16, 'text')">ET PN</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(17, 'text')">Description</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(18, 'text')">Tape</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(19, 'text')">Width (MM)</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(20, 'text')">Length (M)</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(21, 'text')">Color</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(22, 'text')">IMDS Number</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(23, 'text')">Level</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(24, 'text')">PPAP Samples Status</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(25, 'text')">Reason of Submission</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(26, 'date')">Received Date</th>
                            <th style="background-color:#1c18AA; color:white">PPAP ET & IMDS ET / PSW ET & IMDS ET</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(28, 'date')">Sent to Customer</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(29, 'date')">PSW returned from Cust Signed</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(30, 'text')">PPAP from Shipments / Origin from Report</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(31, 'text')">Comments</th>
                            <th style="background-color:#1c18AA; color:white" onclick="sortTable(32, 'text')">Inspection Report Number</th>
                    <?php } ?>
                </tr>
                <?php foreach ($logs as $log) { ?>
                        <tr>
                            <?php if($log['PPAP_Number'] != NULL) {
                                $PPAP_Number = explode("-", $log['PPAP_Number']);
                            }

                            // Green
                            if(($log['PPAP_Signed_Date'] != NULL && $log['Product'] != 'Tube') || 
                                ($log['PPAP_Signed_Date'] != NULL && $log['Product'] == 'Tube' && isset($PPAP_Number[0]) && $PPAP_Number[0] == $log['Customer_PPAP_Number'])
                            ) {?>
                                <td style="text-align: center; vertical-align: middle;">
                                    <form action="?page=Tapes" method="post" style="display:inline;">
                                        <input type="hidden" name="edit" value="">
                                        <input type="hidden" name="btnsearch" value="1">
                                        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                        <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
                                        <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
                                        <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
                                        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                        
                                        
                                        
                                        
                                        <input type="hidden" name="IDedit" value="<?php echo $log['PPAP_ID']; ?>">
                                        <button type="submit" class="editar">Edit</button>
                                    </form>
                                </td>
                                <?php if($_SESSION["Role"] == 'Administrator') { ?>
                                    <td style="text-align: center; vertical-align: middle;">
                                        <form action="?page=Tapes" method="post" style="display:inline;">
                                            <input type="hidden" name="delete" value="">
                                            <input type="hidden" name="btnsearch" value="1">
                                            <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                            <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                            <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                            <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                            <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                            <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                            <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
                                            <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
                                            <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
                                            <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                            <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                            <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                            <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                            <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                            <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                            <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                            <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                            <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                            <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                            <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                            <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                            <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                            <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                            <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
                                            <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                            <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                            <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                            <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                            <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                            <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                            <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                            <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                            <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                            <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                            <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                            <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                            <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                            <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                            <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                            <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                            <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                            <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                            <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                            
                                            
                                            
                                            
                                            <input type="hidden" name="IDdelete" value="<?php echo $log['PPAP_ID']; ?>">
                                            <button type="submit" class="eliminar">Delete</button>
                                        </form>
                                    </td>
                                <?php } ?>
                                <td style="text-align: center; vertical-align: middle;">
                                    <form action="?page=Tapes" method="post" style="display:inline;">
                                        <input type="hidden" name="insert" value="">
                                        <input type="hidden" name="btnsearch" value="1">
                                        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                        <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
                                        <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
                                        <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
                                        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                        <input type="hidden" name="bssearch" value="<?php if(isset($_POST['bssearch'])) { echo $_POST['bssearch']; } ?>">
                                        <input type="hidden" name="cabsearch" value="<?php if(isset($_POST['cabsearch'])) { echo $_POST['cabsearch']; } ?>">
                                        <input type="hidden" name="tapsearch" value="<?php if(isset($_POST['tapsearch'])) { echo $_POST['tapsearch']; } ?>">
                                        <input type="hidden" name="tubsearch" value="<?php if(isset($_POST['tubsearch'])) { echo $_POST['tubsearch']; } ?>">
                                        <input type="hidden" name="PPAP_Number" value="<?php echo $log['PPAP_Number']; ?>">
                                        <input type="hidden" name="Vendor" value="<?php echo $log['Vendor']; ?>">
                                        <input type="hidden" name="Supplier_PN" value="<?php echo $log['Supplier_PN']; ?>">
                                        <input type="hidden" name="OEM" value="<?php echo $log['OEM']; ?>">
                                        <input type="hidden" name="Customer" value="<?php echo $log['Customer']; ?>">
                                        <input type="hidden" name="Country" value="<?php echo $log['Country']; ?>">
                                        <input type="hidden" name="Customer_PN" value="<?php echo $log['Customer_PN']; ?>">
                                        <input type="hidden" name="Eurotech_PN" value="<?php echo $log['Eurotech_PN']; ?>">
                                        <input type="hidden" name="Description" value="<?php echo $log['Description']; ?>">
                                        <input type="hidden" name="IMDS" value="<?php echo $log['IMDS']; ?>">
                                        <input type="hidden" name="PPAP_Level" value="<?php echo $log['PPAP_Level']; ?>">
                                        <input type="hidden" name="PPAP_From_Shipments" value="<?php echo $log['PPAP_From_Shipments']; ?>">
                                        <button type="submit" class="copy">Copy</button>
                                    </form>
                                </td>
                                <td 
                                    <?php if($log['Days to Submit'] <= 18) { ?>
                                        style="background-color: rgba(0, 231, 0, 0.7);"
                                    <?php } 
                                    if($log['Days to Submit'] >= 19 && $log['Days to Submit'] < 30) { ?>
                                        style="background-color: rgba(233, 233, 0, 0.7);"
                                    <?php } 
                                    if($log['Days to Submit'] >= 30) { ?>
                                        style="background-color: rgba(204, 0, 34, 0.8); color:white;"
                                    <?php } ?>
                                ><?php if($log['Days to Submit'] > 0 || $log['Days to Submit'] < 0) { echo $log['Days to Submit']; } if($log['Days to Submit'] == 0) { echo "0"; }?></td>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $log['PPAP_Number']; ?></td>
                                <?php if($log['PPAP_Request_Date'] != NULL) { 
                                    $reqDate = new DateTime($log['PPAP_Request_Date']); ?>
                                    <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $reqDate->format('d/M/Y') ?></td>
                                <?php }
                                if($log['PPAP_Request_Date'] == NULL) { ?>
                                    <td style="background-color: rgba(0, 206, 0, 0.5);"></td>
                                <?php } ?>
                                <?php if($log['PPAP_Requested_Vendor'] != NULL) { 
                                    $reqVend = new DateTime($log['PPAP_Requested_Vendor']); ?>
                                    <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $reqVend->format('d/M/Y') ?></td>
                                <?php } 
                                if($log['PPAP_Requested_Vendor'] == NULL) { ?>
                                    <td style="background-color: rgba(0, 206, 0, 0.5);"></td>
                                <?php } ?>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $log['Current_Status']; ?></td>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php if($log['Vendor'] != NULL) { echo $log['Vendor']; ?> (<?php echo $log['Short_name']; ?>) <?php } ?></td>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $log['Supplier_PN']; ?></td>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $log['OEM']; ?></td>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $log['Customer']; ?></td>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $log['Country']; ?></td>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $log['Customer_PN']; ?></td>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $log['ET_Model']; ?></td>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $log['ET_Dwg']; ?></td>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $log['Rev']; ?></td>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $log['Eurotech_PN']; ?></td>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $log['Description']; ?></td>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $log['Tape']; ?></td>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $log['Width']; ?></td>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $log['Length']; ?></td>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $log['Color']; ?></td>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $log['IMDS']; ?></td>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $log['PPAP_Level']; ?></td>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $log['Samples_Status']; ?></td>
                                <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $log['Reason_Submission']; ?></td>
                                <?php if($log['PPAP_Received_Date'] != NULL) { 
                                    $recDate = new DateTime($log['PPAP_Received_Date']); ?>
                                    <td style="background-color: rgba(0, 206, 0, 0.5);">
                                        <?php echo $recDate->format('d/M/Y') ?>
                                    </td>
                                    <td style="background-color: rgba(0, 206, 0, 0.5); text-align: center; vertical-align: middle;">
                                        <?php if($log['Product'] == 'Cable' || $log['Product'] == 'BluSeal'){ ?>
                                            <form action="?page=Tapes" method="POST">
                                                <input type="hidden" name="note" value="">
                                                <input type="hidden" name="btnsearch" value="1">
                                                <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                                <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                                <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                                <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                                <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                                <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                                <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
                                                <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
                                                <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
                                                <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                                <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                                <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                                <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                                <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                                <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                                <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                                <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                                <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
                                                <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                                <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                                <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                                <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                                <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                                <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                                <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                                <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                                <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                                <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                                <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                                
                                                
                                                
                                                
                                                <input type="hidden" name="IDnote" value="<?php echo $log['PPAP_ID'] ?>">
                                                <button type="submit"  class="note">Note</button>
                                            </form>
                                        <?php } ?>
                                    </td>
                                <?php }
                                if($log['PPAP_Received_Date'] == NULL) { ?>
                                    <td style="background-color: rgba(0, 206, 0, 0.5);"></td>
                                    <td style="background-color: rgba(0, 206, 0, 0.5);"></td>
                                <?php }
                                if($log['PPAP_Sent_Customer'] != NULL) { 
                                    $sentCust = new DateTime($log['PPAP_Sent_Customer']); ?>
                                    <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $sentCust->format('d/M/Y') ?></td>
                                <?php }
                                if($log['PPAP_Sent_Customer'] == NULL) { ?>
                                    <td style="background-color: rgba(0, 206, 0, 0.5);"></td>
                                <?php } 
                                if($log['PPAP_Signed_Date'] != NULL) { 
                                    $signDate = new DateTime($log['PPAP_Signed_Date']); ?>
                                    <td style="background-color: rgba(0, 206, 0, 0.5);"><?php echo $signDate->format('d/M/Y') ?></td>
                                <?php } 
                                if($log['PPAP_Signed_Date'] == NULL) { ?>
                                    <td style="background-color: rgba(0, 206, 0, 0.5);"></td>
                                <?php } ?>
                                <td><?php echo $log['PPAP_From_Shipments']; ?></td>
                                <td><?php echo $log['Comments']; ?></td>
                                <td><?php echo $log['Inspection_Rep_Number']; ?></td>
                            <?php } 

                            // Red
                            if(($log['PPAP_Request_Date'] != NULL && $log['PPAP_Sent_Customer'] == NULL && $log['PPAP_Signed_Date'] == NULL && $log['Days to Submit'] >= 30 && $log['Product'] != 'Tube') ||
                                ($log['PPAP_Request_Date'] != NULL && $log['PPAP_Sent_Customer'] == NULL && $log['PPAP_Signed_Date'] == NULL && $log['Days to Submit'] >= 30 && $log['Product'] == 'Tube' && isset($PPAP_Number[0]) && $PPAP_Number[0] == $log['Customer_PPAP_Number'])
                            ) { ?>
                                        <td style="text-align: center; vertical-align: middle;">
                                            <form action="?page=Tapes" method="post" style="display:inline;">
                                                <input type="hidden" name="edit" value="">
                                                <input type="hidden" name="btnsearch" value="1">
                                                <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                                <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                                <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                                <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                                <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                                <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                                <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
                                                <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
                                                <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
                                                <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                                <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                                <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                                <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                                <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                                <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                                <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                                <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                                <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
                                                <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                                <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                                <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                                <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                                <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                                <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                                <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                                <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                                <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                                <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                                <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                                
                                                
                                                
                                                
                                                <input type="hidden" name="IDedit" value="<?php echo $log['PPAP_ID']; ?>">
                                                <button type="submit" class="editar">Edit</button>
                                            </form>
                                        </td>
                                        <?php if($_SESSION["Role"] == 'Administrator') { ?>
                                            <td style="text-align: center; vertical-align: middle;">
                                                <form action="?page=Tapes" method="post" style="display:inline;">
                                                    <input type="hidden" name="delete" value="">
                                                    <input type="hidden" name="btnsearch" value="1">
                                                    <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                                    <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                                    <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                                    <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                                    <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                                    <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                                    <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
                                                    <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
                                                    <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
                                                    <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                                    <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                                    <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                                    <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                    <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                    <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                    <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                                    <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                    <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                    <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                                    <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                                    <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                                    <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                                    <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                                    <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                    <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
                                                    <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                    <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                                    <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                                    <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                                    <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                                    <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                                    <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                                    <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                                    <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                                    <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                    <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                    <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                    <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                    <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                    <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                    <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                                    <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                                    <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                    <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                                    
                                                    
                                                    
                                                    
                                                    <input type="hidden" name="IDdelete" value="<?php echo $log['PPAP_ID']; ?>">
                                                    <button type="submit" class="eliminar">Delete</button>
                                                </form>
                                            </td>
                                        <?php } ?>
                                        <td style="text-align: center; vertical-align: middle;">
                                            <form action="?page=Tapes" method="post" style="display:inline;">
                                                <input type="hidden" name="insert" value="">
                                                <input type="hidden" name="btnsearch" value="1">
                                                <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                                <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                                <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                                <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                                <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                                <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                                <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
                                                <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
                                                <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
                                                <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                                <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                                <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                                <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                                <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                                <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                                <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                                <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                                <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
                                                <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                                <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                                <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                                <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                                <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                                <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                                <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                                <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                                <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                                <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                                <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                                <input type="hidden" name="bssearch" value="<?php if(isset($_POST['bssearch'])) { echo $_POST['bssearch']; } ?>">
                                                <input type="hidden" name="cabsearch" value="<?php if(isset($_POST['cabsearch'])) { echo $_POST['cabsearch']; } ?>">
                                                <input type="hidden" name="tapsearch" value="<?php if(isset($_POST['tapsearch'])) { echo $_POST['tapsearch']; } ?>">
                                                <input type="hidden" name="tubsearch" value="<?php if(isset($_POST['tubsearch'])) { echo $_POST['tubsearch']; } ?>">
                                                <input type="hidden" name="PPAP_Number" value="<?php echo $log['PPAP_Number']; ?>">
                                                <input type="hidden" name="Vendor" value="<?php echo $log['Vendor']; ?>">
                                                <input type="hidden" name="Supplier_PN" value="<?php echo $log['Supplier_PN']; ?>">
                                                <input type="hidden" name="OEM" value="<?php echo $log['OEM']; ?>">
                                                <input type="hidden" name="Customer" value="<?php echo $log['Customer']; ?>">
                                                <input type="hidden" name="Country" value="<?php echo $log['Country']; ?>">
                                                <input type="hidden" name="Customer_PN" value="<?php echo $log['Customer_PN']; ?>">
                                                <input type="hidden" name="Eurotech_PN" value="<?php echo $log['Eurotech_PN']; ?>">
                                                <input type="hidden" name="Description" value="<?php echo $log['Description']; ?>">
                                                <input type="hidden" name="IMDS" value="<?php echo $log['IMDS']; ?>">
                                                <input type="hidden" name="PPAP_Level" value="<?php echo $log['PPAP_Level']; ?>">
                                                <input type="hidden" name="PPAP_From_Shipments" value="<?php echo $log['PPAP_From_Shipments']; ?>">
                                                <button type="submit" class="copy">Copy</button>
                                            </form>
                                        </td>
                                        <td 
                                            <?php if($log['Days to Submit'] <= 18) { ?>
                                                style="background-color: rgba(0, 231, 0, 0.7);"
                                            <?php } 
                                            if($log['Days to Submit'] >= 19 && $log['Days to Submit'] < 30) { ?>
                                                style="background-color: rgba(233, 233, 0, 0.7);"
                                            <?php } 
                                            if($log['Days to Submit'] >= 30) { ?>
                                                style="background-color: rgba(204, 0, 34, 0.8); color:white;"
                                            <?php } ?>
                                        ><?php if($log['Days to Submit'] > 0 || $log['Days to Submit'] < 0) { echo $log['Days to Submit']; } if($log['Days to Submit'] == 0) { echo "0"; }?></td>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $log['PPAP_Number']; ?></td>
                                        <?php if($log['PPAP_Request_Date'] != NULL) { 
                                            $reqDate = new DateTime($log['PPAP_Request_Date']); ?>
                                            <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $reqDate->format('d/M/Y') ?></td>
                                        <?php } 
                                        if($log['PPAP_Request_Date'] == NULL) { ?>
                                            <td style="background-color: rgba(235, 16, 0, 0.53);"></td>
                                        <?php } ?>
                                        <?php if($log['PPAP_Requested_Vendor'] != NULL) { 
                                            $reqVend = new DateTime($log['PPAP_Requested_Vendor']); ?>
                                            <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $reqVend->format('d/M/Y') ?></td>
                                        <?php } 
                                        if($log['PPAP_Requested_Vendor'] == NULL) { ?>
                                            <td style="background-color: rgba(235, 16, 0, 0.53);"></td>
                                        <?php } ?>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $log['Current_Status']; ?></td>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php if($log['Vendor'] != NULL) { echo $log['Vendor']; ?> (<?php echo $log['Short_name']; ?>) <?php } ?></td>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $log['Supplier_PN']; ?></td>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $log['OEM']; ?></td>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $log['Customer']; ?></td>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $log['Country']; ?></td>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $log['Customer_PN']; ?></td>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $log['ET_Model']; ?></td>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $log['ET_Dwg']; ?></td>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $log['Rev']; ?></td>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $log['Eurotech_PN']; ?></td>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $log['Description']; ?></td>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $log['Tape']; ?></td>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $log['Width']; ?></td>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $log['Length']; ?></td>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $log['Color']; ?></td>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $log['IMDS']; ?></td>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $log['PPAP_Level']; ?></td>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $log['Samples_Status']; ?></td>
                                        <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $log['Reason_Submission']; ?></td>
                                        <?php 
                                        if($log['PPAP_Received_Date'] != NULL) { 
                                            $recDate = new DateTime($log['PPAP_Received_Date']); ?>
                                            <td style="background-color: rgba(235, 16, 0, 0.53);">
                                                <?php echo $recDate->format('d/M/Y') ?>
                                            </td>
                                            <td style="background-color: rgba(235, 16, 0, 0.53); text-align: center; vertical-align: middle;">
                                                <?php if($log['Product'] == 'Cable' || $log['Product'] == 'BluSeal'){ ?>
                                                    <form action="?page=Tapes" method="POST">
                                                        <input type="hidden" name="note" value="">
                                                        <input type="hidden" name="btnsearch" value="1">
                                                        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                                        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                                        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                                        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                                        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                                        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                                        <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
                                                        <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
                                                        <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
                                                        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                                        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                                        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                                        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                                        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                                        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                                        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
                                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                                        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                                        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                                        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                                        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                                        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                                        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                                        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                                        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                                        
                                                        
                                                        
                                                        
                                                        <input type="hidden" name="IDnote" value="<?php echo $log['PPAP_ID'] ?>">
                                                        <button type="submit"  class="note">Note</button>
                                                    </form>
                                                <?php } ?>
                                            </td>
                                        <?php }
                                        if($log['PPAP_Received_Date'] == NULL) { ?>
                                            <td style="background-color: rgba(235, 16, 0, 0.53);"></td>
                                            <td style="background-color: rgba(235, 16, 0, 0.53);"></td>
                                        <?php }
                                        if($log['PPAP_Sent_Customer'] != NULL) { 
                                            $sentCust = new DateTime($log['PPAP_Sent_Customer']); ?>
                                            <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $sentCust->format('d/M/Y') ?></td>
                                        <?php }
                                        if($log['PPAP_Sent_Customer'] == NULL) { ?>
                                            <td style="background-color: rgba(235, 16, 0, 0.53);"></td>
                                        <?php } 
                                        if($log['PPAP_Signed_Date'] != NULL) { 
                                            $sign = new DateTime($log['PPAP_Signed_Date']); ?>
                                            <td style="background-color: rgba(235, 16, 0, 0.53);"><?php echo $sign->format('d/M/Y') ?></td>
                                        <?php }
                                        if($log['PPAP_Signed_Date'] == NULL) { ?>
                                            <td style="background-color: rgba(235, 16, 0, 0.53);;"></td>
                                        <?php } ?>
                                        <td><?php echo $log['PPAP_From_Shipments']; ?></td>
                                        <td><?php echo $log['Comments']; ?></td>
                                        <td><?php echo $log['Inspection_Rep_Number']; ?></td>
                            <?php }

                            // Yellow
                            if(($log['PPAP_Sent_Customer'] != NULL && $log['PPAP_Signed_Date'] == NULL && $log['Product'] != 'Tube') ||
                                ($log['PPAP_Sent_Customer'] != NULL && $log['PPAP_Signed_Date'] == NULL && $log['Product'] == 'Tube' && isset($PPAP_Number[0]) && $PPAP_Number[0] == $log['Customer_PPAP_Number'])
                            ) { ?>
                                        <td style="text-align: center; vertical-align: middle;">
                                            <form action="?page=Tapes" method="post" style="display:inline;">
                                                <input type="hidden" name="edit" value="">
                                                <input type="hidden" name="btnsearch" value="1">
                                                <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                                    <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                                    <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                                    <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                                    <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                                    <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                                    <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
                                                    <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
                                                    <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
                                                    <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                                    <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                                    <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                                    <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                    <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                    <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                    <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                                    <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                    <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                    <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                                    <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                                    <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                                    <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                                    <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                                    <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                    <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
                                                    <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                    <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                                    <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                                    <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                                    <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                                    <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                                    <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                                    <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                                    <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                                    <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                    <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                    <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                    <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                    <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                    <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                    <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                                    <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                                    <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                    <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                                    
                                                    
                                                    
                                                    
                                                <input type="hidden" name="IDedit" value="<?php echo $log['PPAP_ID']; ?>">
                                                <button type="submit" class="editar">Edit</button>
                                            </form>
                                        </td>
                                        <?php if($_SESSION["Role"] == 'Administrator') { ?>
                                            <td style="text-align: center; vertical-align: middle;">
                                                <form action="?page=Tapes" method="post" style="display:inline;">
                                                    <input type="hidden" name="delete" value="">
                                                    <input type="hidden" name="btnsearch" value="1">
                                                    <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                                    <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                                    <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                                    <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                                    <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                                    <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                                    <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
                                                    <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
                                                    <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
                                                    <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                                    <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                                    <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                                    <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                    <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                    <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                    <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                                    <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                    <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                    <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                                    <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                                    <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                                    <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                                    <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                                    <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                    <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
                                                    <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                    <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                                    <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                                    <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                                    <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                                    <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                                    <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                                    <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                                    <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                                    <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                    <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                    <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                    <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                    <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                    <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                    <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                                    <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                                    <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                    <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                                    
                                                    
                                                    
                                                    
                                                    <input type="hidden" name="IDdelete" value="<?php echo $log['PPAP_ID']; ?>">
                                                    <button type="submit" class="eliminar">Delete</button>
                                                </form>
                                            </td>
                                        <?php } ?>
                                        <td style="text-align: center; vertical-align: middle;">
                                            <form action="?page=Tapes" method="post" style="display:inline;">
                                                <input type="hidden" name="insert" value="">
                                                <input type="hidden" name="btnsearch" value="1">
                                                <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                                <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                                <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                                <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                                <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                                <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                                <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
                                                <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
                                                <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
                                                <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                                <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                                <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                                <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                                <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                                <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                                <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                                <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                                <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
                                                <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                                <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                                <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                                <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                                <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                                <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                                <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                                <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                                <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                                <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                                <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                                <input type="hidden" name="bssearch" value="<?php if(isset($_POST['bssearch'])) { echo $_POST['bssearch']; } ?>">
                                                <input type="hidden" name="cabsearch" value="<?php if(isset($_POST['cabsearch'])) { echo $_POST['cabsearch']; } ?>">
                                                <input type="hidden" name="tapsearch" value="<?php if(isset($_POST['tapsearch'])) { echo $_POST['tapsearch']; } ?>">
                                                <input type="hidden" name="tubsearch" value="<?php if(isset($_POST['tubsearch'])) { echo $_POST['tubsearch']; } ?>">
                                                <input type="hidden" name="PPAP_Number" value="<?php echo $log['PPAP_Number']; ?>">
                                                <input type="hidden" name="Vendor" value="<?php echo $log['Vendor']; ?>">
                                                <input type="hidden" name="Supplier_PN" value="<?php echo $log['Supplier_PN']; ?>">
                                                <input type="hidden" name="OEM" value="<?php echo $log['OEM']; ?>">
                                                <input type="hidden" name="Customer" value="<?php echo $log['Customer']; ?>">
                                                <input type="hidden" name="Country" value="<?php echo $log['Country']; ?>">
                                                <input type="hidden" name="Customer_PN" value="<?php echo $log['Customer_PN']; ?>">
                                                <input type="hidden" name="Eurotech_PN" value="<?php echo $log['Eurotech_PN']; ?>">
                                                <input type="hidden" name="Description" value="<?php echo $log['Description']; ?>">
                                                <input type="hidden" name="IMDS" value="<?php echo $log['IMDS']; ?>">
                                                <input type="hidden" name="PPAP_Level" value="<?php echo $log['PPAP_Level']; ?>">
                                                <input type="hidden" name="PPAP_From_Shipments" value="<?php echo $log['PPAP_From_Shipments']; ?>">
                                                <button type="submit" class="copy">Copy</button>
                                            </form>
                                        </td>
                                        <td 
                                            <?php if($log['Days to Submit'] <= 18) { ?>
                                                style="background-color: rgba(0, 231, 0, 0.7);"
                                            <?php } 
                                            if($log['Days to Submit'] >= 19 && $log['Days to Submit'] < 30) { ?>
                                                style="background-color: rgba(233, 233, 0, 0.7);"
                                            <?php } 
                                            if($log['Days to Submit'] >= 30) { ?>
                                                style="background-color: rgba(204, 0, 34, 0.8); color:white;"
                                            <?php } ?>
                                        ><?php if($log['Days to Submit'] > 0 || $log['Days to Submit'] < 0) { echo $log['Days to Submit']; } if($log['Days to Submit'] == 0) { echo "0"; }?></td>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $log['PPAP_Number']; ?></td>
                                        <?php if($log['PPAP_Request_Date'] != NULL) { 
                                            $reqDate = new DateTime($log['PPAP_Request_Date']); ?>
                                            <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $reqDate->format('d/M/Y') ?></td>
                                        <?php } 
                                        if($log['PPAP_Request_Date'] == NULL) { ?>
                                            <td style="background-color: rgba(201, 204, 0, 0.5);"></td>
                                        <?php } ?>
                                        <?php if($log['PPAP_Requested_Vendor'] != NULL) { 
                                            $reqVend = new DateTime($log['PPAP_Requested_Vendor']); ?>
                                            <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $reqVend->format('d/M/Y') ?></td>
                                        <?php } 
                                        if($log['PPAP_Requested_Vendor'] == NULL) { ?>
                                            <td style="background-color: rgba(201, 204, 0, 0.5);"></td>
                                        <?php } ?>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $log['Current_Status']; ?></td>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php if($log['Vendor'] != NULL) { echo $log['Vendor']; ?> (<?php echo $log['Short_name']; ?>) <?php } ?></td>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $log['Supplier_PN']; ?></td>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $log['OEM']; ?></td>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $log['Customer']; ?></td>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $log['Country']; ?></td>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $log['Customer_PN']; ?></td>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $log['ET_Model']; ?></td>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $log['ET_Dwg']; ?></td>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $log['Rev']; ?></td>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $log['Eurotech_PN']; ?></td>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $log['Description']; ?></td>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $log['Tape']; ?></td>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $log['Width']; ?></td>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $log['Length']; ?></td>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $log['Color']; ?></td>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $log['IMDS']; ?></td>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $log['PPAP_Level']; ?></td>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $log['Samples_Status']; ?></td>
                                        <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $log['Reason_Submission']; ?></td>
                                        <?php 
                                        if($log['PPAP_Received_Date'] != NULL) { 
                                            $recDate = new DateTime($log['PPAP_Received_Date']); ?>
                                            <td style="background-color: rgba(201, 204, 0, 0.5);">
                                                <?php echo $recDate->format('d/M/Y') ?>
                                            </td>
                                            <td style="background-color: rgba(201, 204, 0, 0.5); text-align: center; vertical-align: middle;">
                                                <?php if($log['Product'] == 'Cable' || $log['Product'] == 'BluSeal'){ ?>
                                                    <form action="?page=Tapes" method="POST">
                                                        <input type="hidden" name="note" value="">
                                                        <input type="hidden" name="btnsearch" value="1">
                                                        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                                        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                                        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                                        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                                        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                                        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                                        <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
                                                        <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
                                                        <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
                                                        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                                        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                                        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                                        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                                        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                                        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                                        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
                                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                                        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                                        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                                        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                                        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                                        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                                        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                                        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                                        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                                        
                                                        
                                                        
                                                        
                                                        <input type="hidden" name="IDnote" value="<?php echo $log['PPAP_ID'] ?>">
                                                        <button type="submit"  class="note">Note</button>
                                                    </form>
                                                <?php } ?>
                                            </td>
                                        <?php }
                                        if($log['PPAP_Received_Date'] == NULL) { ?>
                                            <td style="background-color: rgba(201, 204, 0, 0.5);"></td>
                                            <td style="background-color: rgba(201, 204, 0, 0.5);"></td>
                                        <?php }
                                        if($log['PPAP_Sent_Customer'] != NULL) { 
                                            $sentCust = new DateTime($log['PPAP_Sent_Customer']); ?>
                                            <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $sentCust->format('d/M/Y') ?></td>
                                        <?php }
                                        if($log['PPAP_Sent_Customer'] == NULL) { ?>
                                            <td style="background-color: rgba(201, 204, 0, 0.5);"></td>
                                        <?php } 
                                        if($log['PPAP_Signed_Date'] != NULL) { 
                                            $sign = new DateTime($log['PPAP_Signed_Date']); ?>
                                            <td style="background-color: rgba(201, 204, 0, 0.5);"><?php echo $sign->format('d/M/Y') ?></td>
                                        <?php }
                                        if($log['PPAP_Signed_Date'] == NULL) { ?>
                                            <td style="background-color: rgba(201, 204, 0, 0.5);"></td>
                                        <?php } ?>
                                        <td><?php echo $log['PPAP_From_Shipments']; ?></td>
                                        <td><?php echo $log['Comments']; ?></td>
                                        <td><?php echo $log['Inspection_Rep_Number']; ?></td>
                            <?php }

                            // Blue
                            if(($log['PPAP_Requested_Vendor'] != NULL && $log['PPAP_Sent_Customer'] == NULL && $log['PPAP_Signed_Date'] == NULL && $log['Days to Submit'] < 30 && $log['Product'] != 'Tube') ||
                                ($log['PPAP_Requested_Vendor'] == NULL && $log['PPAP_Received_Date'] != NULL && $log['PPAP_Sent_Customer'] == NULL && $log['PPAP_Signed_Date'] == NULL && $log['Days to Submit'] < 30 && $log['Product'] != 'Tube') ||
                                ($log['PPAP_Requested_Vendor'] != NULL && $log['PPAP_Sent_Customer'] == NULL && $log['PPAP_Signed_Date'] == NULL && $log['Days to Submit'] < 30 && $log['Product'] == 'Tube' && isset($PPAP_Number[0]) && $PPAP_Number[0] == $log['Customer_PPAP_Number']) ||
                                ($log['PPAP_Requested_Vendor'] == NULL && $log['PPAP_Received_Date'] != NULL && $log['PPAP_Sent_Customer'] == NULL && $log['PPAP_Signed_Date'] == NULL && $log['Days to Submit'] < 30 && $log['Product'] == 'Tube' && isset($PPAP_Number[0]) && $PPAP_Number[0] == $log['Customer_PPAP_Number'])
                            ) { ?>
                                        <td style="text-align: center; vertical-align: middle;">
                                            <form action="?page=Tapes" method="post" style="display:inline;">
                                                <input type="hidden" name="edit" value="">
                                                <input type="hidden" name="btnsearch" value="1">
                                                <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                                <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                                <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                                <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                                <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                                <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                                <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
                                                <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
                                                <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
                                                <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                                <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                                <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                                <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                                <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                                <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                                <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                                <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                                <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
                                                <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                                <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                                <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                                <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                                <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                                <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                                <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                                <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                                <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                                <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                                <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                                
                                                
                                                
                                                
                                                <input type="hidden" name="IDedit" value="<?php echo $log['PPAP_ID']; ?>">
                                                <button type="submit" class="editar">Edit</button>
                                            </form>
                                        </td>
                                        <?php if($_SESSION["Role"] == 'Administrator') { ?>
                                            <td style="text-align: center; vertical-align: middle;">
                                                <form action="?page=Tapes" method="post" style="display:inline;">
                                                    <input type="hidden" name="delete" value="">
                                                    <input type="hidden" name="btnsearch" value="1">
                                                    <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                                    <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                                    <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                                    <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                                    <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                                    <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                                    <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
                                                    <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
                                                    <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
                                                    <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                                    <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                                    <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                                    <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                    <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                    <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                    <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                                    <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                    <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                    <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                                    <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                                    <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                                    <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                                    <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                                    <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                    <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
                                                    <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                    <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                                    <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                                    <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                                    <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                                    <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                                    <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                                    <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                                    <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                                    <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                    <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                    <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                    <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                    <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                    <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                    <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                                    <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                                    <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                    <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                                    
                                                    
                                                    
                                                    
                                                    <input type="hidden" name="IDdelete" value="<?php echo $log['PPAP_ID']; ?>">
                                                    <button type="submit" class="eliminar">Delete</button>
                                                </form>
                                            </td>
                                        <?php } ?>
                                        <td style="text-align: center; vertical-align: middle;">
                                            <form action="?page=Tapes" method="post" style="display:inline;">
                                                <input type="hidden" name="insert" value="">
                                                <input type="hidden" name="btnsearch" value="1">
                                                <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                                <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                                <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                                <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                                <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                                <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                                <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
                                                <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
                                                <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
                                                <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                                <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                                <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                                <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                                <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                                <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                                <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                                <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                                <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
                                                <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                                <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                                <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                                <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                                <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                                <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                                <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                                <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                                <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                                <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                                <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                                <input type="hidden" name="bssearch" value="<?php if(isset($_POST['bssearch'])) { echo $_POST['bssearch']; } ?>">
                                                <input type="hidden" name="cabsearch" value="<?php if(isset($_POST['cabsearch'])) { echo $_POST['cabsearch']; } ?>">
                                                <input type="hidden" name="tapsearch" value="<?php if(isset($_POST['tapsearch'])) { echo $_POST['tapsearch']; } ?>">
                                                <input type="hidden" name="tubsearch" value="<?php if(isset($_POST['tubsearch'])) { echo $_POST['tubsearch']; } ?>">
                                                <input type="hidden" name="PPAP_Number" value="<?php echo $log['PPAP_Number']; ?>">
                                                <input type="hidden" name="Vendor" value="<?php echo $log['Vendor']; ?>">
                                                <input type="hidden" name="Supplier_PN" value="<?php echo $log['Supplier_PN']; ?>">
                                                <input type="hidden" name="OEM" value="<?php echo $log['OEM']; ?>">
                                                <input type="hidden" name="Customer" value="<?php echo $log['Customer']; ?>">
                                                <input type="hidden" name="Country" value="<?php echo $log['Country']; ?>">
                                                <input type="hidden" name="Customer_PN" value="<?php echo $log['Customer_PN']; ?>">
                                                <input type="hidden" name="Eurotech_PN" value="<?php echo $log['Eurotech_PN']; ?>">
                                                <input type="hidden" name="Description" value="<?php echo $log['Description']; ?>">
                                                <input type="hidden" name="IMDS" value="<?php echo $log['IMDS']; ?>">
                                                <input type="hidden" name="PPAP_Level" value="<?php echo $log['PPAP_Level']; ?>">
                                                <input type="hidden" name="PPAP_From_Shipments" value="<?php echo $log['PPAP_From_Shipments']; ?>">
                                                <button type="submit" class="copy">Copy</button>
                                            </form>
                                        </td>
                                        <td 
                                            <?php if($log['Days to Submit'] <= 18) { ?>
                                                style="background-color: rgba(0, 231, 0, 0.7);"
                                            <?php } 
                                            if($log['Days to Submit'] >= 19 && $log['Days to Submit'] < 30) { ?>
                                                style="background-color: rgba(233, 233, 0, 0.7);"
                                            <?php } 
                                            if($log['Days to Submit'] >= 30) { ?>
                                                style="background-color: rgba(204, 0, 34, 0.8); color:white;"
                                            <?php } ?>
                                        ><?php if($log['Days to Submit'] > 0 || $log['Days to Submit'] < 0) { echo $log['Days to Submit']; } if($log['Days to Submit'] == 0) { echo "0"; }?></td>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $log['PPAP_Number']; ?></td>
                                        <?php if($log['PPAP_Request_Date'] != NULL) { 
                                            $reqDate = new DateTime($log['PPAP_Request_Date']); ?>
                                            <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $reqDate->format('d/M/Y') ?></td>
                                        <?php } 
                                        if($log['PPAP_Request_Date'] == NULL) { ?>
                                            <td style="background-color: rgba(0, 122, 209, 0.7);"></td>
                                        <?php } ?>
                                        <?php if($log['PPAP_Requested_Vendor'] != NULL) { 
                                            $reqVend = new DateTime($log['PPAP_Requested_Vendor']); ?>
                                            <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $reqVend->format('d/M/Y') ?></td>
                                        <?php } 
                                        if($log['PPAP_Requested_Vendor'] == NULL) { ?>
                                            <td style="background-color: rgba(0, 122, 209, 0.7);"></td>
                                        <?php } ?>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $log['Current_Status']; ?></td>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php if($log['Vendor'] != NULL) { echo $log['Vendor']; ?> (<?php echo $log['Short_name']; ?>) <?php } ?></td>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $log['Supplier_PN']; ?></td>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $log['OEM']; ?></td>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $log['Customer']; ?></td>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $log['Country']; ?></td>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $log['Customer_PN']; ?></td>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $log['ET_Model']; ?></td>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $log['ET_Dwg']; ?></td>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $log['Rev']; ?></td>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $log['Eurotech_PN']; ?></td>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $log['Description']; ?></td>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $log['Tape']; ?></td>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $log['Width']; ?></td>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $log['Length']; ?></td>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $log['Color']; ?></td>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $log['IMDS']; ?></td>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $log['PPAP_Level']; ?></td>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $log['Samples_Status']; ?></td>
                                        <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $log['Reason_Submission']; ?></td>
                                        <?php 
                                        if($log['PPAP_Received_Date'] != NULL) { 
                                            $recDate = new DateTime($log['PPAP_Received_Date']); ?>
                                            <td style="background-color: rgba(0, 122, 209, 0.7);">
                                                <?php echo $recDate->format('d/M/Y') ?>
                                            </td>
                                            <td style="background-color: rgba(0, 122, 209, 0.7); text-align: center; vertical-align: middle;">
                                                <?php if($log['Product'] == 'Cable' || $log['Product'] == 'BluSeal'){ ?>
                                                    <form action="?page=Tapes" method="POST">
                                                        <input type="hidden" name="note" value="">
                                                        <input type="hidden" name="btnsearch" value="1">
                                                        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                                        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                                        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                                        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                                        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                                        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                                        <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
                                                        <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
                                                        <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
                                                        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                                        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                                        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                                        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                                        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                                        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                                        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
                                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                                        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                                        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                                        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                                        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                                        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                                        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                                        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                                        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                                        
                                                        
                                                        
                                                        
                                                        <input type="hidden" name="IDnote" value="<?php echo $log['PPAP_ID'] ?>">
                                                        <button type="submit"  class="note">Note</button>
                                                    </form>
                                                <?php } ?>
                                            </td>
                                        <?php }
                                        if($log['PPAP_Received_Date'] == NULL) { ?>
                                            <td style="background-color: rgba(0, 122, 209, 0.7);"></td>
                                            <td style="background-color: rgba(0, 122, 209, 0.7);"></td>
                                        <?php }
                                        if($log['PPAP_Sent_Customer'] != NULL) { 
                                            $sentCust = new DateTime($log['PPAP_Sent_Customer']); ?>
                                            <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $sentCust->format('d/M/Y') ?></td>
                                        <?php }
                                        if($log['PPAP_Sent_Customer'] == NULL) { ?>
                                            <td style="background-color: rgba(0, 122, 209, 0.7);"></td>
                                        <?php } 
                                        if($log['PPAP_Signed_Date'] != NULL) { 
                                            $sign = new DateTime($log['PPAP_Signed_Date']); ?>
                                            <td style="background-color: rgba(0, 122, 209, 0.7);"><?php echo $sign->format('d/M/Y') ?></td>
                                        <?php }
                                        if($log['PPAP_Signed_Date'] == NULL) { ?>
                                            <td style="background-color: rgba(0, 122, 209, 0.7);;"></td>
                                        <?php } ?>
                                        <td><?php echo $log['PPAP_From_Shipments']; ?></td>
                                        <td><?php echo $log['Comments']; ?></td>
                                        <td><?php echo $log['Inspection_Rep_Number']; ?></td>
                            <?php }
                            
                            // White
                            if(($log['PPAP_Request_Date'] != NULL && $log['PPAP_Requested_Vendor'] == NULL && $log['PPAP_Received_Date'] == NULL && $log['PPAP_Sent_Customer'] == NULL && $log['PPAP_Signed_Date'] == NULL && $log['Days to Submit'] < 30 && $log['Product'] != 'Tube') ||
                                ($log['PPAP_Request_Date'] != NULL && $log['PPAP_Requested_Vendor'] == NULL && $log['PPAP_Received_Date'] == NULL && $log['PPAP_Sent_Customer'] == NULL && $log['PPAP_Signed_Date'] == NULL && $log['Days to Submit'] < 30 && $log['Product'] == 'Tube' && isset($PPAP_Number[0]) && $PPAP_Number[0] == $log['Customer_PPAP_Number'])
                            ) {?>
                                <td style="text-align: center; vertical-align: middle;">
                                    <form action="?page=Tapes" method="post" style="display:inline;">
                                        <input type="hidden" name="edit" value="">
                                        <input type="hidden" name="btnsearch" value="1">
                                        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                        <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
                                        <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
                                        <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
                                        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
                                        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                        
                                        
                                        
                                        
                                        <input type="hidden" name="IDedit" value="<?php echo $log['PPAP_ID']; ?>">
                                        <button type="submit" class="editar">Edit</button>
                                    </form>
                                </td>
                                <?php if($_SESSION["Role"] == 'Administrator') { ?>
                                    <td style="text-align: center; vertical-align: middle;">
                                        <form action="?page=Tapes" method="post" style="display:inline;">
                                            <input type="hidden" name="delete" value="">
                                            <input type="hidden" name="btnsearch" value="1">
                                            <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                            <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                            <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                            <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                            <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                            <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                            <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
                                            <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
                                            <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
                                            <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                            <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                            <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                            <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                            <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                            <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                            <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                            <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                            <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                            <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                            <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                            <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                            <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                            <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                            <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
                                            <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                            <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                            <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                            <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                            <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                            <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                            <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                            <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                            <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                            <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                            <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                            <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                            <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                            <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                            <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                            <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                            <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                            <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                            <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                            
                                            
                                            
                                            
                                            <input type="hidden" name="IDdelete" value="<?php echo $log['PPAP_ID']; ?>">
                                            <button type="submit" class="eliminar">Delete</button>
                                        </form>
                                    </td>
                                <?php } ?>
                                <td style="text-align: center; vertical-align: middle;">
                                            <form action="?page=Tapes" method="post" style="display:inline;">
                                                <input type="hidden" name="insert" value="">
                                                <input type="hidden" name="btnsearch" value="1">
                                                <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
                                                <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
                                                <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                                <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
                                                <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
                                                <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
                                                <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
                                                <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
                                                <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
                                                <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
                                                <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                                <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                                <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
                                                <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
                                                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                                <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
                                                <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
                                                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                                <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                                <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                                <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                                <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                                <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                                <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
                                                <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                                <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                                <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                                <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                                <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                                <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                                <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
                                                <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
                                                <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
                                                <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
                                                <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
                                                <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
                                                <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                                <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                                <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
                                                <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
                                                <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                                <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                                <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                                <input type="hidden" name="bssearch" value="<?php if(isset($_POST['bssearch'])) { echo $_POST['bssearch']; } ?>">
                                                <input type="hidden" name="cabsearch" value="<?php if(isset($_POST['cabsearch'])) { echo $_POST['cabsearch']; } ?>">
                                                <input type="hidden" name="tapsearch" value="<?php if(isset($_POST['tapsearch'])) { echo $_POST['tapsearch']; } ?>">
                                                <input type="hidden" name="tubsearch" value="<?php if(isset($_POST['tubsearch'])) { echo $_POST['tubsearch']; } ?>">
                                                <input type="hidden" name="PPAP_Number" value="<?php echo $log['PPAP_Number']; ?>">
                                                <input type="hidden" name="Vendor" value="<?php echo $log['Vendor']; ?>">
                                                <input type="hidden" name="Supplier_PN" value="<?php echo $log['Supplier_PN']; ?>">
                                                <input type="hidden" name="OEM" value="<?php echo $log['OEM']; ?>">
                                                <input type="hidden" name="Customer" value="<?php echo $log['Customer']; ?>">
                                                <input type="hidden" name="Country" value="<?php echo $log['Country']; ?>">
                                                <input type="hidden" name="Customer_PN" value="<?php echo $log['Customer_PN']; ?>">
                                                <input type="hidden" name="Eurotech_PN" value="<?php echo $log['Eurotech_PN']; ?>">
                                                <input type="hidden" name="Description" value="<?php echo $log['Description']; ?>">
                                                <input type="hidden" name="IMDS" value="<?php echo $log['IMDS']; ?>">
                                                <input type="hidden" name="PPAP_Level" value="<?php echo $log['PPAP_Level']; ?>">
                                                <input type="hidden" name="PPAP_From_Shipments" value="<?php echo $log['PPAP_From_Shipments']; ?>">
                                                <button type="submit" class="copy">Copy</button>
                                            </form>
                                        </td>
                                <td 
                                    <?php if($log['Days to Submit'] <= 18) { ?>
                                        style="background-color: rgba(0, 231, 0, 0.7);"
                                    <?php } 
                                    if($log['Days to Submit'] >= 19 && $log['Days to Submit'] < 30) { ?>
                                        style="background-color: rgba(233, 233, 0, 0.7);"
                                    <?php } 
                                    if($log['Days to Submit'] >= 30) { ?>
                                        style="background-color: rgba(204, 0, 34, 0.8); color:white;"
                                    <?php } ?>
                                ><?php if($log['Days to Submit'] > 0 || $log['Days to Submit'] < 0) { echo $log['Days to Submit']; } if($log['Days to Submit'] == 0) { echo "0"; }?></td>
                                <td><?php echo $log['PPAP_Number']; ?></td>
                                <?php if($log['PPAP_Request_Date'] != NULL) { 
                                    $reqDate = new DateTime($log['PPAP_Request_Date']); ?>
                                    <td><?php echo $reqDate->format('d/M/Y') ?></td>
                                <?php } 
                                if($log['PPAP_Request_Date'] == NULL) { ?>
                                    <td></td>
                                <?php } ?>
                                <td><?php echo $log['PPAP_Requested_Vendor']; ?></td>
                                <td><?php echo $log['Current_Status']; ?></td>
                                <td><?php if($log['Vendor'] != NULL) { echo $log['Vendor']; ?> (<?php echo $log['Short_name']; ?>) <?php } ?></td>
                                <td><?php echo $log['Supplier_PN']; ?></td>
                                <td><?php echo $log['OEM']; ?></td>
                                <td><?php echo $log['Customer']; ?></td>
                                <td><?php echo $log['Country']; ?></td>
                                <td><?php echo $log['Customer_PN']; ?></td>
                                <td><?php echo $log['ET_Model']; ?></td>
                                <td><?php echo $log['ET_Dwg']; ?></td>
                                <td><?php echo $log['Rev']; ?></td>
                                <td><?php echo $log['Eurotech_PN']; ?></td>
                                <td><?php echo $log['Description']; ?></td>
                                <td><?php echo $log['Tape']; ?></td>
                                <td><?php echo $log['Width']; ?></td>
                                <td><?php echo $log['Length']; ?></td>
                                <td><?php echo $log['Color']; ?></td>
                                <td><?php echo $log['IMDS']; ?></td>
                                <td><?php echo $log['PPAP_Level']; ?></td>
                                <td><?php echo $log['Samples_Status']; ?></td>
                                <td><?php echo $log['Reason_Submission']; ?></td>
                                <td><?php echo $log['PPAP_Received_Date']; ?></td>
                                <td></td>
                                <td><?php echo $log['PPAP_Sent_Customer']; ?></td>
                                <td><?php echo $log['PPAP_Signed_Date']; ?></td>
                                <td><?php echo $log['PPAP_From_Shipments']; ?></td>
                                <td><?php echo $log['Comments']; ?></td>
                                <td><?php echo $log['Inspection_Rep_Number']; ?></td>
                            <?php } ?>
                        </tr> 
                <?php } 
                
                /* foreach ($logsNP as $log) { ?>
                    <tr>
                                <td></td>
                                <?php if($_SESSION["Role"] == 'Administrator') { ?>
                                    <td></td>
                                <?php } ?>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><?php if($log['Name'] != NULL) { echo $log['Name']; ?> (<?php echo $log['Short_name']; ?>) <?php } ?></td>
                                <td><?php echo $log['Supplier_PN']; ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><?php echo $log['ET_Model']; ?></td>
                                <td><?php echo $log['ET_Dwg']; ?></td>
                                <td></td>
                                <td><?php echo $log['Eurotech_PN']; ?></td>
                                <td><?php echo $log['Description']; ?></td>
                                <td><?php echo $log['Tape']; ?></td>
                                <td><?php echo $log['Width']; ?></td>
                                <td><?php echo $log['Length']; ?></td>
                                <td><?php echo $log['Color']; ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>   
                    </tr>     
                <?php } */ ?>
        </table> 
    </div>
<?php }

if (isset($_POST['note'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Note</h2>
    <form action="?page=Tapes" method="post">
        <input type="hidden" name="confirmNote" value="1">
        <input type="hidden" name="confirmIDNote" value="<?php echo $_POST['IDnote']; ?>">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
        <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
        <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
        <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
        
        
        
        
        <div>
            <input style="width: 10px;" type="checkbox" name="PPAP_ET" <?php if($noteData['PPAP_ET'] != NULL) { echo "checked value='<?php echo 1; ?>'";  } else { echo "value=''"; } ?>> PPAP ET
        </div>

        <div>
            <input style="width: 10px;" type="checkbox" name="IMDS_ET" <?php if($noteData['IMDS_ET'] != NULL) { echo "checked value='<?php echo 1; ?>'";  } else { echo "value=''"; } ?>> IMDS ET
        </div>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if (isset($_POST['insert'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New PPAP</h2>
    <?php if (isset($error)) : ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form action="?page=Tapes" method="post">
        <input type="hidden" name="confirmI" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
        <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
        <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
        <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
        
        
        
        
        <label>PPAP Number:</label>
        <input type="text" maxlength="12" id="Customer_PPAP_Number" name="PPAP_Number" list="PPAPN" value="<?php if(isset($_POST['PPAP_Number'])) { echo $_POST['PPAP_Number']; } ?>"> <br>

        <label>PPAP Req'd by Customer:</label>
        <input type="date" name="PPAP_Request_Date" value="<?php if(isset($_POST['PPAP_Request_Date'])) { echo $_POST['PPAP_Request_Date']; } ?>"> <br>

        <label>PPAP Requested to Vendor:</label>
        <input type="date" name="PPAP_Requested_Vendor" value="<?php if(isset($_POST['PPAP_Requested_Vendor'])) { echo $_POST['PPAP_Requested_Vendor']; } ?>"> <br>

        <label>Current Status:</label>
        <input type="text" maxlength="255" list="Current" name="Current_Status" value="<?php if(isset($_POST['Current_Status'])) { echo $_POST['Current_Status']; } ?>"> <br>
        
        <label>Vendor:</label>
        <input type="text" maxlength="20" id="Vendor" name="Vendor" list="PI" value="<?php if(isset($_POST['Vendor'])) { echo $_POST['Vendor']; } ?>"> <br>

        <label>Supplier PN:</label>
        <input type="text" maxlength="6" id="Supplier_PN" name="Supplier_PN" list="SAP" value="<?php if(isset($_POST['Supplier_PN'])) { echo $_POST['Supplier_PN']; } ?>"> <br>

        <label>OEM:</label>
        <input type="text" maxlength="255" name="OEM" list="OEM" value="<?php if(isset($_POST['OEM'])) { echo $_POST['OEM']; } ?>"> <br>

        <label><label style="color:red">*</label> Customer:</label>
        <input type="text" maxlength="70" id="Cust" name="Customer" list="Customer" value="<?php if(isset($_POST['Customer'])) { echo $_POST['Customer']; } ?>" required> <br>

        <label>Country:</label>
        <input type="text" maxlength="30" id="Country_I" name="Country" list="Country" value="<?php if(isset($_POST['Country'])) { echo $_POST['Country']; } ?>"> <br>

        <label><label style="color:red">*</label> Customer PN:</label>
        <input type="text" maxlength="20" id="Customer_PN" name="Customer_PN" list="CPN" value="<?php if(isset($_POST['Customer_PN'])) { echo $_POST['Customer_PN']; } ?>" required> <br>

        <label>Rev:</label>
        <input type="text" maxlength="5" name="Rev" list="Rev" value="<?php if(isset($_POST['Rev'])) { echo $_POST['Rev']; } ?>"> <br>

        <label><label style="color:red">*</label> ET PN:</label>
        <input type="text" maxlength="12" id="Eurotech_PN" name="Eurotech_PN" list="ETPN" value="<?php if(isset($_POST['Eurotech_PN'])) { echo $_POST['Eurotech_PN']; } ?>" required> <br>
        
        <label><label style="color:red">*</label> Description:</label>
        <input type="text" maxlength="255" id="Description" name="Description" list="Desc" value="<?php if(isset($_POST['Description'])) { echo $_POST['Description']; } ?>" required> <br>

        <label>IMDS Number:</label>
        <input type="text" maxlength="15" id="IMDS_I" name="IMDS" list="IMDS" value="<?php if(isset($_POST['IMDS'])) { echo $_POST['IMDS']; } ?>"> <br>

        <label>Level:</label>
        <select name="PPAP_Level">
            <option value=""></option>
            <option value="1" <?php if(isset($_POST['PPAP_Level']) && $_POST['PPAP_Level'] == '1') { echo 'selected'; } ?>>1</option>
            <option value="2" <?php if(isset($_POST['PPAP_Level']) && $_POST['PPAP_Level'] == '2') { echo 'selected'; } ?>>2</option>
            <option value="3" <?php if(isset($_POST['PPAP_Level']) && $_POST['PPAP_Level'] == '3') { echo 'selected'; } ?>>3</option>
            <option value="4" <?php if(isset($_POST['PPAP_Level']) && $_POST['PPAP_Level'] == '4') { echo 'selected'; } ?>>4</option>
            <option value="5" <?php if(isset($_POST['PPAP_Level']) && $_POST['PPAP_Level'] == '5') { echo 'selected'; } ?>>5</option>
        </select> <br>

        <label>PPAP Samples Status:</label>
        <input type="text" maxlength="9" name="Samples_Status" list="PSS" value="<?php if(isset($_POST['Samples_Status'])) { echo $_POST['Samples_Status']; } ?>"> <br>

        <label>Reason of Submission:</label>
        <input type="text" maxlength="20" name="Reason_Submission" list="RS" value="<?php if(isset($_POST['Reason_Submission'])) { echo $_POST['Reason_Submission']; } ?>"> <br>

        <label>Received Date:</label>
        <input type="date" name="PPAP_Received_Date" value="<?php if(isset($_POST['PPAP_Received_Date'])) { echo $_POST['PPAP_Received_Date']; } ?>"> <br>

        <label>Sent to Customer:</label>
        <input type="date" name="PPAP_Sent_Customer" value="<?php if(isset($_POST['PPAP_Sent_Customer'])) { echo $_POST['PPAP_Sent_Customer']; } ?>"> <br>

        <label>PSW returned from Customer Signed:</label>
        <input type="date" name="PPAP_Signed_Date" value="<?php if(isset($_POST['PPAP_Signed_Date'])) { echo $_POST['PPAP_Signed_Date']; } ?>"> <br>

        <label>PPAP from Shipments / Origin from Report:</label required>
        <div>
            <input type="radio" name="PPAP_From_Shipments" value="no" <?php if(isset($_POST['PPAP_From_Shipments']) && $_POST['PPAP_From_Shipments'] == 'no') { echo 'checked'; } ?> checked> No 
        </div>
        <div>
            <input type="radio" name="PPAP_From_Shipments" value="*" <?php if(isset($_POST['PPAP_From_Shipments']) && $_POST['PPAP_From_Shipments'] == '*') { echo 'checked'; } ?>> Yes 
        </div> <br>

        <label>Comments:</label>
        <textarea name="Comments" maxlength="255"><?php if(isset($_POST['Comments'])) { echo $_POST['Comments']; } ?></textarea>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if (isset($_POST['edit'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Update PPAP</h2>
    <?php if (isset($error)) : ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form action="?page=Tapes" method="post">
        <input type="hidden" name="confirmU" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
        <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
        <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
        <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
        
        
        
        
        <input type="hidden" name="PPAP_ID" value="<?php if(isset($_POST['PPAP_ID'])) { echo $_POST['PPAP_ID']; } else { echo $ppapData['PPAP_ID']; } ?>">
        <label>PPAP Number:</label>
        <input type="text" maxlength="12" id="Customer_PPAP_Number" name="PPAP_Number" list="PPAPN" value="<?php if(isset($ppapData['PPAP_Number'])) { echo $ppapData['PPAP_Number']; } if(isset($_POST['PPAP_Number'])) { echo $_POST['PPAP_Number']; } ?>"> <br>
        
        <label>PPAP Req'd by Customer:</label>
        <input type="date" name="PPAP_Request_Date" value="<?php if(isset($ppapData['PPAP_Request_Date'])) { echo $ppapData['PPAP_Request_Date']; } if(isset($_POST['PPAP_Request_Date'])) { echo $_POST['PPAP_Request_Date']; } ?>"> <br>

        <label>PPAP Requested to Vendor:</label>
        <input type="date" name="PPAP_Requested_Vendor" value="<?php if(isset($ppapData['PPAP_Requested_Vendor'])) { echo $ppapData['PPAP_Requested_Vendor']; } if(isset($_POST['PPAP_Requested_Vendor'])) { echo $_POST['PPAP_Requested_Vendor']; } ?>"> <br>

        <label>Current Status:</label>
        <input type="text" maxlength="255" list="Current" name="Current_Status" value="<?php if(isset($ppapData['Current_Status'])) { echo $ppapData['Current_Status']; } if(isset($_POST['Current_Status'])) { echo $_POST['Current_Status']; } ?>"> <br>
        
        <label>Vendor:</label>
        <input type="text" maxlength="20" id="Vendor" name="Vendor" list="PI" value="<?php if(isset($ppapData['Vendor'])) { echo $ppapData['Vendor']; } if(isset($_POST['Vendor'])) { echo $_POST['Vendor']; } ?>"> <br>

        <label>Supplier PN:</label>
        <input type="text" maxlength="6" id="Supplier_PN" name="Supplier_PN" list="SAP" value="<?php if(isset($ppapData['Supplier_PN'])) { echo $ppapData['Supplier_PN']; } if(isset($_POST['Supplier_PN'])) { echo $_POST['Supplier_PN']; } ?>"> <br>

        <label>OEM:</label>
        <input type="text" maxlength="255" name="OEM" list="OEM" value="<?php if(isset($ppapData['OEM'])) { echo $ppapData['OEM']; } if(isset($_POST['OEM'])) { echo $_POST['OEM']; } ?>"> <br>

        <label><label style="color:red">*</label> Customer:</label>
        <input type="text" maxlength="70" id="Cust" name="Customer" list="Customer" value="<?php if(isset($ppapData['Customer'])) { echo $ppapData['Customer']; } if(isset($_POST['Customer'])) { echo $_POST['Customer']; } ?>" required> <br>

        <label>Country:</label>
        <input type="text" maxlength="30" id="Country_I" name="Country" list="Country" value="<?php if(isset($ppapData['Country'])) { echo $ppapData['Country']; } if(isset($_POST['Country'])) { echo $_POST['Country']; } ?>"> <br>

        <label><label style="color:red">*</label> Customer PN:</label>
        <input type="text" maxlength="20" id="Customer_PN" name="Customer_PN" list="CPN" value="<?php if(isset($ppapData['Customer_PN'])) { echo $ppapData['Customer_PN']; } if(isset($_POST['Customer_PN'])) { echo $_POST['Customer_PN']; } ?>" required> <br>

        <label>Rev:</label>
        <input type="text" maxlength="5" name="Rev" list="Rev" value="<?php if(isset($ppapData['Rev'])) { echo $ppapData['Rev']; } if(isset($_POST['Rev'])) { echo $_POST['Rev']; } ?>"> <br>

        <label><label style="color:red">*</label> ET PN:</label>
        <input type="text" maxlength="12" id="Eurotech_PN" name="Eurotech_PN" list="ETPN" value="<?php if(isset($ppapData['Eurotech_PN'])) { echo $ppapData['Eurotech_PN']; } if(isset($_POST['Eurotech_PN'])) { echo $_POST['Eurotech_PN']; } ?>" required> <br>
        
        <label><label style="color:red">*</label> Description:</label>
        <input type="text" maxlength="255" id="Description" name="Description" list="Desc" value="<?php if(isset($ppapData['Description'])) { echo $ppapData['Description']; } if(isset($_POST['Description'])) { echo $_POST['Description']; } ?>" required> <br>

        <label>IMDS Number:</label>
        <input type="text" maxlength="15" id="IMDS_I" name="IMDS" list="IMDS" value="<?php if(isset($ppapData['IMDS'])) { echo $ppapData['IMDS']; } if(isset($_POST['IMDS'])) { echo $_POST['IMDS']; } ?>"> <br>

        <label>Level:</label>
        <select name="PPAP_Level">
            <option value=""></option>
            <option value="1" <?php if(isset($ppapData['PPAP_Level']) && $ppapData['PPAP_Level'] == '1') { echo 'selected'; } if(isset($_POST['PPAP_Level']) && $_POST['PPAP_Level'] == '1') { echo 'selected'; } ?>>1</option>
            <option value="2" <?php if(isset($ppapData['PPAP_Level']) && $ppapData['PPAP_Level'] == '2') { echo 'selected'; } if(isset($_POST['PPAP_Level']) && $_POST['PPAP_Level'] == '2') { echo 'selected'; } ?>>2</option>
            <option value="3" <?php if(isset($ppapData['PPAP_Level']) && $ppapData['PPAP_Level'] == '3') { echo 'selected'; } if(isset($_POST['PPAP_Level']) && $_POST['PPAP_Level'] == '3') { echo 'selected'; } ?>>3</option>
            <option value="4" <?php if(isset($ppapData['PPAP_Level']) && $ppapData['PPAP_Level'] == '4') { echo 'selected'; } if(isset($_POST['PPAP_Level']) && $_POST['PPAP_Level'] == '4') { echo 'selected'; } ?>>4</option>
            <option value="5" <?php if(isset($ppapData['PPAP_Level']) && $ppapData['PPAP_Level'] == '5') { echo 'selected'; } if(isset($_POST['PPAP_Level']) && $_POST['PPAP_Level'] == '5') { echo 'selected'; } ?>>5</option>
        </select> <br>

        <label>PPAP Samples Status:</label>
        <input type="text" maxlength="9" name="Samples_Status" list="PSS" value="<?php if(isset($ppapData['Samples_Status'])) { echo $ppapData['Samples_Status']; } if(isset($_POST['Samples_Status'])) { echo $_POST['Samples_Status']; } ?>"> <br>

        <label>Reason of Submission:</label>
        <input type="text" maxlength="20" name="Reason_Submission" list="RS" value="<?php if(isset($ppapData['Reason_Submission'])) { echo $ppapData['Reason_Submission']; } if(isset($_POST['Reason_Submission'])) { echo $_POST['Reason_Submission']; } ?>"> <br>

        <label>Received Date:</label>
        <input type="date" name="PPAP_Received_Date" value="<?php if(isset($ppapData['PPAP_Received_Date'])) { echo $ppapData['PPAP_Received_Date']; } if(isset($_POST['PPAP_Received_Date'])) { echo $_POST['PPAP_Received_Date']; } ?>"> <br>

        <label>Sent to Customer:</label>
        <input type="date" name="PPAP_Sent_Customer" value="<?php if(isset($ppapData['PPAP_Sent_Customer'])) { echo $ppapData['PPAP_Sent_Customer']; } if(isset($_POST['PPAP_Sent_Customer'])) { echo $_POST['PPAP_Sent_Customer']; } ?>"> <br>

        <label>PSW returned from Customer Signed:</label>
        <input type="date" name="PPAP_Signed_Date" value="<?php if(isset($ppapData['PPAP_Signed_Date'])) { echo $ppapData['PPAP_Signed_Date']; } if(isset($_POST['PPAP_Signed_Date'])) { echo $_POST['PPAP_Signed_Date']; } ?>"> <br>

        <label>PPAP from Shipments / Origin from Report:</label required>
        <div>
            <input type="radio" name="PPAP_From_Shipments" value="no" <?php if(isset($ppapData['PPAP_From_Shipments']) && $ppapData['PPAP_From_Shipments'] == NULL) { echo 'checked'; } if(isset($_POST['PPAP_From_Shipments']) && $_POST['PPAP_From_Shipments'] == 'no') { echo 'checked'; } ?> checked> No 
        </div>
        <div>
            <input type="radio" name="PPAP_From_Shipments" value="*" <?php if(isset($ppapData['PPAP_From_Shipments']) && $ppapData['PPAP_From_Shipments'] == '*') { echo 'checked'; } if(isset($_POST['PPAP_From_Shipments']) && $_POST['PPAP_From_Shipments'] == '*') { echo 'checked'; } ?>> Yes 
        </div> <br>

        <label>Comments:</label>
        <textarea name="Comments" maxlength="255"><?php if(isset($ppapData['Comments'])) { echo $ppapData['Comments']; } if(isset($_POST['Comments'])) { echo $_POST['Comments']; } ?></textarea>

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php } 

if (isset($_POST['delete'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Delete PPAP</h2>
    <form action="?page=Tapes" method="post">
        <input type="hidden" name="confirmD" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="days1search" value="<?php if(isset($_POST['days1search'])) { echo $_POST['days1search']; } ?>">
        <input type="hidden" name="days2search" value="<?php if(isset($_POST['days2search'])) { echo $_POST['days2search']; } ?>">
        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
        <input type="hidden" name="date1search" value="<?php if(isset($_POST['date1search'])) { echo $_POST['date1search']; } ?>">
        <input type="hidden" name="date2search" value="<?php if(isset($_POST['date2search'])) { echo $_POST['date2search']; } ?>">
        <input type="hidden" name="req1n" value="<?php if(isset($_POST['req1n'])) { echo $_POST['req1n']; } ?>">
        <input type="hidden" name="reqv1search" value="<?php if(isset($_POST['reqv1search'])) { echo $_POST['reqv1search']; } ?>">
        <input type="hidden" name="reqv2search" value="<?php if(isset($_POST['reqv2search'])) { echo $_POST['reqv2search']; } ?>">
        <input type="hidden" name="reqvn" value="<?php if(isset($_POST['reqvn'])) { echo $_POST['reqvn']; } ?>">
        <input type="hidden" name="currentsearch" value="<?php if(isset($_POST['currentsearch'])) { echo $_POST['currentsearch']; } ?>">
        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
        <input type="hidden" name="sapsearch" value="<?php if(isset($_POST['sapsearch'])) { echo $_POST['sapsearch']; } ?>">
        <input type="hidden" name="oemsearch" value="<?php if(isset($_POST['oemsearch'])) { echo $_POST['oemsearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="cusn" value="<?php if(isset($_POST['cusn'])) { echo $_POST['cusn']; } ?>">
        <input type="hidden" name="counsearch" value="<?php if(isset($_POST['counsearch'])) { echo $_POST['counsearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>"> 
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
        <input type="hidden" name="date3search" value="<?php if(isset($_POST['date3search'])) { echo $_POST['date3search']; } ?>">
        <input type="hidden" name="date4search" value="<?php if(isset($_POST['date4search'])) { echo $_POST['date4search']; } ?>">
        <input type="hidden" name="recn" value="<?php if(isset($_POST['recn'])) { echo $_POST['recn']; } ?>">
        <input type="hidden" name="ret1search" value="<?php if(isset($_POST['ret1search'])) { echo $_POST['ret1search']; } ?>">
        <input type="hidden" name="ret2search" value="<?php if(isset($_POST['ret2search'])) { echo $_POST['ret2search']; } ?>">
        <input type="hidden" name="retn" value="<?php if(isset($_POST['retn'])) { echo $_POST['retn']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="pscn" value="<?php if(isset($_POST['pscn'])) { echo $_POST['pscn']; } ?>">
        <input type="hidden" name="pfsn" value="<?php if(isset($_POST['pfsn'])) { echo $_POST['pfsn']; } ?>">
        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
        
        
        
        
        <input type="hidden" name="IDdelete" value="<?php echo $ppapDataD['PPAP_ID']; ?>">
        <h5><b>Are you sure you want to delete the data of this PPAP?</b></h5> <br>
        <?php 
            if($ppapDataD['PPAP_Request_Date'] != NULL) {
                $reqD = new DateTime($ppapDataD['PPAP_Request_Date']);
            }
            if($ppapDataD['PPAP_Requested_Vendor'] != NULL) {
                $reqvD = new DateTime($ppapDataD['PPAP_Requested_Vendor']);
            }
            if($ppapDataD['PPAP_Received_Date'] != NULL) {
                $recD = new DateTime($ppapDataD['PPAP_Received_Date']);
            }
            if($ppapDataD['PPAP_Sent_Customer'] != NULL) {
                $senD = new DateTime($ppapDataD['PPAP_Sent_Customer']);
            }
            if($ppapDataD['PPAP_Signed_Date'] != NULL) {
                $sigD = new DateTime($ppapDataD['PPAP_Signed_Date']);
            }
        ?>
        <h6><b>Days to Submit:</b> <?php echo $ppapDataD['Days to Submit']; ?></h6>
        <h6><b>PPAP Number:</b> <?php echo $ppapDataD['PPAP_Number']; ?></h6>
        <h6><b>PPAP Req'd by Customer:</b> <?php if($ppapDataD['PPAP_Request_Date'] != NULL) { echo $reqD->format('d/M/Y'); } else { echo 'No date'; } ?></h6>
        <h6><b>PPAP Requested to Vendor:</b> <?php if($ppapDataD['PPAP_Requested_Vendor'] != NULL) { echo $reqvD->format('d/M/Y'); } else { echo 'No date'; } ?></h6>
        <h6><b>Current Status:</b> <?php echo $ppapDataD['Current_Status']; ?></h6>
        <h6><b>Vendor:</b> <?php echo $ppapDataD['Vendor']; ?></h6>
        <h6><b>Supplier PN:</b> <?php echo $ppapDataD['Supplier_PN']; ?></h6>
        <h6><b>OEM:</b> <?php echo $ppapDataD['OEM']; ?></h6>
        <h6><b>Customer:</b> <?php echo $ppapDataD['Customer']; ?></h6>
        <h6><b>Country:</b> <?php echo $ppapDataD['Country']; ?></h6>
        <h6><b>Customer PN:</b> <?php echo $ppapDataD['Customer_PN']; ?></h6>
        <h6><b>ET Model:</b> <?php echo $ppapDataD['ET_Model']; ?></h6>
        <h6><b>ET Dwg:</b> <?php echo $ppapDataD['ET_Dwg']; ?></h6>
        <h6><b>Rev:</b> <?php echo $ppapDataD['Rev']; ?></h6>
        <h6><b>ET PN:</b> <?php echo $ppapDataD['Eurotech_PN']; ?></h6>
        <h6><b>Description:</b> <?php echo $ppapDataD['Description']; ?></h6>
        <h6><b>IMDS:</b> <?php echo $ppapDataD['IMDS']; ?></h6>
        <h6><b>PPAP Level:</b> <?php echo $ppapDataD['PPAP_Level']; ?></h6>
        <h6><b>PPAP Samples Status:</b> <?php echo $ppapDataD['Samples_Status']; ?></h6>
        <h6><b>Reason of Submission:</b> <?php echo $ppapDataD['Reason_Submission']; ?></h6>
        <h6><b>Received Date:</b> <?php if($ppapDataD['PPAP_Received_Date'] != NULL) { echo $recD->format('d/M/Y'); } else { echo 'No date'; } ?></h6>
        <h6><b>Sent to Customer:</b> <?php if($ppapDataD['PPAP_Sent_Customer'] != NULL) { echo $senD->format('d/M/Y'); } else { echo 'No date'; } ?></h6>
        <h6><b>PSW returned from Cust Signed:</b> <?php if($ppapDataD['PPAP_Signed_Date'] != NULL) { echo $sigD->format('d/M/Y'); } else { echo 'No date'; } ?></h6>
        <h6><b>PPAP from Shipments / Origin from Report:</b> <?php if($ppapDataD['PPAP_From_Shipments'] == '*'){ echo 'Yes'; } else{ echo 'No'; } ?></h6>
        <h6><b>Comments:</b> <?php echo $ppapDataD['Comments']; ?></h6>
        <h6><b>Inspection Report Number:</b> <?php echo $ppapDataD['Inspection_Rep_Number']; ?></h6>
        <button type="submit">Confirm</button>
    </form>
  </div>
</div>
<?php }

if ($Deleted != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Register Deleted</h2>
        <form action="?page=Tapes" method="post">
            <h6><b>The register was deleted correctly.</b></h6>
        </form>
    </div>
    </div>
<?php } ?>

<script>
    function closeForm() {
        document.getElementById('formularioModal').style.display = 'none';
    }

    function sendForm() {
        closeForm();
        return true;
    }

    function clearForm() {
        document.querySelectorAll("#form input[type='text']").forEach(input => input.value = "");
        document.querySelectorAll("#form input[type='date']").forEach(input => input.value = "");

        document.querySelectorAll("#days1search").forEach(input => input.value = "");
        document.querySelectorAll("#days2search").forEach(input => input.value = "");

        const radioButtons = document.querySelectorAll("#form input[type='radio']");
        const defaultValue = '';

        const checks = document.querySelectorAll("#form input[type='checkbox']");


        for (const radio of radioButtons) {
            if (radio.value === defaultValue) {
                radio.checked = true;
            }
        }

        for (const check of checks) {
            check.checked = true;
        }

        const selects = document.querySelectorAll("#form select");

        for (const select of selects) {
            select.value = defaultValue;
        }
    }

    let sortOrder = {};
    
    function sortTable(columnIndex, type) {
        const table = document.getElementById("PPAP_table");
        const rows = Array.from(table.rows).slice(1);
        const isAscending = !sortOrder[columnIndex];

        rows.sort((rowA, rowB) => {
            const cellA = rowA.cells[columnIndex];
            const cellB = rowB.cells[columnIndex];

            const textA = cellA ? cellA.innerText.trim() : "";
            const textB = cellB ? cellB.innerText.trim() : "";

            if (type === "date") {
                const dateA = new Date(textA);
                const dateB = new Date(textB);
                const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
                const dateformatedA = dateA.toLocaleDateString('ja-JP', options);
                const dateformatedB = dateB.toLocaleDateString('ja-JP', options);
                return isAscending ? dateformatedA.localeCompare(dateformatedB) : dateformatedB.localeCompare(dateformatedA);
            } else if (type === "text") {
                return isAscending ? textA.localeCompare(textB) : textB.localeCompare(textA);
            } else if (type === "number") {
                const intA = parseInt(textA);
                const intB = parseInt(textB);
                return isAscending ? intA - intB : intB - intA;
            }

            return 0;
        });

        rows.forEach(row => table.tBodies[0].appendChild(row));
        sortOrder[columnIndex] = isAscending;
    }

    $(document).ready(function() {
        $('#Description').on('keyup', function() {
            const Description = $(this).val().trim();

            if (Description.length > 0) {
                $.ajax({
                    url: 'Search/ETPNsearch.php',
                    method: 'POST',
                    data: { Description: Description },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            $('#Eurotech_PN').val(response.Eurotech_PN);
                            $('#Vendor').val(response.Vendor);
                            $('#Supplier_PN').val(response.Supplier_PN);
                        } 
                        // else {
                        //     $('#Eurotech_PN').val('');
                        //     $('#Vendor').val('');
                        //     $('#Supplier_PN').val('');
                        // }
                    },
                    error: function() {
                        $('#Eurotech_PN').val('Error');
                        $('#Vendor').val('Error');
                        $('#Supplier_PN').val('Error');
                    }
                });
            } 
            // else {
            //     $('#Eurotech_PN').val('');
            //     $('#Vendor').val('');
            //     $('#Supplier_PN').val('');
            // }
        });

        $('#Eurotech_PN').on('keyup', function() {
            const Eurotech_PN = $(this).val().trim();

            if (Eurotech_PN.length > 0) {
                $.ajax({
                    url: 'Search/Descsearch.php',
                    method: 'POST',
                    data: { Eurotech_PN: Eurotech_PN },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            $('#Description').val(response.Description);
                            $('#Vendor').val(response.Vendor);
                            $('#Supplier_PN').val(response.Supplier_PN);
                        } 
                        // else {
                        //     $('#Description').val('');
                        //     $('#Vendor').val('');
                        //     $('#Supplier_PN').val('');
                        // }
                    },
                    error: function() {
                        $('#Description').val('Error');
                        $('#Vendor').val('Error');
                        $('#Supplier_PN').val('Error');
                    }
                });
            } 
            // else {
            //     $('#Description').val('');
            //     $('#Vendor').val('');
            //     $('#Supplier_PN').val('');
            // }
        });

        $('#Customer_PN').on('keyup', function() {
            const Customer_PN = $(this).val().trim();

            if (Customer_PN.length > 0) {
                $.ajax({
                    url: 'Search/CPNsearch.php',
                    method: 'POST',
                    data: { Customer_PN: Customer_PN },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            $('#Eurotech_PN').val(response.Eurotech_PN);
                            $('#Description').val(response.Description);
                            $('#Vendor').val(response.Vendor);
                            $('#Supplier_PN').val(response.Supplier_PN);
                            $('#Cust').val(response.Customer);
                            $('#IMDS_I').val(response.IMDS_ID_no);
                        } 
                        // else {
                        //     $('#Eurotech_PN').val('');
                        //     $('#Description').val('');
                        //     $('#Vendor').val('');
                        //     $('#Supplier_PN').val('');
                        //     $('#Cust').val('');
                        //     $('#IMDS_I').val('');
                        // }
                    },
                    error: function() {
                        $('#Eurotech_PN').val('Error');
                        $('#Description').val('Error');
                        $('#Vendor').val('Error');
                        $('#Supplier_PN').val('Error');
                        $('#Cust').val('Error');
                        $('#IMDS_I').val('Error');
                    }
                });
            } 
            // else {
            //     $('#Eurotech_PN').val('');
            //     $('#Description').val('');
            //     $('#Vendor').val('');
            //     $('#Supplier_PN').val('');
            //     $('#Cust').val('');
            //     $('#IMDS_I').val('');
            // }
        });

        $('#Supplier_PN').on('keyup', function() {
            const Supplier_PN = $(this).val().trim();

            if (Supplier_PN.length > 0) {
                $.ajax({
                    url: 'Search/Suppsearch.php',
                    method: 'POST',
                    data: { Supplier_PN: Supplier_PN },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            $('#Eurotech_PN').val(response.Eurotech_PN);
                            $('#Description').val(response.Description);
                            $('#Vendor').val(response.Vendor);
                            $('#Customer_PN').val('');
                        } 
                        // else {
                        //     $('#Eurotech_PN').val('');
                        //     $('#Description').val('');
                        //     $('#Vendor').val('');
                        //     $('#Customer_PN').val('');
                        // }
                    },
                    error: function() {
                        $('#Eurotech_PN').val('Error');
                        $('#Description').val('Error');
                        $('#Vendor').val('Error');
                    }
                });
            } 
            // else {
            //     $('#Eurotech_PN').val('');
            //     $('#Description').val('');
            //     $('#Vendor').val('');
            //     $('#Customer_PN').val('');
            // }
        });

        $('#Cust, #Eurotech_PN').on('keyup change', function() {
            const customer = $('#Cust').val().trim();
            const eurotechPN = $('#Eurotech_PN').val().trim();

            if (customer.length > 0 && eurotechPN.length > 0) {
                $.ajax({
                    url: 'Search/CustETPNsearch.php',
                    method: 'POST',
                    data: { Customer: customer, Eurotech_PN: eurotechPN },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            $('#Customer_PN').val(response.Customer_PN);
                        } 
                        // else {
                        //     $('#Customer_PN').val('');
                        // }
                    },
                    error: function() {
                        $('#Customer_PN').val('Error');
                    }
                });
            } 
            // else {
            //     $('#Customer_PN').val('');
            // }
        });

        $('#Cust, #Description').on('keyup change', function() {
            const customer = $('#Cust').val().trim();
            const description = $('#Description').val().trim();

            if (customer.length > 0 && description.length > 0) {
                $.ajax({
                    url: 'Search/CustDescsearch.php',
                    method: 'POST',
                    data: { Customer: customer, Description: description },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            $('#Customer_PN').val(response.Customer_PN);
                        } 
                        // else {
                        //     $('#Customer_PN').val('');
                        // }
                    },
                    error: function() {
                        $('#Customer_PN').val('Error');
                    }
                });
            } 
            // else {
            //     $('#Customer_PN').val('');
            // }
        });

        $('#Cust').on('keyup', function() {
            const Customer = $(this).val().trim();

            if (Customer.length > 0) {
                $.ajax({
                    url: 'Search/IMDSsearch.php',
                    method: 'POST',
                    data: { Customer: Customer },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            $('#IMDS_I').val(response.IMDS_ID_no);
                        }
                    },
                    error: function() {
                        $('#IMDS_I').val('Error');
                    }
                });
            }
        });

        $('#Cust, #Country_I, #Customer_PN').on('keyup change', function() {
            setTimeout(() => {
                const customer = $('#Cust').val().trim();
                const country = $('#Country_I').val().trim();
                const customer_pn = $('#Customer_PN').val().trim();

                if (customer.length > 0 && country.length > 0 && customer_pn.length > 0) {
                    $.ajax({
                        url: 'Search/PPAPNumbsearch.php',
                        method: 'POST',
                        data: { Customer: customer, Country: country, Customer_PN: customer_pn },
                        dataType: 'json',
                        success: function(response) {
                            if (response.success) {
                                $('#Customer_PPAP_Number').val(response.PPAP_Number);
                            } 
                            else {
                                $.ajax({
                                    url: 'Search/PPAPNumbsearch2.php',
                                    method: 'POST',
                                    data: { Customer: customer, Country: country },
                                    dataType: 'json',
                                    success: function(response) {
                                        if (response.success) {
                                            $('#Customer_PPAP_Number').val(response.PPAP_Number);
                                        } 
                                        else {
                                            $.ajax({
                                                url: 'Search/PPAPNumbsearch3.php',
                                                method: 'POST',
                                                data: { Customer: customer, Country: country },
                                                dataType: 'json',
                                                success: function(response) {
                                                    if (response.success) {
                                                        $('#Customer_PPAP_Number').val(response.Customer_PPAP_Number + '-0001');
                                                    } 
                                                    // else {
                                                    //     $('#Customer_PPAP_Number').val('');
                                                    // }
                                                },
                                                error: function() {
                                                    $('#Customer_PPAP_Number').val('Error');
                                                }
                                            });
                                        }
                                    },
                                    error: function() {
                                        $('#Customer_PPAP_Number').val('Error');
                                    }
                                });
                            }
                        },
                        error: function() {
                            $('#Customer_PPAP_Number').val('Error');
                        }
                    });
                } 
                // else {
                //     $('#Customer_PPAP_Number').val('');
                // }
            }, 1000);
        });

        $('#Customer_PPAP_Number').on('keyup', function() {
            const PPAP_Number = $(this).val().trim();

            if (PPAP_Number.length > 0) {
                $.ajax({
                    url: 'Search/PPAPNumbDatasearch.php',
                    method: 'POST',
                    data: { PPAP_Number: PPAP_Number },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            $('#Customer_PN').val(response.Customer_PN);
                            $('#IMDS_I').val(response.IMDS);
                            $('#Eurotech_PN').val(response.Eurotech_PN);
                            $('#Description').val(response.Description);
                            $('#Vendor').val(response.Vendor);
                            $('#Supplier_PN').val(response.Supplier_PN);
                            $('#Country_I').val(response.Country);
                            $('#Cust').val(response.Customer);
                        }
                        // else {
                        //     $('#Customer_PN').val('');
                        //     $('#IMDS_I').val('');
                        //     $('#Eurotech_PN').val('');
                        //     $('#Description').val('');
                        //     $('#Vendor').val('');
                        //     $('#Supplier_PN').val('');
                        //     $('#Country_I').val('');
                        //     $('#Cust').val('');
                        // }
                    },
                    error: function() {
                        $('#Customer_PN').val('Error');
                        $('#IMDS_I').val('Error');
                        $('#Eurotech_PN').val('Error');
                        $('#Description').val('Error');
                        $('#Vendor').val('Error');
                        $('#Supplier_PN').val('Error');
                        $('#Country_I').val('Error');
                        $('#Cust').val('Error');
                    }
                });
            }
        });
    });
</script>