<?php
    class model {                                        

        public  $mbd;
        
        function cn() {
            $this->mbd = new PDO('mysql:host=localhost;dbname=eurotechdb;port=3306', 'root', '');
            $this->mbd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
        }
    
        function search(){
            $logs = [];
            if (isset($_POST['btnsearch'])) {
                if (!empty($_POST['submit1search']) || !empty($_POST['submit2search']) || !empty($_POST['custsearch']) ||
                    !empty($_POST['oemsearch']) || !empty($_POST['counsearch']) || !empty($_POST['levelsearch']) || !empty($_POST['sapsearch']) || 
                    !empty($_POST['cpnsearch']) || !empty($_POST['tapesearch'])  || !empty($_POST['widthsearch']) || !empty($_POST['lengthsearch']) ||
                    !empty($_POST['colorsearch']) || !empty($_POST['imdssearch'])  || !empty($_POST['ret1search']) || !empty($_POST['ret2search']) ||
                    !empty($_POST['psw1search']) || !empty($_POST['psw2search']) || !empty($_POST['ren1search']) || !empty($_POST['ren2search']) || 
                    !empty($_POST['req1search']) || !empty($_POST['req2search']) || !empty($_POST['sent1search']) || !empty($_POST['sent2search']) || 
                    ($_POST['shipsearch'] != "" && $_POST['shipsearch'] != NULL) || ($_POST['comsearch'] != "" && $_POST['comsearch'] != NULL)
                    || ($_POST['retn'] != "" && $_POST['retn'] != NULL) || ($_POST['pscn'] != "" && $_POST['pscn'] != NULL) || ($_POST['renn'] != "" && $_POST['renn'] != NULL)  
                    || ($_POST['reqn'] != "" && $_POST['reqn'] != NULL) || ($_POST['stcn'] != "" && $_POST['stcn'] != NULL) || ($_POST['pcsn'] != "" && $_POST['pcsn'] != NULL) 
                    ){
                    $where = [];
                    $where2 = [];
                    $or = [];
                    $and = [];
                    $params = [];
                     
                    if(!empty($_POST['custsearch'])) {
                        $where[] = "`Name` = :cust";
                        $params[':cust'] = $_POST['custsearch'];
                    }

                    if(!empty($_POST['oemsearch'])) {
                        $where[] = "`OEM` = :oem";
                        $params[':oem'] = $_POST['oemsearch'];
                    }

                    if(!empty($_POST['counsearch'])) {
                        $where[] = "Country = :coun";
                        $params[':coun'] = $_POST['counsearch'];
                    }
                    
                    if(!empty($_POST['levelsearch']) && $_POST['levelsearch'] != 'N') {
                        $where[] = "PPAP_level = :lvl";
                        $params[':lvl'] = $_POST['levelsearch'];
                    }
                    if(!empty($_POST['levelsearch']) && $_POST['levelsearch'] == 'N') {
                        $where[] = "PPAP_level IS NULL";
                    }

                    if(!empty($_POST['sapsearch'])) {
                        $where[] = "SAP_Number = :sap";
                        $params[':sap'] = $_POST['sapsearch'];
                    }

                    if(!empty($_POST['cpnsearch'])) {
                        $where[] = "TAP_Customer_PN = :cpn";
                        $params[':cpn'] = $_POST['cpnsearch'];
                    }

                    if(!empty($_POST['tapesearch'])) {
                        $where[] = "Tape = :tap";
                        $params[':tap'] = $_POST['tapesearch'];
                    }

                    if(!empty($_POST['widthsearch'])) {
                        $where[] = "Width = :wid";
                        $params[':wid'] = $_POST['widthsearch'];
                    }

                    if(!empty($_POST['lengthsearch'])) {
                        $where[] = "`Length` = :len";
                        $params[':len'] = $_POST['lengthsearch'];
                    }

                    if(!empty($_POST['colorsearch'])) {
                        $where[] = "Color = :col";
                        $params[':col'] = $_POST['colorsearch'];
                    }

                    if(!empty($_POST['imdssearch'])) {
                        $where[] = "IMDS_ID_No = :imd";
                        $params[':imd'] = $_POST['imdssearch'];
                    }
                    
                    if($_POST['retn'] == "" && !empty($_POST['ret1search']) && !empty($_POST['ret2search'])) {
                        $where[] = "`Returned_CTC-Sent_Cust` BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['ret1search'];
                        $params[':date2'] = $_POST['ret2search'];
                    }
                    if($_POST['retn'] == "Y") {
                        $where[] = "`Returned_CTC-Sent_Cust` IS NOT NULL";
                    }
                    if($_POST['retn'] == "N") {
                        $where[] = "`Returned_CTC-Sent_Cust` IS NULL";
                    }
                    
                    if($_POST['pscn'] == "" && !empty($_POST['psw1search']) && !empty($_POST['psw2search'])) {
                        $where[] = "`Cust_Signed-Sent_CTC` BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['psw1search'];
                        $params[':date2'] = $_POST['psw2search'];
                    }
                    if($_POST['pscn'] == "Y") {
                        $where[] = "`Cust_Signed-Sent_CTC` IS NOT NULL";
                    }
                    if($_POST['pscn'] == "N") {
                        $where[] = "`Cust_Signed-Sent_CTC` IS NULL";
                    }
                    
                    if($_POST['renn'] == "" && !empty($_POST['ren1search']) && !empty($_POST['ren2search'])) {
                        $where[] = "Renewal_Date BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['ren1search'];
                        $params[':date2'] = $_POST['ren2search'];
                    }
                    if($_POST['renn'] == "Y") {
                        $where[] = "Renewal_Date IS NOT NULL AND (YEAR(Renewal_Date) = ".$_POST['submit2search']." OR YEAR(Sent_Request_CTC) = ".$_POST['submit2search']." OR YEAR(Sent_Customer) = ".$_POST['submit2search'].")";
                        $and[] = "YEAR(Renewal_Date) = ".$_POST['submit2search']."";
                    }
                    if($_POST['renn'] == "N") {
                        $where[] = "Renewal_Date IS NULL";
                        $or[] = "YEAR(Renewal_Date) = ".$_POST['submit2search']."";
                    }
                    
                    if($_POST['reqn'] == "" && !empty($_POST['req1search']) && !empty($_POST['req2search'])) {
                        $where[] = "Sent_Request_CTC BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['req1search'];
                        $params[':date2'] = $_POST['req2search'];
                    }
                    if($_POST['reqn'] == "Y") {
                        $where[] = "Sent_Request_CTC IS NOT NULL AND (YEAR(Renewal_Date) = ".$_POST['submit2search']." OR YEAR(Sent_Request_CTC) = ".$_POST['submit2search']." OR YEAR(Sent_Customer) = ".$_POST['submit2search'].")";
                        $and[] = "YEAR(Sent_Request_CTC) = ".$_POST['submit2search']."";
                    }
                    if($_POST['reqn'] == "N") {
                        $py = (int)$_POST['submit2search'] - 1;
                        $or[] = "YEAR(Sent_Request_CTC) = ".$_POST['submit2search']." OR YEAR(Sent_Request_CTC) = ".$py."";
                        $where[] = "Sent_Request_CTC IS NULL";
                    }
                    
                    if($_POST['stcn'] == "" && !empty($_POST['sent1search']) && !empty($_POST['sent2search'])) {
                        $where[] = "Sent_Customer BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['sent1search'];
                        $params[':date2'] = $_POST['sent2search'];
                    }
                    if($_POST['stcn'] == "Y") {
                        $where[] = "Sent_Customer IS NOT NULL AND (YEAR(Renewal_Date) = ".$_POST['submit2search']." OR YEAR(Sent_Request_CTC) = ".$_POST['submit2search']." OR YEAR(Sent_Customer) = ".$_POST['submit2search'].")";
                        $and[] = "YEAR(Sent_Customer) = ".$_POST['submit2search']."";
                    }
                    if($_POST['stcn'] == "N") {
                        $where[] = "Sent_Customer IS NULL";
                        $or[] = "YEAR(Sent_Customer) = ".$_POST['submit2search']."";
                    }
                    
                    if($_POST['pcsn'] == "" && !empty($_POST['pswr1search']) && !empty($_POST['pswr2search'])) {
                        $where[] = "Returned_Cust_Signed BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['pswr1search'];
                        $params[':date2'] = $_POST['pswr2search'];
                    }
                    if($_POST['pcsn'] == "Y") {
                        $where[] = "Returned_Cust_Signed IS NOT NULL AND (YEAR(Renewal_Date) = ".$_POST['submit2search']." OR YEAR(Sent_Request_CTC) = ".$_POST['submit2search']." OR YEAR(Sent_Customer) = ".$_POST['submit2search'].")";
                        $and[] = "YEAR(Returned_Cust_Signed) = ".$_POST['submit2search']."";
                    }
                    if($_POST['pcsn'] == "N") {
                        $where[] = "Returned_Cust_Signed IS NULL";
                        $or[] = "YEAR(Returned_Cust_Signed) = ".$_POST['submit2search']."";
                    }
                    
                    if(!empty($_POST['pfsn']) && $_POST['pfsn'] == "Y") {
                        $where[] = "PPAP_from_shipments IS NOT NULL";
                    }
                    if(!empty($_POST['pfsn']) && $_POST['pfsn'] == "N") {
                        $where[] = "PPAP_from_shipments IS NULL";
                    }

                    if (!empty($_POST['comsearch'])) {
                        $where[] = "Comments = :com";
                        $params[':com'] = $_POST['comsearch'];
                    }

                    if(empty($or) && empty($and) && empty($where)) {
                        $sql = "
                            SELECT DISTINCT
                                tp.TAP_PPAP_ID,
                                tp.OEM,
                                tp.Country,
                                tc.`Name`,
                                tp.PPAP_level,
                                t.SAP_Number,
                                tp.FK_TAP_Customer_PN,
                                t.Tape,
                                t.Width,
                                t.`Length`,
                                t.Color,
                                tp.IMDS_ID_No,
                                tp.`Returned_CTC-Sent_Cust`,
                                tp.`Cust_Signed-Sent_CTC`,
                                tp.PPAP_from_shipments,
                                tp.Comments
                            FROM tapes_ppap tp
                                INNER JOIN tapes_customer_pn tcp ON tp.FK_TAP_Customer_PN  = tcp.TAP_Customer_PN
                                INNER JOIN tapes_customer tc ON tcp.FK_TAP_Customer_ID = tc.TAP_Customer_ID
                                INNER JOIN tapes t ON tcp.FK_TAP_Eurotech_PN = t.TAP_Eurotech_PN
                                LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID 
                            ORDER BY `Name`;";
                    }

                    if(!empty($or) && empty($and) && empty($where)) {
                         $sql = "
                            SELECT DISTINCT
                                tp.TAP_PPAP_ID,
                                tp.OEM,
                                tp.Country,
                                tc.`Name`,
                                tp.PPAP_level,
                                t.SAP_Number,
                                tp.FK_TAP_Customer_PN,
                                t.Tape,
                                t.Width,
                                t.`Length`,
                                t.Color,
                                tp.IMDS_ID_No,
                                tp.`Returned_CTC-Sent_Cust`,
                                tp.`Cust_Signed-Sent_CTC`,
                                tp.PPAP_from_shipments,
                                tp.Comments
                            FROM tapes_ppap tp
                                INNER JOIN tapes_customer_pn tcp ON tp.FK_TAP_Customer_PN  = tcp.TAP_Customer_PN
                                INNER JOIN tapes_customer tc ON tcp.FK_TAP_Customer_ID = tc.TAP_Customer_ID
                                INNER JOIN tapes t ON tcp.FK_TAP_Eurotech_PN = t.TAP_Eurotech_PN
                                LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID AND (". implode(' OR ', $or) .")
                            ORDER BY `Name`;";
                    }

                    if(!empty($or) && !empty($and) && empty($where)) {
                        $resultado = array_slice($and, 0, 1);
                         
                        $sql = "
                            SELECT DISTINCT
                                tp.TAP_PPAP_ID,
                                tp.OEM,
                                tp.Country,
                                tc.`Name`,
                                tp.PPAP_level,
                                t.SAP_Number,
                                tp.FK_TAP_Customer_PN,
                                t.Tape,
                                t.Width,
                                t.`Length`,
                                t.Color,
                                tp.IMDS_ID_No,
                                tp.`Returned_CTC-Sent_Cust`,
                                tp.`Cust_Signed-Sent_CTC`,
                                tp.PPAP_from_shipments,
                                tp.Comments
                            FROM tapes_ppap tp
                                INNER JOIN tapes_customer_pn tcp ON tp.FK_TAP_Customer_PN  = tcp.TAP_Customer_PN
                                INNER JOIN tapes_customer tc ON tcp.FK_TAP_Customer_ID = tc.TAP_Customer_ID
                                INNER JOIN tapes t ON tcp.FK_TAP_Eurotech_PN = t.TAP_Eurotech_PN
                                LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID AND (". implode(' ', $resultado ) ." OR ". implode(' OR ', $or) .") 
                            ORDER BY `Name`;";
                    }

                    if(!empty($or) && empty($and) && !empty($where)) {
                         $sql = "
                            SELECT DISTINCT
                                tp.TAP_PPAP_ID,
                                tp.OEM,
                                tp.Country,
                                tc.`Name`,
                                tp.PPAP_level,
                                t.SAP_Number,
                                tp.FK_TAP_Customer_PN,
                                t.Tape,
                                t.Width,
                                t.`Length`,
                                t.Color,
                                tp.IMDS_ID_No,
                                tp.`Returned_CTC-Sent_Cust`,
                                tp.`Cust_Signed-Sent_CTC`,
                                tp.PPAP_from_shipments,
                                tp.Comments
                            FROM tapes_ppap tp
                                INNER JOIN tapes_customer_pn tcp ON tp.FK_TAP_Customer_PN  = tcp.TAP_Customer_PN
                                INNER JOIN tapes_customer tc ON tcp.FK_TAP_Customer_ID = tc.TAP_Customer_ID
                                INNER JOIN tapes t ON tcp.FK_TAP_Eurotech_PN = t.TAP_Eurotech_PN
                                LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID AND (". implode(' OR ', $or) .") WHERE " . implode(' AND ', $where) . "
                            ORDER BY `Name`;";
                    }

                    if(empty($or) && !empty($and) && empty($where)) {
                         $sql = "
                            SELECT DISTINCT
                                tp.TAP_PPAP_ID,
                                tp.OEM,
                                tp.Country,
                                tc.`Name`,
                                tp.PPAP_level,
                                t.SAP_Number,
                                tp.FK_TAP_Customer_PN,
                                t.Tape,
                                t.Width,
                                t.`Length`,
                                t.Color,
                                tp.IMDS_ID_No,
                                tp.`Returned_CTC-Sent_Cust`,
                                tp.`Cust_Signed-Sent_CTC`,
                                tp.PPAP_from_shipments,
                                tp.Comments
                            FROM tapes_ppap tp
                                INNER JOIN tapes_customer_pn tcp ON tp.FK_TAP_Customer_PN  = tcp.TAP_Customer_PN
                                INNER JOIN tapes_customer tc ON tcp.FK_TAP_Customer_ID = tc.TAP_Customer_ID
                                INNER JOIN tapes t ON tcp.FK_TAP_Eurotech_PN = t.TAP_Eurotech_PN
                                LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID AND (". implode(' AND ', $and) .")
                            ORDER BY `Name`;";
                    }

                    if(empty($or) && !empty($and) && !empty($where)) {
                         $sql = "
                            SELECT DISTINCT
                                tp.TAP_PPAP_ID,
                                tp.OEM,
                                tp.Country,
                                tc.`Name`,
                                tp.PPAP_level,
                                t.SAP_Number,
                                tp.FK_TAP_Customer_PN,
                                t.Tape,
                                t.Width,
                                t.`Length`,
                                t.Color,
                                tp.IMDS_ID_No,
                                tp.`Returned_CTC-Sent_Cust`,
                                tp.`Cust_Signed-Sent_CTC`,
                                tp.PPAP_from_shipments,
                                tp.Comments
                            FROM tapes_ppap tp
                                INNER JOIN tapes_customer_pn tcp ON tp.FK_TAP_Customer_PN  = tcp.TAP_Customer_PN
                                INNER JOIN tapes_customer tc ON tcp.FK_TAP_Customer_ID = tc.TAP_Customer_ID
                                INNER JOIN tapes t ON tcp.FK_TAP_Eurotech_PN = t.TAP_Eurotech_PN
                                LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID AND (". implode(' AND ', $and) .") WHERE " . implode(' AND ', $where) . "
                            ORDER BY `Name`;";
                    }

                    if(empty($or) && empty($and) && !empty($where)) {
                        $sql = "
                            SELECT DISTINCT
                                tp.TAP_PPAP_ID,
                                tp.OEM,
                                tp.Country,
                                tc.`Name`,
                                tp.PPAP_level,
                                t.SAP_Number,
                                tp.FK_TAP_Customer_PN,
                                t.Tape,
                                t.Width,
                                t.`Length`,
                                t.Color,
                                tp.IMDS_ID_No,
                                tp.`Returned_CTC-Sent_Cust`,
                                tp.`Cust_Signed-Sent_CTC`,
                                tp.PPAP_from_shipments,
                                tp.Comments
                            FROM tapes_ppap tp
                                INNER JOIN tapes_customer_pn tcp ON tp.FK_TAP_Customer_PN  = tcp.TAP_Customer_PN
                                INNER JOIN tapes_customer tc ON tcp.FK_TAP_Customer_ID = tc.TAP_Customer_ID
                                INNER JOIN tapes t ON tcp.FK_TAP_Eurotech_PN = t.TAP_Eurotech_PN
                                LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID 
                                WHERE " . implode(' AND ', $where) . "
                            ORDER BY `Name`;";
                    }

                    if(!empty($or) && !empty($and) && !empty($where)) {
                        $resultado = array_slice($and, 0, 1);
                         
                        $sql = "
                            SELECT DISTINCT
                                tp.TAP_PPAP_ID,
                                tp.OEM,
                                tp.Country,
                                tc.`Name`,
                                tp.PPAP_level,
                                t.SAP_Number,
                                tp.FK_TAP_Customer_PN,
                                t.Tape,
                                t.Width,
                                t.`Length`,
                                t.Color,
                                tp.IMDS_ID_No,
                                tp.`Returned_CTC-Sent_Cust`,
                                tp.`Cust_Signed-Sent_CTC`,
                                tp.PPAP_from_shipments,
                                tp.Comments
                            FROM tapes_ppap tp
                                INNER JOIN tapes_customer_pn tcp ON tp.FK_TAP_Customer_PN  = tcp.TAP_Customer_PN
                                INNER JOIN tapes_customer tc ON tcp.FK_TAP_Customer_ID = tc.TAP_Customer_ID
                                INNER JOIN tapes t ON tcp.FK_TAP_Eurotech_PN = t.TAP_Eurotech_PN
                                LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID AND (". implode(' ', $resultado ) ." OR ". implode(' OR ', $or) .") WHERE " . implode(' AND ', $where) . "
                            ORDER BY `Name`;";
                    }

                    $stmt = $this->mbd->prepare($sql);
                    $stmt->execute($params);
                    
                    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
                else {
                    foreach ($this->mbd->query(
                        "SELECT DISTINCT
                            tp.TAP_PPAP_ID,
                            tp.OEM,
                            tp.Country,
                            tc.`Name`,
                            tp.PPAP_level,
                            t.SAP_Number,
                            tp.FK_TAP_Customer_PN,
                            t.Tape,
                            t.Width,
                            t.`Length`,
                            t.Color,
                            tp.IMDS_ID_No,
                            tp.`Returned_CTC-Sent_Cust`,
                            tp.`Cust_Signed-Sent_CTC`,
                            tp.PPAP_from_shipments,
                            tp.Comments
                        FROM tapes_ppap tp
                            INNER JOIN tapes_customer_pn tcp ON tp.FK_TAP_Customer_PN  = tcp.TAP_Customer_PN
                            INNER JOIN tapes_customer tc ON tcp.FK_TAP_Customer_ID = tc.TAP_Customer_ID
                            INNER JOIN tapes t ON tcp.FK_TAP_Eurotech_PN = t.TAP_Eurotech_PN
                            LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID
                        ORDER BY `Name`;"
                    ) as $log) {
                        $logs[] = $log;
                    }
                }
            } else {
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        tp.TAP_PPAP_ID,
                        tp.OEM,
                        tp.Country,
                        tc.`Name`,
                        tp.PPAP_level,
                        t.SAP_Number,
                        tp.FK_TAP_Customer_PN,
                        t.Tape,
                        t.Width,
                        t.`Length`,
                        t.Color,
                        tp.IMDS_ID_No,
                        tp.`Returned_CTC-Sent_Cust`,
                        tp.`Cust_Signed-Sent_CTC`,
                        tp.PPAP_from_shipments,
                        tp.Comments
                    FROM tapes_ppap tp
                        INNER JOIN tapes_customer_pn tcp ON tp.FK_TAP_Customer_PN  = tcp.TAP_Customer_PN
                        INNER JOIN tapes_customer tc ON tcp.FK_TAP_Customer_ID = tc.TAP_Customer_ID
                        INNER JOIN tapes t ON tcp.FK_TAP_Eurotech_PN = t.TAP_Eurotech_PN
                        LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID
                    ORDER BY `Name`;"
                ) as $log) {
                    $logs[] = $log;
                }
            }
            return $logs;
        }

        function searchRenew($ID, $i){
            $Renewlogs = [];
            foreach ($this->mbd->query(
                 "SELECT 
                    tr.Renewal_Date,
                    tr.Sent_Request_CTC,
                    tr.Sent_Customer,
                    tr.Returned_Cust_Signed,
                    tr.FK_TAP_PPAP_ID,
                    tp.TAP_PPAP_ID,
                    YEAR(tr.Renewal_Date) AS 'Year',
                    YEAR(tr.Sent_Customer) AS 'Year2'
                FROM tapes_ppap tp
                    LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID
                WHERE tp.TAP_PPAP_ID = $ID
                HAVING `Year` = $i OR `Year2` = $i;"
            ) as $Renewlog) {
                $Renewlogs[] = $Renewlog;
            }

            return $Renewlogs;
        }

        function searchNoRenew($id){
            $NRenewlogs = [];
            foreach ($this->mbd->query(
                 "SELECT
                    tp.TAP_PPAP_ID
                FROM tapes_ppap tp
                LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID
                WHERE tr.TAP_Renewal_ID IS NULL AND tp.TAP_PPAP_ID = $id;"
            ) as $NRenewlog) {
                $NRenewlogs[] = $NRenewlog;
            }

            return $NRenewlogs;
        }

        function searchMaxYear($id){
            $MaxYears = [];
            foreach ($this->mbd->query(
                "SELECT DISTINCT 
                    tp.TAP_PPAP_ID, 
                    YEAR(MAX(tr.Renewal_Date)) 
                FROM tapes_ppap tp 
                    INNER JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID
                WHERE TAP_PPAP_ID = $id
                GROUP BY tp.TAP_PPAP_ID;"
            ) as $MaxYear) {
                $MaxYears[] = $MaxYear;
            }

            return $MaxYears;
        }

        function searchMaxY(){
            $MaxYs = [];
            foreach ($this->mbd->query(
                "SELECT
                    YEAR(MAX(tr.Renewal_Date)) AS 'Max'
                FROM tapes_renewal tr;"
            ) as $MaxY) {
                $MaxYs[] = $MaxY;
            }

            return $MaxYs;
        }

        function searchDates2($maxy, $id){
            $dates2 = [];
            
                foreach ($this->mbd->query(
                    "SELECT * FROM tapes_renewal tr
                        RIGHT JOIN tapes_ppap tp ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID AND (Year(tr.Renewal_Date) = $maxy OR Year(tr.Sent_Request_CTC) = $maxy OR Year(tr.Sent_Customer) = $maxy)
                        INNER JOIN tapes_customer_pn tcp ON tp.FK_TAP_Customer_PN  = tcp.TAP_Customer_PN
                        INNER JOIN tapes_customer tc ON tcp.FK_TAP_Customer_ID = tc.TAP_Customer_ID
                        INNER JOIN tapes t ON tcp.FK_TAP_Eurotech_PN = t.TAP_Eurotech_PN
                    WHERE TAP_PPAP_ID = $id"
                ) as $date) {
                    $dates2[] = $date;
                }
            
            return $dates2;
        }
        
        function searchDates($maxy, $id){
            $dates = [];
            if($maxy != NULL) {
                foreach ($this->mbd->query(
                    "SELECT 
                        tr.Renewal_Date, 
                        tr.Sent_Request_CTC, 
                        tr.Sent_Customer, 
                        tr.Returned_Cust_Signed 
                    FROM tapes_renewal tr
                    WHERE (Year(tr.Renewal_Date) = $maxy OR Year(tr.Sent_Request_CTC) = $maxy OR Year(tr.Sent_Customer) = $maxy) AND tr.FK_TAP_PPAP_ID = $id
                    UNION
                    SELECT 
                        tr.Renewal_Date, 
                        tr.Sent_Request_CTC, 
                        tr.Sent_Customer, 
                        tr.Returned_Cust_Signed 
                    FROM tapes_renewal tr
                    WHERE (Year(tr.Renewal_Date)IS NULL AND Year(tr.Sent_Request_CTC) IS NULL AND Year(tr.Sent_Customer) IS NULL) AND tr.FK_TAP_PPAP_ID = $id"
                ) as $date) {
                    $dates[] = $date;
                }
            }
            
            return $dates;
        }

        function searchCust(){
            $Customers = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        `Name`
                    FROM tapes_customer
                    ORDER BY `Name`;"
                ) as $Customer) {
                    $Customers[] = $Customer;
                }
            return $Customers;
        }

        function searchOEM(){
            $OEMS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        `OEM`
                    FROM tapes_ppap
                    ORDER BY `OEM`;"
                ) as $OEM) {
                    $OEMS[] = $OEM;
                }
            return $OEMS;
        }

        function searchCoun(){
            $Countries = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Country
                    FROM tapes_ppap
                    ORDER BY Country;"
                ) as $Country) {
                    $Countries[] = $Country;
                }
            return $Countries;
        }

        function searchSAP(){
            $SAPS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        SAP_Number
                    FROM tapes
                    ORDER BY SAP_Number;"
                ) as $SAP) {
                    $SAPS[] = $SAP;
                }
            return $SAPS;
        }

        function searchCPN(){
            $CPNS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        TAP_Customer_PN
                    FROM tapes_customer_pn
                    ORDER BY TAP_Customer_PN;"
                ) as $CPN) {
                    $CPNS[] = $CPN;
                }
            return $CPNS;
        }

        function searchTape(){
            $Tapes = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        `Tape`
                    FROM tapes
                    ORDER BY `Tape`;"
                ) as $Tape) {
                    $Tapes[] = $Tape;
                }
            return $Tapes;
        }

        function searchWidth(){
            $Widths = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Width
                    FROM tapes
                    ORDER BY Width;"
                ) as $Width) {
                    $Widths[] = $Width;
                }
            return $Widths;
        }

        function searchLength(){
            $Lengths = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        `Length`
                    FROM tapes
                    ORDER BY `Length`;"
                ) as $Length) {
                    $Lengths[] = $Length;
                }
            return $Lengths;
        }

        function searchColor(){
            $Colors = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Color
                    FROM tapes
                    ORDER BY Color;"
                ) as $Color) {
                    $Colors[] = $Color;
                }
            return $Colors;
        }

        function searchIMDS(){
            $IMDS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        IMDS_ID_No
                    FROM tapes_ppap
                    ORDER BY IMDS_ID_No;"
                ) as $IM) {
                    $IMDS[] = $IM;
                }
            return $IMDS;
        }

        function searchCom(){
            $Coms = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Comments
                    FROM tapes_ppap
                    ORDER BY Comments;"
                ) as $Com) {
                    $Coms[] = $Com;
                }
            return $Coms;
        }

        function searchETPN(){
            $ETPNS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        TAP_Eurotech_PN
                    FROM tapes
                    ORDER BY TAP_Eurotech_PN;"
                ) as $ETPN) {
                    $ETPNS[] = $ETPN;
                }
            return $ETPNS;
        }
    }
?>