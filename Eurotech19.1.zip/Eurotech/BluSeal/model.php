<?php
    class model {                                        

        public  $mbd;
        
        function cn() {
            $this->mbd = new PDO('mysql:host=localhost;dbname=eurotechdb;port=3306', 'root', '');
            $this->mbd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
        }
    
        function search(){
            $logs = [];
            if (isset($_POST['btnsearch'])) {
                if (!empty($_POST['custsearch']) || !empty($_POST['modelsearch']) || !empty($_POST['descsearch']) 
                    || !empty($_POST['cpnsearch']) || !empty($_POST['imdssearch']) || !empty($_POST['suppsearch']) 
                    || !empty($_POST['spnsearch'])
                    || (!empty($_POST['date1search']) && !empty($_POST['date2search'])) 
                    || (!empty($_POST['date3search']) && !empty($_POST['date4search']))
                    || (!empty($_POST['date5search']) && !empty($_POST['date6search']))
                    || (!empty($_POST['date7search']) && !empty($_POST['date8search']))
                    || isset($_POST['cusn']) || isset($_POST['imdn']) || isset($_POST['reqn']) 
                    || isset($_POST['recn']) || isset($_POST['psen']) || isset($_POST['psin'])) {
                    $where = [];
                    $params = [];
                    
                    if($_POST['cusn'] == "" && !empty($_POST['custsearch'])) {
                        $where[] = "`Name` = :cust";
                        $params[':cust'] = $_POST['custsearch'];
                    }
                    if($_POST['cusn'] == "Y") {
                        $where[] = "`Name` IS NOT NULL";
                    }
                    if($_POST['cusn'] == "N") {
                        $where[] = "`Name` IS NULL";
                    }

                    if (!empty($_POST['modelsearch'])) {
                        $where[] = "BS_Eurotech_PN = :etpn";
                        $params[':etpn'] = $_POST['modelsearch'];
                    }

                    if (!empty($_POST['descsearch'])) {
                        $where[] = "`Description` = :desc";
                        $params[':desc'] = $_POST['descsearch'];
                    }

                    if (!empty($_POST['cpnsearch'])) {
                        $where[] = "CAB_Customer_PN = :cpn";
                        $params[':cpn'] = $_POST['cpnsearch'];
                    }

                    if (!empty($_POST['imdssearch'])) {
                        $where[] = "IMDS = :imds";
                        $params[':imds'] = $_POST['imdssearch'];
                    }

                    if (!empty($_POST['suppsearch'])) {
                        $where[] = "Supplier = :sup";
                        $params[':sup'] = $_POST['suppsearch'];
                    }

                    if (!empty($_POST['spnsearch'])) {
                        $where[] = "Supplier_PN = :spn";
                        $params[':spn'] = $_POST['spnsearch'];
                    }

                    if($_POST['reqn'] == "" && !empty($_POST['date1search']) && !empty($_POST['date2search'])) {
                        $where[] = "Request_Date BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['date1search'];
                        $params[':date2'] = $_POST['date2search'];
                    }
                    if($_POST['reqn'] == "Y") {
                        $where[] = "Request_Date IS NOT NULL";
                    }
                    if($_POST['reqn'] == "N") {
                        $where[] = "Request_Date IS NULL";
                    }

                    if($_POST['psin'] == "" && !empty($_POST['date7search']) && !empty($_POST['date8search'])) {
                        $where[] = "PPAP_Signed_Date BETWEEN :date7 AND :date8";
                        $params[':date7'] = $_POST['date7search'];
                        $params[':date8'] = $_POST['date8search'];
                    }
                    if($_POST['psin'] == "Y") {
                        $where[] = "PPAP_Signed_Date IS NOT NULL";
                    }
                    if($_POST['psin'] == "N") {
                        $where[] = "PPAP_Signed_Date IS NULL";
                    }

                    if($_POST['recn'] == "" && !empty($_POST['date3search']) && !empty($_POST['date4search'])) {
                        $where[] = "PPAP_Received_Date BETWEEN :date3 AND :date4";
                        $params[':date3'] = $_POST['date3search'];
                        $params[':date4'] = $_POST['date4search'];
                    }
                    if($_POST['recn'] == "Y") {
                        $where[] = "PPAP_Received_Date IS NOT NULL";
                    }
                    if($_POST['recn'] == "N") {
                        $where[] = "PPAP_Received_Date IS NULL";
                    }

                    if($_POST['psen'] == "" && !empty($_POST['date5search']) && !empty($_POST['date6search'])) {
                        $where[] = "Sent_Customer BETWEEN :date5 AND :date6search";
                        $params[':date5'] = $_POST['date5search'];
                        $params[':date6search'] = $_POST['date6search'];
                    }
                    if($_POST['psen'] == "Y") {
                        $where[] = "Sent_Customer IS NOT NULL";
                    }
                    if($_POST['psen'] == "N") {
                        $where[] = "Sent_Customer IS NULL";
                    }

                    if(!empty($where)) {
                        $sql = "
                        SELECT 
                            bp.BS_PPAP_ID,
                            b.BS_Eurotech_PN,
                            b.`Description`,
                            bc.`Name`,
                            bcp.BS_Customer_PN,
                            bp.IMDS,
                            b.Supplier,
                            b.Supplier_PN,
                            bp.Request_Date,
                            bp.PPAP_Received_Date,
                            bp.PPAP_Signed_Date,
                            bp.Sent_Customer
                        FROM bluseal b
                            LEFT JOIN bluseal_customer_pn bcp ON b.BS_Eurotech_PN = bcp.FK_BS_Eurotech_PN
                            LEFT JOIN bluseal_customer bc ON bcp.FK_BS_Customer_ID = bc.BS_Customer_ID
                            LEFT JOIN bluseal_ppap bp ON bcp.BS_Customer_PN = bp.FK_BS_Customer_PN
                        WHERE " . implode(' AND ', $where) . "
                        ORDER BY BS_Eurotech_PN;";
                    }
                    else {
                        $sql = "
                        SELECT 
                            bp.BS_PPAP_ID,
                            b.BS_Eurotech_PN,
                            b.`Description`,
                            bc.`Name`,
                            bcp.BS_Customer_PN,
                            bp.IMDS,
                            b.Supplier,
                            b.Supplier_PN,
                            bp.Request_Date,
                            bp.PPAP_Received_Date,
                            bp.PPAP_Signed_Date,
                            bp.Sent_Customer
                        FROM bluseal b
                            LEFT JOIN bluseal_customer_pn bcp ON b.BS_Eurotech_PN = bcp.FK_BS_Eurotech_PN
                            LEFT JOIN bluseal_customer bc ON bcp.FK_BS_Customer_ID = bc.BS_Customer_ID
                            LEFT JOIN bluseal_ppap bp ON bcp.BS_Customer_PN = bp.FK_BS_Customer_PN
                        ORDER BY BS_Eurotech_PN;";
                    }

                    $stmt = $this->mbd->prepare($sql);
                    $stmt->execute($params);

                    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
                else {
                    foreach ($this->mbd->query(
                        "SELECT 
                            bp.BS_PPAP_ID,
                            b.BS_Eurotech_PN,
                            b.`Description`,
                            bc.`Name`,
                            bcp.BS_Customer_PN,
                            bp.IMDS,
                            b.Supplier,
                            b.Supplier_PN,
                            bp.Request_Date,
                            bp.PPAP_Received_Date,
                            bp.PPAP_Signed_Date,
                            bp.Sent_Customer
                        FROM bluseal b
                            LEFT JOIN bluseal_customer_pn bcp ON b.BS_Eurotech_PN = bcp.FK_BS_Eurotech_PN
                            LEFT JOIN bluseal_customer bc ON bcp.FK_BS_Customer_ID = bc.BS_Customer_ID
                            LEFT JOIN bluseal_ppap bp ON bcp.BS_Customer_PN = bp.FK_BS_Customer_PN
                        ORDER BY BS_Eurotech_PN;"
                    ) as $log) {
                        $logs[] = $log;
                    }
                }
            } else {
                foreach ($this->mbd->query(
                    "SELECT 
                        bp.BS_PPAP_ID,
                        b.BS_Eurotech_PN,
                        b.`Description`,
                        bc.`Name`,
                        bcp.BS_Customer_PN,
                        bp.IMDS,
                        b.Supplier,
                        b.Supplier_PN,
                        bp.Request_Date,
                        bp.PPAP_Received_Date,
                        bp.PPAP_Signed_Date,
                        bp.Sent_Customer
                    FROM bluseal b
                        LEFT JOIN bluseal_customer_pn bcp ON b.BS_Eurotech_PN = bcp.FK_BS_Eurotech_PN
                        LEFT JOIN bluseal_customer bc ON bcp.FK_BS_Customer_ID = bc.BS_Customer_ID
                        LEFT JOIN bluseal_ppap bp ON bcp.BS_Customer_PN = bp.FK_BS_Customer_PN
                    ORDER BY BS_Eurotech_PN;"
                ) as $log) {
                    $logs[] = $log;
                }
            }
            return $logs;
        }

        function searchModels(){
            $Models = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        BS_Eurotech_PN
                    FROM bluseal
                    ORDER BY BS_Eurotech_PN;"
                ) as $Model) {
                    $Models[] = $Model;
                }
            return $Models;
        }

        function searchDescs(){
            $Descs = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        `Description`
                    FROM bluseal
                    ORDER BY `Description`;"
                ) as $Desc) {
                    $Descs[] = $Desc;
                }
            return $Descs;
        }

        function searchCustomers(){
            $Customers = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        BS_Customer_ID,
                        `Name`
                    FROM bluseal_customer
                    ORDER BY `Name`;"
                ) as $Customer) {
                    $Customers[] = $Customer;
                }
            return $Customers;
        }

        function searchCPN(){
            $CPNS = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        BS_Customer_PN
                    FROM bluseal_customer_pn
                    ORDER BY BS_Customer_PN;"
                ) as $CPN) {
                    $CPNS[] = $CPN;
                }
            return $CPNS;
        }

        function searchIMDS(){
            $IMDS = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        IMDS
                    FROM bluseal_ppap
                    ORDER BY IMDS;"
                ) as $IM) {
                    $IMDS[] = $IM;
                }
            return $IMDS;
        }

        function searchSupplier(){
            $Suppliers = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Supplier
                    FROM bluseal
                    ORDER BY Supplier;"
                ) as $Supplier) {
                    $Suppliers[] = $Supplier;
                }
            return $Suppliers;
        }

        function searchSupplierPN(){
            $SPNS = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        Supplier_PN
                    FROM bluseal
                    ORDER BY Supplier_PN;"
                ) as $SPN) {
                    $SPNS[] = $SPN;
                }
            return $SPNS;
        }
    }
?>