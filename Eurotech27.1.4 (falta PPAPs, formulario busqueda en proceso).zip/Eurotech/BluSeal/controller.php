<?php 
    include "model.php";

    $model = new model();
    $model->cn();
    $logs = [];
    
    if (isset($_POST["modelsearch"])){
        $modelsearch = $_POST["modelsearch"];
    }    
    else {
        $modelsearch = NULL;
    }

    if (isset($_POST["descsearch"])){
        $descsearch = $_POST["descsearch"];
    }    
    else {
        $descsearch = NULL;
    }

    if (isset($_POST["custsearch"])){
        $custsearch = $_POST["custsearch"];
    }    
    else {
        $custsearch = NULL;
    }

    if (isset($_POST["cpnsearch"])){
        $cpnsearch = $_POST["cpnsearch"];
    }    
    else {
        $cpnsearch = NULL;
    }

    if (isset($_POST["imdssearch"])){
        $imdssearch = $_POST["imdssearch"];
    }    
    else {
        $imdssearch = NULL;
    }

    if (isset($_POST["suppsearch"])){
        $suppsearch = $_POST["suppsearch"];
    }    
    else {
        $suppsearch = NULL;
    }

    if (isset($_POST["spnsearch"])){
        $spnsearch = $_POST["spnsearch"];
    }    
    else {
        $spnsearch = NULL;
    }

    if (isset($_POST["date1search"]) && isset($_POST["date2search"])){
        $date1search = $_POST["date1search"];
        $date2search = $_POST["date2search"];
    }    
    else {
        $date1search = "";
        $date2search = "";
    }

    if (isset($_POST["date3search"]) && isset($_POST["date4search"])){
        $date3search = $_POST["date3search"];
        $date4search = $_POST["date4search"];
    }    
    else {
        $date3search = "";
        $date4search = "";
    }

    if (isset($_POST["date5search"]) && isset($_POST["date6search"])){
        $date5search = $_POST["date5search"];
        $date6search = $_POST["date6search"];
    }    
    else {
        $date5search = "";
        $date6search = "";
    }

    if (isset($_POST["date7search"]) && isset($_POST["date8search"])){
        $date7search = $_POST["date7search"];
        $date8search = $_POST["date8search"];
    }    
    else {
        $date7search = "";
        $date8search = "";
    }

    if (isset($_POST["cusn"])){
        $cusn = $_POST["cusn"];
    }    
    else {
        $cusn = NULL;
    }

    if (isset($_POST["imdn"])){
        $imdn = $_POST["imdn"];
    }    
    else {
        $imdn = NULL;
    }

    if (isset($_POST["reqn"])){
        $reqn = $_POST["reqn"];
    }    
    else {
        $reqn = NULL;
    }

    if (isset($_POST["recn"])){
        $recn = $_POST["recn"];
    }    
    else {
        $recn = NULL;
    }

    if (isset($_POST["psen"])){
        $psen = $_POST["psen"];
    }    
    else {
        $psen = NULL;
    }

    if (isset($_POST["psin"])){
        $psin = $_POST["psin"];
    }    
    else {
        $psin = NULL;
    }

    $noteData = NULL;
    $bsData = NULL;
    $bsDataD = NULL;
    $Deleted = NULL;


    $pdo = new PDO("mysql:host=localhost;dbname=eurotechdb", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        if (isset($_POST['note'])) {
            $id = $_POST['IDnote'];
            $stmt = $pdo->prepare("SELECT BS_PPAP_ID, PPAP_ET, IMDS_ET FROM bluseal_ppap WHERE BS_PPAP_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $noteData = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmNote'])) {
            if(!isset($_POST['PPAP_ET']) &&  !isset($_POST['IMDS_ET'])) {
                $stmt = $pdo->prepare("UPDATE bluseal_ppap SET 
                                        PPAP_ET = NULL, 
                                        IMDS_ET = NULL 
                                        WHERE BS_PPAP_ID = ?");

                $stmt->execute([
                    $_POST['confirmIDNote']
                ]);
            }
            if(!isset($_POST['PPAP_ET']) && isset($_POST['IMDS_ET'])) {
                $stmt = $pdo->prepare("UPDATE bluseal_ppap SET 
                                        PPAP_ET = NULL, 
                                        IMDS_ET = '1' 
                                        WHERE BS_PPAP_ID = ?");

                $stmt->execute([
                    $_POST['confirmIDNote']
                ]);
            }
            if(isset($_POST['PPAP_ET']) && !isset($_POST['IMDS_ET'])) {
                $stmt = $pdo->prepare("UPDATE bluseal_ppap SET 
                                        PPAP_ET = '1', 
                                        IMDS_ET = NULL
                                        WHERE BS_PPAP_ID = ?");

                $stmt->execute([
                    $_POST['confirmIDNote']
                ]);
            }
            if(isset($_POST['PPAP_ET']) && isset($_POST['IMDS_ET']) ) {
                $stmt = $pdo->prepare("UPDATE bluseal_ppap SET 
                                        PPAP_ET = '1', 
                                        IMDS_ET = '1'
                                        WHERE BS_PPAP_ID = ?");

                $stmt->execute([
                    $_POST['confirmIDNote']
                ]);
            } 
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['confirmID'])) {
            $stmt = $pdo->prepare("SELECT Eurotech_PN FROM products WHERE `Description` = ?");
            $stmt->execute([
                $_POST['Description']
            ]);
            $etpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT `Name` FROM customers WHERE `Name` = ?");
            $stmt->execute([
                $_POST['Name']
            ]);
            $cn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($etpn != NULL && $cn != NULL) {
                foreach ($etpn as $pn) {
                    $stmt = $pdo->prepare("SELECT cpn.Customer_PN FROM customer_pn cpn
                                                INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                                WHERE cpn.FK_Eurotech_PN = ? AND c.`Name` = ?");
                    $stmt->execute([
                        $pn,
                        $_POST['Name']
                    ]);
                    $cpn = $stmt->fetchAll(PDO::FETCH_COLUMN);
                }

                
                if(isset($_POST['IMDS']) && $_POST['IMDS'] == "") {
                    $_POST['IMDS'] = NULL;
                }

                if($cpn != NULL) {
                    foreach ($cpn as $c) {
                        if($_POST['PPAP_Received_Date'] == "" && $_POST['Sent_Customer'] == "" && $_POST['PPAP_Signed_Date'] == "") {
                            $stmt = $pdo->prepare("INSERT INTO bluseal_ppap (FK_Customer_PN, IMDS, Request_Date) 
                                                VALUES (?, ?, ?)");
                            $stmt->execute([
                                $c,
                                $_POST['IMDS'],
                                $_POST['Request_Date']
                            ]);
                        }
                        if($_POST['PPAP_Received_Date'] != "" && $_POST['Sent_Customer'] == "" && $_POST['PPAP_Signed_Date'] == "") {
                            $stmt = $pdo->prepare("INSERT INTO bluseal_ppap (FK_Customer_PN, IMDS, Request_Date, PPAP_Received_Date) 
                                                VALUES (?, ?, ?, ?)");
                            $stmt->execute([
                                $c,
                                $_POST['IMDS'],
                                $_POST['Request_Date'],
                                $_POST['PPAP_Received_Date']
                            ]);
                        }
                        if($_POST['PPAP_Received_Date'] != "" && $_POST['Sent_Customer'] != "" && $_POST['PPAP_Signed_Date'] == "") {
                            $stmt = $pdo->prepare("INSERT INTO bluseal_ppap (FK_Customer_PN, IMDS, Request_Date, PPAP_Received_Date, Sent_Customer) 
                                                VALUES (?, ?, ?, ?, ?)");
                            $stmt->execute([
                                $c,
                                $_POST['IMDS'],
                                $_POST['Request_Date'],
                                $_POST['PPAP_Received_Date'],
                                $_POST['Sent_Customer']
                            ]);
                        }
                        if($_POST['PPAP_Received_Date'] != "" && $_POST['Sent_Customer'] != "" && $_POST['PPAP_Signed_Date'] != "") {
                            $stmt = $pdo->prepare("INSERT INTO bluseal_ppap (FK_Customer_PN, IMDS, Request_Date, PPAP_Received_Date, Sent_Customer, PPAP_Signed_Date) 
                                                VALUES (?, ?, ?, ?, ?, ?)");
                            $stmt->execute([
                                $c,
                                $_POST['IMDS'],
                                $_POST['Request_Date'],
                                $_POST['PPAP_Received_Date'],
                                $_POST['Sent_Customer'],
                                $_POST['PPAP_Signed_Date']
                            ]);
                        }
                        if(($_POST['PPAP_Received_Date'] == "" && $_POST['Sent_Customer'] != "" && $_POST['PPAP_Signed_Date'] == "") 
                            || ($_POST['PPAP_Received_Date'] == "" && $_POST['Sent_Customer'] != "" && $_POST['PPAP_Signed_Date'] != "")) {
                            $_POST['insertD'] = 1;
                            $error = "'PPAP Received Date' is missing.";
                        }
                        if($_POST['PPAP_Received_Date'] == "" && $_POST['Sent_Customer'] == "" && $_POST['PPAP_Signed_Date'] != "") {
                            $_POST['insertD'] = 1;
                            $error = "'PPAP Received Date' and 'PPAP Sent Date' are missing.";
                        }
                        if($_POST['PPAP_Received_Date'] != "" && $_POST['Sent_Customer'] == "" && $_POST['PPAP_Signed_Date'] != "") {
                            $_POST['insertD'] = 1;
                            $error = "'PPAP Sent Date' is missing.";
                        }
                    }
                }
                else {
                    $_POST['insertD'] = 1;
                    $error = "Customer PN doesn't exist.";
                }
            }
            if($etpn != NULL && $cn == NULL) {
                $_POST['insertD'] = 1;
                $error = "The customer <b>".$_POST['Name']."</b> doesn't exist.";
            }

            $_SESSION['saved'] = true;
        }

        if (isset($_POST['confirmIE'])) {
            $etpn = $_POST['Eurotech_PN'];

            $stmt = $pdo->prepare("SELECT `Name` FROM customers WHERE `Name` = ?");
            $stmt->execute([
                $_POST['Name']
            ]);
            $cn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($etpn != NULL && $cn != NULL) {
                $stmt = $pdo->prepare("SELECT cpn.Customer_PN FROM customer_pn cpn
                                                INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                                WHERE cpn.FK_Eurotech_PN = ? AND c.`Name` = ?");
                $stmt->execute([
                    $etpn,
                    $_POST['Name']
                ]);
                $cpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

                if(isset($_POST['IMDS']) && $_POST['IMDS'] == "") {
                    $_POST['IMDS'] = NULL;
                }
                
                if($cpn != NULL) {
                    foreach ($cpn as $c) {
                        if($_POST['PPAP_Received_Date'] == "" && $_POST['Sent_Customer'] == "" && $_POST['PPAP_Signed_Date'] == "") {
                            $stmt = $pdo->prepare("INSERT INTO bluseal_ppap (FK_Customer_PN, IMDS, Request_Date) 
                                                VALUES (?, ? , ?)");
                            $stmt->execute([
                                $c,
                                $_POST['IMDS'],
                                $_POST['Request_Date']
                            ]);
                        }
                        if($_POST['PPAP_Received_Date'] != "" && $_POST['Sent_Customer'] == "" && $_POST['PPAP_Signed_Date'] == "") {
                            $stmt = $pdo->prepare("INSERT INTO bluseal_ppap (FK_Customer_PN, IMDS, Request_Date, PPAP_Received_Date) 
                                                VALUES (?, ?, ? , ?)");
                            $stmt->execute([
                                $c,
                                $_POST['IMDS'],
                                $_POST['Request_Date'],
                                $_POST['PPAP_Received_Date']
                            ]);
                        }
                        if($_POST['PPAP_Received_Date'] != "" && $_POST['Sent_Customer'] != "" && $_POST['PPAP_Signed_Date'] == "") {
                            $stmt = $pdo->prepare("INSERT INTO bluseal_ppap (FK_Customer_PN, IMDS, Request_Date, PPAP_Received_Date, Sent_Customer) 
                                                VALUES (?, ?, ?, ? , ?)");
                            $stmt->execute([
                                $c,
                                $_POST['IMDS'],
                                $_POST['Request_Date'],
                                $_POST['PPAP_Received_Date'],
                                $_POST['Sent_Customer']
                            ]);
                        }
                        if($_POST['PPAP_Received_Date'] != "" && $_POST['Sent_Customer'] != "" && $_POST['PPAP_Signed_Date'] != "") {
                            $stmt = $pdo->prepare("INSERT INTO bluseal_ppap (FK_Customer_PN, IMDS, Request_Date, PPAP_Received_Date, Sent_Customer, PPAP_Signed_Date) 
                                                VALUES (?, ?, ?, ?, ?, ?)");
                            $stmt->execute([
                                $c,
                                $_POST['IMDS'],
                                $_POST['Request_Date'],
                                $_POST['PPAP_Received_Date'],
                                $_POST['Sent_Customer'],
                                $_POST['PPAP_Signed_Date']
                            ]);
                        }
                        if(($_POST['PPAP_Received_Date'] == "" && $_POST['Sent_Customer'] != "" && $_POST['PPAP_Signed_Date'] == "") 
                            || ($_POST['PPAP_Received_Date'] == "" && $_POST['Sent_Customer'] != "" && $_POST['PPAP_Signed_Date'] != "")) {
                            $_POST['insertET'] = 1;
                            $error = "'PPAP Received Date' is missing.";
                        }
                        if($_POST['PPAP_Received_Date'] == "" && $_POST['Sent_Customer'] == "" && $_POST['PPAP_Signed_Date'] != "") {
                            $_POST['insertET'] = 1;
                            $error = "'PPAP Received Date' and 'PPAP Sent Date' are missing.";
                        }
                        if($_POST['PPAP_Received_Date'] != "" && $_POST['Sent_Customer'] == "" && $_POST['PPAP_Signed_Date'] != "") {
                            $_POST['insertET'] = 1;
                            $error = "'PPAP Sent Date' is missing.";
                        }
                    }
                }
                else {
                    $_POST['insertET'] = 1;
                    $error = "Customer PN doesn't exist.";
                }
            }
            if($etpn != NULL && $cn == NULL) {
               $_POST['insertET'] = 1;
                $error = "The customer <b>".$_POST['Name']."</b> doesn't exist.";
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['confirmIC'])) {
            $stmt = $pdo->prepare("SELECT Customer_PN FROM customer_pn WHERE Customer_PN = ?");
            $stmt->execute([
                $_POST['Customer_PN']
            ]);
            $cpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if(isset($_POST['IMDS']) && $_POST['IMDS'] == "") {
                    $_POST['IMDS'] = NULL;
                }

            if($cpn != NULL) {
                foreach ($cpn as $c) {
                    if($_POST['PPAP_Received_Date'] == "" && $_POST['Sent_Customer'] == "" && $_POST['PPAP_Signed_Date'] == "") {
                        $stmt = $pdo->prepare("INSERT INTO bluseal_ppap (FK_Customer_PN, IMDS, Request_Date) 
                                                VALUES (?, ?, ?)");
                        $stmt->execute([
                            $c,
                            $_POST['IMDS'],
                            $_POST['Request_Date']
                        ]);
                    }
                    if($_POST['PPAP_Received_Date'] != "" && $_POST['Sent_Customer'] == "" && $_POST['PPAP_Signed_Date'] == "") {
                        $stmt = $pdo->prepare("INSERT INTO bluseal_ppap (FK_Customer_PN, IMDS, Request_Date, PPAP_Received_Date) 
                                                VALUES (?, ?, ?, ?)");
                        $stmt->execute([
                            $c,
                            $_POST['IMDS'],
                            $_POST['Request_Date'],
                            $_POST['PPAP_Received_Date']
                        ]);
                    }
                    if($_POST['PPAP_Received_Date'] != "" && $_POST['Sent_Customer'] != "" && $_POST['PPAP_Signed_Date'] == "") {
                        $stmt = $pdo->prepare("INSERT INTO bluseal_ppap (FK_Customer_PN, IMDS, Request_Date, PPAP_Received_Date, Sent_Customer) 
                                                VALUES (?, ?, ?, ?, ?)");
                        $stmt->execute([
                            $c,
                            $_POST['IMDS'],
                            $_POST['Request_Date'],
                            $_POST['PPAP_Received_Date'],
                            $_POST['Sent_Customer']
                        ]);
                    }
                    if($_POST['PPAP_Received_Date'] != "" && $_POST['Sent_Customer'] != "" && $_POST['PPAP_Signed_Date'] != "") {
                        $stmt = $pdo->prepare("INSERT INTO bluseal_ppap (FK_Customer_PN, IMDS, Request_Date, PPAP_Received_Date, Sent_Customer, PPAP_Signed_Date) 
                                                VALUES (?, ?, ?, ?, ?, ?)");
                        $stmt->execute([
                            $c,
                            $_POST['IMDS'],
                            $_POST['Request_Date'],
                            $_POST['PPAP_Received_Date'],
                            $_POST['Sent_Customer'],
                            $_POST['PPAP_Signed_Date']
                        ]);
                    }
                    if(($_POST['PPAP_Received_Date'] == "" && $_POST['Sent_Customer'] != "" && $_POST['PPAP_Signed_Date'] == "") 
                        || ($_POST['PPAP_Received_Date'] == "" && $_POST['Sent_Customer'] != "" && $_POST['PPAP_Signed_Date'] != "")) {
                        $_POST['insertC'] = 1;
                        $error = "'PPAP Received Date' is missing.";
                    }
                    if($_POST['PPAP_Received_Date'] == "" && $_POST['Sent_Customer'] == "" && $_POST['PPAP_Signed_Date'] != "") {
                        $_POST['insertC'] = 1;
                        $error = "'PPAP Received Date' and 'PPAP Sent Date' are missing.";
                    }
                    if($_POST['PPAP_Received_Date'] != "" && $_POST['Sent_Customer'] == "" && $_POST['PPAP_Signed_Date'] != "") {
                        $_POST['insertC'] = 1;
                        $error = "'PPAP Sent Date' is missing.";
                    }
                }
            }
            else {
                $_POST['insertC'] = 1;
                $error = "The Customer PN <b>".$_POST['Customer_PN']."</b> doesn't exist.";
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['edit'])) {
            $id = $_POST['IDedit'];
            $stmt = $pdo->prepare("SELECT BS_PPAP_ID, IMDS, Request_Date, PPAP_Received_Date, Sent_Customer, PPAP_Signed_Date FROM bluseal_ppap WHERE BS_PPAP_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $bsData = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmU'])) {
            if($_POST['Request_Date'] != "") {
                $reqD = new DateTime($_POST['Request_Date']);
            }
            if($_POST['PPAP_Received_Date'] != "") {
                $recD = new DateTime($_POST['PPAP_Received_Date']);
            }
            if($_POST['Sent_Customer'] != "") {
                $senD = new DateTime($_POST['Sent_Customer']);
            }
            if($_POST['PPAP_Signed_Date'] != "") {
                $sigD = new DateTime($_POST['PPAP_Signed_Date']);
            }

            if(isset($_POST['IMDS']) && $_POST['IMDS'] == "") {
                $_POST['IMDS'] = NULL;
            }

            if($_POST['PPAP_Received_Date'] == "" && $_POST['Sent_Customer'] == "" && $_POST['PPAP_Signed_Date'] == "") {
                $stmt = $pdo->prepare("UPDATE bluseal_ppap SET 
                                        IMDS = ?, 
                                        Request_Date = ?, 
                                        PPAP_Received_Date = NULL, 
                                        Sent_Customer = NULL, 
                                        PPAP_Signed_Date = NULL
                                        WHERE BS_PPAP_ID = ?");

                $stmt->execute([
                    $_POST['IMDS'],
                    $reqD->format('Y-m-d'),
                    $_POST['BS_PPAP_ID']
                ]);
            }
            if($_POST['PPAP_Received_Date'] != "" && $_POST['Sent_Customer'] == "" && $_POST['PPAP_Signed_Date'] == "")  {
                $stmt = $pdo->prepare("UPDATE bluseal_ppap SET 
                                        IMDS = ?, 
                                        Request_Date = ?, 
                                        PPAP_Received_Date = ?, 
                                        Sent_Customer = NULL, 
                                        PPAP_Signed_Date = NULL
                                        WHERE BS_PPAP_ID = ?");

                $stmt->execute([
                    $_POST['IMDS'],
                    $reqD->format('Y-m-d'),
                    $recD->format('Y-m-d'),
                    $_POST['BS_PPAP_ID']
                ]);
            }
            if($_POST['PPAP_Received_Date'] != "" && $_POST['Sent_Customer'] != "" && $_POST['PPAP_Signed_Date'] == "") {
                $stmt = $pdo->prepare("UPDATE bluseal_ppap SET 
                                        IMDS = ?, 
                                        Request_Date = ?, 
                                        PPAP_Received_Date = ?, 
                                        Sent_Customer = ?, 
                                        PPAP_Signed_Date = NULL
                                        WHERE BS_PPAP_ID = ?");

                $stmt->execute([
                    $_POST['IMDS'],
                    $reqD->format('Y-m-d'),
                    $recD->format('Y-m-d'),
                    $senD->format('Y-m-d'),
                    $_POST['BS_PPAP_ID']
                ]);
            }
            if($_POST['PPAP_Received_Date'] && $_POST['Sent_Customer'] != "" && $_POST['PPAP_Signed_Date'] != "")  {
                $stmt = $pdo->prepare("UPDATE bluseal_ppap SET 
                                        IMDS = ?, 
                                        Request_Date = ?, 
                                        PPAP_Received_Date = ?, 
                                        Sent_Customer = ?, 
                                        PPAP_Signed_Date = ?
                                        WHERE BS_PPAP_ID = ?");

                $stmt->execute([
                    $_POST['IMDS'],
                    $reqD->format('Y-m-d'),
                    $recD->format('Y-m-d'),
                    $senD->format('Y-m-d'),
                    $sigD->format('Y-m-d'),
                    $_POST['BS_PPAP_ID']
                ]);
            }
            if(($_POST['PPAP_Received_Date'] == "" && $_POST['Sent_Customer'] != "" && $_POST['PPAP_Signed_Date'] == "") 
                || ($_POST['PPAP_Received_Date'] == "" && $_POST['Sent_Customer'] != "" && $_POST['PPAP_Signed_Date'] != "")) {
                $_POST['edit'] = 1;
                $error = "'PPAP Received Date' is missing.";
            }
            if($_POST['PPAP_Received_Date'] == "" && $_POST['Sent_Customer'] == "" && $_POST['PPAP_Signed_Date'] != "") {
                $_POST['edit'] = 1;
                $error = "'PPAP Received Date' and 'PPAP Sent Date' are missing.";
            }
            if($_POST['PPAP_Received_Date'] != "" && $_POST['Sent_Customer'] == "" && $_POST['PPAP_Signed_Date'] != "") {
                $_POST['edit'] = 1;
                $error = "'PPAP Sent Date' is missing.";
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['delete'])) {
            $id = $_POST['IDdelete'];
            $stmt = $pdo->prepare("SELECT 
                                    bp.BS_PPAP_ID,
                                    p.Eurotech_PN,
                                    p.`Description`,
                                    c.`Name`,
                                    cpn.Customer_PN,
                                    bp.IMDS,
                                    v.`Name` AS 'Vendor',
                                    v.Short_name,
                                    p.Supplier_PN,
                                    bp.Request_Date,
                                    bp.PPAP_Received_Date,
                                    bp.PPAP_Signed_Date,
                                    bp.Sent_Customer
                                FROM products p
                                    LEFT JOIN customer_pn cpn ON p.Eurotech_PN = cpn.FK_Eurotech_PN
                                    LEFT JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                    LEFT JOIN bluseal_ppap bp ON cpn.Customer_PN = bp.FK_Customer_PN
                                    LEFT JOIN vendors v ON v.Vendor_ID = p.Supplier
                                WHERE BS_PPAP_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $bsDataD = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmD'])) {
            $id = $_POST['IDdelete'];
            $stmt = $pdo->prepare("DELETE FROM bluseal_ppap
                                    WHERE BS_PPAP_ID = ?");

            $stmt->execute([
                $id
            ]);
           
            $Deleted = 'Y';

            $_SESSION['saved'] = true;
        }
    }
    
    
    $Models = $model->searchModels();
    $Descs = $model->searchDescs();
    $Customers = $model->searchCustomers();
    $CPNS = $model->searchCPN();
    $IMDS = $model->searchIMDS();
    $Suppliers = $model->searchSupplier();
    $SPNS = $model->searchSupplierPN();
    $logs = $model->search();

    include 'view.php';
?>