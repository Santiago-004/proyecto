<?php 
    include "model.php";

    $model = new model();
    $model->cn();
    $logs = [];
    
    if (isset($_POST["submit1search"]) && isset($_POST["submit2search"])){
        $submit1search = $_POST["submit1search"];
        $submit2search = $_POST["submit2search"];
    }    
    else {
        $submit1search = "";
        $submit2search = "";
    }

    if (isset($_POST["ppapnsearch"])){
        $ppapnsearch = $_POST["ppapnsearch"];
    }    
    else {
        $ppapnsearch = "";
    }
    
    if (isset($_POST["req1search"]) && isset($_POST["req2search"])){
        $req1search = $_POST["req1search"];
        $req2search = $_POST["req2search"];
    }    
    else {
        $req1search = "";
        $req2search = "";
    }

    if (isset($_POST["currentsearch"])){
        $currentsearch = $_POST["currentsearch"];
    }    
    else {
        $currentsearch = "";
    }

    if (isset($_POST["pisearch"])){
        $pisearch = $_POST["pisearch"];
    }    
    else {
        $pisearch = "";
    }

    if (isset($_POST["custsearch"])){
        $custsearch = $_POST["custsearch"];
    }    
    else {
        $custsearch = "";
    }

    if (isset($_POST["countrysearch"])){
        $countrysearch = $_POST["countrysearch"];
    }    
    else {
        $countrysearch = "";
    }

    if (isset($_POST["cpnsearch"])){
        $cpnsearch = $_POST["cpnsearch"];
    }    
    else {
        $cpnsearch = "";
    }

    if (isset($_POST["etmsearch"])){
        $etmsearch = $_POST["etmsearch"];
    }    
    else {
        $etmsearch = "";
    }

    if (isset($_POST["etdsearch"])){
        $etdsearch = $_POST["etdsearch"];
    }    
    else {
        $etdsearch = "";
    }

    if (isset($_POST["revsearch"])){
        $revsearch = $_POST["revsearch"];
    }    
    else {
        $revsearch = "";
    }

    if (isset($_POST["etpnsearch"])){
        $etpnsearch = $_POST["etpnsearch"];
    }    
    else {
        $etpnsearch = "";
    }

    if (isset($_POST["descsearch"])){
        $descsearch = $_POST["descsearch"];
    }    
    else {
        $descsearch = "";
    }

    if (isset($_POST["imdssearch"])){
        $imdssearch = $_POST["imdssearch"];
    }    
    else {
        $imdssearch = "";
    }

    if (isset($_POST["issearch"])){
        $issearch = $_POST["issearch"];
    }    
    else {
        $issearch = "";
    }

    if (isset($_POST["pdsearch"])){
        $pdsearch = $_POST["pdsearch"];
    }    
    else {
        $pdsearch = "";
    }

    if (isset($_POST["levelsearch"])){
        $levelsearch = $_POST["levelsearch"];
    }    
    else {
        $levelsearch = "";
    }

    if (isset($_POST["psssearch"])){
        $psssearch = $_POST["psssearch"];
    }    
    else {
        $psssearch = "";
    }

    if (isset($_POST["rssearch"])){
        $rssearch = $_POST["rssearch"];
    }    
    else {
        $rssearch = "";
    }  

    if (isset($_POST["sent1search"]) && isset($_POST["sent2search"])){
        $sent1search = $_POST["sent1search"];
        $sent2search = $_POST["sent2search"];
    }    
    else {
        $sent1search = "";
        $sent2search = "";
    }

    if (isset($_POST["psw1search"]) && isset($_POST["psw2search"])){
        $psw1search = $_POST["psw1search"];
        $psw2search = $_POST["psw2search"];
    }    
    else {
        $psw1search = "";
        $psw2search = "";
    }

    if (isset($_POST["originsearch"])){
        $originsearch = $_POST["originsearch"];
    }    
    else {
        $originsearch = "";
    } 

    if (isset($_POST["comsearch"])){
        $comsearch = $_POST["comsearch"];
    }    
    else {
        $comsearch = "";
    }

    if (isset($_POST["irnsearch"])){
        $irnsearch = $_POST["irnsearch"];
    }    
    else {
        $irnsearch = "";
    } 

    if (isset($_POST["reqn"])){
        $reqn = $_POST["reqn"];
    }    
    else {
        $reqn = NULL;
    }

    if (isset($_POST["curn"])){
        $curn = $_POST["curn"];
    }    
    else {
        $curn = NULL;
    }

    if (isset($_POST["imdn"])){
        $imdn = $_POST["imdn"];
    }    
    else {
        $imdn = NULL;
    }

    if (isset($_POST["imsn"])){
        $imsn = $_POST["imsn"];
    }    
    else {
        $imsn = NULL;
    }

    if (isset($_POST["ppdn"])){
        $ppdn = $_POST["ppdn"];
    }    
    else {
        $ppdn = NULL;
    }

    if (isset($_POST["lvln"])){
        $lvln = $_POST["lvln"];
    }    
    else {
        $lvln = NULL;
    }

    if (isset($_POST["pssn"])){
        $pssn = $_POST["pssn"];
    }    
    else {
        $pssn = NULL;
    }

    if (isset($_POST["rosn"])){
        $rosn = $_POST["rosn"];
    }    
    else {
        $rosn = NULL;
    }

    if (isset($_POST["stcn"])){
        $stcn = $_POST["stcn"];
    }    
    else {
        $stcn = NULL;
    }

    if (isset($_POST["pcsn"])){
        $pcsn = $_POST["pcsn"];
    }    
    else {
        $pcsn = NULL;
    }

    $NocpnError = NULL;
    $etpnError = NULL;
    $descError = NULL;
    $custError = NULL;
    $dcError = NULL;
    $ecError = NULL;
    $cpnError = NULL;
    $NoDatesError = NULL;
    $VendError = NULL;
    $tubeData = NULL;
    $tubeDataD = NULL;
    $Deleted = NULL;

    $pdo = new PDO("mysql:host=localhost;dbname=eurotechdb", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        if (isset($_POST['confirmID'])) {
            $stmt = $pdo->prepare("SELECT TUB_Eurotech_PN FROM tubes WHERE `Description` = ?");
            $stmt->execute([
                $_POST['Description']
            ]);
            $etpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT `Name` FROM tubes_customer WHERE `Name` = ?");
            $stmt->execute([
                $_POST['Name']
            ]);
            $cn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT TUB_Vendor_ID FROM tubes_vendor
                                                WHERE Short_name = ?");
            $stmt->execute([
                $_POST['Short_name']
            ]);
            $ven = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($etpn != NULL && $cn != NULL) {
                foreach ($etpn as $pn) {
                    $stmt = $pdo->prepare("SELECT ccpn.TUB_Customer_PN FROM tubes_customer_pn ccpn
                                                INNER JOIN tubes_customer cc ON ccpn.FK_TUB_Customer_ID = cc.TUB_Customer_ID
                                                WHERE ccpn.FK_TUB_Eurotech_PN = ? AND cc.`Name` = ?");
                    $stmt->execute([
                        $pn,
                        $_POST['Name']
                    ]);
                    $cpn = $stmt->fetchAll(PDO::FETCH_COLUMN);
                }

                if($cpn != NULL) {
                    $insertsP = [];
                    $paramsP = [];
                    $insertsPS = [];
                    $paramsPS = [];

                    foreach ($cpn as $c) {
                        if(!empty($_POST['PPAP_Number'])) {
                            $insertsP[] = "PPAP_Number";
                            $paramsP[] = "'".$_POST['PPAP_Number']."'";

                            $insertsPS[] = "FK_PPAP_Number";
                            $paramsPS[] = "'".$_POST['PPAP_Number']."'";
                        }

                        if(!empty($_POST['PPAP_Req_by_Cus_Date'])) {
                            $insertsPS[] = "PPAP_Req_by_Cus_Date";
                            $paramsPS[] = "'".$_POST['PPAP_Req_by_Cus_Date']."'";
                        }

                        if(!empty($_POST['Current_Status'])) {
                            $insertsPS[] = "Current_Status";
                            $paramsPS[] = "'".$_POST['Current_Status']."'";
                        }

                        if($ven != NULL) {
                            foreach ($ven as $v) {
                                $insertsP[] = "FK_TUB_Vendor_ID";
                                $paramsP[] = "'".$v."'";
                            }
                        }

                        if(!empty($_POST['Country'])) {
                            $insertsP[] = "Country";
                            $paramsP[] = "'".$_POST['Country']."'";
                        }

                        if(!empty($_POST['Rev'])) {
                            $insertsPS[] = "Rev";
                            $paramsPS[] = "'".$_POST['Rev']."'";
                        }

                        if(!empty($_POST['IMDS_Number'])) {
                            $insertsPS[] = "IMDS_Number";
                            $paramsPS[] = "'".$_POST['IMDS_Number']."'";
                        }

                        if(!empty($_POST['IMDS_Status'])) {
                            $insertsPS[] = "IMDS_Status";
                            $paramsPS[] = "'".$_POST['IMDS_Status']."'";
                        }

                        if(!empty($_POST['PPAP_docs'])) {
                            $insertsPS[] = "PPAP_docs";
                            $paramsPS[] = "'".$_POST['PPAP_docs']."'";
                        }

                        if(!empty($_POST['Level'])) {
                            $insertsPS[] = "Level";
                            $paramsPS[] = "'".$_POST['Level']."'";
                        }

                        if(!empty($_POST['Samples_Status'])) {
                            $insertsPS[] = "Samples_Status";
                            $paramsPS[] = "'".$_POST['Samples_Status']."'";
                        }

                        if(!empty($_POST['Reason_submission'])) {
                            $insertsPS[] = "Reason_submission";
                            $paramsPS[] = "'".$_POST['Reason_submission']."'";
                        }

                        if(!empty($_POST['Sent_Customer'])) {
                            $insertsPS[] = "Sent_Customer";
                            $paramsPS[] = "'".$_POST['Sent_Customer']."'";
                        }

                        if(!empty($_POST['PSW_Returned'])) {
                            $insertsPS[] = "PSW_Returned";
                            $paramsPS[] = "'".$_POST['PSW_Returned']."'";
                        }

                        if(!empty($_POST['Origin_from_report']) && $_POST['Origin_from_report'] != 'no') {
                            $insertsPS[] = "Origin_from_report";
                            $paramsPS[] = "'".$_POST['Origin_from_report']."'";
                        }

                        if(!empty($_POST['Inspection_rep_numb'])) {
                            $insertsPS[] = "Inspection_rep_numb";
                            $paramsPS[] = "'".$_POST['Inspection_rep_numb']."'";
                        }

                        $insertsP[] = "FK_TUB_Customer_PN";
                        $paramsP[] = "'$c'";

                        $stmt = $pdo->prepare("SELECT PPAP_Number FROM tubes_ppap WHERE PPAP_Number = ?");
                        $stmt->execute([
                            $_POST['PPAP_Number']
                        ]);
                        $ppapn = $stmt->fetchAll(PDO::FETCH_COLUMN);

                        if(($_POST['PPAP_Req_by_Cus_Date'] == "" && $_POST['Sent_Customer'] == "" && $_POST['PSW_Returned'] != "")
                            || ($_POST['PPAP_Req_by_Cus_Date'] == "" && $_POST['Sent_Customer'] != "" && $_POST['PSW_Returned'] != "")
                            || ($_POST['PPAP_Req_by_Cus_Date'] == "" && $_POST['Sent_Customer'] != "" && $_POST['PSW_Returned'] == "")
                            || ($_POST['PPAP_Req_by_Cus_Date'] != "" && $_POST['Sent_Customer'] == "" && $_POST['PSW_Returned'] != "")) {
                            $NoDatesError = 'Y';
                        }
                        else {
                            if($ppapn == NULL) {
                                $stmt = $pdo->prepare("INSERT INTO tubes_ppap (". implode(', ', $insertsP) .") 
                                                    VALUES (". implode(', ', $paramsP) .")");
                                $stmt->execute([]);
                            }

                            $stmt = $pdo->prepare("INSERT INTO tubes_ppaps (". implode(', ', $insertsPS) .") 
                                                    VALUES (". implode(', ', $paramsPS) .")");
                            $stmt->execute([]);
                        }
                    }
                }
                else {
                    $NocpnError = 'Y';
                }
            }
            if($etpn == NULL && $cn != NULL) {
                $descError = 'Y';
            }
            if($etpn != NULL && $cn == NULL) {
                $custError = 'Y';
            }
            if($etpn == NULL && $cn == NULL) {
                $dcError = 'Y';
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['confirmIE'])) {
            $stmt = $pdo->prepare("SELECT TUB_Eurotech_PN FROM tubes WHERE TUB_Eurotech_PN = ?");
            $stmt->execute([
                $_POST['TUB_Eurotech_PN']
            ]);
            $etpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT `Name` FROM tubes_customer WHERE `Name` = ?");
            $stmt->execute([
                $_POST['Name']
            ]);
            $cn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT TUB_Vendor_ID FROM tubes_vendor
                                                WHERE Short_name = ?");
            $stmt->execute([
                $_POST['Short_name']
            ]);
            $ven = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($etpn != NULL && $cn != NULL) {
                foreach ($etpn as $pn) {
                    $stmt = $pdo->prepare("SELECT ccpn.TUB_Customer_PN FROM tubes_customer_pn ccpn
                                                INNER JOIN tubes_customer cc ON ccpn.FK_TUB_Customer_ID = cc.TUB_Customer_ID
                                                WHERE ccpn.FK_TUB_Eurotech_PN = ? AND cc.`Name` = ?");
                    $stmt->execute([
                        $pn,
                        $_POST['Name']
                    ]);
                    $cpn = $stmt->fetchAll(PDO::FETCH_COLUMN);
                }

                if($cpn != NULL) {
                    $insertsP = [];
                    $paramsP = [];
                    $insertsPS = [];
                    $paramsPS = [];

                    foreach ($cpn as $c) {
                        if(!empty($_POST['PPAP_Number'])) {
                            $insertsP[] = "PPAP_Number";
                            $paramsP[] = "'".$_POST['PPAP_Number']."'";

                            $insertsPS[] = "FK_PPAP_Number";
                            $paramsPS[] = "'".$_POST['PPAP_Number']."'";
                        }

                        if(!empty($_POST['PPAP_Req_by_Cus_Date'])) {
                            $insertsPS[] = "PPAP_Req_by_Cus_Date";
                            $paramsPS[] = "'".$_POST['PPAP_Req_by_Cus_Date']."'";
                        }

                        if(!empty($_POST['Current_Status'])) {
                            $insertsPS[] = "Current_Status";
                            $paramsPS[] = "'".$_POST['Current_Status']."'";
                        }

                        if($ven != NULL) {
                            foreach ($ven as $v) {
                                $insertsP[] = "FK_TUB_Vendor_ID";
                                $paramsP[] = "'".$v."'";
                            }
                        }

                        if(!empty($_POST['Country'])) {
                            $insertsP[] = "Country";
                            $paramsP[] = "'".$_POST['Country']."'";
                        }

                        if(!empty($_POST['Rev'])) {
                            $insertsPS[] = "Rev";
                            $paramsPS[] = "'".$_POST['Rev']."'";
                        }

                        if(!empty($_POST['IMDS_Number'])) {
                            $insertsPS[] = "IMDS_Number";
                            $paramsPS[] = "'".$_POST['IMDS_Number']."'";
                        }

                        if(!empty($_POST['IMDS_Status'])) {
                            $insertsPS[] = "IMDS_Status";
                            $paramsPS[] = "'".$_POST['IMDS_Status']."'";
                        }

                        if(!empty($_POST['PPAP_docs'])) {
                            $insertsPS[] = "PPAP_docs";
                            $paramsPS[] = "'".$_POST['PPAP_docs']."'";
                        }

                        if(!empty($_POST['Level'])) {
                            $insertsPS[] = "Level";
                            $paramsPS[] = "'".$_POST['Level']."'";
                        }

                        if(!empty($_POST['Samples_Status'])) {
                            $insertsPS[] = "Samples_Status";
                            $paramsPS[] = "'".$_POST['Samples_Status']."'";
                        }

                        if(!empty($_POST['Reason_submission'])) {
                            $insertsPS[] = "Reason_submission";
                            $paramsPS[] = "'".$_POST['Reason_submission']."'";
                        }

                        if(!empty($_POST['Sent_Customer'])) {
                            $insertsPS[] = "Sent_Customer";
                            $paramsPS[] = "'".$_POST['Sent_Customer']."'";
                        }

                        if(!empty($_POST['PSW_Returned'])) {
                            $insertsPS[] = "PSW_Returned";
                            $paramsPS[] = "'".$_POST['PSW_Returned']."'";
                        }

                        if(!empty($_POST['Origin_from_report']) && $_POST['Origin_from_report'] != 'no') {
                            $insertsPS[] = "Origin_from_report";
                            $paramsPS[] = "'".$_POST['Origin_from_report']."'";
                        }

                        if(!empty($_POST['Inspection_rep_numb'])) {
                            $insertsPS[] = "Inspection_rep_numb";
                            $paramsPS[] = "'".$_POST['Inspection_rep_numb']."'";
                        }

                        $insertsP[] = "FK_TUB_Customer_PN";
                        $paramsP[] = "'$c'";

                        $stmt = $pdo->prepare("SELECT PPAP_Number FROM tubes_ppap WHERE PPAP_Number = ?");
                        $stmt->execute([
                            $_POST['PPAP_Number']
                        ]);
                        $ppapn = $stmt->fetchAll(PDO::FETCH_COLUMN);

                        if(
                            ($_POST['PPAP_Req_by_Cus_Date'] == "" && $_POST['Sent_Customer'] == "" && $_POST['PSW_Returned'] != "")
                            || ($_POST['PPAP_Req_by_Cus_Date'] == "" && $_POST['Sent_Customer'] != "" && $_POST['PSW_Returned'] != "")
                            || ($_POST['PPAP_Req_by_Cus_Date'] == "" && $_POST['Sent_Customer'] != "" && $_POST['PSW_Returned'] == "")
                            || ($_POST['PPAP_Req_by_Cus_Date'] != "" && $_POST['Sent_Customer'] == "" && $_POST['PSW_Returned'] != "")
                            ) {
                            $NoDatesError = 'Y';
                        }
                        else {
                            if($ppapn == NULL) {
                                $stmt = $pdo->prepare("INSERT INTO tubes_ppap (". implode(', ', $insertsP) .") 
                                                    VALUES (". implode(', ', $paramsP) .")");
                                $stmt->execute([]);
                            }

                            $stmt = $pdo->prepare("INSERT INTO tubes_ppaps (". implode(', ', $insertsPS) .") 
                                                    VALUES (". implode(', ', $paramsPS) .")");
                            $stmt->execute([]);
                        }
                    }
                }
                else {
                    $NocpnError = 'Y';
                }
            }
            if($etpn == NULL && $cn != NULL) {
                $etpnError = 'Y';
            }
            if($etpn != NULL && $cn == NULL) {
                $custError = 'Y';
            }
            if($etpn == NULL && $cn == NULL) {
                $ecError = 'Y';
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['confirmIC'])) {
            $stmt = $pdo->prepare("SELECT TUB_Customer_PN FROM tubes_customer_pn WHERE TUB_Customer_PN = ?");
            $stmt->execute([
                $_POST['TUB_Customer_PN']
            ]);
            $cpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT TUB_Vendor_ID FROM tubes_vendor
                                                WHERE Short_name = ?");
            $stmt->execute([
                $_POST['Short_name']
            ]);
            $ven = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($cpn != NULL) {
                $insertsP = [];
                $paramsP = [];
                $insertsPS = [];
                $paramsPS = [];

                foreach ($cpn as $c) {
                    if(!empty($_POST['PPAP_Number'])) {
                        $insertsP[] = "PPAP_Number";
                        $paramsP[] = "'".$_POST['PPAP_Number']."'";

                        $insertsPS[] = "FK_PPAP_Number";
                        $paramsPS[] = "'".$_POST['PPAP_Number']."'";
                    }

                    if(!empty($_POST['PPAP_Req_by_Cus_Date'])) {
                        $insertsPS[] = "PPAP_Req_by_Cus_Date";
                        $paramsPS[] = "'".$_POST['PPAP_Req_by_Cus_Date']."'";
                    }

                    if(!empty($_POST['Current_Status'])) {
                        $insertsPS[] = "Current_Status";
                        $paramsPS[] = "'".$_POST['Current_Status']."'";
                    }

                    if($ven != NULL) {
                        foreach ($ven as $v) {
                            $insertsP[] = "FK_TUB_Vendor_ID";
                            $paramsP[] = "'".$v."'";
                        }
                    }

                    if(!empty($_POST['Country'])) {
                        $insertsP[] = "Country";
                        $paramsP[] = "'".$_POST['Country']."'";
                    }

                    if(!empty($_POST['Rev'])) {
                        $insertsPS[] = "Rev";
                        $paramsPS[] = "'".$_POST['Rev']."'";
                    }

                    if(!empty($_POST['IMDS_Number'])) {
                        $insertsPS[] = "IMDS_Number";
                        $paramsPS[] = "'".$_POST['IMDS_Number']."'";
                    }

                    if(!empty($_POST['IMDS_Status'])) {
                        $insertsPS[] = "IMDS_Status";
                        $paramsPS[] = "'".$_POST['IMDS_Status']."'";
                    }

                    if(!empty($_POST['PPAP_docs'])) {
                        $insertsPS[] = "PPAP_docs";
                        $paramsPS[] = "'".$_POST['PPAP_docs']."'";
                    }

                    if(!empty($_POST['Level'])) {
                        $insertsPS[] = "Level";
                        $paramsPS[] = "'".$_POST['Level']."'";
                    }

                    if(!empty($_POST['Samples_Status'])) {
                        $insertsPS[] = "Samples_Status";
                        $paramsPS[] = "'".$_POST['Samples_Status']."'";
                    }

                    if(!empty($_POST['Reason_submission'])) {
                        $insertsPS[] = "Reason_submission";
                        $paramsPS[] = "'".$_POST['Reason_submission']."'";
                    }

                    if(!empty($_POST['Sent_Customer'])) {
                        $insertsPS[] = "Sent_Customer";
                        $paramsPS[] = "'".$_POST['Sent_Customer']."'";
                    }

                    if(!empty($_POST['PSW_Returned'])) {
                        $insertsPS[] = "PSW_Returned";
                        $paramsPS[] = "'".$_POST['PSW_Returned']."'";
                    }

                    if(!empty($_POST['Origin_from_report']) && $_POST['Origin_from_report'] != 'no') {
                        $insertsPS[] = "Origin_from_report";
                        $paramsPS[] = "'".$_POST['Origin_from_report']."'";
                    }

                    if(!empty($_POST['Inspection_rep_numb'])) {
                        $insertsPS[] = "Inspection_rep_numb";
                        $paramsPS[] = "'".$_POST['Inspection_rep_numb']."'";
                    }

                    $insertsP[] = "FK_TUB_Customer_PN";
                    $paramsP[] = "'$c'";

                    $stmt = $pdo->prepare("SELECT PPAP_Number FROM tubes_ppap WHERE PPAP_Number = ?");
                    $stmt->execute([
                        $_POST['PPAP_Number']
                    ]);
                    $ppapn = $stmt->fetchAll(PDO::FETCH_COLUMN);

                    if(
                        ($_POST['PPAP_Req_by_Cus_Date'] == "" && $_POST['Sent_Customer'] == "" && $_POST['PSW_Returned'] != "")
                        || ($_POST['PPAP_Req_by_Cus_Date'] == "" && $_POST['Sent_Customer'] != "" && $_POST['PSW_Returned'] != "")
                        || ($_POST['PPAP_Req_by_Cus_Date'] == "" && $_POST['Sent_Customer'] != "" && $_POST['PSW_Returned'] == "")
                        || ($_POST['PPAP_Req_by_Cus_Date'] != "" && $_POST['Sent_Customer'] == "" && $_POST['PSW_Returned'] != "")
                    ) {
                        $NoDatesError = 'Y';
                    }
                    else {
                        if($ppapn == NULL) {
                            $stmt = $pdo->prepare("INSERT INTO tubes_ppap (". implode(', ', $insertsP) .") 
                                                    VALUES (". implode(', ', $paramsP) .")");
                            $stmt->execute([]);
                        }

                        $stmt = $pdo->prepare("INSERT INTO tubes_ppaps (". implode(', ', $insertsPS) .") 
                                                    VALUES (". implode(', ', $paramsPS) .")");
                        $stmt->execute([]);
                    }
                }
            }
            else {
                $cpnError = 'Y';
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['edit'])) {
            $id = $_POST['IDedit'];
            $stmt = $pdo->prepare("SELECT TUB_PPAPS_ID, FK_PPAP_Number, PPAP_Req_by_Cus_Date, Current_Status, Rev, IMDS_Number, 
                                        IMDS_Status, PPAP_docs, `Level`, Samples_Status, Reason_submission, Sent_Customer,
                                        PSW_Returned, Origin_from_report, Comments, Inspection_rep_numb, Country, Short_name
                                    FROM tubes_ppaps tps
                                        INNER JOIN tubes_ppap tp ON tps.FK_PPAP_Number = tp.PPAP_Number
                                        LEFT JOIN tubes_vendor tv ON tp.FK_TUB_Vendor_ID = tv.TUB_Vendor_ID
                                    WHERE TUB_PPAPS_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $tubeData = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmU'])) {
            if($_POST['PPAP_Req_by_Cus_Date'] != "") {
                $reqD = new DateTime($_POST['PPAP_Req_by_Cus_Date']);
                $rD = $reqD->format('Y-m-d');
            }
            else {
                $rD = NULL;
            }
            if($_POST['Current_Status'] != "") {
                $cs = $_POST['Current_Status'];
            }
            else {
                $cs = NULL;
            }
            if($_POST['Short_name'] != "") {
                $stmt = $pdo->prepare("SELECT TUB_Vendor_ID FROM tubes_vendor WHERE Short_name = ?");
                $stmt->execute([
                    $_POST['Short_name']
                ]);
                $ven = $stmt->fetchAll(PDO::FETCH_COLUMN);
            }
            else {
                $ven = "NULL";
            }
            if($_POST['Country'] != "") {
                $cy = $_POST['Country'];
            }
            else {
                $cy = NULL;
            }
            if($_POST['Rev'] != "") {
                $rv = $_POST['Rev'];
            }
            else {
                $rv = NULL;
            }
            if($_POST['IMDS_Number'] != "") {
                $in = $_POST['IMDS_Number'];
            }
            else {
                $in = NULL;
            }
            if($_POST['IMDS_Status'] != "") {
                $is = $_POST['IMDS_Status'];
            }
            else {
                $is = NULL;
            }
            if($_POST['PPAP_docs'] != "") {
                $pd = $_POST['PPAP_docs'];
            }
            else {
                $pd = NULL;
            }
            if($_POST['Level'] != "") {
                $lv = $_POST['Level'];
            }
            else {
                $lv = NULL;
            }
            if($_POST['Samples_Status'] != "") {
                $ss = $_POST['Samples_Status'];
            }
            else {
                $ss = NULL;
            }
            if($_POST['Reason_submission'] != "") {
                $rs = $_POST['Reason_submission'];
            }
            else {
                $rs = NULL;
            }
            if($_POST['Sent_Customer'] != "") {
                $senD = new DateTime($_POST['Sent_Customer']);
                $sD = $senD->format('Y-m-d');
            }
            else {
                $sD = NULL;
            }
            if($_POST['PSW_Returned'] != "") {
                $sigD = new DateTime($_POST['PSW_Returned']);
                $siD = $sigD->format('Y-m-d');
            }
            else {
                $siD = NULL;
            }
            if($_POST['Origin_from_report'] != "no") {
                $ofr = $_POST['Origin_from_report'];
            }
            else {
                $ofr = NULL;
            }
            if($_POST['Comments'] != "") {
                $co = $_POST['Comments'];
            }
            else {
                $co = NULL;
            }
            if($_POST['Inspection_rep_numb'] != "") {
                $irn = $_POST['Inspection_rep_numb'];
            }
            else {
                $irn = NULL;
            }

            if(
                ($_POST['PPAP_Req_by_Cus_Date'] == "" && $_POST['Sent_Customer'] == "" && $_POST['PSW_Returned'] != "")
                || ($_POST['PPAP_Req_by_Cus_Date'] == "" && $_POST['Sent_Customer'] != "" && $_POST['PSW_Returned'] != "")
                || ($_POST['PPAP_Req_by_Cus_Date'] == "" && $_POST['Sent_Customer'] != "" && $_POST['PSW_Returned'] == "")
                || ($_POST['PPAP_Req_by_Cus_Date'] != "" && $_POST['Sent_Customer'] == "" && $_POST['PSW_Returned'] != "")
                ) {
                $NoDatesError = 'Y';
            }
            else {
                if($ven == NULL){
                    $VendError = "Y";
                }
                if($ven != NULL && $ven != "NULL"){
                    foreach ($ven as $v) {
                        $stmt = $pdo->prepare("UPDATE tubes_ppap SET 
                                                FK_TUB_Vendor_ID = ?
                                            WHERE PPAP_Number = ?");

                        $stmt->execute([
                            $v,
                            $_POST['FK_PPAP_Number']
                        ]);
                    }
                }
                
                if($ven == "NULL"){
                    $stmt = $pdo->prepare("UPDATE tubes_ppap SET 
                                                FK_TUB_Vendor_ID = NULL
                                            WHERE PPAP_Number = ?");

                    $stmt->execute([
                        $_POST['FK_PPAP_Number']
                    ]);
                }
                if($ven != NULL) {
                    $stmt = $pdo->prepare("UPDATE tubes_ppaps SET 
                                                PPAP_Req_by_Cus_Date = ?, 
                                                Current_Status = ?,
                                                Country = ?, 
                                                Rev = ?, 
                                                IMDS_Number = ?, 
                                                IMDS_Status = ?, 
                                                PPAP_docs = ?, 
                                                `Level` = ?, 
                                                Samples_Status = ?, 
                                                Reason_submission = ?, 
                                                Sent_Customer = ?, 
                                                PSW_Returned = ?,
                                                Origin_from_report = ?,
                                                Comments = ?,
                                                Inspection_rep_numb = ?
                                            WHERE TUB_PPAPS_ID = ?");

                    $stmt->execute([
                        $rD,
                        $cs,
                        $cy,
                        $rv,
                        $in,
                        $is,
                        $pd,
                        $lv,
                        $ss,
                        $rs,
                        $sD,
                        $siD,
                        $ofr,
                        $co,
                        $irn,
                        $_POST['TUB_PPAPS_ID']
                    ]);
                }
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['delete'])) {
            $id = $_POST['IDdelete'];
            $stmt = $pdo->prepare("SELECT 
                            if(Sent_Customer IS NULL, datediff(NOW(), PPAP_Req_by_Cus_Date), datediff(Sent_Customer, PPAP_Req_by_Cus_Date)) AS 'Days to Submit',
                            tps.TUB_PPAPS_ID,
                            tp.PPAP_Number,
                            tps.PPAP_Req_by_Cus_Date,
                            tps.Current_Status,
                            tv.Short_name,
                            tc.`Name`,
                            tps.Country,
                            tcp.TUB_Customer_PN,
                            t.ET_Model,
                            t.ET_Dwg,
                            tps.Rev,
                            t.TUB_Eurotech_PN,
                            t.`Description`,
                            tps.IMDS_Number,
                            tps.IMDS_Status,
                            tps.PPAP_docs,
                            tps.`Level`,
                            tps.Samples_Status,
                            tps.Reason_submission,
                            tps.Sent_Customer,
                            tps.PSW_Returned,
                            tps.Origin_from_report,
                            tps.Comments,
                            tps.Inspection_rep_numb
                        FROM tubes_ppaps tps
                            INNER JOIN tubes_ppap tp ON tps.FK_PPAP_Number = tp.PPAP_Number
                            INNER JOIN tubes_customer_pn tcp ON tp.FK_TUB_Customer_PN = tcp.TUB_Customer_PN
                            INNER JOIN tubes_customer tc ON tcp.FK_TUB_Customer_ID = tc.TUB_Customer_ID
                            INNER JOIN tubes t ON tcp.FK_TUB_Eurotech_PN = t.TUB_Eurotech_PN
                            LEFT JOIN tubes_vendor tv ON tp.FK_TUB_Vendor_ID = tv.TUB_Vendor_ID
                        WHERE TUB_PPAPS_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $tubeDataD = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmD'])) {
            $id = $_POST['IDdelete'];
            $stmt = $pdo->prepare("DELETE FROM tubes_ppaps
                                    WHERE TUB_PPAPS_ID = ?");

            $stmt->execute([
                $id
            ]);
           
            $Deleted = 'Y';

            $_SESSION['saved'] = true;
        }
    }


    $logs = $model->search();
    $PPAPNS = $model->searchPPAPN();
    $Currents = $model->searchCS();
    $PIS = $model->searchPIS();
    $Customers = $model->searchCust();
    $Countries = $model->searchCountry();
    $CPNS = $model->searchCPN();
    $ETMS = $model->searchETM();
    $ETDS = $model->searchETD();
    $ETPNS = $model->searchETPN();
    $Descs = $model->searchDesc();
    $IMDS = $model->searchIMDS();
    $ISS = $model->searchIS();
    $PDS = $model->searchPD();
    $Levels = $model->searchLevel();
    $PSSS = $model->searchPS();
    $RSS = $model->searchRS();
    $Coms = $model->searchCom();
    $IRNS = $model->searchIRN();

    include 'view.php';
?>