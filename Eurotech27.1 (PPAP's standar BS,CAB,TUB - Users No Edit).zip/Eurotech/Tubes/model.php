<?php
    class model {                                        

        public  $mbd;
        
        function cn() {
            $this->mbd = new PDO('mysql:host=localhost;dbname=eurotechdb;port=3306', 'root', '');
            $this->mbd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
        }
    
        function search(){
            $logs = [];
            if (isset($_POST['btnsearch'])) {
                if (!empty($_POST['submit1search']) || !empty($_POST['submit2search']) || !empty($_POST['ppapnsearch']) ||
                    !empty($_POST['req1search']) || !empty($_POST['req2search']) || !empty($_POST['pisearch']) || !empty($_POST['custsearch']) || 
                    !empty($_POST['countrysearch']) || !empty($_POST['cpnsearch'])  || !empty($_POST['etmsearch']) || !empty($_POST['etdsearch']) ||
                    !empty($_POST['revsearch']) || !empty($_POST['etpnsearch'])  || !empty($_POST['descsearch']) || !empty($_POST['imdssearch']) ||
                    !empty($_POST['issearch']) || !empty($_POST['pdsearch']) || !empty($_POST['levelsearch']) || !empty($_POST['psssearch']) ||
                    !empty($_POST['rssearch']) || !empty($_POST['sent1search']) || !empty($_POST['sent2search']) || !empty($_POST['psw1search']) || 
                    !empty($_POST['psw2search']) || !empty($_POST['originsearch']) 
                    || !empty($_POST['comsearch']) || !empty($_POST['irnsearch'])
                    || isset($_POST['reqn']) || isset($_POST['curn']) || isset($_POST['imdn']) || isset($_POST['imsn'])  
                    || isset($_POST['ppdn']) || isset($_POST['lvln']) || isset($_POST['pssn']) || isset($_POST['rosn']) 
                    || isset($_POST['stcn']) || isset($_POST['pcsn']) 
                    ){
                    $having = [];
                    $params = [];

                    if($_POST['reqn'] == "" && (empty($_POST['req1search']) || empty($_POST['req2search']))) {
                        $having[] = "1 = 1";
                    }
                    if($_POST['reqn'] == "" && !empty($_POST['req1search']) && !empty($_POST['req2search'])) {
                        $having[] = "PPAP_Req_by_Cus_Date BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['req1search'];
                        $params[':date2'] = $_POST['req2search'];
                    }
                    if($_POST['reqn'] == "Y") {
                        $having[] = "PPAP_Req_by_Cus_Date IS NOT NULL";
                    }
                    if($_POST['reqn'] == "N") {
                        $having[] = "PPAP_Req_by_Cus_Date IS NULL";
                    }

                    if($_POST['curn'] == "" && empty($_POST['currentsearch'])) {
                        $having[] = "1 = 1";
                    }
                    if($_POST['curn'] == "" && !empty($_POST['currentsearch'])) {
                        $having[] = "Current_Status = :cur";
                        $params[':cur'] = $_POST['currentsearch'];
                    }
                    if($_POST['curn'] == "Y") {
                        $having[] = "Current_Status IS NOT NULL";
                    }
                    if($_POST['curn'] == "N") {
                        $having[] = "Current_Status IS NULL";
                    }
                    
                    if($_POST['imdn'] == "" && empty($_POST['imdssearch'])) {
                        $having[] = "1 = 1";
                    }
                    if($_POST['imdn'] == "" && !empty($_POST['imdssearch'])) {
                        $having[] = "IMDS_Number = :imd";
                        $params[':imd'] = $_POST['imdssearch'];
                    }
                    if($_POST['imdn'] == "Y") {
                        $having[] = "IMDS_Number IS NOT NULL";
                    }
                    if($_POST['imdn'] == "N") {
                        $having[] = "IMDS_Number IS NULL";
                    }

                    if($_POST['imsn'] == "" && empty($_POST['issearch'])) {
                        $having[] = "1 = 1";
                    }
                    if($_POST['imsn'] == "" && !empty($_POST['issearch'])) {
                        $having[] = "IMDS_Status = :ims";
                        $params[':ims'] = $_POST['issearch'];
                    }
                    if($_POST['imsn'] == "Y") {
                        $having[] = "IMDS_Status IS NOT NULL";
                    }
                    if($_POST['imsn'] == "N") {
                        $having[] = "IMDS_Status IS NULL";
                    }

                    if($_POST['ppdn'] == "" && empty($_POST['pdsearch'])) {
                        $having[] = "1 = 1";
                    }
                    if($_POST['ppdn'] == "" && !empty($_POST['pdsearch'])) {
                        $having[] = "PPAP_docs = :ppd";
                        $params[':ppd'] = $_POST['pdsearch'];
                    }
                    if($_POST['ppdn'] == "Y") {
                        $having[] = "PPAP_docs IS NOT NULL";
                    }
                    if($_POST['ppdn'] == "N") {
                        $having[] = "PPAP_docs IS NULL";
                    }

                    if($_POST['lvln'] == "" && empty($_POST['levelsearch'])) {
                        $having[] = "1 = 1";
                    }
                    if($_POST['lvln'] == "" && !empty($_POST['levelsearch'])) {
                        $having[] = "`Level` = :lvl";
                        $params[':lvl'] = $_POST['levelsearch'];
                    }
                    if($_POST['lvln'] == "Y") {
                        $having[] = "`Level` IS NOT NULL";
                    }
                    if($_POST['lvln'] == "N") {
                        $having[] = "`Level` IS NULL";
                    }

                    if($_POST['pssn'] == "" && empty($_POST['psssearch'])) {
                        $having[] = "1 = 1";
                    }
                    if($_POST['pssn'] == "" && !empty($_POST['psssearch'])) {
                        $having[] = "Samples_Status = :pss";
                        $params[':pss'] = $_POST['rssearch'];
                    }
                    if($_POST['pssn'] == "Y") {
                        $having[] = "Samples_Status IS NOT NULL";
                    }
                    if($_POST['pssn'] == "N") {
                        $having[] = "Samples_Status IS NULL";
                    }

                    if($_POST['rosn'] == "" && empty($_POST['rssearch'])) {
                        $having[] = "1 = 1";
                    }
                    if($_POST['rosn'] == "" && !empty($_POST['rssearch'])) {
                        $having[] = "Reason_submission = :ros";
                        $params[':ros'] = $_POST['rssearch'];
                    }
                    if($_POST['rosn'] == "Y") {
                        $having[] = "Reason_submission IS NOT NULL";
                    }
                    if($_POST['rosn'] == "N") {
                        $having[] = "Reason_submission IS NULL";
                    }

                    if($_POST['stcn'] == "" && (empty($_POST['sent1search']) || empty($_POST['sent2search']))) {
                        $having[] = "1 = 1";
                    }
                    if($_POST['stcn'] == "" && !empty($_POST['sent1search']) && !empty($_POST['sent2search'])) {
                        $having[] = "Sent_Customer BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['sent1search'];
                        $params[':date2'] = $_POST['sent2search'];
                    }
                    if($_POST['stcn'] == "Y") {
                        $having[] = "Sent_Customer IS NOT NULL";
                    }
                    if($_POST['stcn'] == "N") {
                        $having[] = "Sent_Customer IS NULL";
                    }

                    if($_POST['pcsn'] == "" && (empty($_POST['psw1search']) || empty($_POST['psw2search']))) {
                        $having[] = "1 = 1";
                    }
                    if($_POST['pcsn'] == "" && !empty($_POST['psw1search']) && !empty($_POST['psw2search'])) {
                        $having[] = "PSW_Returned BETWEEN :date1 AND :date2";
                        $params[':date1'] = $_POST['psw1search'];
                        $params[':date2'] = $_POST['psw2search'];
                    }
                    if($_POST['pcsn'] == "Y") {
                        $having[] = "PSW_Returned IS NOT NULL";
                    }
                    if($_POST['pcsn'] == "N") {
                        $having[] = "PSW_Returned IS NULL";
                    }

                    if(empty($_POST['submit1search']) || empty($_POST['submit2search'])) {
                        $having[] = "1 = 1";
                    }
                    if(!empty($_POST['submit1search']) && !empty($_POST['submit2search'])) {
                        $having[] = "`Days to Submit` BETWEEN :sub1 AND :sub2";
                        $params[':sub1'] = $_POST['submit1search'];
                        $params[':sub2'] = $_POST['submit2search'];
                    }

                    if (!empty($_POST['ppapnsearch'])) {
                        $having[] = "PPAP_Number LIKE :ppapn";
                        $params[':ppapn'] = $_POST['ppapnsearch']."%";
                    }

                    if(!empty($_POST['req1search']) && !empty($_POST['req2search'])) {
                        $having[] = "PPAP_Req_by_Cus_Date BETWEEN :req1 AND :req2";
                        $params[':req1'] = $_POST['req1search'];
                        $params[':req2'] = $_POST['req2search'];
                    }

                    if (!empty($_POST['currentsearch'])) {
                        $having[] = "Current_Status = :current";
                        $params[':current'] = $_POST['currentsearch'];
                    }

                    if (!empty($_POST['pisearch'])) {
                        $having[] = "Short_name = :pi";
                        $params[':pi'] = $_POST['pisearch'];
                    }

                    if (!empty($_POST['custsearch'])) {
                        $having[] = "`Name` LIKE :cust";
                        $params[':cust'] = $_POST['custsearch']."%";
                    }

                    if (!empty($_POST['countrysearch'])) {
                        $having[] = "Country = :country";
                        $params[':country'] = $_POST['countrysearch'];
                    }

                    if (!empty($_POST['cpnsearch'])) {
                        $having[] = "TUB_Customer_PN = :cpn";
                        $params[':cpn'] = $_POST['cpnsearch'];
                    }

                    if (!empty($_POST['etmsearch'])) {
                        $having[] = "ET_Model = :etm";
                        $params[':etm'] = $_POST['etmsearch'];
                    }

                    if (!empty($_POST['etdsearch'])) {
                        $having[] = "ET_Dwg = :etd";
                        $params[':etd'] = $_POST['etdsearch'];
                    }

                    if (!empty($_POST['revsearch'])) {
                        $having[] = "Rev = :rev";
                        $params[':rev'] = $_POST['revsearch'];
                    }

                    if (!empty($_POST['etpnsearch'])) {
                        $having[] = "TUB_Eurotech_PN = :etpn";
                        $params[':etpn'] = $_POST['etpnsearch'];
                    }

                    if (!empty($_POST['descsearch'])) {
                        $having[] = "`Description` = :desc";
                        $params[':desc'] = $_POST['descsearch'];
                    }

                    if (!empty($_POST['imdssearch'])) {
                        $having[] = "IMDS_Number = :imds";
                        $params[':imds'] = $_POST['imdssearch'];
                    }

                    if (!empty($_POST['issearch'])) {
                        $having[] = "IMDS_Status = :is";
                        $params[':is'] = $_POST['issearch'];
                    }

                    if (!empty($_POST['pdsearch'])) {
                        $having[] = "PPAP_docs = :pd";
                        $params[':pd'] = $_POST['pdsearch'];
                    }

                    if (!empty($_POST['levelsearch'])) {
                        $having[] = "`Level` = :lvl";
                        $params[':lvl'] = $_POST['levelsearch'];
                    }

                    if (!empty($_POST['psssearch'])) {
                        $having[] = "Samples_Status = :ps";
                        $params[':ps'] = $_POST['psssearch'];
                    }

                    if (!empty($_POST['rssearch'])) {
                        $having[] = "Reason_submission = :rs";
                        $params[':rs'] = $_POST['rssearch'];
                    }

                    if(empty($_POST['sent1search']) || empty($_POST['sent2search'])) {
                        $having[] = "1 = 1";
                    }
                    if(!empty($_POST['sent1search']) && !empty($_POST['sent2search'])) {
                        $having[] = "Sent_Customer BETWEEN :sent1 AND :sent2";
                        $params[':sent1'] = $_POST['sent1search'];
                        $params[':sent2'] = $_POST['sent2search'];
                    }

                    if(empty($_POST['psw1search']) || empty($_POST['psw2search'])) {
                        $having[] = "1 = 1";
                    }
                    if(!empty($_POST['psw1search']) && !empty($_POST['psw2search'])) {
                        $having[] = "PSW_Returned BETWEEN :psw1 AND :psw2";
                        $params[':psw1'] = $_POST['psw1search'];
                        $params[':psw2'] = $_POST['psw2search'];
                    }

                    if(!empty($_POST['originsearch']) && $_POST['originsearch'] == "") {
                        $having[] = "1 = 1";
                    }
                    if(!empty($_POST['originsearch']) && $_POST['originsearch'] == "Y") {
                        $having[] = "Origin_from_report IS NOT NULL";
                    }
                    if(!empty($_POST['originsearch']) && $_POST['originsearch'] == "N") {
                        $having[] = "Origin_from_report IS NULL";
                    }

                    if (!empty($_POST['comsearch'])) {
                        $having[] = "Comments = :com";
                        $params[':com'] = $_POST['comsearch'];
                    }

                    if (!empty($_POST['irnsearch'])) {
                        $having[] = "Inspection_rep_numb = :irn";
                        $params[':irn'] = $_POST['irnsearch'];
                    }

                    $sql = "
                        SELECT 
                            if(Sent_Customer IS NULL, datediff(NOW(), PPAP_Req_by_Cus_Date), datediff(Sent_Customer, PPAP_Req_by_Cus_Date)) AS 'Days to Submit',
                            tps.TUB_PPAPS_ID,
                            tp.PPAP_Number,
                            tps.PPAP_Req_by_Cus_Date,
                            tps.Current_Status,
                            v.Short_name,
                            c.`Name`,
                            tps.Country,
                            tcp.TUB_Customer_PN,
                            t.ET_Model,
                            t.ET_Dwg,
                            tps.Rev,
                            t.TUB_Eurotech_PN,
                            t.`Description`,
                            tps.IMDS_Number,
                            tps.IMDS_Status,
                            tps.PPAP_docs,
                            tps.`Level`,
                            tps.Samples_Status,
                            tps.Reason_submission,
                            tps.Sent_Customer,
                            tps.PSW_Returned,
                            tps.Origin_from_report,
                            tps.Comments,
                            tps.Inspection_rep_numb
                        FROM tubes_ppaps tps
                            INNER JOIN tubes_ppap tp ON tps.FK_PPAP_Number = tp.PPAP_Number
                            INNER JOIN tubes_customer_pn tcp ON tp.FK_TUB_Customer_PN = tcp.TUB_Customer_PN
                            INNER JOIN customers c ON tcp.FK_Customer_ID = c.Customer_ID
                            INNER JOIN tubes t ON tcp.FK_TUB_Eurotech_PN = t.TUB_Eurotech_PN
                            LEFT JOIN vendors v ON tps.FK_Vendor_ID = v.Vendor_ID
                        HAVING " . implode(' AND ', $having) . "
                        ORDER BY PPAP_Number;";

                    $stmt = $this->mbd->prepare($sql);
                    $stmt->execute($params);
                    
                    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
                else {
                    foreach ($this->mbd->query(
                        "SELECT 
                            if(Sent_Customer IS NULL, datediff(NOW(), PPAP_Req_by_Cus_Date), datediff(Sent_Customer, PPAP_Req_by_Cus_Date)) AS 'Days to Submit',
                            tps.TUB_PPAPS_ID,
                            tp.PPAP_Number,
                            tps.PPAP_Req_by_Cus_Date,
                            tps.Current_Status,
                            v.Short_name,
                            c.`Name`,
                            tps.Country,
                            tcp.TUB_Customer_PN,
                            t.ET_Model,
                            t.ET_Dwg,
                            tps.Rev,
                            t.TUB_Eurotech_PN,
                            t.`Description`,
                            tps.IMDS_Number,
                            tps.IMDS_Status,
                            tps.PPAP_docs,
                            tps.`Level`,
                            tps.Samples_Status,
                            tps.Reason_submission,
                            tps.Sent_Customer,
                            tps.PSW_Returned,
                            tps.Origin_from_report,
                            tps.Comments,
                            tps.Inspection_rep_numb
                        FROM tubes_ppaps tps
                            INNER JOIN tubes_ppap tp ON tps.FK_PPAP_Number = tp.PPAP_Number
                            INNER JOIN tubes_customer_pn tcp ON tp.FK_TUB_Customer_PN = tcp.TUB_Customer_PN
                            INNER JOIN customers c ON tcp.FK_Customer_ID = c.Customer_ID
                            INNER JOIN tubes t ON tcp.FK_TUB_Eurotech_PN = t.TUB_Eurotech_PN
                            LEFT JOIN vendors v ON tps.FK_Vendor_ID = v.Vendor_ID
                        ORDER BY PPAP_Number;"
                    ) as $log) {
                        $logs[] = $log;
                    }
                }
            } else {
                foreach ($this->mbd->query(
                    "SELECT 
                            if(Sent_Customer IS NULL, datediff(NOW(), PPAP_Req_by_Cus_Date), datediff(Sent_Customer, PPAP_Req_by_Cus_Date)) AS 'Days to Submit',
                            tps.TUB_PPAPS_ID,
                            tp.PPAP_Number,
                            tps.PPAP_Req_by_Cus_Date,
                            tps.Current_Status,
                            v.Short_name,
                            c.`Name`,
                            tps.Country,
                            tcp.TUB_Customer_PN,
                            t.ET_Model,
                            t.ET_Dwg,
                            tps.Rev,
                            t.TUB_Eurotech_PN,
                            t.`Description`,
                            tps.IMDS_Number,
                            tps.IMDS_Status,
                            tps.PPAP_docs,
                            tps.`Level`,
                            tps.Samples_Status,
                            tps.Reason_submission,
                            tps.Sent_Customer,
                            tps.PSW_Returned,
                            tps.Origin_from_report,
                            tps.Comments,
                            tps.Inspection_rep_numb
                        FROM tubes_ppaps tps
                            INNER JOIN tubes_ppap tp ON tps.FK_PPAP_Number = tp.PPAP_Number
                            INNER JOIN tubes_customer_pn tcp ON tp.FK_TUB_Customer_PN = tcp.TUB_Customer_PN
                            INNER JOIN customers c ON tcp.FK_Customer_ID = c.Customer_ID
                            INNER JOIN tubes t ON tcp.FK_TUB_Eurotech_PN = t.TUB_Eurotech_PN
                            LEFT JOIN vendors v ON tps.FK_Vendor_ID = v.Vendor_ID
                        ORDER BY PPAP_Number;"
                ) as $log) {
                    $logs[] = $log;
                }
            }
            return $logs;
        }

        function searchPPAPN(){
            $PPAPNS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        PPAP_Number
                    FROM tubes_ppap
                    ORDER BY PPAP_Number;"
                ) as $PPAPN) {
                    $PPAPNS[] = $PPAPN;
                }
            return $PPAPNS;
        }

        function searchCS(){
            $Currents = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Current_Status
                    FROM tubes_ppaps
                    ORDER BY Current_Status;"
                ) as $Current) {
                    $Currents[] = $Current;
                }
            return $Currents;
        }

        function searchPIS(){
            $PIS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Short_name
                    FROM vendors
                    ORDER BY Short_name;"
                ) as $PI) {
                    $PIS[] = $PI;
                }
            return $PIS;
        }

        function searchCust(){
            $Customers = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        `Name`
                    FROM customers
                    WHERE Products LIKE '%Tubes%'
                    ORDER BY `Name`;"
                ) as $Customer) {
                    $Customers[] = $Customer;
                }
            return $Customers;
        }

        function searchCountry(){
            $Countries = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Country
                    FROM `tubes_ppaps`
                    ORDER BY Country;"
                ) as $Country) {
                    $Countries[] = $Country;
                }
            return $Countries;
        }

        function searchCPN(){
            $CPNS = [];
                foreach ($this->mbd->query(
                    "SELECT
                        TUB_Customer_PN
                    FROM tubes_customer_pn
                    ORDER BY TUB_Customer_PN;"
                ) as $CPN) {
                    $CPNS[] = $CPN;
                }
            return $CPNS;
        }

        function searchETM(){
            $ETMS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        ET_Model
                    FROM tubes
                    ORDER BY ET_Model;"
                ) as $ETM) {
                    $ETMS[] = $ETM;
                }
            return $ETMS;
        }

        function searchETD(){
            $ETDS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        ET_Dwg
                    FROM tubes
                    ORDER BY ET_Dwg;"
                ) as $ETD) {
                    $ETDS[] = $ETD;
                }
            return $ETDS;
        }

        function searchETPN(){
            $EPNS = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        TUB_Eurotech_PN
                    FROM tubes
                    ORDER BY TUB_Eurotech_PN;"
                ) as $EPN) {
                    $EPNS[] = $EPN;
                }
            return $EPNS;
        }

        function searchDesc(){
            $Descs = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        `Description`
                    FROM tubes
                    ORDER BY `Description`;"
                ) as $Desc) {
                    $Descs[] = $Desc;
                }
            return $Descs;
        }

        function searchRev(){
            $Revs = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Rev
                    FROM tubes_ppaps
                    ORDER BY Rev;"
                ) as $Rev) {
                    $Revs[] = $Rev;
                }
            return $Revs;
        }

        function searchIMDS(){
            $IMDS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        IMDS_Number
                    FROM tubes_ppaps
                    ORDER BY IMDS_Number;"
                ) as $IM) {
                    $IMDS[] = $IM;
                }
            return $IMDS;
        }

        function searchIS(){
            $ISS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        IMDS_Status
                    FROM tubes_ppaps
                    ORDER BY IMDS_Status;"
                ) as $IS) {
                    $ISS[] = $IS;
                }
            return $ISS;
        }

        function searchPD(){
            $PDS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        PPAP_docs
                    FROM tubes_ppaps
                    ORDER BY PPAP_docs;"
                ) as $PD) {
                    $PDS[] = $PD;
                }
            return $PDS;
        }

        function searchLevel(){
            $Levels = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        `Level`
                    FROM tubes_ppaps
                    ORDER BY `Level`;"
                ) as $Level) {
                    $Levels[] = $Level;
                }
            return $Levels;
        }

        function searchPS(){
            $PSSS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Samples_Status
                    FROM tubes_ppaps
                    ORDER BY Samples_Status;"
                ) as $PSS) {
                    $PSSS[] = $PSS;
                }
            return $PSSS;
        }

        function searchRS(){
            $RSS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Reason_submission
                    FROM tubes_ppaps
                    ORDER BY Reason_submission;"
                ) as $RS) {
                    $RSS[] = $RS;
                }
            return $RSS;
        }

        function searchCom(){
            $Coms = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Comments
                    FROM tubes_ppaps
                    ORDER BY Comments;"
                ) as $Com) {
                    $Coms[] = $Com;
                }
            return $Coms;
        }

        function searchIRN(){
            $IRNS = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Inspection_rep_numb
                    FROM tubes_ppaps
                    ORDER BY Inspection_rep_numb;"
                ) as $IRN) {
                    $IRNS[] = $IRN;
                }
            return $IRNS;
        }

        function searchCustomer(){
            $Custs = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        `Description`
                    FROM tubes_customer_ppap_number
                    ORDER BY `Description`;"
                ) as $Cust) {
                    $Custs[] = $Cust;
                }
            return $Custs;
        }
    }
?>