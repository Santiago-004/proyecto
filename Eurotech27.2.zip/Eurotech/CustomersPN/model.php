<?php
    class model {                                        

        public  $mbd;
        
        function cn() {
            $this->mbd = new PDO('mysql:host=localhost;dbname=eurotechdb;port=3306', 'root', '');
            $this->mbd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
        }
    
        function search(){
            $logs = [];
            if (isset($_POST['btnsearch'])) {
                if (!empty($_POST['idsearch']) || !empty($_POST['custsearch']) || !empty($_POST['etpnsearch']) 
                ) {
                    $where = [];
                    $params = [];

                    if (!empty($_POST['idsearch'])) {
                        $where[] = "Customer_PN LIKE :id";
                        $params[':id'] = $_POST['idsearch']."%";
                    }

                    if (!empty($_POST['custsearch'])) {
                        $where[] = "Name = :cust";
                        $params[':cust'] = $_POST['custsearch'];
                    }

                    if (!empty($_POST['etpnsearch'])) {
                        $where[] = "Eurotech_PN LIKE :etpn";
                        $params[':etpn'] = $_POST['etpnsearch']."%";
                    }

                    if(!empty($where)) {
                        $sql = "
                        SELECT 
                            *
                        FROM customer_pn cpn
                        INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                        INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                        WHERE " . implode(' AND ', $where) . "
                        ORDER BY Customer_PN;";
                    }
                    else {
                        $sql = "
                        SELECT 
                            *
                        FROM customer_pn cpn
                        INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                        INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                        ORDER BY Customer_PN;";
                    }

                    $stmt = $this->mbd->prepare($sql);
                    $stmt->execute($params);

                    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
                else {
                    foreach ($this->mbd->query(
                        "SELECT 
                            *
                        FROM customer_pn cpn
                        INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                        INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                        ORDER BY Customer_PN;"
                    ) as $log) {
                        $logs[] = $log;
                    }
                }
            } else {
                foreach ($this->mbd->query(
                    "SELECT 
                            *
                        FROM customer_pn cpn
                        INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                        INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                        ORDER BY Customer_PN;"
                ) as $log) {
                    $logs[] = $log;
                }
            }
            return $logs;
        }

        function searchCPN(){
            $CPNs = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        Customer_PN
                    FROM customer_pn
                    ORDER BY Customer_PN;"
                ) as $CPN) {
                    $CPNs[] = $CPN;
                }
            return $CPNs;
        }

        function searchCustomers(){
            $Customers = [];
                foreach ($this->mbd->query(
                    "SELECT
                        `Name`
                    FROM customers
                    ORDER BY `Name`;"
                ) as $Customer) {
                    $Customers[] = $Customer;
                }
            return $Customers;
        }

        function searchETPNs(){
            $ETPNs = [];
                foreach ($this->mbd->query(
                    "SELECT
                        Eurotech_PN
                    FROM products
                    ORDER BY Eurotech_PN;"
                ) as $ETPN) {
                    $ETPNs[] = $ETPN;
                }
            return $ETPNs;
        }
    }
?>