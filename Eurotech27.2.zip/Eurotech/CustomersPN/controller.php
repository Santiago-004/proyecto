<?php 
    include "model.php";

    $model = new model();
    $model->cn();
    $logs = [];
    
    if (isset($_POST["idsearch"])){
        $idsearch = $_POST["idsearch"];
    }    
    else {
        $idsearch = NULL;
    }

    if (isset($_POST["custsearch"])){
        $custsearch = $_POST["custsearch"];
    }    
    else {
        $custsearch = NULL;
    }

    if (isset($_POST["etpnsearch"])){
        $etpnsearch = $_POST["etpnsearch"];
    }    
    else {
        $etpnsearch = NULL;
    }

    $cpnData = NULL;
    $cpnDataD = NULL;
    $Deleted = NULL;

    $pdo = new PDO("mysql:host=localhost;dbname=eurotechdb", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        if (isset($_POST['confirmI'])) {
            $stmt = $pdo->prepare("SELECT Customer_PN FROM customer_pn WHERE Customer_PN = ?");
            $stmt->execute([
                $_POST['Customer_PN']
            ]);
            $cpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT Customer_ID FROM customers WHERE `Name` = ?");
            $stmt->execute([
                $_POST['Name']
            ]);
            $customer = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT Eurotech_PN FROM products WHERE Eurotech_PN = ?");
            $stmt->execute([
                $_POST['Eurotech_PN']
            ]);
            $etpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT `Name`, Eurotech_PN FROM customer_pn cpn
                                    INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                    INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                                    WHERE `Name` = ? AND Eurotech_PN = ?");
            $stmt->execute([
                $_POST['Name'],
                $_POST['Eurotech_PN']
            ]);
            $ce = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($cpn == NULL && $customer != NULL && $etpn != NULL && $ce == NULL) {
                    $stmt = $pdo->prepare("INSERT INTO customer_pn (Customer_PN, FK_Customer_ID, FK_Eurotech_PN) 
                                            VALUES (?, ?, ?)");
                    $stmt->execute([
                        $_POST['Customer_PN'],
                        $customer[0],
                        $etpn[0]
                    ]);
            }
            if($cpn == NULL && $ce == NULL && $customer == NULL && $etpn == NULL) {
                $_POST['insert'] = 1;
                $error = "Customer <b>".$_POST['Name']."</b> and the Eurotech PN <b>".$_POST['Eurotech_PN']."</b> don't exist.";
            }
            if($cpn != NULL && $ce == NULL && $customer == NULL && $etpn == NULL) {
                $_POST['insert'] = 1;
                $error = "The Customer PN <b>".$_POST['Customer_PN']."</b> already exists, and the Eurotech PN <b>".$_POST['Eurotech_PN']."</b> and the customer <b>".$_POST['Name']."</b> don't exist.";
            }
            if($cpn == NULL && $ce == NULL && $customer != NULL && $etpn == NULL) {
                $_POST['insert'] = 1;
                $error = "The Eurotech PN <b>".$_POST['Eurotech_PN']."</b> doesn't exist.";
            }
            if($cpn == NULL && $ce == NULL && $customer == NULL && $etpn != NULL) {
                $_POST['insert'] = 1;
                $error = "Customer <b>".$_POST['Name']."</b> doesn't exist.";
            }
            if($cpn != NULL && $ce == NULL && $customer != NULL && $etpn == NULL) {
                $_POST['insert'] = 1;
                $error = "The Customer PN <b>".$_POST['Customer_PN']."</b> already exists, and the Eurotech PN <b>".$_POST['Eurotech_PN']."</b> doesn't exist.";
            }
            if($cpn != NULL && $ce == NULL && $customer == NULL && $etpn != NULL) {
                $_POST['insert'] = 1;
                $error = "The Customer PN <b>".$_POST['Customer_PN']."</b> already exists, and the customer <b>".$_POST['Name']."</b> doesn't exist.";
            }
            if($cpn != NULL && $ce == NULL && $customer != NULL && $etpn != NULL) {
                $_POST['insert'] = 1;
                $error = "The Customer PN <b>".$_POST['Customer_PN']."</b> already exist.";
            }
            if($cpn == NULL && $ce != NULL && $customer != NULL && $etpn != NULL) {
                $_POST['insert'] = 1;
                $error = "A Customer PN already exists for the Eurotech PN <b>".$_POST['Eurotech_PN']."</b> and the customer <b>".$_POST['Name']."</b>.";
            }

            $_SESSION['saved'] = true;
        }

        if (isset($_POST['edit'])) {
            $id = $_POST['IDedit'];
            $stmt = $pdo->prepare("SELECT * FROM customer_pn cpn
                INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                WHERE Customer_PN = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $cpnData = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmU'])) {
            $stmt = $pdo->prepare("SELECT Customer_ID FROM customers WHERE `Name` = ?");
            $stmt->execute([
                $_POST['Name']
            ]);
            $customer = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT Eurotech_PN FROM products WHERE Eurotech_PN = ?");
            $stmt->execute([
                $_POST['Eurotech_PN']
            ]);
            $etpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT `Name`, Eurotech_PN FROM customer_pn cpn
                                    INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                    INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                                    WHERE `Name` = ? AND Eurotech_PN = ? AND Customer_PN != ?");
            $stmt->execute([
                $_POST['Name'],
                $_POST['Eurotech_PN'],
                $_POST['Customer_PN']
            ]);
            $ce = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($customer == NULL && $etpn == NULL && $ce == NULL) {
                $_POST['edit'] = 1;
                $error = "The customer <b>".$_POST['Name']."</b> and the Eurotech PN <b>".$_POST['Eurotech_PN']."</b> don't exist.";
            }
            if($customer != NULL && $etpn == NULL && $ce == NULL) {
                $_POST['edit'] = 1;
                $error = "The Eurotech PN <b>".$_POST['Eurotech_PN']."</b> doesn't exists.";
            }
            if($customer == NULL && $etpn != NULL && $ce == NULL) {
                $_POST['edit'] = 1;
                $error = "The customer <b>".$_POST['Name']."</b> doesn't exists.";
            }
            if($customer != NULL && $etpn != NULL && $ce == NULL) {
                    $stmt = $pdo->prepare("UPDATE customer_pn SET 
                                                FK_Customer_ID = ?, 
                                                FK_Eurotech_PN = ? 
                                            WHERE Customer_PN = ?");
                    $stmt->execute([
                        $customer[0],
                        $_POST['Eurotech_PN'],
                        $_POST['Customer_PN']
                    ]);
            }
            if($customer != NULL && $etpn != NULL && $ce != NULL) {
                $_POST['edit'] = 1;
                $error = "A Customer PN already exists for the Eurotech PN <b>".$_POST['Eurotech_PN']."</b> and the customer <b>".$_POST['Name']."</b>.";
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['delete'])) {
            $id = $_POST['IDdelete'];
            $stmt = $pdo->prepare("SELECT * FROM customer_pn cpn
                INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                WHERE Customer_PN = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $cpnDataD = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmD'])) {
            $id = $_POST['Customer_PN'];
            $stmt = $pdo->prepare("SELECT FK_Customer_PN FROM bluseal_ppap
                                    WHERE FK_Customer_PN = ?");
            $stmt->execute([$id]);
            $bs = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT FK_Customer_PN FROM cables_ppap 
                                    WHERE FK_Customer_PN = ?");
            $stmt->execute([$id]);
            $cab = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT FK_Customer_PN FROM tapes_ppap 
                                    WHERE FK_Customer_PN = ?");
            $stmt->execute([$id]);
            $tap = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT FK_Customer_PN FROM tubes_ppap 
                                    WHERE FK_Customer_PN = ?");
            $stmt->execute([$id]);
            $tub = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($bs == NULL && $cab == NULL && $tap == NULL && $tub == NULL) {
                $stmt = $pdo->prepare("DELETE FROM customer_pn
                                        WHERE Customer_PN = ?");

                $stmt->execute([$id]);
            
                $Deleted = 'Y';
            }
            else {
                $_POST['delete'] = 1;
                $error = "This customer PN can't be deleted, because it already has registers.";

                $stmt = $pdo->prepare("SELECT * FROM customer_pn cpn
                                        INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                        INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
                                        WHERE Customer_PN = ?");
                $stmt->execute([$id]);

                if ($stmt->rowCount() > 0) {
                    $cpnDataD = $stmt->fetch(PDO::FETCH_ASSOC);
                }
            }

            $_SESSION['saved'] = true;
        }
    }
    
    
    $CPNs = $model->searchCPN();
    $Customers = $model->searchCustomers();
    $ETPNs = $model->searchETPNs();
    $logs = $model->search();

    include 'view.php';
?>