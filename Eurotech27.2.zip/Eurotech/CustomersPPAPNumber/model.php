<?php
    class model {                                        

        public  $mbd;
        
        function cn() {
            $this->mbd = new PDO('mysql:host=localhost;dbname=eurotechdb;port=3306', 'root', '');
            $this->mbd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
        }
    
        function search(){
            $logs = [];
            if (isset($_POST['btnsearch'])) {
                if (!empty($_POST['idsearch']) || !empty($_POST['custsearch']) || !empty($_POST['counsearch']) 
                ) {
                    $where = [];
                    $params = [];

                    if (!empty($_POST['idsearch'])) {
                        $where[] = "Customer_PPAP_Number = :id";
                        $params[':id'] = $_POST['idsearch'];
                    }

                    if (!empty($_POST['custsearch'])) {
                        $where[] = "Name = :cust";
                        $params[':cust'] = $_POST['custsearch'];
                    }

                    if (!empty($_POST['counsearch'])) {
                        $where[] = "Country = :coun";
                        $params[':coun'] = $_POST['counsearch'];
                    }

                    if(!empty($where)) {
                        $sql = "SELECT 
                                    *
                                FROM customer_ppap_number cpn
                                INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                        WHERE " . implode(' AND ', $where) . "
                        ORDER BY Customer_PPAP_Number;";
                    }
                    else {
                        $sql = "SELECT 
                                    *
                                FROM customer_ppap_number cpn
                                INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                ORDER BY Customer_PPAP_Number;";
                    }

                    $stmt = $this->mbd->prepare($sql);
                    $stmt->execute($params);

                    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
                else {
                    foreach ($this->mbd->query(
                        "SELECT 
                            *
                        FROM customer_ppap_number cpn
                        INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                        ORDER BY Customer_PPAP_Number;"
                    ) as $log) {
                        $logs[] = $log;
                    }
                }
            } else {
                foreach ($this->mbd->query(
                    "SELECT 
                            *
                        FROM customer_ppap_number cpn
                        INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                        ORDER BY Customer_PPAP_Number;"
                ) as $log) {
                    $logs[] = $log;
                }
            }
            return $logs;
        }

        function searchCPN(){
            $CPNs = [];
                foreach ($this->mbd->query(
                    "SELECT 
                        Customer_PPAP_Number
                    FROM customer_ppap_number
                    ORDER BY Customer_PPAP_Number;"
                ) as $CPN) {
                    $CPNs[] = $CPN;
                }
            return $CPNs;
        }

        function searchCustomers(){
            $Customers = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        `Name`
                    FROM customers c
                    INNER JOIN customer_ppap_number cpn ON c.Customer_ID = cpn.FK_Customer_ID
                    ORDER BY `Name`;"
                ) as $Customer) {
                    $Customers[] = $Customer;
                }
            return $Customers;
        }

        function searchCountries(){
            $Countries = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        Country
                    FROM customer_ppap_number
                    ORDER BY Country;"
                ) as $Country) {
                    $Countries[] = $Country;
                }
            return $Countries;
        }
    }
?>