<?php
header('Content-Type: application/json');

$connection = new mysqli("localhost", "root", "", "eurotechdb");
if ($connection->connect_error) {
    echo json_encode(["success" => false, "error" => "Connection Error"]);
    exit;
}

$Customer = $_POST['Customer'] ?? '';
$Country = $_POST['Country'] ?? '';
$Customer_PN = $_POST['Customer_PN'] ?? '';

if ($Customer !== ''  && $Customer_PN !== '') {
    $stmt = $connection->prepare("
        SELECT PPAP_Number
        FROM ppap p
        INNER JOIN customer_pn cpn ON p.FK_Customer_PN_ID = cpn.Customer_PN_ID
        INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
        WHERE Name = ? AND p.Country = ? AND Customer_PN = ?
        LIMIT 1
    ");
    $stmt->bind_param("sss", $Customer, $Country, $Customer_PN);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($fila = $resultado->fetch_assoc()) {
        echo json_encode([
            "success" => true,
            "PPAP_Number" => $fila['PPAP_Number']
        ]);
    } else {
        echo json_encode(["success" => false]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false]);
}

$connection->close();
?>