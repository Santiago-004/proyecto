<?php
header('Content-Type: application/json');

$connection = new mysqli("localhost", "root", "", "eurotechdb");
if ($connection->connect_error) {
    echo json_encode(["success" => false, "error" => "Connection Error"]);
    exit;
}

$Customer = $_POST['Customer'] ?? '';
$Eurotech_PN = $_POST['Eurotech_PN'] ?? '';

if ($Customer !== '' && $Eurotech_PN !== '') {
    $stmt = $connection->prepare("
        SELECT Customer_PN
        FROM customer_pn cpn
        INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
        INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
        WHERE Name = ? AND Eurotech_PN = ?
        LIMIT 1
    ");
    $stmt->bind_param("ss", $Customer, $Eurotech_PN);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($fila = $resultado->fetch_assoc()) {
        echo json_encode([
            "success" => true,
            "Customer_PN" => $fila['Customer_PN']
        ]);
    } else {
        echo json_encode(["success" => false]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false]);
}

$connection->close();
?>