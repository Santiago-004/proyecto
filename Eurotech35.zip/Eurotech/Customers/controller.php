<?php 
    include "model.php";

    $model = new model();
    $model->cn();
    $logs = [];
    
    if (isset($_POST["idsearch"])){
        $idsearch = $_POST["idsearch"];
    }    
    else {
        $idsearch = NULL;
    }

    if (isset($_POST["custsearch"])){
        $custsearch = $_POST["custsearch"];
    }    
    else {
        $custsearch = NULL;
    }

    if (isset($_POST["imdssearch"])){
        $imdssearch = $_POST["imdssearch"];
    }    
    else {
        $imdssearch = NULL;
    }

    if (isset($_POST["bssearch"])){
        $bssearch = $_POST["bssearch"];
    }    
    else {
        $bssearch = "";
    } 

    if (isset($_POST["cabsearch"])){
        $cabsearch = $_POST["cabsearch"];
    }    
    else {
        $cabsearch = "";
    } 

    if (isset($_POST["tapsearch"])){
        $tapsearch = $_POST["tapsearch"];
    }    
    else {
        $tapsearch = "";
    } 

    if (isset($_POST["tubsearch"])){
        $tubsearch = $_POST["tubsearch"];
    }    
    else {
        $tubsearch = "";
    } 

    $Products = $model->searchProducts();
    $cus = NULL;
    $customerData = NULL;
    $customerDataD = NULL;
    $Deleted = NULL;

    $pdo = new PDO("mysql:host=localhost;dbname=eurotechdb", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        if (isset($_POST['confirmI'])) {
            $cus = $_POST['Customer_ID'][0].''.$_POST['Customer_ID'][1].''.$_POST['Customer_ID'][2];
            if($cus == 'CUS') {
                $ID = explode("CUS", $_POST['Customer_ID']);
                $ID_number = $ID[1];
                if (ctype_digit($ID_number)) {
                    $stmt = $pdo->prepare("SELECT Customer_ID FROM customers WHERE Customer_ID = ?");
                    $stmt->execute([
                        $_POST['Customer_ID']
                    ]);
                    $cid = $stmt->fetchAll(PDO::FETCH_COLUMN);

                    $stmt = $pdo->prepare("SELECT `Name` FROM customers WHERE `Name` = ?");
                    $stmt->execute([
                        $_POST['Name']
                    ]);
                    $name = $stmt->fetchAll(PDO::FETCH_COLUMN);

                    if($_POST['IMDS_ID_no'] == "") {
                        $_POST['IMDS_ID_no'] = NULL;
                        $imds = NULL;
                    }
                    else { 
                        $stmt = $pdo->prepare("SELECT IMDS_ID_no FROM customers WHERE IMDS_ID_no = ?");
                        $stmt->execute([
                            $_POST['IMDS_ID_no']
                        ]);
                        $imds = $stmt->fetchAll(PDO::FETCH_COLUMN);
                    }

                    if($cid != NULL && $name == NULL && $imds == NULL) {
                        $_POST['insert'] = 1;
                        $error = "The customer ID <b>".$_POST['Customer_ID']."</b> already exists.";
                    }
                    if($cid == NULL && $name != NULL && $imds == NULL) {
                        $_POST['insert'] = 1;
                        $error = "The customer <b>".$_POST['Name']."</b> already exists.";
                    }
                    if($cid == NULL && $name == NULL && $imds != NULL) {
                        $_POST['insert'] = 1;
                        $error = "The IMDS ID no. <b>".$_POST['IMDS_ID_no']."</b> already exists.";
                    }
                    if($cid != NULL && $name != NULL && $imds == NULL) {
                        $_POST['insert'] = 1;
                        $error = "The customer ID <b>".$_POST['Customer_ID']."</b> and the customer <b>".$_POST['Name']."</b> already exist.";
                    }
                    if($cid != NULL && $name == NULL && $imds != NULL) {
                        $_POST['insert'] = 1;
                        $error = "The customer ID <b>".$_POST['Customer_ID']."</b> and the IMDS ID no. <b>".$_POST['IMDS_ID_no']."</b> already exist.";
                    }
                    if($cid == NULL && $name != NULL && $imds != NULL) {
                        $_POST['insert'] = 1;
                        $error = "The customer <b>".$_POST['Name']."</b> and the IMDS ID no. <b>".$_POST['IMDS_ID_no']."</b> already exist.";
                    }
                    if($cid != NULL && $name != NULL && $imds != NULL) {
                        $_POST['insert'] = 1;
                        $error = "The customer ID <b>".$_POST['Customer_ID']."</b>, the customer <b>".$_POST['Name']."</b> and the IMDS ID no. <b>".$_POST['IMDS_ID_no']."</b> already exist.";
                    }
                    if(!isset($error)) {
                        $prods_array = [];
                        foreach($Products as $Prod) {
                            if(isset($_POST[$Prod]) && $_POST[$Prod] != NULL) {
                                $prods_array[] = $_POST[$Prod];
                            }
                        }

                        $prods = implode(', ', $prods_array);

                        if($prods != "") {
                            $stmt = $pdo->prepare("INSERT INTO customers (Customer_ID, `Name`, IMDS_ID_no, Products) 
                                                            VALUES (?, ?, ?, ?)");
                            $stmt->execute([
                                $_POST['Customer_ID'],
                                $_POST['Name'],
                                $_POST['IMDS_ID_no'],
                                $prods
                            ]);
                        }
                        else {
                            $_POST['insert'] = 1;
                            $error = "You should select at least 1 product for the customer.";
                        }
                    }
                } else {
                    $_POST['insert'] = 1;
                    $error = "Customer ID must contain only numbers after 'CUS'.";
                }
            }
            else {
                $_POST['insert'] = 1;
                $error = "Customer ID must start with 'CUS'.";
            }

            $_SESSION['saved'] = true;
        }

        if (isset($_POST['edit'])) {
            $id = $_POST['IDedit'];
            $stmt = $pdo->prepare("SELECT Customer_ID, `Name`, IMDS_ID_no FROM customers WHERE Customer_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $customerData = $stmt->fetch(PDO::FETCH_ASSOC);
            }

            $stmt = $pdo->prepare("SELECT Products FROM customers WHERE Customer_ID = ?");
            $stmt->execute([$id]);
            $productsData = $stmt->fetch(PDO::FETCH_ASSOC);
        }

        if (isset($_POST['confirmU'])) {
            $stmt = $pdo->prepare("SELECT `Name` FROM customers WHERE `Name` = ? AND Customer_ID != ?");
            $stmt->execute([
                $_POST['Name'],
                $_POST['Customer_ID']
            ]);
            $name = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($_POST['IMDS_ID_no'] == "") {
                $_POST['IMDS_ID_no'] = NULL;
                $imds = NULL;
            }
            else { 
                $stmt = $pdo->prepare("SELECT IMDS_ID_no FROM customers WHERE IMDS_ID_no = ? AND Customer_ID != ?");
                $stmt->execute([
                    $_POST['IMDS_ID_no'],
                    $_POST['Customer_ID']
                ]);
                $imds = $stmt->fetchAll(PDO::FETCH_COLUMN);
            }

            if($name != NULL && $imds == NULL) {
                $_POST['edit'] = 1;
                $error = "The customer <b>".$_POST['Name']."</b> already exists.";
            }
            if($name == NULL && $imds != NULL) {
                $_POST['edit'] = 1;
                $error = "The IMDS ID no. <b>".$_POST['IMDS_ID_no']."</b> already exists.";
            }
            if($name != NULL && $imds != NULL) {
                $_POST['edit'] = 1;
                $error = "The customer <b>".$_POST['Name']."</b> and the IMDS ID no. <b>".$_POST['IMDS_ID_no']."</b> already exist.";
            }
            if(!isset($error)) {
                $prods_array = [];
                foreach($Products as $Prod) {
                    if(isset($_POST[$Prod]) && $_POST[$Prod] != NULL) {
                        $prods_array[] = $_POST[$Prod];
                    }
                }

                $prods = implode(', ', $prods_array);

                if($prods != "") {
                    $stmt = $pdo->prepare("UPDATE customers SET 
                                                `Name` = ?, 
                                                Products = ?,
                                                IMDS_ID_no = ?
                                            WHERE Customer_ID = ?");
                    $stmt->execute([
                        $_POST['Name'],
                        $prods,
                        $_POST['IMDS_ID_no'],
                        $_POST['Customer_ID']
                    ]);
                }
                else {
                    $_POST['edit'] = 1;
                    $error = "You should select at least 1 more product for the customer.";
                }
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['delete'])) {
            $id = $_POST['IDdelete'];
            $stmt = $pdo->prepare("SELECT * FROM customers WHERE Customer_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $customerDataD = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmD'])) {
            $id = $_POST['Customer_ID'];
            $stmt = $pdo->prepare("SELECT Customer_ID FROM customers c
                                        INNER JOIN customer_pn cpn ON c.Customer_ID = cpn.FK_Customer_ID
                                    WHERE Customer_ID = ?");
            $stmt->execute([$id]);
            $cpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($cpn == NULL) {
                $stmt = $pdo->prepare("DELETE FROM customers
                                        WHERE Customer_ID = ?");

                $stmt->execute([$id]);
            
                $Deleted = 'Y';
            }
            else {
                $_POST['delete'] = 1;
                $error = "This customer can't be deleted, because it already has registers.";

                $stmt = $pdo->prepare("SELECT * FROM customers WHERE Customer_ID = ?");
                $stmt->execute([$id]);

                if ($stmt->rowCount() > 0) {
                    $customerDataD = $stmt->fetch(PDO::FETCH_ASSOC);
                }
            }

            $_SESSION['saved'] = true;
        }
    }
    
    
    $IDs = $model->searchIDs();
    $Customers = $model->searchCustomers();
    $IMDSs = $model->searchIMDS();
    $logs = $model->search();

    include 'view.php';
?>