<?php 
    include "model.php";

    $model = new model();
    $model->cn();
    $logs = [];
    $Renewlogs = [];
    
    if (isset($_POST["txtsearch"])){
        $txtsearch = $_POST["txtsearch"];
    }    
    else {
        $txtsearch ="";
    }

    if (isset($_POST["retn"])){
        $retn = $_POST["retn"];
    }    
    else {
        $retn = NULL;
    }

    if (isset($_POST["pscn"])){
        $pscn = $_POST["pscn"];
    }    
    else {
        $pscn = NULL;
    }

    if (isset($_POST["renn"])){
        $renn = $_POST["renn"];
    }    
    else {
        $renn = NULL;
    }

    if (isset($_POST["reqn"])){
        $reqn = $_POST["reqn"];
    }    
    else {
        $reqn = NULL;
    }
    
    if (isset($_POST["stcn"])){
        $stcn = $_POST["stcn"];
    }    
    else {
        $stcn = NULL;
    }

    if (isset($_POST["pcsn"])){
        $pcsn = $_POST["pcsn"];
    }    
    else {
        $pcsn = NULL;
    }

    $logs = $model->search();

    include 'view.php';
?>