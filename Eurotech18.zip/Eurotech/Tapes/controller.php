<?php 
    include "model.php";

    $model = new model();
    $model->cn();
    $logs = [];
    $Renewlogs = [];
    $NRenewlogs = [];
    $MaxYears = [];
    $MaxYs = [];
    $Regs = [];
    $dates = [];
    $datesNULL = [];

    if (isset($_POST["submit1search"]) && isset($_POST["submit2search"])){
        $submit1search = $_POST["submit1search"];
        $submit2search = $_POST["submit2search"];
    }    
    else {
        $submit1search = "";
        $submit2search = "";
    }

    if (isset($_POST["custsearch"])){
        $custsearch = $_POST["custsearch"];
    }    
    else {
        $custsearch = NULL;
    }

    if (isset($_POST["oemsearch"])){
        $oemsearch = $_POST["oemsearch"];
    }    
    else {
        $oemsearch = NULL;
    }

    if (isset($_POST["counsearch"])){
        $counsearch = $_POST["counsearch"];
    }    
    else {
        $counsearch = NULL;
    }

    if (isset($_POST["levelsearch"])){
        $levelsearch = $_POST["levelsearch"];
    }    
    else {
        $levelsearch = NULL;
    }

    if (isset($_POST["sapsearch"])){
        $sapsearch = $_POST["sapsearch"];
    }    
    else {
        $sapsearch = NULL;
    }

    if (isset($_POST["cpnsearch"])){
        $cpnsearch = $_POST["cpnsearch"];
    }    
    else {
        $cpnsearch = NULL;
    }

    if (isset($_POST["tapesearch"])){
        $tapesearch = $_POST["tapesearch"];
    }    
    else {
        $tapesearch = NULL;
    }

    if (isset($_POST["widthsearch"])){
        $widthsearch = $_POST["widthsearch"];
    }    
    else {
        $widthsearch = NULL;
    }

    if (isset($_POST["lengthsearch"])){
        $lengthsearch = $_POST["lengthsearch"];
    }    
    else {
        $lengthsearch = NULL;
    }

    if (isset($_POST["colorsearch"])){
        $colorsearch = $_POST["colorsearch"];
    }    
    else {
        $colorsearch = NULL;
    }
    
    if (isset($_POST["imdssearch"])){
        $imdssearch = $_POST["imdssearch"];
    }    
    else {
        $imdssearch = NULL;
    }

    if (isset($_POST["ret1search"]) && isset($_POST["ret2search"])){
        $ret1search = $_POST["ret1search"];
        $ret2search = $_POST["ret2search"];
    }    
    else {
        $ret1search = "";
        $ret2search = "";
    }

    if (isset($_POST["psw1search"]) && isset($_POST["psw2search"])){
        $psw1search = $_POST["psw1search"];
        $psw2search = $_POST["psw2search"];
    }    
    else {
        $psw1search = "";
        $psw2search = "";
    }

    if (isset($_POST["ren1search"]) && isset($_POST["ren2search"])){
        $ren1search = $_POST["ren1search"];
        $ren2search = $_POST["ren2search"];
    }    
    else {
        $ren1search = "";
        $ren2search = "";
    }

    if (isset($_POST["req1search"]) && isset($_POST["req2search"])){
        $req1search = $_POST["req1search"];
        $req2search = $_POST["req2search"];
    }    
    else {
        $req1search = "";
        $req2search = "";
    }

    if (isset($_POST["sent1search"]) && isset($_POST["sent2search"])){
        $sent1search = $_POST["sent1search"];
        $sent2search = $_POST["sent2search"];
    }    
    else {
        $sent1search = "";
        $sent2search = "";
    }

    if (isset($_POST["pswr1search"]) && isset($_POST["pswr2search"])){
        $pswr1search = $_POST["pswr1search"];
        $pswr2search = $_POST["pswr2search"];
    }    
    else {
        $pswr1search = "";
        $pswr2search = "";
    }

    if (isset($_POST["retn"])){
        $retn = $_POST["retn"];
    }    
    else {
        $retn = NULL;
    }

    if (isset($_POST["pscn"])){
        $pscn = $_POST["pscn"];
    }    
    else {
        $pscn = NULL;
    }

    if (isset($_POST["renn"])){
        $renn = $_POST["renn"];
    }    
    else {
        $renn = NULL;
    }

    if (isset($_POST["reqn"])){
        $reqn = $_POST["reqn"];
    }    
    else {
        $reqn = NULL;
    }
    
    if (isset($_POST["stcn"])){
        $stcn = $_POST["stcn"];
    }    
    else {
        $stcn = NULL;
    }

    if (isset($_POST["pcsn"])){
        $pcsn = $_POST["pcsn"];
    }    
    else {
        $pcsn = NULL;
    }

    if (isset($_POST["pfsn"])){
        $pfsn = $_POST["pfsn"];
    }    
    else {
        $pfsn = NULL;
    }

    if (isset($_POST["comsearch"])){
        $comsearch = $_POST["comsearch"];
    }    
    else {
        $comsearch = NULL;
    }

    $NocpnError = NULL;
    $etpnError = NULL;
    $descError = NULL;
    $custError = NULL;
    $dcError = NULL;
    $ecError = NULL;
    $cpnError = NULL;
    $selects = [];
    $params = [];
    $tapeData = NULL;
    $tapeDataD = NULL;
    $tapeRenewData = [];
    $tapeRenewDataD = [];
    $tapeRenewD = NULL;
    $tapeRenewDDel = NULL;
    $NoDatesError = NULL;


    $pdo = new PDO("mysql:host=localhost;dbname=eurotechdb", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        if (isset($_POST['confirmID'])) {
            $stmt = $pdo->prepare("SELECT TAP_Eurotech_PN FROM tapes WHERE `Tape` = '".$_POST['Tape']."' 
                                    AND Width = '".$_POST['Width']."' AND Length = '".$_POST['Length']."' 
                                    AND Color = '".$_POST['Color']."';");
            $stmt->execute([]);
            $etpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT `Name` FROM tapes_customer WHERE `Name` = ?");
            $stmt->execute([
                $_POST['Name']
            ]);
            $cn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($etpn != NULL && $cn != NULL) {
                foreach ($etpn as $pn) {
                    $stmt = $pdo->prepare("SELECT TAP_Customer_PN FROM tapes_customer_pn cpn
                                                INNER JOIN tapes_customer c ON cpn.FK_TAP_Customer_ID = c.TAP_Customer_ID
                                                WHERE cpn.FK_TAP_Eurotech_PN = ? AND c.`Name` = ?");
                    $stmt->execute([
                        $pn,
                        $_POST['Name']
                    ]);
                    $cpn = $stmt->fetchAll(PDO::FETCH_COLUMN);
                }

                if($cpn != NULL) {
                    foreach ($cpn as $c) {
                        if(!empty($_POST['OEM'])) {
                            $inserts[] = "OEM";
                            $paramsI[] = "'".$_POST['OEM']."'";
                        }

                        if(!empty($_POST['Country'])) {
                            $inserts[] = "Country";
                            $paramsI[] = "'".$_POST['Country']."'";
                        }

                        if(!empty($_POST['PPAP_level'])) {
                            $inserts[] = "PPAP_level";
                            $paramsI[] = "'".$_POST['PPAP_level']."'";
                        }

                        if(!empty($_POST['IMDS'])) {
                            $inserts[] = "IMDS_ID_No";
                            $paramsI[] = "'".$_POST['IMDS']."'";
                        }

                        if(!empty($_POST['Returned_CTC-Sent_Cust'])) {
                            $inserts[] = "`Returned_CTC-Sent_Cust`";
                            $paramsI[] = "'".$_POST['Returned_CTC-Sent_Cust']."'";
                        }

                        if(!empty($_POST['Cust_Signed-Sent_CTC'])) {
                            $inserts[] = "`Cust_Signed-Sent_CTC`";
                            $paramsI[] = "'".$_POST['Cust_Signed-Sent_CTC']."'";
                        }

                        if(!empty($_POST['PPAP_from_shipments']) && $_POST['PPAP_from_shipments'] != 'no') {
                            $inserts[] = "PPAP_from_shipments";
                            $paramsI[] = "'".$_POST['PPAP_from_shipments']."'";
                        }

                        if(!empty($_POST['Comments'])) {
                            $inserts[] = "Comments";
                            $paramsI[] = "'".$_POST['Comments']."'";
                        }

                        $inserts[] = "FK_TAP_Customer_PN";
                        $paramsI[] = "'$c'";
                        
                        $stmt = $pdo->prepare("INSERT INTO tapes_ppap (". implode(', ', $inserts) .") 
                                                VALUES (". implode(', ', $paramsI) .")");
                        $stmt->execute([]);
                    }
                }
                else {
                    $NocpnError = 'Y';
                }
            }
            if($etpn == NULL && $cn != NULL) {
                $descError = 'Y';
            }
            if($etpn != NULL && $cn == NULL) {
                $custError = 'Y';
            }
            if($etpn == NULL && $cn == NULL) {
                $dcError = 'Y';
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['confirmIE'])) {
            $stmt = $pdo->prepare("SELECT TAP_Eurotech_PN FROM tapes WHERE TAP_Eurotech_PN = ?;");
            $stmt->execute([
                $_POST['TAP_Eurotech_PN']
            ]);
            $etpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT `Name` FROM tapes_customer WHERE `Name` = ?");
            $stmt->execute([
                $_POST['Name']
            ]);
            $cn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($etpn != NULL && $cn != NULL) {
                foreach ($etpn as $pn) {
                    $stmt = $pdo->prepare("SELECT TAP_Customer_PN FROM tapes_customer_pn cpn
                                                INNER JOIN tapes_customer c ON cpn.FK_TAP_Customer_ID = c.TAP_Customer_ID
                                                WHERE cpn.FK_TAP_Eurotech_PN = ? AND c.`Name` = ?");
                    $stmt->execute([
                        $pn,
                        $_POST['Name']
                    ]);
                    $cpn = $stmt->fetchAll(PDO::FETCH_COLUMN);
                }

                if($cpn != NULL) {
                    foreach ($cpn as $c) {
                        if(!empty($_POST['OEM'])) {
                            $inserts[] = "OEM";
                            $paramsI[] = "'".$_POST['OEM']."'";
                        }

                        if(!empty($_POST['Country'])) {
                            $inserts[] = "Country";
                            $paramsI[] = "'".$_POST['Country']."'";
                        }

                        if(!empty($_POST['PPAP_level'])) {
                            $inserts[] = "PPAP_level";
                            $paramsI[] = "'".$_POST['PPAP_level']."'";
                        }

                        if(!empty($_POST['IMDS'])) {
                            $inserts[] = "IMDS_ID_No";
                            $paramsI[] = "'".$_POST['IMDS']."'";
                        }

                        if(!empty($_POST['Returned_CTC-Sent_Cust'])) {
                            $inserts[] = "`Returned_CTC-Sent_Cust`";
                            $paramsI[] = "'".$_POST['Returned_CTC-Sent_Cust']."'";
                        }

                        if(!empty($_POST['Cust_Signed-Sent_CTC'])) {
                            $inserts[] = "`Cust_Signed-Sent_CTC`";
                            $paramsI[] = "'".$_POST['Cust_Signed-Sent_CTC']."'";
                        }

                        if(!empty($_POST['PPAP_from_shipments']) && $_POST['PPAP_from_shipments'] != 'no') {
                            $inserts[] = "PPAP_from_shipments";
                            $paramsI[] = "'".$_POST['PPAP_from_shipments']."'";
                        }

                        if(!empty($_POST['Comments'])) {
                            $inserts[] = "Comments";
                            $paramsI[] = "'".$_POST['Comments']."'";
                        }

                        $inserts[] = "FK_TAP_Customer_PN";
                        $paramsI[] = "'$c'";
                        
                        $stmt = $pdo->prepare("INSERT INTO tapes_ppap (". implode(', ', $inserts) .") 
                                                VALUES (". implode(', ', $paramsI) .")");
                        $stmt->execute([]);
                    }
                }
                else {
                    $NocpnError = 'Y';
                }
            }
            if($etpn == NULL && $cn != NULL) {
                $etpnError = 'Y';
            }
            if($etpn != NULL && $cn == NULL) {
                $custError = 'Y';
            }
            if($etpn == NULL && $cn == NULL) {
                $ecError = 'Y';
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['confirmIC'])) {
            $stmt = $pdo->prepare("SELECT TAP_Customer_PN FROM tapes_customer_pn WHERE TAP_Customer_PN = ?");
            $stmt->execute([
                $_POST['TAP_Customer_PN']
            ]);
            $cpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($cpn != NULL) {
                foreach ($cpn as $c) {
                        if(!empty($_POST['OEM'])) {
                            $inserts[] = "OEM";
                            $paramsI[] = "'".$_POST['OEM']."'";
                        }

                        if(!empty($_POST['Country'])) {
                            $inserts[] = "Country";
                            $paramsI[] = "'".$_POST['Country']."'";
                        }

                        if(!empty($_POST['PPAP_level'])) {
                            $inserts[] = "PPAP_level";
                            $paramsI[] = "'".$_POST['PPAP_level']."'";
                        }

                        if(!empty($_POST['IMDS'])) {
                            $inserts[] = "IMDS_ID_No";
                            $paramsI[] = "'".$_POST['IMDS']."'";
                        }

                        if(!empty($_POST['Returned_CTC-Sent_Cust'])) {
                            $inserts[] = "`Returned_CTC-Sent_Cust`";
                            $paramsI[] = "'".$_POST['Returned_CTC-Sent_Cust']."'";
                        }

                        if(!empty($_POST['Cust_Signed-Sent_CTC'])) {
                            $inserts[] = "`Cust_Signed-Sent_CTC`";
                            $paramsI[] = "'".$_POST['Cust_Signed-Sent_CTC']."'";
                        }

                        if(!empty($_POST['PPAP_from_shipments']) && $_POST['PPAP_from_shipments'] != 'no') {
                            $inserts[] = "PPAP_from_shipments";
                            $paramsI[] = "'".$_POST['PPAP_from_shipments']."'";
                        }

                        if(!empty($_POST['Comments'])) {
                            $inserts[] = "Comments";
                            $paramsI[] = "'".$_POST['Comments']."'";
                        }

                        $inserts[] = "FK_TAP_Customer_PN";
                        $paramsI[] = "'$c'";
                        
                        $stmt = $pdo->prepare("INSERT INTO tapes_ppap (". implode(', ', $inserts) .") 
                                                VALUES (". implode(', ', $paramsI) .")");
                        $stmt->execute([]);
                }
            }
            else {
                $cpnError = 'Y';
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['edit'])) {
            $id = $_POST['IDedit'];
            $stmt = $pdo->prepare("SELECT DISTINCT
                                        tp.TAP_PPAP_ID,
                                        tp.OEM,
                                        tp.Country,
                                        tc.`Name`,
                                        tp.PPAP_level,
                                        t.SAP_Number,
                                        tp.FK_TAP_Customer_PN,
                                        t.Tape,
                                        t.Width,
                                        t.`Length`,
                                        t.Color,
                                        tp.IMDS_ID_No,
                                        tp.`Returned_CTC-Sent_Cust`,
                                        tp.`Cust_Signed-Sent_CTC`,
                                        tp.PPAP_from_shipments,
                                        tp.Comments
                                    FROM tapes_ppap tp
                                        INNER JOIN tapes_customer_pn tcp ON tp.FK_TAP_Customer_PN  = tcp.TAP_Customer_PN
                                        INNER JOIN tapes_customer tc ON tcp.FK_TAP_Customer_ID = tc.TAP_Customer_ID
                                        INNER JOIN tapes t ON tcp.FK_TAP_Eurotech_PN = t.TAP_Eurotech_PN
                                        LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID 
                                    WHERE TAP_PPAP_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $tapeData = $stmt->fetch(PDO::FETCH_ASSOC);

                if($_POST['submit1search'] != NULL && $_POST['submit2search'] != NULL) {
                    for($i = (int)$_POST['submit1search']; $i <= (int)$_POST['submit2search']; $i++) { 
                        $stmt = $pdo->prepare("SELECT *
                                                FROM tapes_renewal 
                                                WHERE FK_TAP_PPAP_ID = ?
                                                AND (YEAR(Renewal_Date) = $i || YEAR(Sent_Request_CTC) = $i || YEAR(Sent_Customer) = $i 
                                                    || YEAR(Returned_Cust_Signed) = $i) 
                                                AND (YEAR(Renewal_Date) = $i || YEAR(Renewal_Date) IS NULL)");
                        $stmt->execute([$id]);


                        $year = (string)$i;
                        $tapeRenewD = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        array_push($tapeRenewData, $tapeRenewD);
                    }
                } 
                else {
                    for($i = (int)(date("Y", strtotime("-1 year"))); $i <= (int)(date("Y")); $i++) { 
                        $stmt = $pdo->prepare("SELECT *
                                                FROM tapes_renewal 
                                                WHERE FK_TAP_PPAP_ID = ?
                                                AND (YEAR(Renewal_Date) = $i || YEAR(Sent_Request_CTC) = $i || YEAR(Sent_Customer) = $i 
                                                    || YEAR(Returned_Cust_Signed) = $i) 
                                                AND (YEAR(Renewal_Date) = $i || YEAR(Renewal_Date) IS NULL)");
                        $stmt->execute([$id]);

                        $year = (string)$i;
                        $tapeRenewD = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        array_push($tapeRenewData, $tapeRenewD);
                    }
                }
            }
        }

        if (isset($_POST['confirmU'])) {
            if($_POST['submit1search'] != "" && $_POST['submit2search'] != ""){
                for($i = (int)$_POST['submit1search']; $i <= (int)$_POST['submit2search']; $i++) {  
                    $y = (string)$i;
                    if($_POST['Renewal_Date'.$y] != "") {
                        $renD = new DateTime($_POST['Renewal_Date'.$y]);
                        $rD = $renD->format('Y-m-d');
                    }
                    else {
                        $rD = NULL; 
                    }

                    if($_POST['Sent_Request_CTC'.$y] != "") {
                        $senD = new DateTime($_POST['Sent_Request_CTC'.$y]);
                        $sD = $senD->format('Y-m-d');
                    }
                    else {
                        $sD = NULL; 
                    }

                    if($_POST['Sent_Customer'.$y] != "") {
                        $sencD = new DateTime($_POST['Sent_Customer'.$y]);
                        $scD = $sencD->format('Y-m-d');
                    }
                    else {
                        $scD = NULL; 
                    }

                    if($_POST['Returned_Cust_Signed'.$y] != "") {
                        $retD = new DateTime($_POST['Returned_Cust_Signed'.$y]);
                        $rcD = $retD->format('Y-m-d');
                    }
                    else {
                        $rcD = NULL; 
                    }

                    if($_POST['TAP_Renewal_ID'.$y] != NULL) {
                        if($rD == NULL && $sD == NULL && $scD  == NULL && $rcD  == NULL) {
                            break;
                        }
                         if(
                            ($rD != NULL && $sD == NULL && $scD  == NULL && $rcD  == NULL) ||
                            ($rD != NULL && $sD != NULL && $scD  == NULL && $rcD  == NULL) ||
                            ($rD != NULL && $sD != NULL && $scD  != NULL && $rcD  == NULL) ||
                            ($rD != NULL && $sD != NULL && $scD  != NULL && $rcD  != NULL) 
                        ) {
                            $stmt = $pdo->prepare("UPDATE tapes_renewal SET 
                                                    Renewal_Date = ?, 
                                                    Sent_Request_CTC = ?,
                                                    Sent_Customer = ?, 
                                                    Returned_Cust_Signed = ?
                                                WHERE TAP_Renewal_ID = ?");

                            $stmt->execute([
                                $rD,
                                $sD,
                                $scD,
                                $rcD,
                                $_POST['TAP_Renewal_ID'.$y]
                            ]);
                        }
                        else {
                            $NoDatesError = 'Y';
                        }
                    }
                    else {
                        if($rD == NULL && $sD == NULL && $scD  == NULL && $rcD  == NULL) {
                            break;
                        }
                        if(
                            ($rD != NULL && $sD == NULL && $scD  == NULL && $rcD  == NULL) ||
                            ($rD != NULL && $sD != NULL && $scD  == NULL && $rcD  == NULL) ||
                            ($rD != NULL && $sD != NULL && $scD  != NULL && $rcD  == NULL) ||
                            ($rD != NULL && $sD != NULL && $scD  != NULL && $rcD  != NULL) 
                        ) {
                            $stmt = $pdo->prepare("INSERT INTO tapes_renewal (Renewal_Date, Sent_Request_CTC, Sent_Customer, Returned_Cust_Signed, FK_TAP_PPAP_ID) 
                                                        VALUES (?, ?, ?, ?, ?)");

                            $stmt->execute([
                                $rD,
                                $sD,
                                $scD,
                                $rcD,
                                $_POST['TAP_PPAP_ID']
                            ]);
                        }
                        else {
                            $NoDatesError = 'Y';
                        }
                    }
                }
            }
            else {
                for($i = (int)(date("Y", strtotime("-1 year"))); $i <= (int)(date("Y")); $i++) {  
                    $y = (string)$i;
                    if($_POST['Renewal_Date'.$y] != "") {
                        $renD = new DateTime($_POST['Renewal_Date'.$y]);
                        $rD = $renD->format('Y-m-d');
                    }
                    else {
                        $rD = NULL; 
                    }

                    if($_POST['Sent_Request_CTC'.$y] != "") {
                        $senD = new DateTime($_POST['Sent_Request_CTC'.$y]);
                        $sD = $senD->format('Y-m-d');
                    }
                    else {
                        $sD = NULL; 
                    }

                    if($_POST['Sent_Customer'.$y] != "") {
                        $sencD = new DateTime($_POST['Sent_Customer'.$y]);
                        $scD = $sencD->format('Y-m-d');
                    }
                    else {
                        $scD = NULL; 
                    }

                    if($_POST['Returned_Cust_Signed'.$y] != "") {
                        $retD = new DateTime($_POST['Returned_Cust_Signed'.$y]);
                        $rcD = $retD->format('Y-m-d');
                    }
                    else {
                        $rcD = NULL; 
                    }

                    var_dump($rD);
                    var_dump($sD);
                    var_dump($scD);
                    var_dump($rcD);

                    if($_POST['TAP_Renewal_ID'.$y] != NULL) {
                        if($rD == NULL && $sD == NULL && $scD  == NULL && $rcD  == NULL) {
                            break;
                        }
                        if(
                            ($rD != NULL && $sD == NULL && $scD  == NULL && $rcD  == NULL) ||
                            ($rD != NULL && $sD != NULL && $scD  == NULL && $rcD  == NULL) ||
                            ($rD != NULL && $sD != NULL && $scD  != NULL && $rcD  == NULL) ||
                            ($rD != NULL && $sD != NULL && $scD  != NULL && $rcD  != NULL) 
                        ) {
                            $stmt = $pdo->prepare("UPDATE tapes_renewal SET 
                                                    Renewal_Date = ?, 
                                                    Sent_Request_CTC = ?,
                                                    Sent_Customer = ?, 
                                                    Returned_Cust_Signed = ?
                                                WHERE TAP_Renewal_ID = ?");

                            $stmt->execute([
                                $rD,
                                $sD,
                                $scD,
                                $rcD,
                                $_POST['TAP_Renewal_ID'.$y]
                            ]);
                        }
                        else {
                            $NoDatesError = 'Y';
                        }
                    }
                    else {
                        if($rD == NULL && $sD == NULL && $scD  == NULL && $rcD  == NULL) {
                            break;
                        }
                        if(
                            ($rD != NULL && $sD == NULL && $scD  == NULL && $rcD  == NULL) ||
                            ($rD != NULL && $sD != NULL && $scD  == NULL && $rcD  == NULL) ||
                            ($rD != NULL && $sD != NULL && $scD  != NULL && $rcD  == NULL) ||
                            ($rD != NULL && $sD != NULL && $scD  != NULL && $rcD  != NULL) 
                        ) {
                            $stmt = $pdo->prepare("INSERT INTO tapes_renewal (Renewal_Date, Sent_Request_CTC, Sent_Customer, Returned_Cust_Signed, FK_TAP_PPAP_ID) 
                                                        VALUES (?, ?, ?, ?, ?)");

                            $stmt->execute([
                                $rD,
                                $sD,
                                $scD,
                                $rcD,
                                $_POST['TAP_PPAP_ID']
                            ]);
                        }
                        else {
                            $NoDatesError = 'Y';
                        }
                    }
                }
            }

            if($_POST['OEM'] != "") {
                $oem = $_POST['OEM'];
            }
            else {
                $oem = NULL;
            }

            if($_POST['Country'] != "") {
                $cou = $_POST['Country'];
            }
            else {
                $cou = NULL;
            }

            if($_POST['PPAP_level'] != "") {
                $lvl = $_POST['PPAP_level'];
            }
            else {
                $lvl = NULL;
            }

            if($_POST['IMDS'] != "") {
                $imds = $_POST['IMDS'];
            }
            else {
                $imds = NULL;
            }

            if($_POST['Returned_CTC-Sent_Cust'] != "") {
                $custD = new DateTime($_POST['Returned_CTC-Sent_Cust']);
                $cusD = $custD->format('Y-m-d');
            }
            else {
                $cusD = NULL;
            }

            if($_POST['Cust_Signed-Sent_CTC'] != "") {
                $ctcD = new DateTime($_POST['Cust_Signed-Sent_CTC']);
                $ctD = $ctcD->format('Y-m-d');
            }
            else {
                $ctD = NULL;
            }

            if($_POST['PPAP_from_shipments'] != "no") {
                $pfs = $_POST['PPAP_from_shipments'];
            }
            else {
                $pfs = NULL;
            }

            if($_POST['Comments'] != "") {
                $com = $_POST['Comments'];
            }
            else {
                $com = NULL;
            }

            $stmt = $pdo->prepare("UPDATE tapes_ppap SET 
                                                `OEM` = ?, 
                                                Country = ?, 
                                                PPAP_level = ?, 
                                                IMDS_ID_No = ?, 
                                                `Returned_CTC-Sent_Cust` = ?, 
                                                `Cust_Signed-Sent_CTC` = ?, 
                                                PPAP_from_shipments = ?, 
                                                Comments = ?
                                            WHERE TAP_PPAP_ID = ?");

            $stmt->execute([
                $oem,
                $cou,
                $lvl,
                $imds,
                $cusD,
                $ctD,
                $pfs,
                $com,
                $_POST['TAP_PPAP_ID']
            ]);
        }

        if (isset($_POST['delete'])) {
            $id = $_POST['IDdelete'];
            $stmt = $pdo->prepare("SELECT DISTINCT
                                        tp.TAP_PPAP_ID,
                                        tp.OEM,
                                        tp.Country,
                                        tc.`Name`,
                                        tp.PPAP_level,
                                        t.SAP_Number,
                                        tp.FK_TAP_Customer_PN,
                                        t.Tape,
                                        t.Width,
                                        t.`Length`,
                                        t.Color,
                                        tp.IMDS_ID_No,
                                        tp.`Returned_CTC-Sent_Cust`,
                                        tp.`Cust_Signed-Sent_CTC`,
                                        tp.PPAP_from_shipments,
                                        tp.Comments
                                    FROM tapes_ppap tp
                                        INNER JOIN tapes_customer_pn tcp ON tp.FK_TAP_Customer_PN  = tcp.TAP_Customer_PN
                                        INNER JOIN tapes_customer tc ON tcp.FK_TAP_Customer_ID = tc.TAP_Customer_ID
                                        INNER JOIN tapes t ON tcp.FK_TAP_Eurotech_PN = t.TAP_Eurotech_PN
                                        LEFT JOIN tapes_renewal tr ON tp.TAP_PPAP_ID = tr.FK_TAP_PPAP_ID 
                                    WHERE TAP_PPAP_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $tapeDataD = $stmt->fetch(PDO::FETCH_ASSOC);

                if($_POST['submit1search'] != NULL && $_POST['submit2search'] != NULL) {
                    for($i = (int)$_POST['submit1search']; $i <= (int)$_POST['submit2search']; $i++) { 
                        $stmt = $pdo->prepare("SELECT *
                                                FROM tapes_renewal 
                                                WHERE FK_TAP_PPAP_ID = ?
                                                AND (YEAR(Renewal_Date) = $i || YEAR(Sent_Request_CTC) = $i || YEAR(Sent_Customer) = $i 
                                                    || YEAR(Returned_Cust_Signed) = $i) 
                                                AND (YEAR(Renewal_Date) = $i || YEAR(Renewal_Date) IS NULL)");
                        $stmt->execute([$id]);


                        $year = (string)$i;
                        $tapeRenewDDel = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        array_push($tapeRenewDataD, $tapeRenewDDel);
                    }
                } 
                else {
                    for($i = (int)(date("Y", strtotime("-1 year"))); $i <= (int)(date("Y")); $i++) { 
                        $stmt = $pdo->prepare("SELECT *
                                                FROM tapes_renewal 
                                                WHERE FK_TAP_PPAP_ID = ?
                                                AND (YEAR(Renewal_Date) = $i || YEAR(Sent_Request_CTC) = $i || YEAR(Sent_Customer) = $i 
                                                    || YEAR(Returned_Cust_Signed) = $i) 
                                                AND (YEAR(Renewal_Date) = $i || YEAR(Renewal_Date) IS NULL)");
                        $stmt->execute([$id]);

                        $year = (string)$i;
                        $tapeRenewDDel = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        array_push($tapeRenewDataD, $tapeRenewDDel);
                    }
                }
            }
        }

        if (isset($_POST['confirmD'])) {
            $id = $_POST['IDdelete'];
            $stmt = $pdo->prepare("DELETE FROM tapes_renewal
                                    WHERE FK_TAP_PPAP_ID = ?");

            $stmt->execute([
                $id
            ]);

            $stmt = $pdo->prepare("DELETE FROM tapes_ppap
                                    WHERE TAP_PPAP_ID = ?");

            $stmt->execute([
                $id
            ]);
           
            $Deleted = 'Y';

            $_SESSION['saved'] = true;
        }
    }

    $logs = $model->search();
    $Customers = $model->searchCust();
    $OEMS = $model->searchOEM();
    $Countries = $model->searchCoun();
    $SAPS = $model->searchSAP();
    $CPNS = $model->searchCPN();
    $Tapes = $model->searchTape();
    $Widths = $model->searchWidth();
    $Lengths = $model->searchLength();
    $Colors = $model->searchColor();
    $IMDS = $model->searchIMDS();
    $Coms = $model->searchCom();
    $ETPNS = $model->searchETPN();

    include 'view.php';
?>