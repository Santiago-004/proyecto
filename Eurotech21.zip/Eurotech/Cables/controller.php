<?php 
    include "model.php";

    $model = new model();
    $model->cn();
    $logs = [];
    
    if (isset($_POST["custsearch"])){
        $custsearch = $_POST["custsearch"];
    }    
    else {
        $custsearch = "";
    }

    if (isset($_POST["etpnsearch"])){
        $etpnsearch = $_POST["etpnsearch"];
    }    
    else {
        $etpnsearch = "";
    }

    if (isset($_POST["copnsearch"])){
        $copnsearch = $_POST["copnsearch"];
    }    
    else {
        $copnsearch = "";
    }

    if (isset($_POST["cpnsearch"])){
        $cpnsearch = $_POST["cpnsearch"];
    }    
    else {
        $cpnsearch = "";
    }

    if (isset($_POST["descsearch"])){
        $descsearch = $_POST["descsearch"];
    }    
    else {
        $descsearch = "";
    }

    if (isset($_POST["date1search"]) && isset($_POST["date2search"])){
        $date1search = $_POST["date1search"];
        $date2search = $_POST["date2search"];
    }    
    else {
        $date1search = "";
        $date2search = "";
    }

    if (isset($_POST["date3search"]) && isset($_POST["date4search"])){
        $date3search = $_POST["date3search"];
        $date4search = $_POST["date4search"];
    }    
    else {
        $date3search = "";
        $date4search = "";
    }

    if (isset($_POST["date5search"]) && isset($_POST["date6search"])){
        $date5search = $_POST["date5search"];
        $date6search = $_POST["date6search"];
    }    
    else {
        $date5search = "";
        $date6search = "";
    }

    if (isset($_POST["date7search"]) && isset($_POST["date8search"])){
        $date7search = $_POST["date7search"];
        $date8search = $_POST["date8search"];
    }    
    else {
        $date7search = "";
        $date8search = "";
    }

    if (isset($_POST["cusn"])){
        $cusn = $_POST["cusn"];
    }    
    else {
        $cusn = NULL;
    }

    if (isset($_POST["cpnn"])){
        $cpnn = $_POST["cpnn"];
    }    
    else {
        $cpnn = NULL;
    }

    if (isset($_POST["reqn"])){
        $reqn = $_POST["reqn"];
    }    
    else {
        $reqn = NULL;
    }

    if (isset($_POST["recn"])){
        $recn = $_POST["recn"];
    }    
    else {
        $recn = NULL;
    }

    if (isset($_POST["senn"])){
        $senn = $_POST["senn"];
    }    
    else {
        $senn = NULL;
    }

    if (isset($_POST["sign"])){
        $sign = $_POST["sign"];
    }    
    else {
        $sign = NULL;
    }

    $descError = NULL;
    $custError = NULL;
    $NocpnError = NULL;
    $ReceivedDateError = NULL;
    $RecSentDateError = NULL;
    $SentDateError = NULL;
    $cpnError = NULL;
    $dcError = NULL;
    $ecError = NULL;
    $etpnError = NULL;
    $noteData = NULL;
    $cableData = NULL;
    $cableDataD = NULL;
    $Deleted = NULL;

    $pdo = new PDO("mysql:host=localhost;dbname=eurotechdb", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        if (isset($_POST['note'])) {
            $id = $_POST['IDnote'];
            $stmt = $pdo->prepare("SELECT CAB_PPAP_ID, PSW_ET, IMDS_ET FROM cables_ppap WHERE CAB_PPAP_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $noteData = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmNote'])) {
            if(!isset($_POST['PSW_ET']) &&  !isset($_POST['IMDS_ET'])) {
                $stmt = $pdo->prepare("UPDATE cables_ppap SET 
                                        PSW_ET = NULL, 
                                        IMDS_ET = NULL 
                                        WHERE CAB_PPAP_ID = ?");

                $stmt->execute([
                    $_POST['confirmIDNote']
                ]);
            }
            if(!isset($_POST['PSW_ET']) && isset($_POST['IMDS_ET'])) {
                $stmt = $pdo->prepare("UPDATE cables_ppap SET 
                                        PSW_ET = NULL, 
                                        IMDS_ET = '1' 
                                        WHERE CAB_PPAP_ID = ?");

                $stmt->execute([
                    $_POST['confirmIDNote']
                ]);
            }
            if(isset($_POST['PSW_ET']) && !isset($_POST['IMDS_ET'])) {
                $stmt = $pdo->prepare("UPDATE cables_ppap SET 
                                        PSW_ET = '1', 
                                        IMDS_ET = NULL
                                        WHERE CAB_PPAP_ID = ?");

                $stmt->execute([
                    $_POST['confirmIDNote']
                ]);
            }
            if(isset($_POST['PSW_ET']) && isset($_POST['IMDS_ET']) ) {
                $stmt = $pdo->prepare("UPDATE cables_ppap SET 
                                        PSW_ET = '1', 
                                        IMDS_ET = '1'
                                        WHERE CAB_PPAP_ID = ?");

                $stmt->execute([
                    $_POST['confirmIDNote']
                ]);
            } 
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['confirmID'])) {
            $stmt = $pdo->prepare("SELECT CAB_Eurotech_PN FROM cables WHERE `Description` = ?");
            $stmt->execute([
                $_POST['Description']
            ]);
            $etpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT `Name` FROM cables_customer WHERE `Name` = ?");
            $stmt->execute([
                $_POST['Name']
            ]);
            $cn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($etpn != NULL && $cn != NULL) {
                foreach ($etpn as $pn) {
                    $stmt = $pdo->prepare("SELECT ccpn.CAB_Customer_PN FROM cables_customer_pn ccpn
                                                INNER JOIN cables_customer cc ON ccpn.FK_CAB_Customer_ID = cc.CAB_Customer_ID
                                                WHERE ccpn.FK_CAB_Eurotech_PN = ? AND cc.`Name` = ?");
                    $stmt->execute([
                        $pn,
                        $_POST['Name']
                    ]);
                    $cpn = $stmt->fetchAll(PDO::FETCH_COLUMN);
                }

                if($cpn != NULL) {
                    foreach ($cpn as $c) {
                        if($_POST['PPAP_Received_Date'] == "" && $_POST['PPAP_Sent_Date'] == "" && $_POST['PPAP_Signed_Date'] == "") {
                            $stmt = $pdo->prepare("INSERT INTO cables_ppap (FK_CAB_Customer_PN, PPAP_Requested_Date) 
                                                VALUES (?, ?)");
                            $stmt->execute([
                                $c,
                                $_POST['PPAP_Requested_Date']
                            ]);
                        }
                        if($_POST['PPAP_Received_Date'] != "" && $_POST['PPAP_Sent_Date'] == "" && $_POST['PPAP_Signed_Date'] == "") {
                            $stmt = $pdo->prepare("INSERT INTO cables_ppap (FK_CAB_Customer_PN, PPAP_Requested_Date, PPAP_Received_Date) 
                                                VALUES (?, ?, ?)");
                            $stmt->execute([
                                $c,
                                $_POST['PPAP_Requested_Date'],
                                $_POST['PPAP_Received_Date']
                            ]);
                        }
                        if($_POST['PPAP_Received_Date'] != "" && $_POST['PPAP_Sent_Date'] != "" && $_POST['PPAP_Signed_Date'] == "") {
                            $stmt = $pdo->prepare("INSERT INTO cables_ppap (FK_CAB_Customer_PN, PPAP_Requested_Date, PPAP_Received_Date, PPAP_Sent_Date) 
                                                VALUES (?, ?, ?, ?)");
                            $stmt->execute([
                                $c,
                                $_POST['PPAP_Requested_Date'],
                                $_POST['PPAP_Received_Date'],
                                $_POST['PPAP_Sent_Date']
                            ]);
                        }
                        if($_POST['PPAP_Received_Date'] != "" && $_POST['PPAP_Sent_Date'] != "" && $_POST['PPAP_Signed_Date'] != "") {
                            $stmt = $pdo->prepare("INSERT INTO cables_ppap (FK_CAB_Customer_PN, PPAP_Requested_Date, PPAP_Received_Date, PPAP_Sent_Date, PPAP_Signed_Date) 
                                                VALUES (?, ?, ?, ?, ?)");
                            $stmt->execute([
                                $c,
                                $_POST['PPAP_Requested_Date'],
                                $_POST['PPAP_Received_Date'],
                                $_POST['PPAP_Sent_Date'],
                                $_POST['PPAP_Signed_Date']
                            ]);
                        }
                        if(($_POST['PPAP_Received_Date'] == "" && $_POST['PPAP_Sent_Date'] != "" && $_POST['PPAP_Signed_Date'] == "") 
                            || ($_POST['PPAP_Received_Date'] == "" && $_POST['PPAP_Sent_Date'] != "" && $_POST['PPAP_Signed_Date'] != "")) {
                            $ReceivedDateError = 'Y';
                        }
                        if($_POST['PPAP_Received_Date'] == "" && $_POST['PPAP_Sent_Date'] == "" && $_POST['PPAP_Signed_Date'] != "") {
                            $RecSentDateError = 'Y';
                        }
                        if(($_POST['PPAP_Received_Date'] != "" && $_POST['PPAP_Sent_Date'] == "" && $_POST['PPAP_Signed_Date'] != "")) {
                            $SentDateError = 'Y';
                        }
                    }
                }
                else {
                    $NocpnError = 'Y';
                }
            }
            if($etpn == NULL && $cn != NULL) {
                $descError = 'Y';
            }
            if($etpn != NULL && $cn == NULL) {
                $custError = 'Y';
            }
            if($etpn == NULL && $cn == NULL) {
                $dcError = 'Y';
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['confirmIE'])) {
            $stmt = $pdo->prepare("SELECT CAB_Eurotech_PN FROM cables WHERE CAB_Eurotech_PN = ?");
            $stmt->execute([
                $_POST['CAB_Eurotech_PN']
            ]);
            $etpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT `Name` FROM cables_customer WHERE `Name` = ?");
            $stmt->execute([
                $_POST['Name']
            ]);
            $cn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($etpn != NULL && $cn != NULL) {
                foreach ($etpn as $pn) {
                    $stmt = $pdo->prepare("SELECT ccpn.CAB_Customer_PN FROM cables_customer_pn ccpn
                                                INNER JOIN cables_customer cc ON ccpn.FK_CAB_Customer_ID = cc.CAB_Customer_ID
                                                WHERE ccpn.FK_CAB_Eurotech_PN = ? AND cc.`Name` = ?");
                    $stmt->execute([
                        $pn,
                        $_POST['Name']
                    ]);
                    $cpn = $stmt->fetchAll(PDO::FETCH_COLUMN);
                }

                if($cpn != NULL) {
                    foreach ($cpn as $c) {
                        if($_POST['PPAP_Received_Date'] == "" && $_POST['PPAP_Sent_Date'] == "" && $_POST['PPAP_Signed_Date'] == "") {
                            $stmt = $pdo->prepare("INSERT INTO cables_ppap (FK_CAB_Customer_PN, PPAP_Requested_Date) 
                                                VALUES (?, ?)");
                            $stmt->execute([
                                $c,
                                $_POST['PPAP_Requested_Date']
                            ]);
                        }
                        if($_POST['PPAP_Received_Date'] != "" && $_POST['PPAP_Sent_Date'] == "" && $_POST['PPAP_Signed_Date'] == "") {
                            $stmt = $pdo->prepare("INSERT INTO cables_ppap (FK_CAB_Customer_PN, PPAP_Requested_Date, PPAP_Received_Date) 
                                                VALUES (?, ?, ?)");
                            $stmt->execute([
                                $c,
                                $_POST['PPAP_Requested_Date'],
                                $_POST['PPAP_Received_Date']
                            ]);
                        }
                        if($_POST['PPAP_Received_Date'] != "" && $_POST['PPAP_Sent_Date'] != "" && $_POST['PPAP_Signed_Date'] == "") {
                            $stmt = $pdo->prepare("INSERT INTO cables_ppap (FK_CAB_Customer_PN, PPAP_Requested_Date, PPAP_Received_Date, PPAP_Sent_Date) 
                                                VALUES (?, ?, ?, ?)");
                            $stmt->execute([
                                $c,
                                $_POST['PPAP_Requested_Date'],
                                $_POST['PPAP_Received_Date'],
                                $_POST['PPAP_Sent_Date']
                            ]);
                        }
                        if($_POST['PPAP_Received_Date'] != "" && $_POST['PPAP_Sent_Date'] != "" && $_POST['PPAP_Signed_Date'] != "") {
                            $stmt = $pdo->prepare("INSERT INTO cables_ppap (FK_CAB_Customer_PN, PPAP_Requested_Date, PPAP_Received_Date, PPAP_Sent_Date, PPAP_Signed_Date) 
                                                VALUES (?, ?, ?, ?, ?)");
                            $stmt->execute([
                                $c,
                                $_POST['PPAP_Requested_Date'],
                                $_POST['PPAP_Received_Date'],
                                $_POST['PPAP_Sent_Date'],
                                $_POST['PPAP_Signed_Date']
                            ]);
                        }
                        if(($_POST['PPAP_Received_Date'] == "" && $_POST['PPAP_Sent_Date'] != "" && $_POST['PPAP_Signed_Date'] == "") 
                            || ($_POST['PPAP_Received_Date'] == "" && $_POST['PPAP_Sent_Date'] != "" && $_POST['PPAP_Signed_Date'] != "")) {
                            $ReceivedDateError = 'Y';
                        }
                        if($_POST['PPAP_Received_Date'] == "" && $_POST['PPAP_Sent_Date'] == "" && $_POST['PPAP_Signed_Date'] != "") {
                            $RecSentDateError = 'Y';
                        }
                        if($_POST['PPAP_Received_Date'] != "" && $_POST['PPAP_Sent_Date'] == "" && $_POST['PPAP_Signed_Date'] != "") {
                            $SentDateError = 'Y';
                        }
                    }
                }
                else {
                    $NocpnError = 'Y';
                }
            }
            if($etpn == NULL && $cn != NULL) {
                $etpnError = 'Y';
            }
            if($etpn != NULL && $cn == NULL) {
                $custError = 'Y';
            }
            if($etpn == NULL && $cn == NULL) {
                $ecError = 'Y';
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['confirmIC'])) {
            $stmt = $pdo->prepare("SELECT CAB_Customer_PN FROM cables_customer_pn WHERE CAB_Customer_PN = ?");
            $stmt->execute([
                $_POST['CAB_Customer_PN']
            ]);
            $cpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($cpn != NULL) {
                foreach ($cpn as $c) {
                    if($_POST['PPAP_Received_Date'] == "" && $_POST['PPAP_Sent_Date'] == "" && $_POST['PPAP_Signed_Date'] == "") {
                        $stmt = $pdo->prepare("INSERT INTO cables_ppap (FK_CAB_Customer_PN, PPAP_Requested_Date) 
                                                VALUES (?, ?)");
                        $stmt->execute([
                            $c,
                            $_POST['PPAP_Requested_Date']
                        ]);
                    }
                    if($_POST['PPAP_Received_Date'] != "" && $_POST['PPAP_Sent_Date'] == "" && $_POST['PPAP_Signed_Date'] == "") {
                        $stmt = $pdo->prepare("INSERT INTO cables_ppap (FK_CAB_Customer_PN, PPAP_Requested_Date, PPAP_Received_Date) 
                                                VALUES (?, ?, ?)");
                        $stmt->execute([
                            $c,
                            $_POST['PPAP_Requested_Date'],
                            $_POST['PPAP_Received_Date']
                        ]);
                    }
                    if($_POST['PPAP_Received_Date'] != "" && $_POST['PPAP_Sent_Date'] != "" && $_POST['PPAP_Signed_Date'] == "") {
                        $stmt = $pdo->prepare("INSERT INTO cables_ppap (FK_CAB_Customer_PN, PPAP_Requested_Date, PPAP_Received_Date, PPAP_Sent_Date) 
                                                VALUES (?, ?, ?, ?)");
                        $stmt->execute([
                            $c,
                            $_POST['PPAP_Requested_Date'],
                            $_POST['PPAP_Received_Date'],
                            $_POST['PPAP_Sent_Date']
                        ]);
                    }
                    if($_POST['PPAP_Received_Date'] != "" && $_POST['PPAP_Sent_Date'] != "" && $_POST['PPAP_Signed_Date'] != "") {
                        $stmt = $pdo->prepare("INSERT INTO cables_ppap (FK_CAB_Customer_PN, PPAP_Requested_Date, PPAP_Received_Date, PPAP_Sent_Date, PPAP_Signed_Date) 
                                                VALUES (?, ?, ?, ?, ?)");
                        $stmt->execute([
                            $c,
                            $_POST['PPAP_Requested_Date'],
                            $_POST['PPAP_Received_Date'],
                            $_POST['PPAP_Sent_Date'],
                            $_POST['PPAP_Signed_Date']
                        ]);
                    }
                    if(($_POST['PPAP_Received_Date'] == "" && $_POST['PPAP_Sent_Date'] != "" && $_POST['PPAP_Signed_Date'] == "") 
                            || ($_POST['PPAP_Received_Date'] == "" && $_POST['PPAP_Sent_Date'] != "" && $_POST['PPAP_Signed_Date'] != "")) {
                            $ReceivedDateError = 'Y';
                        }
                        if($_POST['PPAP_Received_Date'] == "" && $_POST['PPAP_Sent_Date'] == "" && $_POST['PPAP_Signed_Date'] != "") {
                            $RecSentDateError = 'Y';
                        }
                        if($_POST['PPAP_Received_Date'] != "" && $_POST['PPAP_Sent_Date'] == "" && $_POST['PPAP_Signed_Date'] != "") {
                            $SentDateError = 'Y';
                        }
                }
            }
            else {
                $cpnError = 'Y';
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['edit'])) {
            $id = $_POST['IDedit'];
            $stmt = $pdo->prepare("SELECT CAB_PPAP_ID, PPAP_Requested_Date, PPAP_Received_Date, PPAP_Sent_Date, PPAP_Signed_Date FROM cables_ppap WHERE CAB_PPAP_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $cableData = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmU'])) {
            if($_POST['PPAP_Requested_Date'] != "") {
                $reqD = new DateTime($_POST['PPAP_Requested_Date']);
            }
            if($_POST['PPAP_Received_Date'] != "") {
                $recD = new DateTime($_POST['PPAP_Received_Date']);
            }
            if($_POST['PPAP_Sent_Date'] != "") {
                $senD = new DateTime($_POST['PPAP_Sent_Date']);
            }
            if($_POST['PPAP_Signed_Date'] != "") {
                $sigD = new DateTime($_POST['PPAP_Signed_Date']);
            }

            if($_POST['PPAP_Received_Date'] == "" && $_POST['PPAP_Sent_Date'] == "" && $_POST['PPAP_Signed_Date'] == "") {
                $stmt = $pdo->prepare("UPDATE cables_ppap SET 
                                        PPAP_Requested_Date = ?, 
                                        PPAP_Received_Date = NULL, 
                                        PPAP_Sent_Date = NULL, 
                                        PPAP_Signed_Date = NULL
                                        WHERE CAB_PPAP_ID = ?");

                $stmt->execute([
                    $reqD->format('Y-m-d'),
                    $_POST['CAB_PPAP_ID']
                ]);
            }
            if($_POST['PPAP_Received_Date'] != "" && $_POST['PPAP_Sent_Date'] == "" && $_POST['PPAP_Signed_Date'] == "")  {
                $stmt = $pdo->prepare("UPDATE cables_ppap SET 
                                        PPAP_Requested_Date = ?, 
                                        PPAP_Received_Date = ?, 
                                        PPAP_Sent_Date = NULL, 
                                        PPAP_Signed_Date = NULL
                                        WHERE CAB_PPAP_ID = ?");

                $stmt->execute([
                    $reqD->format('Y-m-d'),
                    $recD->format('Y-m-d'),
                    $_POST['CAB_PPAP_ID']
                ]);
            }
            if($_POST['PPAP_Received_Date'] != "" && $_POST['PPAP_Sent_Date'] != "" && $_POST['PPAP_Signed_Date'] == "") {
                $stmt = $pdo->prepare("UPDATE cables_ppap SET 
                                        PPAP_Requested_Date = ?, 
                                        PPAP_Received_Date = ?, 
                                        PPAP_Sent_Date = ?, 
                                        PPAP_Signed_Date = NULL
                                        WHERE CAB_PPAP_ID = ?");

                $stmt->execute([
                    $reqD->format('Y-m-d'),
                    $recD->format('Y-m-d'),
                    $senD->format('Y-m-d'),
                    $_POST['CAB_PPAP_ID']
                ]);
            }
            if($_POST['PPAP_Received_Date'] && $_POST['PPAP_Sent_Date'] != "" && $_POST['PPAP_Signed_Date'] != "")  {
                $stmt = $pdo->prepare("UPDATE cables_ppap SET 
                                        PPAP_Requested_Date = ?, 
                                        PPAP_Received_Date = ?, 
                                        PPAP_Sent_Date = ?, 
                                        PPAP_Signed_Date = ?
                                        WHERE CAB_PPAP_ID = ?");

                $stmt->execute([
                    $reqD->format('Y-m-d'),
                    $recD->format('Y-m-d'),
                    $senD->format('Y-m-d'),
                    $sigD->format('Y-m-d'),
                    $_POST['CAB_PPAP_ID']
                ]);
            }
            if(($_POST['PPAP_Received_Date'] == "" && $_POST['PPAP_Sent_Date'] != "" && $_POST['PPAP_Signed_Date'] == "") 
                || ($_POST['PPAP_Received_Date'] == "" && $_POST['PPAP_Sent_Date'] != "" && $_POST['PPAP_Signed_Date'] != "")) {
                $ReceivedDateError = 'Y';
            }
            if($_POST['PPAP_Received_Date'] == "" && $_POST['PPAP_Sent_Date'] == "" && $_POST['PPAP_Signed_Date'] != "") {
                $RecSentDateError = 'Y';
            }
            if($_POST['PPAP_Received_Date'] != "" && $_POST['PPAP_Sent_Date'] == "" && $_POST['PPAP_Signed_Date'] != "") {
                $SentDateError = 'Y';
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['delete'])) {
            $id = $_POST['IDdelete'];
            $stmt = $pdo->prepare("SELECT 
                            CAB_PPAP_ID,
                            CAB_Eurotech_PN,
                            Coroflex_PN,
                            CAB_Customer_PN, 
                            `Description`,
                            PPAP_Requested_Date,
                            PPAP_Received_Date,
                            PPAP_Sent_Date,
                            PPAP_Signed_Date,
                            `Name`
                        FROM cables ca
                            LEFT JOIN cables_customer_pn ccp ON ccp.FK_CAB_Eurotech_PN = ca.CAB_Eurotech_PN
                            LEFT JOIN cables_ppap p ON ccp.CAB_Customer_PN = p.FK_CAB_Customer_PN
                            LEFT JOIN cables_customer c ON ccp.FK_CAB_Customer_ID = c.CAB_Customer_ID
                        WHERE CAB_PPAP_ID = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $cableDataD = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmD'])) {
            $id = $_POST['IDdelete'];
            $stmt = $pdo->prepare("DELETE FROM cables_ppap
                                    WHERE CAB_PPAP_ID = ?");

            $stmt->execute([
                $id
            ]);
           
            $Deleted = 'Y';

            $_SESSION['saved'] = true;
        }
    }

    $Customers = $model->searchCustomers();
    $ETPNS = $model->searchETPN();
    $COPNS = $model->searchCOPN();
    $CPNS = $model->searchCPN();
    $Descs = $model->searchDesc();
    $logs = $model->search();

    include 'view.php';
?>