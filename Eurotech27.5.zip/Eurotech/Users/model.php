<?php
    class model {                                        

        public  $mbd;
        
        function cn() {
            $this->mbd = new PDO('mysql:host=localhost;dbname=eurotechdb;port=3306', 'root', '');
            $this->mbd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
        }
    
        function search(){
            $logs = [];
            if (isset($_POST['btnsearch'])) {
                if (!empty($_POST['usersearch'])|| !empty($_POST['rolesearch'])) {
                    $where = [];
                    $params = [];

                    if (!empty($_POST['usersearch'])) {
                        $where[] = "Username LIKE :user";
                        $params[':user'] = $_POST['usersearch']."%";
                    }

                    if (!empty($_POST['rolesearch'])) {
                        $where[] = "Role = :role";
                        $params[':role'] = $_POST['rolesearch'];
                    }

                    if(!empty($where)) {
                        $sql = "
                        SELECT 
                            *
                        FROM users
                        WHERE " . implode(' AND ', $where) . "
                        ORDER BY Username;";
                    }
                    else {
                        $sql = "
                        SELECT 
                            *
                        FROM users
                        ORDER BY Username;";
                    }

                    $stmt = $this->mbd->prepare($sql);
                    $stmt->execute($params);

                    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
                else {
                    foreach ($this->mbd->query(
                        "SELECT 
                            *
                        FROM users
                        ORDER BY Username;"
                    ) as $log) {
                        $logs[] = $log;
                    }
                }
            } else {
                foreach ($this->mbd->query(
                    "SELECT 
                        *
                    FROM users
                    ORDER BY Username;"
                ) as $log) {
                    $logs[] = $log;
                }
            }
            return $logs;
        }

        function searchUsernames(){
            $Usernames = [];
                foreach ($this->mbd->query(
                    "SELECT
                        Username
                    FROM users
                    ORDER BY Username;"
                ) as $Username) {
                    $Usernames[] = $Username;
                }
            return $Usernames;
        }

        function searchRoles(){
            $Roles = [];
                foreach ($this->mbd->query(
                    "SELECT DISTINCT
                        `Role`
                    FROM users
                    ORDER BY `Role`;"
                ) as $Role) {
                    $Roles[] = $Role;
                }
            return $Roles;
        }
    }
?>