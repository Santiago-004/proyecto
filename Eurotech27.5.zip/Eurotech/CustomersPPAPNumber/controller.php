<?php 
    include "model.php";

    $model = new model();
    $model->cn();
    $logs = [];
    
    if (isset($_POST["idsearch"])){
        $idsearch = $_POST["idsearch"];
    }    
    else {
        $idsearch = NULL;
    }

    if (isset($_POST["custsearch"])){
        $custsearch = $_POST["custsearch"];
    }    
    else {
        $custsearch = NULL;
    }

    if (isset($_POST["counsearch"])){
        $counsearch = $_POST["counsearch"];
    }    
    else {
        $counsearch = NULL;
    }

    $cpnData = NULL;
    $cpnDataD = NULL;
    $Deleted = NULL;

    $pdo = new PDO("mysql:host=localhost;dbname=eurotechdb", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        if (isset($_POST['confirmI'])) {
            $stmt = $pdo->prepare("SELECT Customer_PPAP_Number FROM customer_ppap_number WHERE Customer_PPAP_Number = ?");
            $stmt->execute([
                $_POST['Customer_PPAP_Number']
            ]);
            $cpn = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT Customer_ID FROM customers WHERE `Name` = ?");
            $stmt->execute([
                $_POST['Name']
            ]);
            $customer = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT `Name`, Country FROM customer_ppap_number cpn
                                    INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                    WHERE `Name` = ? AND Country = ?");
            $stmt->execute([
                $_POST['Name'],
                $_POST['Country']
            ]);
            $ce = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($cpn == NULL && $customer == NULL && $ce == NULL) {
                $_POST['insert'] = 1;
                $error = "The customer <b>".$_POST['Name']."</b> doesn't exists.";
            }
            if($cpn != NULL && $customer == NULL && $ce == NULL) {
                $_POST['insert'] = 1;
                $error = "The Customer PPAP Number <b>".$_POST['Customer_PPAP_Number']."</b> already exists and the customer <b>".$_POST['Name']."</b> doesn't exists.";
            }
            if($cpn == NULL && $customer != NULL && $ce == NULL) {
                    $stmt = $pdo->prepare("INSERT INTO customer_ppap_number (Customer_PPAP_Number, FK_Customer_ID, Country) 
                                            VALUES (?, ?, ?)");
                    $stmt->execute([
                        $_POST['Customer_PPAP_Number'],
                        $customer[0],
                        $_POST['Country']
                    ]);
            }
            if($cpn != NULL && $customer != NULL && $ce == NULL) {
                $_POST['insert'] = 1;
                $error = "The Customer PPAP Number <b>".$_POST['Customer_PPAP_Number']."</b> already exists.";
            }
            if($cpn == NULL && $customer != NULL && $ce != NULL) {
                $_POST['insert'] = 1;
                $error = "A Customer PN already exists for the customer <b>".$_POST['Name']."</b> and the country <b>".$_POST['Country']."</b>.";
            }
            if($cpn != NULL && $customer != NULL && $ce != NULL) {
                $_POST['insert'] = 1;
                $error = "A Customer PN already exists for the customer <b>".$_POST['Name']."</b> and the country <b>".$_POST['Country']."</b> and the Customer PPAP Number <b>".$_POST['Customer_PPAP_Number']."</b> already exists.";
            }

            $_SESSION['saved'] = true;
        }

        if (isset($_POST['edit'])) {
            $id = $_POST['IDedit'];
            $stmt = $pdo->prepare("SELECT * FROM customer_ppap_number cpn
                INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                WHERE Customer_PPAP_Number = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $cpnData = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmU'])) {
            $stmt = $pdo->prepare("SELECT Customer_ID FROM customers WHERE `Name` = ?");
            $stmt->execute([
                $_POST['Name']
            ]);
            $customer = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $stmt = $pdo->prepare("SELECT `Name`, Country FROM customer_ppap_number cpn
                                    INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                                    WHERE `Name` = ? AND Country = ? AND Customer_PPAP_Number != ?");
            $stmt->execute([
                $_POST['Name'],
                $_POST['Country'],
                $_POST['Customer_PPAP_Number']
            ]);
            $ce = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if($customer == NULL && $ce == NULL) {
                $_POST['edit'] = 1;
                $error = "The customer <b>".$_POST['Name']."</b> doesn't exists.";
            }
            if($customer != NULL && $ce == NULL) {
                    $stmt = $pdo->prepare("UPDATE customer_ppap_number SET 
                                                FK_Customer_ID = ?, 
                                                Country = ? 
                                            WHERE Customer_PPAP_Number = ?");
                    $stmt->execute([
                        $customer[0],
                        $_POST['Country'],
                        $_POST['Customer_PPAP_Number']
                    ]);
            }
            if($customer != NULL && $ce != NULL) {
                $_POST['edit'] = 1;
                $error = "A Customer PPAP Number already exists for the customer <b>".$_POST['Name']."</b> and the country <b>".$_POST['Country']."</b>.";
            }
           
            $_SESSION['saved'] = true;
        }

        if (isset($_POST['delete'])) {
            $id = $_POST['IDdelete'];
            $stmt = $pdo->prepare("SELECT * FROM customer_ppap_number cpn
                INNER JOIN customers c ON cpn.FK_Customer_ID = c.Customer_ID
                WHERE Customer_PPAP_Number = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $cpnDataD = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }

        if (isset($_POST['confirmD'])) {
            $id = $_POST['Customer_PPAP_Number'];

            $stmt = $pdo->prepare("DELETE FROM customer_ppap_number
                                        WHERE Customer_PPAP_Number = ?");

            $stmt->execute([$id]);
            
            $Deleted = 'Y';

            $_SESSION['saved'] = true;
        }
    }
    
    
    $CPNs = $model->searchCPN();
    $Customers = $model->searchCustomers();
    $Countries = $model->searchCountries();
    $logs = $model->search();

    include 'view.php';
?>