<link href="./css/style.css" rel="stylesheet">
<style>
    .clear {
        color: white;
        padding: 8px 14px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
        transition: background-color 0.2s;
        font-size: 14px;
        background-color: #16bacfff;
    }

    .error {
        background-color: #ffe6e6;
        color: #d63031;
        padding: 10px;
        border-radius: 8px;
        margin-bottom: 15px;
        font-size: 0.9rem;
    }

    .clear:hover {
        background-color: #1dd1e8ff;
        color: white;
    }

    .form-search .camp {
        flex: 1 1 20%;
        min-width: 250px;
    }

    .form-search input[type="date"],
    .form-search input[type="number"]{
        padding: 8px 10px;
        border: 1px solid #bbb;
        border-radius: 8px;
        box-sizing: border-box;
        width: 46%;
    }


    @media (max-width: 1453px) {
        .form-search .camp {
            flex: 1 1 40%; 
            min-width: 300px;
        }
    }
</style>
<form action="" id="form" method="post" class="form-search">
    <input type="hidden" name="page" value="Tubes">
    <div class="camp">
        <label>Days to Submit:</label>
        <input type="number" name="submit1search" value="<?php if ($submit1search != NULL) { echo $submit1search;} ?>"> -
        <input type="number" name="submit2search" value="<?php if ($submit2search != NULL) { echo $submit2search;} ?>">
    </div>
    
    <div class="camp">
        <label>PPAP Number:</label>
        <input type="text" name="ppapnsearch" maxlength="10" list="PPAPN" value="<?php if ($ppapnsearch != NULL) { echo $ppapnsearch;} ?>">
        <datalist id="PPAPN">
            <?php foreach ($PPAPNS as $PPAPN) {  ?>
                <option value="<?php echo $PPAPN['PPAP_Number'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>PPAP Req'd by Customer:</label>
        <input type="date" name="req1search" value="<?php if ($req1search != NULL) { echo $req1search;} ?>"> - <input type="date" name="req2search" value="<?php if ($req2search != NULL) { echo $req2search;} ?>">
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="reqn" id="" value="" <?php if ($reqn != "N" && $reqn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="reqn" id="" value="N" <?php if ($reqn == "N") { echo "checked";} ?>> No date
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="reqn" id="" value="Y" <?php if ($reqn == "Y") { echo "checked";} ?>> W/ date
    </div>
    
    <div class="camp">
        <label>Current Status:</label>
        <input type="text" name="currentsearch" maxlength="255" list="Current" value="<?php  if ($currentsearch != NULL) { echo $currentsearch;} ?>">
        <datalist id="Current">
            <?php foreach ($Currents as $Current) {  ?>
                <option value="<?php echo $Current['Current_Status'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="curn" id="" value="" <?php if ($curn != "N" && $curn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="curn" id="" value="N" <?php if ($curn == "N") { echo "checked";} ?>> No current status
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="curn" id="" value="Y" <?php if ($curn == "Y") { echo "checked";} ?>> W/ current status
    </div>

    <div class="camp">
        <label>Vendor:</label>
        <input type="text" name="pisearch" maxlength="5" list="PI" value="<?php if ($pisearch != NULL) { echo $pisearch;} ?>">
        <datalist id="PI">
            <?php foreach ($PIS as $PI) {  ?>
                <option value="<?php echo $PI['Short_name'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Customer:</label>
        <input type="text" name="custsearch" maxlength="70" list="Customer" value="<?php if ($custsearch != NULL) { echo $custsearch;} ?>">
        <datalist id="Customer">
            <?php foreach ($Customers as $Customer) {  ?>
                <option value="<?php echo $Customer['Name'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Country:</label>
        <input type="text" name="countrysearch" maxlength="30" list="Country" value="<?php if ($countrysearch != NULL) { echo $countrysearch;} ?>">
        <datalist id="Country">
            <?php foreach ($Countries as $Country) {  ?>
                <option value="<?php echo $Country['Country'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Customer PN:</label>
        <input type="text" name="cpnsearch" maxlength="30" list="CPN" value="<?php if ($cpnsearch != NULL) { echo $cpnsearch;} ?>">
        <datalist id="CPN">
            <?php foreach ($CPNS as $CPN) {  ?>
                <option value="<?php echo $CPN['TUB_Customer_PN'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>ET Model:</label>
        <input type="text" name="etmsearch" maxlength="10" list="ETM" value="<?php if ($etmsearch != NULL) { echo $etmsearch;} ?>">
        <datalist id="ETM">
            <?php foreach ($ETMS as $ETM) {  ?>
                <option value="<?php echo $ETM['ET_Model'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>ET Dwg:</label>
        <input type="text" name="etdsearch" maxlength="8" list="ETD" value="<?php if ($etdsearch != NULL) { echo $etdsearch;} ?>">
        <datalist id="ETD">
            <?php foreach ($ETDS as $ETD) {  ?>
                <option value="<?php echo $ETD['ET_Dwg'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Rev:</label>
        <input type="text" name="revsearch" maxlength="5" list="Rev" value="<?php if ($revsearch != NULL) { echo $revsearch;} ?>">
        <datalist id="Rev">
            <?php foreach ($Revs as $Rev) {  ?>
                <option value="<?php echo $Rev['Rev'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>ET PN:</label>
        <input type="text" name="etpnsearch" maxlength="10" list="ETPN" value="<?php if ($etpnsearch != NULL) { echo $etpnsearch;} ?>">
        <datalist id="ETPN">
            <?php foreach ($ETPNS as $ETPN) {  ?>
                <option value="<?php echo $ETPN['TUB_Eurotech_PN'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Description:</label>
        <input type="text" name="descsearch" maxlength="255" list="Desc" value="<?php if ($descsearch != NULL) { echo $descsearch;} ?>">
        <datalist id="Desc">
            <?php foreach ($Descs as $Desc) {  ?>
                <option value="<?php echo $Desc['Description'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp"></div>

    <div class="camp">
        <label>IMDS Number:</label>
        <input type="text" name="imdssearch" maxlength="15" list="IMDS" value="<?php if ($imdssearch != NULL) { echo $imdssearch;} ?>">
        <datalist id="IMDS">
            <?php foreach ($IMDS as $IM) {  ?>
                <option value="<?php echo $IM['IMDS_Number'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="imdn" id="" value="" <?php if ($imdn != "N" && $imdn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="imdn" id="" value="N" <?php if ($imdn == "N") { echo "checked";} ?>> No IMDS Number
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="imdn" id="" value="Y" <?php if ($imdn == "Y") { echo "checked";} ?>> W/ IMDS Number
    </div>

    <div class="camp">
        <label>IMDS Status:</label>
        <input type="text" name="issearch" maxlength="10" list="IS" value="<?php if ($issearch != NULL) { echo $issearch;} ?>">
        <datalist id="IS">
            <?php foreach ($ISS as $IS) {  ?>
                <option value="<?php echo $IS['IMDS_Status'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="imsn" id="" value="" <?php if ($imsn != "N" && $imsn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="imsn" id="" value="N" <?php if ($imsn == "N") { echo "checked";} ?>> No IMDS status
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="imsn" id="" value="Y" <?php if ($imsn == "Y") { echo "checked";} ?>> W/ IMDS status
    </div>

    <div class="camp">
        <label>PPAP docs:</label>
        <input type="text" name="pdsearch" maxlength="15" list="PD" value="<?php if ($pdsearch != NULL) { echo $pdsearch;} ?>">
        <datalist id="PD">
            <?php foreach ($PDS as $PD) {  ?>
                <option value="<?php echo $PD['PPAP_docs'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="ppdn" id="" value="" <?php if ($ppdn != "N" && $ppdn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="ppdn" id="" value="N" <?php if ($ppdn == "N") { echo "checked";} ?>> No PPAP docs
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="ppdn" id="" value="Y" <?php if ($ppdn == "Y") { echo "checked";} ?>> W/ PPAP docs
    </div>

    <div class="camp">
        <label>Level:</label>
        <input type="text" name="levelsearch" maxlength="3" list="Level" value="<?php if ($levelsearch != NULL) { echo $levelsearch;} ?>">
        <datalist id="Level">
            <?php foreach ($Levels as $Level) {  ?>
                <option value="<?php echo $Level['Level'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="lvln" id="" value="" <?php if ($lvln != "N" && $lvln != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="lvln" id="" value="N" <?php if ($lvln == "N") { echo "checked";} ?>> No level
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="lvln" id="" value="Y" <?php if ($lvln == "Y") { echo "checked";} ?>> W/ level
    </div>

    <div class="camp">
        <label>PPAP samples status:</label>
        <input type="text" name="psssearch" maxlength="9" list="PSS" value="<?php if ($psssearch != NULL) { echo $psssearch;} ?>">
        <datalist id="PSS">
            <?php foreach ($PSSS as $PSS) {  ?>
                <option value="<?php echo $PSS['Samples_Status'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="pssn" id="" value="" <?php if ($pssn != "N" && $pssn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pssn" id="" value="N" <?php if ($pssn == "N") { echo "checked";} ?>> No PPAP sample status
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pssn" id="" value="Y" <?php if ($pssn == "Y") { echo "checked";} ?>> W/ PPAP sample status
    </div>

    <div class="camp">
        <label>Reason of Submission:</label>
        <input type="text" name="rssearch" maxlength="20" list="RS" value="<?php if ($rssearch != NULL) { echo $rssearch;} ?>">
        <datalist id="RS">
            <?php foreach ($RSS as $RS) {  ?>
                <option value="<?php echo $RS['Reason_submission'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="rosn" id="" value="" <?php if ($rosn != "N" && $rosn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="rosn" id="" value="N" <?php if ($rosn == "N") { echo "checked";} ?>> No reason of submission
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="rosn" id="" value="Y" <?php if ($rosn == "Y") { echo "checked";} ?>> W/ reason of submission
    </div>

    <div class="camp">
        <label>Sent to Customer:</label>
        <input type="date" name="sent1search" value="<?php if ($sent1search != NULL) { echo $sent1search;} ?>"> - <input type="date" name="sent2search" value="<?php if ($sent2search != NULL) { echo $sent2search;} ?>">
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="stcn" id="" value="" <?php if ($stcn != "N" && $stcn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="stcn" id="" value="N" <?php if ($stcn == "N") { echo "checked";} ?>> No date
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="stcn" id="" value="Y" <?php if ($stcn == "Y") { echo "checked";} ?>> W/ date
    </div>

    <div class="camp">
        <label>PSW returned from Customer Signed:</label>
        <input type="date" name="psw1search" value="<?php if ($psw1search != NULL) { echo $psw1search;} ?>"> - <input type="date" name="psw2search" value="<?php if ($psw2search != NULL) { echo $psw2search;} ?>">
    </div>

    <div class="camp">
        <input style="margin: 15px 0px 0px 10px;" type="radio" name="pcsn" id="" value="" <?php if ($pcsn != "N" && $pcsn != "Y") { echo "checked";} ?> checked> All
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pcsn" id="" value="N" <?php if ($pcsn == "N") { echo "checked";} ?>> No date
        <br> <input style="margin: 0px 0px 0px 10px;" type="radio" name="pcsn" id="" value="Y" <?php if ($pcsn == "Y") { echo "checked";} ?>> W/ date
    </div>
    
    <div class="camp">
        <label>Origin from report:</label>
        <input type="radio" name="originsearch" value="" checked> All <br>
        <input type="radio" name="originsearch" value="N" <?php if ($originsearch == "N") { echo "checked";} ?>> No <br>
        <input type="radio" name="originsearch" value="Y" <?php if ($originsearch == "Y") { echo "checked";} ?>> Yes
    </div>

    <div class="camp">
        <label>Comments:</label>
        <input type="text" name="comsearch" maxlength="255" list="Com" value="<?php if ($comsearch != NULL) { echo $comsearch;} ?>">
        <datalist id="Com">
            <?php foreach ($Coms as $Com) {  ?>
                <option value="<?php echo $Com['Comments'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Inspection Report Number:</label>
        <input type="text" name="irnsearch" maxlength="10" list="IRN" value="<?php if ($irnsearch != NULL) { echo $irnsearch;} ?>">
        <datalist id="IRN">
            <?php foreach ($IRNS as $IRN) {  ?>
                <option value="<?php echo $IRN['Inspection_rep_numb'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp"></div>
    <div class="camp"></div>
    <div class="camp"></div>
    <div class="camp"></div>


    <div class="campbtn">
        <button type="submit" name="btnsearch" class="insert">Search</button>
        <button style="margin: 0px 0px 0px 15px;"  type="submit" name="btnsearch" class="clear" onclick="clearForm()">Clear All</button>
    </div>
</form>

<div style="display: flex;">
    <form action="?page=Tubes" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insertD" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="countrysearch" value="<?php if(isset($_POST['countrysearch'])) { echo $_POST['countrysearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">
        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
        <button type="submit" class="insert">New PPAP (Description)</button>
    </form>

    <form action="?page=Tubes" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insertET" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="countrysearch" value="<?php if(isset($_POST['countrysearch'])) { echo $_POST['countrysearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">
        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
        <button type="submit" class="insert">New PPAP (ET PN)</button>
    </form>

    <form action="?page=Tubes" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insertC" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="countrysearch" value="<?php if(isset($_POST['countrysearch'])) { echo $_POST['countrysearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">
        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
        <button type="submit" class="insert">New PPAP (Cust PN)</button>
    </form>
</div>

<?php if($logs == NULL) { ?>
    <br>
    <h1>No results.</h1>
<?php } ?>

<?php if($logs != NULL) { ?>
    <div class="table-responsive">
        <table class="table table-bordered" id="PPAP_table">
            <?php if($_SESSION["Role"] == 'Administrator') { ?>
                <tr>    
                    <th style="background-color:#1c18AA;"></th>
                    <th style="background-color:#1c18AA;"></th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(2, 'number')">Days to Submit</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(3, 'text')">PPAP Number</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(4, 'date')">PPAP Req'd by Customer</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(5, 'text')">Current Status</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(6, 'text')">Vendor</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(7, 'text')">Customer</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(8, 'text')">Country</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(9, 'text')">Customer PN</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(10, 'text')">ET Model</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(11, 'text')">ET Dwg</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(12, 'text')">Rev</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(13, 'text')">ET PN</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(14, 'text')">Description</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(15, 'text')">IMDS Number</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(16, 'text')">IMDS Status</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(17, 'text')">PPAP docs</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(18, 'text')">Level</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(19, 'text')">PPAP samples status</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(20, 'text')">Reason of Submission</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(21, 'date')">Sent to Customer</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(22, 'date')">PSW returned from Cust Signed</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(23, 'text')">Origin from report</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(24, 'text')">Comments</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(25, 'text')">Inspection Report Number</th>
                </tr>
            <?php }  
            else { ?>
                <tr>    
                    <th style="background-color:#1c18AA;"></th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(1, 'number')">Days to Submit</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(2, 'text')">PPAP Number</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(3, 'date')">PPAP Req'd by Customer</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(4, 'text')">Current Status</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(5, 'text')">Vendor</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(6, 'text')">Customer</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(7, 'text')">Country</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(8, 'text')">Customer PN</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(9, 'text')">ET Model</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(10, 'text')">ET Dwg</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(11, 'text')">Rev</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(12, 'text')">ET PN</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(13, 'text')">Description</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(14, 'text')">IMDS Number</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(15, 'text')">IMDS Status</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(16, 'text')">PPAP docs</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(17, 'text')">Level</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(18, 'text')">PPAP samples status</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(19, 'text')">Reason of Submission</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(20, 'date')">Sent to Customer</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(21, 'date')">PSW returned from Cust Signed</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(22, 'text')">Origin from report</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(23, 'text')">Comments</th>
                    <th style="background-color:#1c18AA; color:white" onclick="sortTable(24, 'text')">Inspection Report Number</th>
                </tr>
            <?php }
            
            foreach ($logs as $log) { ?>
                <tr>
                    <td style="text-align: center; vertical-align: middle;">
                        <form action="?page=Tubes" method="post" style="display:inline;">
                            <input type="hidden" name="edit" value="">
                            <input type="hidden" name="btnsearch" value="1">
                            <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                            <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                            <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                            <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                            <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                            <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                            <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                            <input type="hidden" name="countrysearch" value="<?php if(isset($_POST['countrysearch'])) { echo $_POST['countrysearch']; } ?>">
                            <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                            <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                            <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                            <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                            <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                            <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                            <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                            <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">
                            <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">
                            <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                            <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                            <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                            <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                            <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                            <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                            <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                            <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                            <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                            <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                            <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                            <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                            <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                            <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                            <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                            <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                            <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                            <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                            <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                            <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                            <input type="hidden" name="IDedit" value="<?php echo $log['TUB_PPAPS_ID']; ?>">
                            <button type="submit" class="editar">Edit</button>
                        </form>
                    </td>
                    <?php if($_SESSION["Role"] == 'Administrator') { ?>
                        <td style="text-align: center; vertical-align: middle;">
                            <form action="?page=Tubes" method="post" style="display:inline;">
                                <input type="hidden" name="delete" value="">
                                <input type="hidden" name="btnsearch" value="1">
                                <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
                                <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
                                <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
                                <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
                                <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
                                <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
                                <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
                                <input type="hidden" name="countrysearch" value="<?php if(isset($_POST['countrysearch'])) { echo $_POST['countrysearch']; } ?>">
                                <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
                                <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
                                <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
                                <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
                                <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
                                <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
                                <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
                                <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">
                                <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">
                                <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
                                <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
                                <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
                                <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
                                <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
                                <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
                                <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
                                <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
                                <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
                                <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
                                <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
                                <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
                                <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
                                <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
                                <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
                                <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
                                <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
                                <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
                                <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
                                <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
                                <input type="hidden" name="IDdelete" value="<?php echo $log['TUB_PPAPS_ID']; ?>">
                                <button type="submit" class="eliminar">Delete</button>
                            </form>
                        </td>
                    <?php } 
                    if($log['PPAP_Req_by_Cus_Date'] != NULL) { ?>
                        <?php if($log['Sent_Customer'] != NULL) { ?>
                            <?php if($log['PSW_Returned'] != NULL) { ?>
                                <td 
                                    <?php if($log['Days to Submit'] <= 18) { ?>
                                        style="background-color: rgba(0, 255, 0, 0.7);"
                                    <?php } 
                                    if($log['Days to Submit'] >= 19 && $log['Days to Submit'] <= 30) { ?>
                                        style="background-color: rgba(255, 255, 26, 0.7);"
                                    <?php } 
                                    if($log['Days to Submit'] >= 31) { ?>
                                        style="background-color: rgba(204, 0, 34, 0.8); color:white;"
                                    <?php } ?>
                                ><?php echo $log['Days to Submit']; ?></td>
                                <td style="background-color: rgba(12, 223, 12, 0.7);"><?php echo $log['PPAP_Number']; ?></td>
                                <?php if($log['PPAP_Req_by_Cus_Date'] != NULL) { 
                                    $reqDate = new DateTime($log['PPAP_Req_by_Cus_Date']); ?>
                                    <td style="background-color: rgba(12, 223, 12, 0.7);"><?php echo $reqDate->format('m/d/Y') ?></td>
                                <?php }
                                if($log['PPAP_Req_by_Cus_Date'] == NULL) { ?>
                                    <td style="background-color: rgba(12, 223, 12, 0.7);"></td>
                                <?php } ?>
                                <td style="background-color: rgba(12, 223, 12, 0.7);"><?php echo $log['Current_Status']; ?></td>
                                <td style="background-color: rgba(12, 223, 12, 0.7);"><?php echo $log['Short_name']; ?></td>
                                <td style="background-color: rgba(12, 223, 12, 0.7);"><?php echo $log['Name']; ?></td>
                                <td style="background-color: rgba(12, 223, 12, 0.7);"><?php echo $log['Country']; ?></td>
                                <td style="background-color: rgba(12, 223, 12, 0.7);"><?php echo $log['TUB_Customer_PN']; ?></td>
                                <td style="background-color: rgba(12, 223, 12, 0.7);"><?php echo $log['ET_Model']; ?></td>
                                <td style="background-color: rgba(12, 223, 12, 0.7);"><?php echo $log['ET_Dwg']; ?></td>
                                <td style="background-color: rgba(12, 223, 12, 0.7);"><?php echo $log['Rev']; ?></td>
                                <td style="background-color: rgba(12, 223, 12, 0.7);"><?php echo $log['TUB_Eurotech_PN']; ?></td>
                                <td style="background-color: rgba(12, 223, 12, 0.7);"><?php echo $log['Description']; ?></td>
                                <td style="background-color: rgba(12, 223, 12, 0.7);"><?php echo $log['IMDS_Number']; ?></td>
                                <td style="background-color: rgba(12, 223, 12, 0.7);"><?php echo $log['IMDS_Status']; ?></td>
                                <td style="background-color: rgba(12, 223, 12, 0.7);"><?php echo $log['PPAP_docs']; ?></td>
                                <td style="background-color: rgba(12, 223, 12, 0.7);"><?php echo $log['Level']; ?></td>
                                <td style="background-color: rgba(12, 223, 12, 0.7);"><?php echo $log['Samples_Status']; ?></td>
                                <td style="background-color: rgba(12, 223, 12, 0.7);"><?php echo $log['Reason_submission']; ?></td>
                                <?php if($log['Sent_Customer'] != NULL) { 
                                    $sentCust = new DateTime($log['Sent_Customer']); ?>
                                    <td style="background-color: rgba(12, 223, 12, 0.7);"><?php echo $sentCust->format('m/d/Y') ?></td>
                                <?php }
                                if($log['Sent_Customer'] == NULL) { ?>
                                    <td style="background-color: rgba(12, 223, 12, 0.7);"></td>
                                <?php } 
                                if($log['PSW_Returned'] != NULL) { 
                                    $pswRet = new DateTime($log['PSW_Returned']); ?>
                                    <td style="background-color: rgba(12, 223, 12, 0.7);"><?php echo $pswRet->format('m/d/Y') ?></td>
                                <?php }
                                if($log['PSW_Returned'] == NULL) { ?>
                                    <td style="background-color: rgba(12, 223, 12, 0.7);"></td>
                                <?php } 
                            } 
                            else { ?>
                                <td 
                                    <?php if($log['Days to Submit'] <= 18) { ?>
                                        style="background-color: rgba(0, 255, 0, 0.7);"
                                    <?php } 
                                    if($log['Days to Submit'] >= 19 && $log['Days to Submit'] <= 30) { ?>
                                        style="background-color: rgba(255, 255, 26, 0.7);"
                                    <?php } 
                                    if($log['Days to Submit'] >= 31) { ?>
                                        style="background-color: rgba(204, 0, 34, 0.8); color:white;"
                                    <?php } ?>
                                ><?php echo $log['Days to Submit']; ?></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['PPAP_Number']; ?></td>
                                <?php if($log['PPAP_Req_by_Cus_Date'] != NULL) { 
                                    $reqDate = new DateTime($log['PPAP_Req_by_Cus_Date']); ?>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $reqDate->format('m/d/Y') ?></td>
                                <?php }
                                if($log['PPAP_Req_by_Cus_Date'] == NULL) { ?>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                <?php } ?>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Current_Status']; ?></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Short_name']; ?></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Name']; ?></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Country']; ?></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['TUB_Customer_PN']; ?></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['ET_Model']; ?></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['ET_Dwg']; ?></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Rev']; ?></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['TUB_Eurotech_PN']; ?></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Description']; ?></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['IMDS_Number']; ?></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['IMDS_Status']; ?></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['PPAP_docs']; ?></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Level']; ?></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Samples_Status']; ?></td>
                                <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $log['Reason_submission']; ?></td>
                                <?php if($log['Sent_Customer'] != NULL) { 
                                    $sentCust = new DateTime($log['Sent_Customer']); ?>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $sentCust->format('m/d/Y') ?></td>
                                <?php }
                                if($log['Sent_Customer'] == NULL) { ?>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                <?php } 
                                if($log['PSW_Returned'] != NULL) { 
                                    $pswRet = new DateTime($log['PSW_Returned']); ?>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"><?php echo $pswRet->format('m/d/Y') ?></td>
                                <?php }
                                if($log['PSW_Returned'] == NULL) { ?>
                                    <td style="background-color: rgba(255, 235, 0, 0.7);"></td>
                                <?php } 
                            }
                        } 
                        else { ?>
                         <td 
                                    <?php if($log['Days to Submit'] <= 18) { ?>
                                        style="background-color: rgba(0, 255, 0, 0.7);"
                                    <?php } 
                                    if($log['Days to Submit'] >= 19 && $log['Days to Submit'] <= 30) { ?>
                                        style="background-color: rgba(255, 255, 26, 0.7);"
                                    <?php } 
                                    if($log['Days to Submit'] >= 31) { ?>
                                        style="background-color: rgba(204, 0, 34, 0.8); color:white;"
                                    <?php } ?>
                                ><?php echo $log['Days to Submit']; ?></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['PPAP_Number']; ?></td>
                                <?php if($log['PPAP_Req_by_Cus_Date'] != NULL) { 
                                    $reqDate = new DateTime($log['PPAP_Req_by_Cus_Date']); ?>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $reqDate->format('m/d/Y') ?></td>
                                <?php }
                                if($log['PPAP_Req_by_Cus_Date'] == NULL) { ?>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                <?php } ?>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Current_Status']; ?></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Short_name']; ?></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Name']; ?></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Country']; ?></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['TUB_Customer_PN']; ?></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['ET_Model']; ?></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['ET_Dwg']; ?></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Rev']; ?></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['TUB_Eurotech_PN']; ?></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Description']; ?></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['IMDS_Number']; ?></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['IMDS_Status']; ?></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['PPAP_docs']; ?></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Level']; ?></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Samples_Status']; ?></td>
                                <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $log['Reason_submission']; ?></td>
                                <?php if($log['Sent_Customer'] != NULL) { 
                                    $sentCust = new DateTime($log['Sent_Customer']); ?>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $sentCust->format('m/d/Y') ?></td>
                                <?php }
                                if($log['Sent_Customer'] == NULL) { ?>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                <?php } 
                                if($log['PSW_Returned'] != NULL) { 
                                    $pswRet = new DateTime($log['PSW_Returned']); ?>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"><?php echo $pswRet->format('m/d/Y') ?></td>
                                <?php }
                                if($log['PSW_Returned'] == NULL) { ?>
                                    <td style="background-color: rgba(0, 150, 255, 0.7);"></td>
                                <?php } ?>
                        <?php } 
                    } 
                    else { ?>
                        <td style="background-color: rgba(204, 0, 34, 0.8); color:white;"></td>
                                <td><?php echo $log['PPAP_Number']; ?></td>
                                <?php if($log['PPAP_Req_by_Cus_Date'] != NULL) { 
                                    $reqDate = new DateTime($log['PPAP_Req_by_Cus_Date']); ?>
                                    <td><?php echo $reqDate->format('m/d/Y') ?></td>
                                <?php }
                                if($log['PPAP_Req_by_Cus_Date'] == NULL) { ?>
                                    <td></td>
                                <?php } ?>
                                <td><?php echo $log['Current_Status']; ?></td>
                                <td><?php echo $log['Short_name']; ?></td>
                                <td><?php echo $log['Name']; ?></td>
                                <td><?php echo $log['Country']; ?></td>
                                <td><?php echo $log['TUB_Customer_PN']; ?></td>
                                <td><?php echo $log['ET_Model']; ?></td>
                                <td><?php echo $log['ET_Dwg']; ?></td>
                                <td><?php echo $log['Rev']; ?></td>
                                <td><?php echo $log['TUB_Eurotech_PN']; ?></td>
                                <td><?php echo $log['Description']; ?></td>
                                <td><?php echo $log['IMDS_Number']; ?></td>
                                <td><?php echo $log['IMDS_Status']; ?></td>
                                <td><?php echo $log['PPAP_docs']; ?></td>
                                <td><?php echo $log['Level']; ?></td>
                                <td><?php echo $log['Samples_Status']; ?></td>
                                <td><?php echo $log['Reason_submission']; ?></td>
                                <?php if($log['Sent_Customer'] != NULL) { 
                                    $sentCust = new DateTime($log['Sent_Customer']); ?>
                                    <td><?php echo $sentCust->format('m/d/Y') ?></td>
                                <?php }
                                if($log['Sent_Customer'] == NULL) { ?>
                                    <td></td>
                                <?php } 
                                if($log['PSW_Returned'] != NULL) { 
                                    $pswRet = new DateTime($log['PSW_Returned']); ?>
                                    <td><?php echo $pswRet->format('m/d/Y') ?></td>
                                <?php }
                                if($log['PSW_Returned'] == NULL) { ?>
                                    <td></td>
                                <?php } ?>
                                
                    <?php } ?>
                    <td><?php echo $log['Origin_from_report']; ?></td>
                    <td><?php echo $log['Comments']; ?></td>
                    <td><?php echo $log['Inspection_rep_numb']; ?></td>
                </tr> 
            <?php } ?>
        </table> 
    </div>
<?php } 

if (isset($_POST['insertD'])) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Register New PPAP</h2>
        <?php if (isset($error)) : ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>

        <form action="?page=Tubes" method="post">
            <input type="hidden" name="confirmID" value="1">
            <label>PPAP Req'd by Customer:</label>
            <input type="date" name="PPAP_Req_by_Cus_Date" value="<?php if(isset($_POST['PPAP_Req_by_Cus_Date'])) { echo $_POST['PPAP_Req_by_Cus_Date']; } ?>"> <br>

            <label>Current Status:</label>
            <input type="text" maxlength="255" name="Current_Status" list="Current" value="<?php if(isset($_POST['Current_Status'])) { echo $_POST['Current_Status']; } ?>"> <br>

            <label>Vendor:</label>
            <input type="text" maxlength="5" name="Short_name" list="PI" value="<?php if(isset($_POST['Short_name'])) { echo $_POST['Short_name']; } ?>"> <br>

            <label><label style="color:red">*</label> Customer:</label>
            <input type="text" maxlength="70" name="Name" list="Custs" value="<?php if(isset($_POST['Name'])) { echo $_POST['Name']; } ?>" required> <br>
            <datalist id="Custs">
                <?php foreach ($Custs as $Cust) {  ?>
                    <option value="<?php echo $Cust['Description'] ?>">
                <?php } ?>
            </datalist>

            <label>Country:</label>
            <input type="text" maxlength="30" name="Country" list="Country" value="<?php if(isset($_POST['Country'])) { echo $_POST['Country']; } ?>"> <br>

            <label><label style="color:red">*</label> Description:</label>
            <input type="text" maxlength="255" name="Description" list="Desc" value="<?php if(isset($_POST['Description'])) { echo $_POST['Description']; } ?>" required> <br>

            <label>Rev:</label>
            <input type="text" maxlength="5" name="Rev" list="Rev" value="<?php if(isset($_POST['Rev'])) { echo $_POST['Rev']; } ?>"> <br>

            <label>IMDS Number:</label>
            <input type="text" maxlength="15" name="IMDS_Number" list="IMDS" value="<?php if(isset($_POST['IMDS_Number'])) { echo $_POST['IMDS_Number']; } ?>"> <br>

            <label>IMDS Status:</label>
            <input type="text" maxlength="10" name="IMDS_Status" list="IS" value="<?php if(isset($_POST['IMDS_Status'])) { echo $_POST['IMDS_Status']; } ?>"> <br>

            <label>PPAP docs:</label>
            <input type="text" maxlength="15" name="PPAP_docs" list="PD" value="<?php if(isset($_POST['PPAP_docs'])) { echo $_POST['PPAP_docs']; } ?>"> <br>

            <label>Level:</label>
            <input type="text" maxlength="3" name="Level" list="Level" value="<?php if(isset($_POST['Level'])) { echo $_POST['Level']; } ?>"> <br>

            <label>PPAP samples status:</label>
            <input type="text" maxlength="9" name="Samples_Status" list="PSS" value="<?php if(isset($_POST['Samples_Status'])) { echo $_POST['Samples_Status']; } ?>"> <br>

            <label><label style="color:red">*</label> Reason of Submission:</label>
            <input type="text" maxlength="20" name="Reason_submission" list="RS" value="<?php if(isset($_POST['Reason_submission'])) { echo $_POST['Reason_submission']; } ?>" required> <br>

            <label>Sent to Customer:</label>
            <input type="date" name="Sent_Customer" value="<?php if(isset($_POST['Sent_Customer'])) { echo $_POST['Sent_Customer']; } ?>"> <br>

            <label>PSW returned from Cust Signed:</label>
            <input type="date" name="PSW_Returned" value="<?php if(isset($_POST['PSW_Returned'])) { echo $_POST['PSW_Returned']; } ?>"> <br>

            <label>Origin from report:</label required>
            <div>
                <input type="radio" name="Origin_from_report" value="no" <?php if(isset($_POST['Origin_from_report']) && $_POST['Origin_from_report'] == "no") { echo 'checked'; } ?> checked> No 
            </div>
            <div>
                <input type="radio" name="Origin_from_report" value="**" <?php if(isset($_POST['Origin_from_report']) && $_POST['Origin_from_report'] == "**") { echo 'checked'; } ?>> Yes 
            </div> <br>

            <label>Comments:</label>
            <textarea name="Comments" maxlength="255"><?php if(isset($_POST['Comments'])) { echo $_POST['Comments']; } ?></textarea> <br>

            <label>Inspection Report Number:</label>
            <input type="text" maxlength="10" name="Inspection_rep_numb" list="IRN" value="<?php if(isset($_POST['Inspection_rep_numb'])) { echo $_POST['Inspection_rep_numb']; } ?>">

            <button type="submit">Save</button>
        </form>
    </div>
    </div>
<?php }

if (isset($_POST['insertET'])) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Register New PPAP</h2>
        <?php if (isset($error)) : ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>

        <form action="?page=Tubes" method="post">
            <input type="hidden" name="confirmIE" value="1">
            <label>PPAP Req'd by Customer:</label>
            <input type="date" name="PPAP_Req_by_Cus_Date" value="<?php if(isset($_POST['PPAP_Req_by_Cus_Date'])) { echo $_POST['PPAP_Req_by_Cus_Date']; } ?>"> <br>

            <label>Current Status:</label>
            <input type="text" maxlength="255" name="Current_Status" list="Current" value="<?php if(isset($_POST['Current_Status'])) { echo $_POST['Current_Status']; } ?>"> <br>

            <label>Vendor:</label>
            <input type="text" maxlength="5" name="Short_name" list="PI" value="<?php if(isset($_POST['Short_name'])) { echo $_POST['Short_name']; } ?>"> <br>

            <label><label style="color:red">*</label> Customer:</label>
            <input type="text" maxlength="70" name="Name" list="Custs" value="<?php if(isset($_POST['Name'])) { echo $_POST['Name']; } ?>" required> <br>
            <datalist id="Custs">
                <?php foreach ($Custs as $Cust) {  ?>
                    <option value="<?php echo $Cust['Description'] ?>">
                <?php } ?>
            </datalist>

            <label>Country:</label>
            <input type="text" maxlength="30" name="Country" list="Country" value="<?php if(isset($_POST['Country'])) { echo $_POST['Country']; } ?>"> <br>

            <label><label style="color:red">*</label> Eurotech PN:</label>
            <input type="text" maxlength="10" name="TUB_Eurotech_PN" list="ETPN" value="<?php if(isset($_POST['TUB_Eurotech_PN'])) { echo $_POST['TUB_Eurotech_PN']; } ?>" required> <br>

            <label>Rev:</label>
            <input type="text" maxlength="5" name="Rev" list="Rev" value="<?php if(isset($_POST['Rev'])) { echo $_POST['Rev']; } ?>"> <br>

            <label>IMDS Number:</label>
            <input type="text" maxlength="15" name="IMDS_Number" list="IMDS" value="<?php if(isset($_POST['IMDS_Number'])) { echo $_POST['IMDS_Number']; } ?>"> <br>

            <label>IMDS Status:</label>
            <input type="text" maxlength="10" name="IMDS_Status" list="IS" value="<?php if(isset($_POST['IMDS_Status'])) { echo $_POST['IMDS_Status']; } ?>"> <br>

            <label>PPAP docs:</label>
            <input type="text" maxlength="15" name="PPAP_docs" list="PD" value="<?php if(isset($_POST['PPAP_docs'])) { echo $_POST['PPAP_docs']; } ?>"> <br>

            <label>Level:</label>
            <input type="text" maxlength="3" name="Level" list="Level" value="<?php if(isset($_POST['Level'])) { echo $_POST['Level']; } ?>"> <br>

            <label>PPAP samples status:</label>
            <input type="text" maxlength="9" name="Samples_Status" list="PSS" value="<?php if(isset($_POST['Samples_Status'])) { echo $_POST['Samples_Status']; } ?>"> <br>

            <label><label style="color:red">*</label> Reason of Submission:</label>
            <input type="text" maxlength="20" name="Reason_submission" list="RS" value="<?php if(isset($_POST['Reason_submission'])) { echo $_POST['Reason_submission']; } ?>" required> <br>

            <label>Sent to Customer:</label>
            <input type="date" name="Sent_Customer" value="<?php if(isset($_POST['Sent_Customer'])) { echo $_POST['Sent_Customer']; } ?>"> <br>

            <label>PSW returned from Cust Signed:</label>
            <input type="date" name="PSW_Returned" value="<?php if(isset($_POST['PSW_Returned'])) { echo $_POST['PSW_Returned']; } ?>"> <br>

            <label>Origin from report:</label required>
            <div>
                <input type="radio" name="Origin_from_report" value="no" <?php if(isset($_POST['Origin_from_report']) && $_POST['Origin_from_report'] == "no") { echo 'checked'; } ?> checked> No 
            </div>
            <div>
                <input type="radio" name="Origin_from_report" value="**" <?php if(isset($_POST['Origin_from_report']) && $_POST['Origin_from_report'] == "**") { echo 'checked'; } ?>> Yes 
            </div> <br>

            <label>Comments:</label>
            <textarea name="Comments" maxlength="255"><?php if(isset($_POST['Comments'])) { echo $_POST['Comments']; } ?></textarea> <br>

            <label>Inspection Report Number:</label>
            <input type="text" maxlength="10" name="Inspection_rep_numb" list="IRN" value="<?php if(isset($_POST['Inspection_rep_numb'])) { echo $_POST['Inspection_rep_numb']; } ?>">

            <button type="submit">Save</button>
        </form>
    </div>
    </div>
<?php }

if (isset($_POST['insertC'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New PPAP</h2>
    <?php if (isset($error)) : ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form action="?page=Tubes" method="post">
        <input type="hidden" name="confirmIC" value="1">
        <label>PPAP Req'd by Customer:</label>
        <input type="date" name="PPAP_Req_by_Cus_Date" value="<?php if(isset($_POST['PPAP_Req_by_Cus_Date'])) { echo $_POST['PPAP_Req_by_Cus_Date']; } ?>"> <br>

        <label>Current Status:</label>
        <input type="text" maxlength="255" name="Current_Status" list="Current" value="<?php if(isset($_POST['Current_Status'])) { echo $_POST['Current_Status']; } ?>"> <br>

        <label>Vendor:</label>
        <input type="text" maxlength="5" name="Short_name" list="PI" value="<?php if(isset($_POST['Short_name'])) { echo $_POST['Short_name']; } ?>"> <br>

        <label><label style="color:red">*</label> Customer:</label>
        <input type="text" maxlength="70" name="Name" list="Custs" value="<?php if(isset($_POST['Name'])) { echo $_POST['Name']; } ?>" required> <br>
        <datalist id="Custs">
            <?php foreach ($Custs as $Cust) {  ?>
                <option value="<?php echo $Cust['Description'] ?>">
            <?php } ?>
        </datalist>

        <label>Country:</label>
        <input type="text" maxlength="30" name="Country" list="Country" value="<?php if(isset($_POST['Country'])) { echo $_POST['Country']; } ?>"> <br>

        <label><label style="color:red">*</label> Customer PN:</label>
        <input type="text" maxlength="30" name="TUB_Customer_PN" list="CPN" value="<?php if(isset($_POST['TUB_Customer_PN'])) { echo $_POST['TUB_Customer_PN']; } ?>" required> <br>

        <label>Rev:</label>
        <input type="text" maxlength="5" name="Rev" list="Rev" value="<?php if(isset($_POST['Rev'])) { echo $_POST['Rev']; } ?>"> <br>

        <label>IMDS Number:</label>
        <input type="text" maxlength="15" name="IMDS_Number" list="IMDS" value="<?php if(isset($_POST['IMDS_Number'])) { echo $_POST['IMDS_Number']; } ?>"> <br>

        <label>IMDS Status:</label>
        <input type="text" maxlength="10" name="IMDS_Status" list="IS" value="<?php if(isset($_POST['IMDS_Status'])) { echo $_POST['IMDS_Status']; } ?>"> <br>

        <label>PPAP docs:</label>
        <input type="text" maxlength="15" name="PPAP_docs" list="PD" value="<?php if(isset($_POST['PPAP_docs'])) { echo $_POST['PPAP_docs']; } ?>"> <br>

        <label>Level:</label>
        <input type="text" maxlength="3" name="Level" list="Level" value="<?php if(isset($_POST['Level'])) { echo $_POST['Level']; } ?>"> <br>

        <label>PPAP samples status:</label>
        <input type="text" maxlength="9" name="Samples_Status" list="PSS" value="<?php if(isset($_POST['Samples_Status'])) { echo $_POST['Samples_Status']; } ?>"> <br>

        <label><label style="color:red">*</label> Reason of Submission:</label>
        <input type="text" maxlength="20" name="Reason_submission" list="RS" value="<?php if(isset($_POST['Reason_submission'])) { echo $_POST['Reason_submission']; } ?>" required> <br>

        <label>Sent to Customer:</label>
        <input type="date" name="Sent_Customer" value="<?php if(isset($_POST['Sent_Customer'])) { echo $_POST['Sent_Customer']; } ?>"> <br>

        <label>PSW returned from Cust Signed:</label>
        <input type="date" name="PSW_Returned" value="<?php if(isset($_POST['PSW_Returned'])) { echo $_POST['PSW_Returned']; } ?>"> <br>

        <label>Origin from report:</label required>
        <div>
            <input type="radio" name="Origin_from_report" value="no" <?php if(isset($_POST['Origin_from_report']) && $_POST['Origin_from_report'] == "no") { echo 'checked'; } ?> checked> No 
        </div>
        <div>
            <input type="radio" name="Origin_from_report" value="**" <?php if(isset($_POST['Origin_from_report']) && $_POST['Origin_from_report'] == "**") { echo 'checked'; } ?>> Yes 
        </div> <br>

        <label>Comments:</label>
        <textarea name="Comments" maxlength="255"><?php if(isset($_POST['Comments'])) { echo $_POST['Comments']; } ?></textarea> <br>

        <label>Inspection Report Number:</label>
        <input type="text" maxlength="10" name="Inspection_rep_numb" list="IRN" value="<?php if(isset($_POST['Inspection_rep_numb'])) { echo $_POST['Inspection_rep_numb']; } ?>">

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php }

if (isset($_POST['edit'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Update PPAP</h2>
    <?php if (isset($error)) : ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form action="?page=Tubes" method="post">
        <input type="hidden" name="confirmU" value="1">
        <input type="hidden" name="TUB_PPAPS_ID" value="<?php if(isset($_POST['TUB_PPAPS_ID'])) { echo $_POST['TUB_PPAPS_ID']; } else { echo $tubeData['TUB_PPAPS_ID']; } ?>">
        <input type="hidden" name="FK_PPAP_Number" value="<?php if(isset($_POST['FK_PPAP_Number'])) { echo $_POST['FK_PPAP_Number']; } else { echo $tubeData['FK_PPAP_Number']; } ?>">
        <label>PPAP Req'd by Customer:</label>
        <input type="date" name="PPAP_Req_by_Cus_Date" value="<?php if(isset($_POST['PPAP_Req_by_Cus_Date'])) { echo $_POST['PPAP_Req_by_Cus_Date']; } else { echo $tubeData['PPAP_Req_by_Cus_Date']; } ?>"> <br>

        <label>Current Status:</label>
        <input type="text" maxlength="255" name="Current_Status" list="Current" value="<?php if(isset($_POST['Current_Status'])) { echo $_POST['Current_Status']; } else { echo $tubeData['Current_Status']; } ?>"> <br>

        <label>Vendor:</label>
        <input type="text" maxlength="5" name="Short_name" list="PI" value="<?php if(isset($_POST['Short_name'])) { echo $_POST['Short_name']; } else { echo $tubeData['Short_name']; } ?>"> <br>

        <label>Country:</label>
        <input type="text" maxlength="30" name="Country" list="Country" value="<?php if(isset($_POST['Country'])) { echo $_POST['Country']; } else { echo $tubeData['Country']; } ?>"> <br>

        <label>Rev:</label>
        <input type="text" maxlength="5" name="Rev" list="Rev" value="<?php if(isset($_POST['Rev'])) { echo $_POST['Rev']; } else { echo $tubeData['Rev']; } ?>"> <br>

        <label>IMDS Number:</label>
        <input type="text" maxlength="15" name="IMDS_Number" list="IMDS" value="<?php if(isset($_POST['IMDS_Number'])) { echo $_POST['IMDS_Number']; } else { echo $tubeData['IMDS_Number']; } ?>"> <br>

        <label>IMDS Status:</label>
        <input type="text" maxlength="10" name="IMDS_Status" list="IS" value="<?php if(isset($_POST['IMDS_Status'])) { echo $_POST['IMDS_Status']; } else { echo $tubeData['IMDS_Status']; } ?>"> <br>

        <label>PPAP docs:</label>
        <input type="text" maxlength="15" name="PPAP_docs" list="PD" value="<?php if(isset($_POST['PPAP_docs'])) { echo $_POST['PPAP_docs']; } else { echo $tubeData['PPAP_docs']; } ?>"> <br>

        <label>Level:</label>
        <input type="text" maxlength="3" name="Level" list="Level" value="<?php if(isset($_POST['Level'])) { echo $_POST['Level']; } else { echo $tubeData['Level']; } ?>"> <br>

        <label>PPAP samples status:</label>
        <input type="text" maxlength="9" name="Samples_Status" list="PSS" value="<?php if(isset($_POST['Samples_Status'])) { echo $_POST['Samples_Status']; } else { echo $tubeData['Samples_Status']; } ?>"> <br>

        <label><label style="color:red">*</label> Reason of Submission:</label>
        <input type="text" maxlength="20" name="Reason_submission" list="RS" value="<?php if(isset($_POST['Reason_submission'])) { echo $_POST['Reason_submission']; } else { echo $tubeData['Reason_submission']; } ?>" required> <br>

        <label>Sent to Customer:</label>
        <input type="date" name="Sent_Customer" value="<?php if(isset($_POST['Sent_Customer'])) { echo $_POST['Sent_Customer']; } else { echo $tubeData['Sent_Customer']; } ?>"> <br>

        <label>PSW returned from Cust Signed:</label>
        <input type="date" name="PSW_Returned" value="<?php if(isset($_POST['PSW_Returned'])) { echo $_POST['PSW_Returned']; } else { echo $tubeData['PSW_Returned']; } ?>"> <br>

        <label>Origin from report:</label required>
        <div>
            <input type="radio" name="Origin_from_report" value="no" checked <?php 
                if(isset($_POST['Origin_from_report']) && $_POST['Origin_from_report'] == 'no') { echo 'checked'; }
                if(isset($tubeData['Origin_from_report'])) { if($tubeData['Origin_from_report'] == NULL) { echo 'checked';} }?>> No 
        </div>
        <div>
            <input type="radio" name="Origin_from_report" value="**" <?php 
                if(isset($_POST['Origin_from_report']) && $_POST['Origin_from_report'] == '**') { echo 'checked'; }
                if(isset($tubeData['Origin_from_report'])) { if($tubeData['Origin_from_report'] != NULL) { echo 'checked';} } ?>> Yes 
        </div> <br>

        <label>Comments:</label>
        <textarea name="Comments" maxlength="255"><?php if(isset($_POST['Comments'])) { echo $_POST['Comments']; } else { echo $tubeData['Comments']; } ?></textarea> <br>

        <label>Inspection Report Number:</label>
        <input type="text" maxlength="10" name="Inspection_rep_numb" list="IRN" value="<?php if(isset($_POST['Inspection_rep_numb'])) { echo $_POST['Inspection_rep_numb']; } else { echo $tubeData['Inspection_rep_numb']; } ?>">

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php }

if (isset($_POST['delete'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Delete PPAP</h2>
    <form action="?page=Tubes" method="post">
        <input type="hidden" name="confirmD" value="1">
        <input type="hidden" name="btnsearch" value="1">
        <input type="hidden" name="submit1search" value="<?php if(isset($_POST['submit1search'])) { echo $_POST['submit1search']; } ?>">
        <input type="hidden" name="submit2search" value="<?php if(isset($_POST['submit2search'])) { echo $_POST['submit2search']; } ?>">
        <input type="hidden" name="ppapnsearch" value="<?php if(isset($_POST['ppapnsearch'])) { echo $_POST['ppapnsearch']; } ?>">
        <input type="hidden" name="req1search" value="<?php if(isset($_POST['req1search'])) { echo $_POST['req1search']; } ?>">
        <input type="hidden" name="req2search" value="<?php if(isset($_POST['req2search'])) { echo $_POST['req2search']; } ?>">
        <input type="hidden" name="pisearch" value="<?php if(isset($_POST['pisearch'])) { echo $_POST['pisearch']; } ?>">
        <input type="hidden" name="custsearch" value="<?php if(isset($_POST['custsearch'])) { echo $_POST['custsearch']; } ?>">
        <input type="hidden" name="countrysearch" value="<?php if(isset($_POST['countrysearch'])) { echo $_POST['countrysearch']; } ?>">
        <input type="hidden" name="cpnsearch" value="<?php if(isset($_POST['cpnsearch'])) { echo $_POST['cpnsearch']; } ?>">
        <input type="hidden" name="etmsearch" value="<?php if(isset($_POST['etmsearch'])) { echo $_POST['etmsearch']; } ?>">
        <input type="hidden" name="etdsearch" value="<?php if(isset($_POST['etdsearch'])) { echo $_POST['etdsearch']; } ?>">
        <input type="hidden" name="revsearch" value="<?php if(isset($_POST['revsearch'])) { echo $_POST['revsearch']; } ?>">
        <input type="hidden" name="etpnsearch" value="<?php if(isset($_POST['etpnsearch'])) { echo $_POST['etpnsearch']; } ?>">
        <input type="hidden" name="descsearch" value="<?php if(isset($_POST['descsearch'])) { echo $_POST['descsearch']; } ?>">
        <input type="hidden" name="imdssearch" value="<?php if(isset($_POST['imdssearch'])) { echo $_POST['imdssearch']; } ?>">
        <input type="hidden" name="issearch" value="<?php if(isset($_POST['issearch'])) { echo $_POST['issearch']; } ?>">
        <input type="hidden" name="pdsearch" value="<?php if(isset($_POST['pdsearch'])) { echo $_POST['pdsearch']; } ?>">
        <input type="hidden" name="levelsearch" value="<?php if(isset($_POST['levelsearch'])) { echo $_POST['levelsearch']; } ?>">
        <input type="hidden" name="psssearch" value="<?php if(isset($_POST['psssearch'])) { echo $_POST['psssearch']; } ?>">
        <input type="hidden" name="rssearch" value="<?php if(isset($_POST['rssearch'])) { echo $_POST['rssearch']; } ?>">
        <input type="hidden" name="sent1search" value="<?php if(isset($_POST['sent1search'])) { echo $_POST['sent1search']; } ?>">
        <input type="hidden" name="sent2search" value="<?php if(isset($_POST['sent2search'])) { echo $_POST['sent2search']; } ?>">
        <input type="hidden" name="psw1search" value="<?php if(isset($_POST['psw1search'])) { echo $_POST['psw1search']; } ?>">
        <input type="hidden" name="psw2search" value="<?php if(isset($_POST['psw2search'])) { echo $_POST['psw2search']; } ?>">
        <input type="hidden" name="originsearch" value="<?php if(isset($_POST['originsearch'])) { echo $_POST['originsearch']; } ?>">
        <input type="hidden" name="comsearch" value="<?php if(isset($_POST['comsearch'])) { echo $_POST['comsearch']; } ?>">
        <input type="hidden" name="irnsearch" value="<?php if(isset($_POST['irnsearch'])) { echo $_POST['irnsearch']; } ?>">
        <input type="hidden" name="reqn" value="<?php if(isset($_POST['reqn'])) { echo $_POST['reqn']; } ?>">
        <input type="hidden" name="curn" value="<?php if(isset($_POST['curn'])) { echo $_POST['curn']; } ?>">
        <input type="hidden" name="imdn" value="<?php if(isset($_POST['imdn'])) { echo $_POST['imdn']; } ?>">
        <input type="hidden" name="imsn" value="<?php if(isset($_POST['imsn'])) { echo $_POST['imsn']; } ?>">
        <input type="hidden" name="ppdn" value="<?php if(isset($_POST['ppdn'])) { echo $_POST['ppdn']; } ?>">
        <input type="hidden" name="lvln" value="<?php if(isset($_POST['lvln'])) { echo $_POST['lvln']; } ?>">
        <input type="hidden" name="pssn" value="<?php if(isset($_POST['pssn'])) { echo $_POST['pssn']; } ?>">
        <input type="hidden" name="rosn" value="<?php if(isset($_POST['rosn'])) { echo $_POST['rosn']; } ?>">
        <input type="hidden" name="stcn" value="<?php if(isset($_POST['stcn'])) { echo $_POST['stcn']; } ?>">
        <input type="hidden" name="pcsn" value="<?php if(isset($_POST['pcsn'])) { echo $_POST['pcsn']; } ?>">
        <input type="hidden" name="IDdelete" value="<?php echo $_POST['IDdelete'] ?>" required>
        <?php 
            if($tubeDataD['PPAP_Req_by_Cus_Date'] != NULL) {
                $reqD = new DateTime($tubeDataD['PPAP_Req_by_Cus_Date']);
            }
            if($tubeDataD['Sent_Customer'] != NULL) {
                $senD = new DateTime($tubeDataD['Sent_Customer']);
            }
            if($tubeDataD['PSW_Returned'] != NULL) {
                $pswD = new DateTime($tubeDataD['PSW_Returned']);
            }
            
        ?>
        <h5><b>Are you sure you want to delete the data of this PPAP?</b></h5> <br>
        <h6><b>Days to Submit:</b> <?php echo $tubeDataD['Days to Submit'] ?></h6>
        <h6><b>PPAP Number:</b> <?php echo $tubeDataD['PPAP_Number'] ?></h6>
        <h6><b>PPAP Req'd by Customer:</b> <?php if($tubeDataD['PPAP_Req_by_Cus_Date'] != NULL) { echo $reqD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
        <h6><b>Current Status:</b> <?php echo $tubeDataD['Current_Status'] ?></h6>
        <h6><b>Vendor:</b> <?php echo $tubeDataD['Short_name'] ?></h6>
        <h6><b>Customer:</b> <?php echo $tubeDataD['Name'] ?></h6>
        <h6><b>Country:</b> <?php echo $tubeDataD['Country'] ?></h6>
        <h6><b>Customer PN:</b> <?php echo $tubeDataD['TUB_Customer_PN'] ?></h6>
        <h6><b>ET Model:</b> <?php echo $tubeDataD['ET_Model'] ?></h6>
        <h6><b>ET Dwg:</b> <?php echo $tubeDataD['ET_Dwg'] ?></h6>
        <h6><b>Rev:</b> <?php echo $tubeDataD['Rev'] ?></h6>
        <h6><b>ET PN:</b> <?php echo $tubeDataD['TUB_Eurotech_PN'] ?></h6>
        <h6><b>Description:</b> <?php echo $tubeDataD['Description'] ?></h6>
        <h6><b>IMDS Number:</b> <?php echo $tubeDataD['IMDS_Number'] ?></h6>
        <h6><b>IMDS Status:</b> <?php echo $tubeDataD['IMDS_Status'] ?></h6>
        <h6><b>PPAP docs:</b> <?php echo $tubeDataD['PPAP_docs'] ?></h6>
        <h6><b>Level:</b> <?php echo $tubeDataD['Level'] ?></h6>
        <h6><b>PPAP samples status:</b> <?php echo $tubeDataD['Samples_Status'] ?></h6>
        <h6><b>Reason of submission:</b> <?php echo $tubeDataD['Reason_submission'] ?></h6>
        <h6><b>Sent to Customer:</b> <?php if($tubeDataD['Sent_Customer'] != NULL) { echo $senD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
        <h6><b>PSW returned from Cust Signed:</b> <?php if($tubeDataD['PSW_Returned'] != NULL) { echo $pswD->format('m/d/Y'); } else { echo 'No date'; } ?></h6>
        <h6><b>Origin from report:</b> <?php if($tubeDataD['Origin_from_report'] != NULL) { echo 'Yes'; } else { echo 'No'; } ?></h6>
        <h6><b>Comments:</b> <?php echo $tubeDataD['Comments'] ?></h6>
        <h6><b>Inspection Report Number:</b> <?php echo $tubeDataD['Inspection_rep_numb'] ?></h6>
        <button type="submit">Confirm</button>
    </form>
  </div>
</div>
<?php } 

if ($Deleted != NULL) { ?>
    <div id="formularioModal" class="modal" style="display:block;">
    <div class="modal-contenido">
        <span class="cerrar" onclick="closeForm()">&times;</span>
        <h2>Register Deleted</h2>
        <form action="?page=Tubes" method="post">
            <h6><b>The register was deleted correctly.</b></h6>
        </form>
    </div>
    </div>
<?php } ?>

<script>
    function closeForm() {
        document.getElementById('formularioModal').style.display = 'none';
    }

    function sendForm() {
        closeForm();
        return true;
    }

    function clearForm() {
        document.querySelectorAll("#form input[type='text']").forEach(input => input.value = "");
        document.querySelectorAll("#form input[type='number']").forEach(input => input.value = "");
        document.querySelectorAll("#form input[type='date']").forEach(input => input.value = "");

        const radioButtons = document.querySelectorAll("#form input[type='radio']");
        const defaultValue = '';

        for (const radio of radioButtons) {
            if (radio.value === defaultValue) {
                radio.checked = true;
            }
        }
    }

    let sortOrder = {};

    function sortTable(columnIndex, type) {
        const table = document.getElementById("PPAP_table");
        const rows = Array.from(table.rows).slice(1);
        const isAscending = !sortOrder[columnIndex];
        const isNumeric = !isNaN(rows[0].cells[columnIndex].innerText);

        rows.sort((rowA, rowB) => {
            const cellA = rowA.cells[columnIndex].innerText.trim();
            const cellB = rowB.cells[columnIndex].innerText.trim();
            
            if (type === "date") {
                const dateA = new Date(cellA);
                const dateB = new Date(cellB);
                const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
                const dateformatedA = dateA.toLocaleDateString('ja-JP', options);
                const dateformatedB = dateB.toLocaleDateString('ja-JP', options);
                return isAscending ? dateformatedA.localeCompare(dateformatedB) : dateformatedB.localeCompare(dateformatedA);
            } else if (type === "text") {
                return isAscending ? cellA.localeCompare(cellB) : cellB.localeCompare(cellA);
            }
            else if (type === "number") {
                const cellA = rowA.cells[columnIndex].innerText.toLowerCase();
                const cellB = rowB.cells[columnIndex].innerText.toLowerCase();

                if (!isNaN(cellA) && !isNaN(cellB)) {
                return isAscending ? cellA - cellB : cellB - cellA; 
                }
                return isAscending
                ? cellA.localeCompare(cellB) 
                : cellB.localeCompare(cellA);
            }

        });

        rows.forEach(row => table.tBodies[0].appendChild(row));
        sortOrder[columnIndex] = isAscending;
    }
</script>