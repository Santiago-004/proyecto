<?php
header('Content-Type: application/json');

$connection = new mysqli("localhost", "root", "", "eurotechdb");
if ($connection->connect_error) {
    echo json_encode(["success" => false, "error" => "Connection Error"]);
    exit;
}

$Customer = $_POST['Customer'] ?? '';
$Country = $_POST['Country'] ?? '';
$Eurotech_PN = $_POST['Eurotech_PN'] ?? '';

if ($Customer !== '' && $Country !== '' && $Eurotech_PN !== '') {
    $stmt = $connection->prepare("
        SELECT Customer_PN
        FROM customer_pn cpn
        INNER JOIN customers c ON cpn.FK_Customer_ID = c.C_ID
        INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
        WHERE Name = ? AND Eurotech_PN = ? AND Country = ?
        LIMIT 1
    ");
    $stmt->bind_param("sss", $Customer, $Eurotech_PN, $Country);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($fila = $resultado->fetch_assoc()) {
        echo json_encode([
            "success" => true,
            "Customer_PN" => $fila['Customer_PN']
        ]);
    } else {
        echo json_encode(["success" => false]);
    }

    $stmt->close();
} 
if ($Customer !== '' && $Country == '' && $Eurotech_PN !== '') {
    $stmt = $connection->prepare("
        SELECT Customer_PN
        FROM customer_pn cpn
        INNER JOIN customers c ON cpn.FK_Customer_ID = c.C_ID
        INNER JOIN products p ON cpn.FK_Eurotech_PN = p.Eurotech_PN
        WHERE Name = ? AND Eurotech_PN = ? AND Country IS NULL
        LIMIT 1
    ");
    $stmt->bind_param("ss", $Customer, $Eurotech_PN);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($fila = $resultado->fetch_assoc()) {
        echo json_encode([
            "success" => true,
            "Customer_PN" => $fila['Customer_PN']
        ]);
    } else {
        echo json_encode(["success" => false]);
    }

    $stmt->close();
}

$connection->close();
?>