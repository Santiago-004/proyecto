<link href="./css/style.css" rel="stylesheet">
<style>
    .form-search .camp {
        flex: 1 1 20%;
        min-width: 250px;
    }

    .form-search input[type="date"],
    .form-search input[type="number"]{
        padding: 8px 10px;
        border: 1px solid #bbb;
        border-radius: 8px;
        box-sizing: border-box;
        width: 48%;
    }

    @media (max-width: 1604px) {
        .form-search input[type="date"],
        .form-search input[type="number"] {
            width: 47%;
        }
    }

    @media (max-width: 1453px) {
        .form-search .camp {
            flex: 1 1 30%; 
            min-width: 300px;
        }
    }

    @media (max-width: 1209px) {
        .form-search input[type="date"]{
            width: 47%;
        }
    }

    @media (max-width: 1005px) {
        .form-search .camp {
            flex: 1 1 30%; 
            min-width: 300px;
        }
    }
</style>
<form action="" method="post" class="form-search">
    <input type="hidden" name="page" value="Tubes">
    <div class="camp">
        <label>Days to Submit:</label>
        <input type="number" name="submit1search" value="<?php if ($submit1search != NULL) { echo $submit1search;} ?>"> -
        <input type="number" name="submit2search" value="<?php if ($submit2search != NULL) { echo $submit2search;} ?>">
    </div>
    
    <div class="camp">
        <label>PPAP Number:</label>
        <input type="text" name="ppapnsearch" list="PPAPN" value="<?php if ($ppapnsearch != NULL) { echo $ppapnsearch;} ?>">
        <datalist id="PPAPN">
            <?php foreach ($PPAPNS as $PPAPN) {  ?>
                <option value="<?php echo $PPAPN['PPAP_Number'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>PPAP Req'd by Customer:</label>
        <input type="date" name="req1search" value="<?php if ($req1search != NULL) { echo $req1search;} ?>"> - <input type="date" name="req2search" value="<?php if ($req2search != NULL) { echo $req2search;} ?>">
    </div>
    
    <div class="camp">
        <label>Current Status:</label>
        <input type="text" name="currentsearch" list="Current" value="<?php  if ($currentsearch != NULL) { echo $currentsearch;} ?>">
        <datalist id="Current">
            <?php foreach ($Currents as $Current) {  ?>
                <option value="<?php echo $Current['Current_Status'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>PPAP/IMDS from:</label>
        <input type="text" name="pisearch" list="PI" value="<?php if ($pisearch != NULL) { echo $pisearch;} ?>">
        <datalist id="PI">
            <?php foreach ($PIS as $PI) {  ?>
                <option value="<?php echo $PI['Vendor'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Customer:</label>
        <input type="text" name="custsearch" list="Customer" value="<?php if ($custsearch != NULL) { echo $custsearch;} ?>">
        <datalist id="Customer">
            <?php foreach ($Customers as $Customer) {  ?>
                <option value="<?php echo $Customer['Name'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Country:</label>
        <input type="text" name="countrysearch" list="Country" value="<?php if ($countrysearch != NULL) { echo $countrysearch;} ?>">
        <datalist id="Country">
            <?php foreach ($Countries as $Country) {  ?>
                <option value="<?php echo $Country['Country'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Customer PN:</label>
        <input type="text" name="cpnsearch" list="CPN" value="<?php if ($cpnsearch != NULL) { echo $cpnsearch;} ?>">
        <datalist id="CPN">
            <?php foreach ($CPNS as $CPN) {  ?>
                <option value="<?php echo $CPN['TUB_Customer_PN'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>ET Model:</label>
        <input type="text" name="etmsearch" list="ETM" value="<?php if ($etmsearch != NULL) { echo $etmsearch;} ?>">
        <datalist id="ETM">
            <?php foreach ($ETMS as $ETM) {  ?>
                <option value="<?php echo $ETM['ET_Model'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>ET Dwg:</label>
        <input type="text" name="etdsearch" list="ETD" value="<?php if ($etdsearch != NULL) { echo $etdsearch;} ?>">
        <datalist id="ETD">
            <?php foreach ($ETDS as $ETD) {  ?>
                <option value="<?php echo $ETD['ET_Dwg'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Rev:</label>
        <input type="number" name="revsearch" value="<?php if ($revsearch != NULL) { echo $revsearch;} ?>">
    </div>

    <div class="camp">
        <label>ET PN:</label>
        <input type="text" name="etpnsearch" list="ETPN" value="<?php if ($etpnsearch != NULL) { echo $etpnsearch;} ?>">
        <datalist id="ETPN">
            <?php foreach ($ETPNS as $ETPN) {  ?>
                <option value="<?php echo $ETPN['Eurotech_PN_TUB'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Description:</label>
        <input type="text" name="descsearch" list="Desc" value="<?php if ($descsearch != NULL) { echo $descsearch;} ?>">
        <datalist id="Desc">
            <?php foreach ($Descs as $Desc) {  ?>
                <option value="<?php echo $Desc['Description'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>IMDS Number:</label>
        <input type="text" name="imdssearch" list="IMDS" value="<?php if ($imdssearch != NULL) { echo $imdssearch;} ?>">
        <datalist id="IMDS">
            <?php foreach ($IMDS as $IM) {  ?>
                <option value="<?php echo $IM['IMDS_Number'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>IMDS Status:</label>
        <input type="text" name="issearch" list="IS" value="<?php if ($issearch != NULL) { echo $issearch;} ?>">
        <datalist id="IS">
            <?php foreach ($ISS as $IS) {  ?>
                <option value="<?php echo $IS['IMDS_Status'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>PPAP_do:</label>
        <input type="text" name="pdsearch" list="PD" value="<?php if ($pdsearch != NULL) { echo $pdsearch;} ?>">
        <datalist id="PD">
            <?php foreach ($PDS as $PD) {  ?>
                <option value="<?php echo $PD['PPAP_do'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Level:</label>
        <input type="text" name="levelsearch" list="Level" value="<?php if ($levelsearch != NULL) { echo $levelsearch;} ?>">
        <datalist id="Level">
            <?php foreach ($Levels as $Level) {  ?>
                <option value="<?php echo $Level['Level'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>PPAP samples status:</label>
        <input type="text" name="psssearch" list="PSS" value="<?php if ($psssearch != NULL) { echo $psssearch;} ?>">
        <datalist id="PSS">
            <?php foreach ($PSSS as $PSS) {  ?>
                <option value="<?php echo $PSS['Samples_Status'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Reason of Submission:</label>
        <input type="text" name="rssearch" list="RS" value="<?php if ($rssearch != NULL) { echo $rssearch;} ?>">
        <datalist id="RS">
            <?php foreach ($RSS as $RS) {  ?>
                <option value="<?php echo $RS['Reason_submission'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Sent to Customer:</label>
        <input type="date" name="sent1search" value="<?php if ($sent1search != NULL) { echo $sent1search;} ?>"> - <input type="date" name="sent2search" value="<?php if ($sent2search != NULL) { echo $sent2search;} ?>">
    </div>

    <div class="camp">
        <label>PSW returned from Customer Signed:</label>
        <input type="date" name="psw1search" value="<?php if ($psw1search != NULL) { echo $psw1search;} ?>"> - <input type="date" name="psw2search" value="<?php if ($psw2search != NULL) { echo $psw2search;} ?>">
    </div>
    
    <div class="camp">
        <label>Origin from report:</label>
        <input type="radio" name="originsearch" value="" checked> All <br>
        <input type="radio" name="originsearch" value="N" <?php if ($originsearch == "N") { echo "checked";} ?>> No <br>
        <input type="radio" name="originsearch" value="Y" <?php if ($originsearch == "Y") { echo "checked";} ?>> Yes
    </div>

    <div class="camp">
        <label>Comments:</label>
        <input type="text" name="comsearch" list="Com" value="<?php if ($comsearch != NULL) { echo $comsearch;} ?>">
        <datalist id="Com">
            <?php foreach ($Coms as $Com) {  ?>
                <option value="<?php echo $Com['Comments'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="camp">
        <label>Inspection Report Number:</label>
        <input type="text" name="irnsearch" list="IRN" value="<?php if ($irnsearch != NULL) { echo $irnsearch;} ?>">
        <datalist id="IRN">
            <?php foreach ($IRNS as $IRN) {  ?>
                <option value="<?php echo $IRN['Inspection_rep_numb'] ?>">
            <?php } ?>
        </datalist>
    </div>

    <div class="campbtn">
        <button type="submit" name="btnsearch" class="insert">Search</button>
    </div>
</form>

<div style="display: flex;">
    <form action="?page=Tubes" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insert" value="1">
        <button type="submit" class="insert">New PPAP (Description)</button>
    </form>

    <form action="?page=Tubes" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insertET" value="1">
        <button type="submit" class="insert">New PPAP (ET PN)</button>
    </form>

    <form action="?page=Tubes" method="post" style="margin: 0px 15px 0px 0px;">
        <input type="hidden" name="insertC" value="1">
        <button type="submit" class="insert">New PPAP (Cust PN)</button>
    </form>
</div>

<?php if($logs == NULL) { ?>
    <br>
    <h1>No results.</h1>
<?php } ?>

<?php if($logs != NULL) { ?>
    <div class="table-responsive">
        <table class="table table-bordered">
            <tr>    
                <th style="background-color:#1c18AA;"></th>
                <th style="background-color:#1c18AA;"></th>
                <th style="background-color:#1c18AA; color:white">Days to Submit</th>
                <th style="background-color:#1c18AA; color:white">PPAP Number</th>
                <th style="background-color:#1c18AA; color:white">PPAP Req'd by Customer</th>
                <th style="background-color:#1c18AA; color:white">Current Status</th>
                <th style="background-color:#1c18AA; color:white">PPAP/IMDS from</th>
                <th style="background-color:#1c18AA; color:white">Customer</th>
                <th style="background-color:#1c18AA; color:white">Country</th>
                <th style="background-color:#1c18AA; color:white">Customer PN</th>
                <th style="background-color:#1c18AA; color:white">ET Model</th>
                <th style="background-color:#1c18AA; color:white">ET Dwg</th>
                <th style="background-color:#1c18AA; color:white">Rev</th>
                <th style="background-color:#1c18AA; color:white">ET PN</th>
                <th style="background-color:#1c18AA; color:white">Description</th>
                <th style="background-color:#1c18AA; color:white">IMDS Number</th>
                <th style="background-color:#1c18AA; color:white">IMDS Status</th>
                <th style="background-color:#1c18AA; color:white">PPAP_do</th>
                <th style="background-color:#1c18AA; color:white">Level</th>
                <th style="background-color:#1c18AA; color:white">PPAP samples status</th>
                <th style="background-color:#1c18AA; color:white">Reason of Submission</th>
                <th style="background-color:#1c18AA; color:white">Sent to Customer</th>
                <th style="background-color:#1c18AA; color:white">PSW returned from Cust Signed</th>
                <th style="background-color:#1c18AA; color:white">Origin from report</th>
                <th style="background-color:#1c18AA; color:white">Comments</th>
                <th style="background-color:#1c18AA; color:white">Inspection Report Number</th>
            </tr>
            
            <?php foreach ($logs as $log) { ?>
                <tr>
                    <td>
                        <form action="?page=Tubes" method="post" style="display:inline;">
                            <input type="hidden" name="edit" value="">
                            <button type="submit" class="editar">Edit</button>
                        </form>
                    </td>
                    <td>
                        <form action="?page=Tubes" method="post" style="display:inline;">
                            <input type="hidden" name="delete" value="">
                            <button type="submit" class="eliminar">Delete</button>
                        </form>
                    </td>
                    <td 
                        <?php if($log['Days to Submit'] <= 18) { ?>
                            style="background-color:#00D900; color:black"
                        <?php } 
                        if($log['Days to Submit'] >= 19 && $log['Days to Submit'] <= 30) { ?>
                            style="background-color:#FFEE00; color:black"
                        <?php } 
                        if($log['Days to Submit'] >= 31) { ?>
                            style="background-color:#FF0000; color:white"
                        <?php } ?>
                    ><?php echo $log['Days to Submit']; ?></td>
                    <td><?php echo $log['PPAP_Number']; ?></td>
                    <?php if($log['PPAP_Req_by_Cus_Date'] != NULL) { 
                        $reqDate = new DateTime($log['PPAP_Req_by_Cus_Date']); ?>
                        <td><?php echo $reqDate->format('d/m/Y') ?></td>
                    <?php }
                    if($log['PPAP_Req_by_Cus_Date'] == NULL) { ?>
                        <td></td>
                    <?php } ?>
                    <td><?php echo $log['Current_Status']; ?></td>
                    <td><?php echo $log['Vendor']; ?></td>
                    <td><?php echo $log['Name']; ?></td>
                    <td><?php echo $log['Country']; ?></td>
                    <td><?php echo $log['TUB_Customer_PN']; ?></td>
                    <td><?php echo $log['ET_Model']; ?></td>
                    <td><?php echo $log['ET_Dwg']; ?></td>
                    <td><?php echo $log['Rev']; ?></td>
                    <td><?php echo $log['Eurotech_PN_TUB']; ?></td>
                    <td><?php echo $log['Description']; ?></td>
                    <td><?php echo $log['IMDS_Number']; ?></td>
                    <td><?php echo $log['IMDS_Status']; ?></td>
                    <td><?php echo $log['PPAP_do']; ?></td>
                    <td><?php echo $log['Level']; ?></td>
                    <td><?php echo $log['Samples_Status']; ?></td>
                    <td><?php echo $log['Reason_submission']; ?></td>
                    <?php if($log['Sent_Customer'] != NULL) { 
                        $sentCust = new DateTime($log['Sent_Customer']); ?>
                        <td><?php echo $sentCust->format('d/m/Y') ?></td>
                    <?php }
                    if($log['Sent_Customer'] == NULL) { ?>
                        <td></td>
                    <?php } 
                    if($log['PSW_Returned'] != NULL) { 
                        $pswRet = new DateTime($log['PSW_Returned']); ?>
                        <td><?php echo $pswRet->format('d/m/Y') ?></td>
                    <?php }
                    if($log['PSW_Returned'] == NULL) { ?>
                        <td></td>
                    <?php } ?>
                    <td><?php echo $log['Origin_from_report']; ?></td>
                    <td><?php echo $log['Comments']; ?></td>
                    <td><?php echo $log['Inspection_rep_numb']; ?></td>
                </tr> 
            <?php } ?>
        </table> 
    </div>
<?php } 

if (isset($_POST['insert'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New PPAP</h2>
    <form action="?page=Tubes" method="post">
        <input type="hidden" name="confirmI" value="1">
        <label>PPAP Number:</label>
        <input type="text" name="PPAP_Number" list="PPAPN" required>
        <datalist id="PPAPN">
            <?php /*foreach ($PPAPNS as $PPAPN) {  ?>
                <option value="<?php echo $PPAPN['PPAP_Number'] ?>">
            <?php }*/ ?>
        </datalist> <br>

        <label>PPAP Req'd by Customer:</label>
        <input type="date" name="PPAP_Req_by_Cus_Date" id=""> <br>

        <label>Current Status:</label>
        <input type="text" name="Current_Status" list="CS">
        <datalist id="CS">
            <?php /*foreach ($CSS as $CS) {  ?>
                <option value="<?php echo $CS['Current_Status'] ?>">
            <?php }*/ ?>
        </datalist> <br>

        <label>PPAP/IMDS from:</label>
        <input type="text" name="Vendor" list="Vendor">
        <datalist id="Vendor">
            <?php /*foreach ($Vendors as $Vendor) {  ?>
                <option value="<?php echo $Vendor['Vendor'] ?>">
            <?php }*/ ?>
        </datalist> <br>

        <label>Customer:</label>
        <input type="text" name="Name" list="Customer" required>
        <datalist id="Customer">
            <?php /* foreach ($Customers as $Customer) {  ?>
                <option value="<?php echo $Customer['Name'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Country:</label>
        <input type="text" name="Country" list="Country">
        <datalist id="Country">
            <?php /* foreach ($Countries as $Country) {  ?>
                <option value="<?php echo $Country['Country'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Description:</label>
        <input type="text" name="Description" list="Desc" required>
        <datalist id="Desc">
            <?php /*foreach ($Descs as $Desc) {  ?>
                <option value="<?php echo $Desc['Description'] ?>">
            <?php }*/ ?>
        </datalist> <br>

        <label>Rev:</label>
        <input type="text" name="Rev" list="Rev">
        <datalist id="Rev">
            <?php /* foreach ($Revs as $Rev) {  ?>
                <option value="<?php echo $Rev['Rev'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>IMDS Number:</label>
        <input type="text" name="IMDS_Number" list="IMDSN">
        <datalist id="IMDSN">
            <?php /* foreach ($IMDSNS as $IMDSN) {  ?>
                <option value="<?php echo $IMDSN['IMDS_Number'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>IMDS Status:</label>
        <input type="text" name="IMDS_Status" list="IMDSS">
        <datalist id="IMDSS">
            <?php /* foreach ($IMDSSS as $IMDSS) {  ?>
                <option value="<?php echo $IMDSS['IMDS_Status'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>PPAP do:</label>
        <input type="text" name="PPAP_do" list="PPAPD">
        <datalist id="PPAPD">
            <?php /* foreach ($PPAPDS as $PPAPD) {  ?>
                <option value="<?php echo $PPAPD['PPAP_do'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Level:</label>
        <input type="text" name="Level" list="Level">
        <datalist id="Level">
            <?php /* foreach ($Levels as $Level) {  ?>
                <option value="<?php echo $Level['Level'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>PPAP samples status:</label>
        <input type="text" name="Samples_Status" list="SS">
        <datalist id="SS">
            <?php /* foreach ($SSS as $SS) {  ?>
                <option value="<?php echo $SS['Samples_Status'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Reason of Submission:</label>
        <input type="text" name="Reason_submission" list="RS" required>
        <datalist id="RS">
            <?php /* foreach ($RSS as $RS) {  ?>
                <option value="<?php echo $RS['Reason_submission'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Sent to Customer:</label>
        <input type="date" name="Sent_Customer" id=""> <br>

        <label>PSW returned from Cust Signed:</label>
        <input type="date" name="PSW_Returned" id=""> <br>

        <label>Origin from report:</label required>
        <div>
            <input type="radio" name="Origin_from_report" value="no" checked> No 
        </div>
        <div>
            <input type="radio" name="Origin_from_report" value="*"> Yes 
        </div> <br>

        <label>Comments:</label>
        <textarea name="Comments" id=""></textarea> <br>

        <label>Inspection Report Number:</label>
        <input type="text" name="" list="">

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php }

if (isset($_POST['insertET'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New PPAP</h2>
    <form action="?page=Tubes" method="post">
        <input type="hidden" name="confirmI" value="1">
        <label>PPAP Number:</label>
        <input type="text" name="PPAP_Number" list="PPAPN" required>
        <datalist id="PPAPN">
            <?php /*foreach ($PPAPNS as $PPAPN) {  ?>
                <option value="<?php echo $PPAPN['PPAP_Number'] ?>">
            <?php }*/ ?>
        </datalist> <br>

        <label>PPAP Req'd by Customer:</label>
        <input type="date" name="PPAP_Req_by_Cus_Date" id=""> <br>

        <label>Current Status:</label>
        <input type="text" name="Current_Status" list="CS">
        <datalist id="CS">
            <?php /*foreach ($CSS as $CS) {  ?>
                <option value="<?php echo $CS['Current_Status'] ?>">
            <?php }*/ ?>
        </datalist> <br>

        <label>PPAP/IMDS from:</label>
        <input type="text" name="Vendor" list="Vendor">
        <datalist id="Vendor">
            <?php /*foreach ($Vendors as $Vendor) {  ?>
                <option value="<?php echo $Vendor['Vendor'] ?>">
            <?php }*/ ?>
        </datalist> <br>

        <label>Customer:</label>
        <input type="text" name="Name" list="Customer" required>
        <datalist id="Customer">
            <?php /* foreach ($Customers as $Customer) {  ?>
                <option value="<?php echo $Customer['Name'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Country:</label>
        <input type="text" name="Country" list="Country">
        <datalist id="Country">
            <?php /* foreach ($Countries as $Country) {  ?>
                <option value="<?php echo $Country['Country'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Eurotech PN:</label>
        <input type="text" name="Description" list="Desc" required>
        <datalist id="Desc">
            <?php /*foreach ($Descs as $Desc) {  ?>
                <option value="<?php echo $Desc['Description'] ?>">
            <?php }*/ ?>
        </datalist> <br>

        <label>Rev:</label>
        <input type="text" name="Rev" list="Rev">
        <datalist id="Rev">
            <?php /* foreach ($Revs as $Rev) {  ?>
                <option value="<?php echo $Rev['Rev'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>IMDS Number:</label>
        <input type="text" name="IMDS_Number" list="IMDSN">
        <datalist id="IMDSN">
            <?php /* foreach ($IMDSNS as $IMDSN) {  ?>
                <option value="<?php echo $IMDSN['IMDS_Number'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>IMDS Status:</label>
        <input type="text" name="IMDS_Status" list="IMDSS">
        <datalist id="IMDSS">
            <?php /* foreach ($IMDSSS as $IMDSS) {  ?>
                <option value="<?php echo $IMDSS['IMDS_Status'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>PPAP do:</label>
        <input type="text" name="PPAP_do" list="PPAPD">
        <datalist id="PPAPD">
            <?php /* foreach ($PPAPDS as $PPAPD) {  ?>
                <option value="<?php echo $PPAPD['PPAP_do'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Level:</label>
        <input type="text" name="Level" list="Level">
        <datalist id="Level">
            <?php /* foreach ($Levels as $Level) {  ?>
                <option value="<?php echo $Level['Level'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>PPAP samples status:</label>
        <input type="text" name="Samples_Status" list="SS">
        <datalist id="SS">
            <?php /* foreach ($SSS as $SS) {  ?>
                <option value="<?php echo $SS['Samples_Status'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Reason of Submission:</label>
        <input type="text" name="Reason_submission" list="RS" required>
        <datalist id="RS">
            <?php /* foreach ($RSS as $RS) {  ?>
                <option value="<?php echo $RS['Reason_submission'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Sent to Customer:</label>
        <input type="date" name="Sent_Customer" id=""> <br>

        <label>PSW returned from Cust Signed:</label>
        <input type="date" name="PSW_Returned" id=""> <br>

        <label>Origin from report:</label required>
        <div>
            <input type="radio" name="Origin_from_report" value="no" checked> No 
        </div>
        <div>
            <input type="radio" name="Origin_from_report" value="*"> Yes 
        </div> <br>

        <label>Comments:</label>
        <textarea name="Comments" id=""></textarea> <br>

        <label>Inspection Report Number:</label>
        <input type="text" name="" list="">

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php }

if (isset($_POST['insertC'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Register New PPAP</h2>
    <form action="?page=Tubes" method="post">
        <input type="hidden" name="confirmI" value="1">
        <label>PPAP Number:</label>
        <input type="text" name="PPAP_Number" list="PPAPN" required>
        <datalist id="PPAPN">
            <?php /*foreach ($PPAPNS as $PPAPN) {  ?>
                <option value="<?php echo $PPAPN['PPAP_Number'] ?>">
            <?php }*/ ?>
        </datalist> <br>

        <label>PPAP Req'd by Customer:</label>
        <input type="date" name="PPAP_Req_by_Cus_Date" id=""> <br>

        <label>Current Status:</label>
        <input type="text" name="Current_Status" list="CS">
        <datalist id="CS">
            <?php /*foreach ($CSS as $CS) {  ?>
                <option value="<?php echo $CS['Current_Status'] ?>">
            <?php }*/ ?>
        </datalist> <br>

        <label>PPAP/IMDS from:</label>
        <input type="text" name="Vendor" list="Vendor">
        <datalist id="Vendor">
            <?php /*foreach ($Vendors as $Vendor) {  ?>
                <option value="<?php echo $Vendor['Vendor'] ?>">
            <?php }*/ ?>
        </datalist> <br>

        <label>Customer PN:</label>
        <input type="text" name="Description" list="Desc" required>
        <datalist id="Desc">
            <?php /*foreach ($Descs as $Desc) {  ?>
                <option value="<?php echo $Desc['Description'] ?>">
            <?php }*/ ?>
        </datalist> <br>

        <label>Country:</label>
        <input type="text" name="Country" list="Country">
        <datalist id="Country">
            <?php /* foreach ($Countries as $Country) {  ?>
                <option value="<?php echo $Country['Country'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Rev:</label>
        <input type="text" name="Rev" list="Rev">
        <datalist id="Rev">
            <?php /* foreach ($Revs as $Rev) {  ?>
                <option value="<?php echo $Rev['Rev'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>IMDS Number:</label>
        <input type="text" name="IMDS_Number" list="IMDSN">
        <datalist id="IMDSN">
            <?php /* foreach ($IMDSNS as $IMDSN) {  ?>
                <option value="<?php echo $IMDSN['IMDS_Number'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>IMDS Status:</label>
        <input type="text" name="IMDS_Status" list="IMDSS">
        <datalist id="IMDSS">
            <?php /* foreach ($IMDSSS as $IMDSS) {  ?>
                <option value="<?php echo $IMDSS['IMDS_Status'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>PPAP do:</label>
        <input type="text" name="PPAP_do" list="PPAPD">
        <datalist id="PPAPD">
            <?php /* foreach ($PPAPDS as $PPAPD) {  ?>
                <option value="<?php echo $PPAPD['PPAP_do'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Level:</label>
        <input type="text" name="Level" list="Level">
        <datalist id="Level">
            <?php /* foreach ($Levels as $Level) {  ?>
                <option value="<?php echo $Level['Level'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>PPAP samples status:</label>
        <input type="text" name="Samples_Status" list="SS">
        <datalist id="SS">
            <?php /* foreach ($SSS as $SS) {  ?>
                <option value="<?php echo $SS['Samples_Status'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Reason of Submission:</label>
        <input type="text" name="Reason_submission" list="RS" required>
        <datalist id="RS">
            <?php /* foreach ($RSS as $RS) {  ?>
                <option value="<?php echo $RS['Reason_submission'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Sent to Customer:</label>
        <input type="date" name="Sent_Customer" id=""> <br>

        <label>PSW returned from Cust Signed:</label>
        <input type="date" name="PSW_Returned" id=""> <br>

        <label>Origin from report:</label required>
        <div>
            <input type="radio" name="Origin_from_report" value="no" checked> No 
        </div>
        <div>
            <input type="radio" name="Origin_from_report" value="*"> Yes 
        </div> <br>

        <label>Comments:</label>
        <textarea name="Comments" id=""></textarea> <br>

        <label>Inspection Report Number:</label>
        <input type="text" name="" list="">

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php }

if (isset($_POST['edit'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Update PPAP</h2>
    <form action="?page=Tubes" method="post">
        <input type="hidden" name="confirmU" value="1">
        <label>PPAP Req'd by Customer:</label>
        <input type="date" name="PPAP_Req_by_Cus_Date" id=""> <br>

        <label>Current Status:</label>
        <input type="text" name="Current_Status" list="CS">
        <datalist id="CS">
            <?php /*foreach ($CSS as $CS) {  ?>
                <option value="<?php echo $CS['Current_Status'] ?>">
            <?php }*/ ?>
        </datalist> <br>

        <label>PPAP/IMDS from:</label>
        <input type="text" name="Vendor" list="Vendor">
        <datalist id="Vendor">
            <?php /*foreach ($Vendors as $Vendor) {  ?>
                <option value="<?php echo $Vendor['Vendor'] ?>">
            <?php }*/ ?>
        </datalist> <br>

        <label>Rev:</label>
        <input type="text" name="Rev" list="Rev">
        <datalist id="Rev">
            <?php /* foreach ($Revs as $Rev) {  ?>
                <option value="<?php echo $Rev['Rev'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>IMDS Number:</label>
        <input type="text" name="IMDS_Number" list="IMDSN">
        <datalist id="IMDSN">
            <?php /* foreach ($IMDSNS as $IMDSN) {  ?>
                <option value="<?php echo $IMDSN['IMDS_Number'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>IMDS Status:</label>
        <input type="text" name="IMDS_Status" list="IMDSS">
        <datalist id="IMDSS">
            <?php /* foreach ($IMDSSS as $IMDSS) {  ?>
                <option value="<?php echo $IMDSS['IMDS_Status'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>PPAP do:</label>
        <input type="text" name="PPAP_do" list="PPAPD">
        <datalist id="PPAPD">
            <?php /* foreach ($PPAPDS as $PPAPD) {  ?>
                <option value="<?php echo $PPAPD['PPAP_do'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Level:</label>
        <input type="text" name="Level" list="Level">
        <datalist id="Level">
            <?php /* foreach ($Levels as $Level) {  ?>
                <option value="<?php echo $Level['Level'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>PPAP samples status:</label>
        <input type="text" name="Samples_Status" list="SS">
        <datalist id="SS">
            <?php /* foreach ($SSS as $SS) {  ?>
                <option value="<?php echo $SS['Samples_Status'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Reason of Submission:</label>
        <input type="text" name="Reason_submission" list="RS" required>
        <datalist id="RS">
            <?php /* foreach ($RSS as $RS) {  ?>
                <option value="<?php echo $RS['Reason_submission'] ?>">
            <?php } */?>
        </datalist> <br>

        <label>Sent to Customer:</label>
        <input type="date" name="Sent_Customer" id=""> <br>

        <label>PSW returned from Cust Signed:</label>
        <input type="date" name="PSW_Returned" id=""> <br>

        <label>Origin from report:</label required>
        <div>
            <input type="radio" name="Origin_from_report" value="no" checked> No 
        </div>
        <div>
            <input type="radio" name="Origin_from_report" value="*"> Yes 
        </div> <br>

        <label>Comments:</label>
        <textarea name="Comments" id=""></textarea> <br>

        <label>Inspection Report Number:</label>
        <input type="text" name="" list="">

        <button type="submit">Save</button>
    </form>
  </div>
</div>
<?php }

if (isset($_POST['delete'])) { ?>
<div id="formularioModal" class="modal" style="display:block;">
  <div class="modal-contenido">
    <span class="cerrar" onclick="closeForm()">&times;</span>
    <h2>Delete PPAP</h2>
    <form action="?page=Tubes" method="post">
        <input type="hidden" name="confirmD" value="1">
        <!-- <input type="hidden" name="id_animal" value="<?php // $_POST['eliminar'] ?>" required> <br> -->
        <h5>Are you sure you want to delete the data of this PPAP?</h5> <br>
        <h6>Days to Submit : ...</h6>
        <h6>PPAP Number : ...</h6>
        <h6>PPAP Req'd by Customer : ...</h6>
        <h6>Current Status : ...</h6>
        <h6>PPAP/IMDS from : ...</h6>
        <h6>Customer : ...</h6>
        <h6>Country : ...</h6>
        <h6>Customer PN : ...</h6>
        <h6>ET Model : ...</h6>
        <h6>ET Dwg : ...</h6>
        <h6>Rev : ...</h6>
        <h6>ET PN : ...</h6>
        <h6>Description : ...</h6>
        <h6>IMDS Number : ...</h6>
        <h6>IMDS Status : ...</h6>
        <h6>PPAP do : ...</h6>
        <h6>Level : ...</h6>
        <h6>PPAP samples status : ...</h6>
        <h6>Reason of submission : ...</h6>
        <h6>Sent to Customer : ...</h6>
        <h6>PSW returned from Cust Signed : ...</h6>
        <h6> Origin from report : ...</h6>
        <h6> Comments : ...</h6>
        <h6> Inspection Report Number : ...</h6>
        <button type="submit">Confirm</button>
    </form>
  </div>
</div>
<?php } ?>

<script>
    function closeForm() {
        document.getElementById('formularioModal').style.display = 'none';
    }

    function sendForm() {
        closeForm();
        return true;
    }
</script>